package baird.LiquidOffice.TestSuite;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInfo;
import org.springframework.util.Assert;

import baird.LiquidOffice.Automation.BusinessLayer.CTAjournalFormTestLogic;

/**
 * @author AmitaKumari
 */

public class CTAjournalIRATests extends TestBase {

	CTAjournalFormTestLogic TestLogic = null;

	@BeforeEach
	public void TestInitialize(TestInfo info) {
		log.LogDebug(info.getDisplayName());
		TestLogic = new CTAjournalFormTestLogic(commonapi, testSettings);
	}

	void NavigateToJournalFormPage() throws Exception {
		TestLogic.OpenCTApage("SignIn");
		TestLogic.GetClientInfo("86997083", "Journal Request");
		TestLogic.ClickContinueOnClientInfo();
	}

	void NavigateToJournalFormPageMMF() throws Exception {
		TestLogic.OpenCTApage("SignIn");
		TestLogic.GetClientInfo("16869265", "Journal Request");
		TestLogic.ClickContinueOnClientInfo();
	}

	void NavigateToJournalFormSecurity() throws Exception {
		TestLogic.OpenCTApage("SignIn");
		TestLogic.GetClientInfo("10099999", "Journal Request");
		TestLogic.ClickContinueOnClientInfo();
	}

	void NavigateToJournalFormNoCash() throws Exception {
		TestLogic.OpenCTApage("SignIn");
		TestLogic.GetClientInfo("48616390", "Journal Request");
		TestLogic.ClickContinueOnClientInfo();
	}

	// Test Case 1
	@Test
	public void VerifyIRAJournalFormOpeningTest() throws Exception {
		try {
			NavigateToJournalFormPageMMF();
			Assert.isTrue(TestLogic.VerifyJournalInfoTitle(), "Journal Information Title Verified");
			reporter.LogSuccess("VerifyIRAJournalFormOpeningTest", "Journal Information Title Verified");
		} catch (Exception e) {
			reporter.LogFail("VerifyIRAJournalFormOpeningTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 2
	@Test
	public void VerifyWarningPopUpForTypeAIRATest() throws Exception {
		try {
			NavigateToJournalFormPage();
			Assert.isTrue(
					TestLogic.VerifyWarningPopUpForTypeA("48616390", "A",
							"The from-account and to-account owner's TaxID does not match."),
					"Error Pop Verified For Beneficiary Type A");
			reporter.LogSuccess("VerifyWarningPopUpForTypeAIRATest", "Error Pop Verified For Beneficiary Type A");
		} catch (Exception e) {
			reporter.LogFail("VerifyWarningPopUpForTypeAIRATest", e.getMessage());
			throw e;
		}
	}

	// Test Case 3
	@Test
	public void VerifyTotalfromAllSelectionsIRATest() throws Exception {
		try {
			NavigateToJournalFormPage();
			Assert.isTrue(TestLogic.VerifyTotalfromAllSelections("48616390", "B", "2"),
					"Total from All Selections Verified");
			reporter.LogSuccess("VerifyTotalfromAllSelectionsTest", "Total from All Selections Verified");
		} catch (Exception e) {
			reporter.LogFail("VerifyTotalfromAllSelectionsTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 4
	@Test
	public void VerifyTransferDescIRATest() throws Exception {
		try {
			NavigateToJournalFormPageMMF();
			Assert.isTrue(TestLogic.VerifyTransferDescIRA("48616390"), "Transfer Description Verified For IRA");
			reporter.LogSuccess("VerifyTransferDescIRATest", "Transfer Description Verified For IRA");
		} catch (Exception e) {
			reporter.LogFail("VerifyTransferDescIRATest", e.getMessage());
			throw e;
		}
	}

	// Test Case 5
	@Test
	public void VerifyTotalfromAllPositionsIRATest() throws Exception {
		try {
			NavigateToJournalFormPage();
			Assert.isTrue(TestLogic.VerifyTotalfromPositions("48616390", "B", "2"),
					"Total from All Positions Verified");
			reporter.LogSuccess("VerifyTotalfromAllPositionsIRATest", "Total from All Positions Verified");
		} catch (Exception e) {
			reporter.LogFail("VerifyTotalfromAllPositionsIRATest", e.getMessage());
			throw e;
		}
	}

	// Test Case 6
	@Test
	public void VerifyIRAaccInfoPageTest() throws Exception {
		try {
			NavigateToJournalFormPageMMF();
			Assert.isTrue(TestLogic.VerifyIRAaccInfoTitle("48616390", "B", "2"),
					"IRA Account Information Page Opening Verified");
			reporter.LogSuccess("VerifyIRAaccInfoPageTest", "IRA Account Information Page Opening Verified");
		} catch (Exception e) {
			reporter.LogFail("VerifyIRAaccInfoPageTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 7
	@Test
	public void VerifyIRATypeFieldTest() throws Exception {
		try {
			NavigateToJournalFormPageMMF();
			Assert.isTrue(TestLogic.VerifyIRATypeField("48616390", "B", "2"), "IRA Type Field Verified");
			reporter.LogSuccess("VerifyIRATypeFieldTest", "IRA Type Field Verified");
		} catch (Exception e) {
			reporter.LogFail("VerifyIRATypeFieldTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 8
	@Test
	public void VerifyWarningPopUpDepositCodeTest() throws Exception {
		try {
			NavigateToJournalFormPageMMF();
			Assert.isTrue(
					TestLogic.VerifyIRADepositWithdrawalCodeWarningPopUp("48616390", "B", "2", "WDRO", "",
							"The following information is missing:"),
					"Error Pop Verified When Deposit Code Is Not Selected");
			reporter.LogSuccess("VerifyWarningPopUpDepositCodeTest",
					"Error Pop Verified When Deposit Code Is Not Selected");
		} catch (Exception e) {
			reporter.LogFail("VerifyWarningPopUpDepositCodeTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 9
	@Test
	public void VerifyWarningPopUpDistributionFormTest() throws Exception {
		try {
			NavigateToJournalFormPageMMF();
			Assert.isTrue(
					TestLogic.VerifyIRADistributionFormWarningPopUp("48616390", "B", "2", "WDRO", "DDRO",
							"The following information is missing:"),
					"Error Pop Verified When Distribution Form Is Not Selected");
			reporter.LogSuccess("VerifyWarningPopUpDistributionFormTest",
					"Error Pop Verified When Distribution Form Is Not Selected");
		} catch (Exception e) {
			reporter.LogFail("VerifyWarningPopUpDistributionFormTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 10
	@Test
	public void VerifyWarningPopUpWithdrawalCodeTest() throws Exception {
		try {
			NavigateToJournalFormPageMMF();
			Assert.isTrue(
					TestLogic.VerifyIRADepositWithdrawalCodeWarningPopUp("48616390", "B", "2", "", "DDRO",
							"The following information is missing:"),
					"Error Pop Verified When Withdrawal Code Is Not Selected");
			reporter.LogSuccess("VerifyWarningPopUpNoContributionTypeTest",
					"Error Pop Verified When Withdrawal Code Is Not Selected");
		} catch (Exception e) {
			reporter.LogFail("VerifyWarningPopUpNoContributionTypeTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 11
	@Test
	public void VerifyAccNoOnIRAAccInfoPageTest() throws Exception {
		try {
			NavigateToJournalFormPageMMF();
			Assert.isTrue(TestLogic.VerifyAccNoOnIRAAccInfoPage("48616390", "B", "2"), "IRA Type Field Verified");
			reporter.LogSuccess("VerifyAccNoOnIRAAccInfoPageTest", "IRA Type Field Verified");
		} catch (Exception e) {
			reporter.LogFail("VerifyAccNoOnIRAAccInfoPageTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 12
	@Test
	public void VerifyIRAJournalFormSubmitTypeBTest() throws Exception {
		try {
			NavigateToJournalFormPageMMF();
			TestLogic.VerifyJournalFormSubmitIRATypeB_C_D_E("48616390", "B", "1", "WDRO", "DDRO");
			reporter.LogSuccess("VerifyIRAJournalFormSubmitTypeBTest",
					"Successfully IRA Journal Request Submission With Type B Beneficiary");
		} catch (Exception e) {
			reporter.LogFail("VerifyIRAJournalFormSubmitTypeBTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 13
	@Test
	public void VerifyIRAJournalFormSubmitTypeCTest() throws Exception {
		try {
			NavigateToJournalFormPageMMF();
			TestLogic.VerifyJournalFormSubmitIRATypeB_C_D_E("48616390", "C", "1.5", "WDRO", "DDRO");
			reporter.LogSuccess("VerifyIRAJournalFormSubmitTypeCTest",
					"Successfully IRA Journal Request Submission With Type C Beneficiary");
		} catch (Exception e) {
			reporter.LogFail("VerifyIRAJournalFormSubmitTypeCTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 14
	@Test
	public void VerifyIRAJournalFormSubmitTypeDTest() throws Exception {
		try {
			NavigateToJournalFormPageMMF();
			TestLogic.VerifyJournalFormSubmitIRATypeB_C_D_E("48616390", "D", "2", "WDRO", "DDRO");
			reporter.LogSuccess("VerifyIRAJournalFormSubmitTypeDTest",
					"Successfully IRA Journal Request Submission With Type D Beneficiary");
		} catch (Exception e) {
			reporter.LogFail("VerifyIRAJournalFormSubmitTypeDTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 15
	@Test
	public void VerifyIRAJournalFormSubmitTypeETest() throws Exception {
		try {
			NavigateToJournalFormPageMMF();
			TestLogic.VerifyJournalFormSubmitIRATypeB_C_D_E("48616390", "E", "2.5", "WDRO", "DDRO");
			reporter.LogSuccess("VerifyIRAJournalFormSubmitTypeETest",
					"Successfully IRA Journal Request Submission With Type E Beneficiary");
		} catch (Exception e) {
			reporter.LogFail("VerifyIRAJournalFormSubmitTypeETest", e.getMessage());
			throw e;
		}
	}

	// Test Case 16
	@Test
	public void VerifyWarningPopUpForIRATypeATest() throws Exception {
		try {
			NavigateToJournalFormPage();
			Assert.isTrue(
					TestLogic.VerifyWarningPopUpForTypeA("48616390", "A",
							"The from-account and to-account owner's TaxID does not match."),
					"Error Pop Verified For Beneficiary Type A");
			reporter.LogSuccess("VerifyWarningPopUpForTypeATest", "Error Pop Verified For Beneficiary Type A");
		} catch (Exception e) {
			reporter.LogFail("VerifyWarningPopUpForTypeATest", e.getMessage());
			throw e;
		}
	}

	// Test Case 17
	@Test
	public void VerifyTransferDescIRAtoIRATest() throws Exception {
		try {
			NavigateToJournalFormPage();
			Assert.isTrue(TestLogic.VerifyTransferDescIRAtoIRA("16869265"), "Transfer Description Verified For IRA");
			reporter.LogSuccess("VerifyTransferDescIRAtoIRATest", "Transfer Description Verified For IRA");
		} catch (Exception e) {
			reporter.LogFail("VerifyTransferDescIRAtoIRATest", e.getMessage());
			throw e;
		}
	}

	// Test Case 18
	@Test
	public void VerifyWarningPopUpWithoutTransferDateIRATest() throws Exception {
		try {
			NavigateToJournalFormPage();
			Assert.isTrue(
					TestLogic.VerifyTransferDateForFutureDate("The transfer date must be in the same calendar year."),
					"Warning PopUp Verified When Journal Transfer Date Is Cleared Out For IRA Account");
			reporter.LogSuccess("VerifyWarningPopUpWithoutTransferDateIRATest",
					"Warning PopUp Verified When Journal Transfer Date Is Cleared Out");
		} catch (Exception e) {
			reporter.LogFail("VerifyWarningPopUpWithoutTransferDateIRATest", e.getMessage());
			throw e;
		}
	}

	// Test Case 19
	@Test
	public void VerifyJournalFormSubmitIRATypeATest() throws Exception {
		try {
			NavigateToJournalFormPage();
			TestLogic.VerifyJournalFormSubmitTypeA("57523032", "3");
			reporter.LogSuccess("VerifyJournalFormSubmitIRATypeATest",
					"Successfully Journal Request Submission With Type A Beneficiary");
		} catch (Exception e) {
			reporter.LogFail("VerifyJournalFormSubmitIRATypeATest", e.getMessage());
			throw e;
		}
	}

	// Test Case 20
	@Test
	public void VerifyTransferDescIRACommingleTest() throws Exception {
		try {
			NavigateToJournalFormPage();
			Assert.isTrue(TestLogic.VerifyTransferDescIRACommingle("57523032"),
					"Transfer Description Verified For IRA TypeA Beneficiary");
			reporter.LogSuccess("VerifyTransferDescIRACommingleTest",
					"Transfer Description Verified For IRA TypeA Beneficiary");
		} catch (Exception e) {
			reporter.LogFail("VerifyTransferDescIRACommingleTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 21
	@Test
	public void VerifyIRAJournalFormSubmitWithSLOATest() throws Exception {
		try {
			NavigateToJournalFormPageMMF();
			TestLogic.VerifyJournalFormSubmitWithSLOA("48616390", "E", "Amita", "3.5", "WDRO", "DDRO");
			reporter.LogSuccess("VerifyIRAJournalFormSubmitWithSLOATest",
					"Successfully IRA Journal Request Submission With SLOA");
		} catch (Exception e) {
			reporter.LogFail("VerifyIRAJournalFormSubmitWithSLOATest", e.getMessage());
			throw e;
		}
	}

	// Test Case 22
	@Test
	public void VerifyIRAJournalFormSubmitTypeBSecurityTest() throws Exception {
		try {
			NavigateToJournalFormSecurity();
			TestLogic.VerifyJournalFormSubmitTypeBSecurities("74116970", "B", "1", "WDRO", "DDRO");
			reporter.LogSuccess("VerifyIRAJournalFormSubmitTypeBSecurityTest",
					"Successfully IRA Journal Request Submission With Partial Security");
		} catch (Exception e) {
			reporter.LogFail("VerifyIRAJournalFormSubmitTypeBSecurityTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 23
	@Test
	public void VerifyIRAJournalFormSubmitTypeDSecurityTest() throws Exception {
		try {
			NavigateToJournalFormSecurity();
			TestLogic.VerifyJournalFormSubmitTypeDSecurities("74116970", "D", "WDRO", "DDRO");
			reporter.LogSuccess("VerifyIRAJournalFormSubmitTypeBSecurityTest",
					"Successfully IRA Journal Request Submission With All Securities");
		} catch (Exception e) {
			reporter.LogFail("VerifyIRAJournalFormSubmitTypeBSecurityTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 24
	@Test
	public void VerifyIRATotalfromValuationsTypeFullTest() throws Exception {
		try {
			NavigateToJournalFormPage();
			Assert.isTrue(TestLogic.VerifyTotalfromValuationsTransferTypeFull("74116970"),
					"Total from Valuations Verified");
			reporter.LogSuccess("VerifyIRATotalfromValuationsTypeFullTest",
					"Total from Valuations Verified When Transfer Type Is Full");
		} catch (Exception e) {
			reporter.LogFail("VerifyIRATotalfromValuationsTypeFullTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 25
	@Test
	public void VerifyIRATotalfromValuationsTypeFullTypeATest() throws Exception {
		try {
			NavigateToJournalFormPage();
			Assert.isTrue(TestLogic.VerifyTotalfromValuationsTransferTypeFull("57523032"),
					"Total from Valuations Verified");
			reporter.LogSuccess("VerifyIRATotalfromValuationsTypeFullTypeATest",
					"Total from Valuations Verified When Transfer Type Is Full");
		} catch (Exception e) {
			reporter.LogFail("VerifyIRATotalfromValuationsTypeFullTypeATest", e.getMessage());
			throw e;
		}
	}

	// Test Case 26
	@Test
	public void VerifyJournalWarningPopUpNoCashTest() throws Exception {
		try {
			NavigateToJournalFormNoCash();
			Assert.isTrue(TestLogic.VerifyJournalWarningPopUpNoGiftforTax("74116970", "B", "1",
					"If you would like to sumbit a full transfer, please submit an Advisory Workflow Termination process."),
					"Error PopUp Verified When Account Has No Cash");
			reporter.LogSuccess("VerifyJournalWarningPopUpNoCashTest", "Error PopUp Verified When Account Has No Cash");
		} catch (Exception e) {
			reporter.LogFail("VerifyJournalWarningPopUpNoCashTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 27
	@Test
	public void VerifyJournalWarningPopWhenNoAttachmentIRATest() throws Exception {
		try {
			NavigateToJournalFormPageMMF();
			Assert.isTrue(
					TestLogic.VerifyJournalWarningPopWhenNoAttachmentIRA("74116970", "B", "4", "WDRO", "DDRO",
							"There is 1 attachment required."),
					"Error PopUp Verified For No Attachment For an IRA Account");
			reporter.LogSuccess("VerifyJournalWarningPopWhenNoAttachmentIRATest",
					"Error PopUp Verified For No Attachment For an IRA Account");
		} catch (Exception e) {
			reporter.LogFail("VerifyJournalWarningPopWhenNoAttachmentIRATest", e.getMessage());
			throw e;
		}
	}

	// Test Case 28
	@Test
	public void VerifyJournalFormSubmitNoAdvisoryIRATest() throws Exception {
		try {
			NavigateToJournalFormPageMMF();
			Assert.isTrue(TestLogic.VerifyJournalFormSubmitNoAdvisoryIRA("74116970", "B", "4", "WDRO", "DDRO"),
					"Journal Request Submitted Successfully When No Advisory Radio Button Selected");
			reporter.LogSuccess("VerifyJournalFormSubmitNoAdvisoryIRATest",
					"Journal Request Submitted Successfully When No Advisory Radio Button Selected");
		} catch (Exception e) {
			reporter.LogFail("VerifyJournalFormSubmitNoAdvisoryIRATest", e.getMessage());
			throw e;
		}
	}

	// Test Case 29
	@Test
	public void VerifyTotalValueWhenCashWithdrawalGreaterTest() throws Exception {
		try {
			NavigateToJournalFormPageMMF();
			Assert.isTrue(TestLogic.VerifyTotalValueWhenCashWithdrawalGreater("74116970", "B", "4000"),
					"Total Value and Transfer Value are Same When Cash Withdrawal Is Greater Than Actual Value");
			reporter.LogSuccess("VerifyTotalValueWithTransferValueTest",
					"Total Value and Transfer Value are Same When Cash Withdrawal Is Greater Than Actual Value");
		} catch (Exception e) {
			reporter.LogFail("VerifyTotalValueWithTransferValueTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 30
	@Test
	public void VerifyAccNoOnAdvisoryAccInfoPageTest() throws Exception {
		try {
			NavigateToJournalFormPageMMF();
			Assert.isTrue(TestLogic.VerifyTransferFromAccNoOnAdvisoryAccInfoPage("74116970", "B", "1", "WDRO", "DDRO"),
					"Transfer From Account Number Verified On Advisory Acc Info");
			reporter.LogSuccess("VerifyAccNoOnAdvisoryAccInfoPageTest",
					"Transfer From Account Number Verified On Advisory Acc Info");
		} catch (Exception e) {
			reporter.LogFail("VerifyAccNoOnAdvisoryAccInfoPageTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 31
	@Test
	public void VerifyTransferToAccNoOnAdvisoryAccInfoPage() throws Exception {
		try {
			NavigateToJournalFormPageMMF();
			Assert.isTrue(TestLogic.VerifyTransferToAccNoOnAdvisoryAccInfoPage("74116970", "B", "1", "WDRO", "DDRO"),
					"Transfer To Account Number Verified On Advisory Acc Info");
			reporter.LogSuccess("VerifyAccNoOnAdvisoryAccInfoPageTest",
					"Transfer To Account Number Verified On Advisory Acc Info");
		} catch (Exception e) {
			reporter.LogFail("VerifyAccNoOnAdvisoryAccInfoPageTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 32
	@Test
	public void VerifyJournalFormSubmitTransferTypeFullTest() throws Exception {
		try {
			NavigateToJournalFormPage();
			TestLogic.VerifyJournalFormSubmitTypeBFull("74116970", "B", "WDRO", "DDRO");
			reporter.LogSuccess("VerifyJournalFormSubmitTransferTypeFullTest",
					"Successfully Journal Request Submission With Type B Transfer Type Full");
		} catch (Exception e) {
			reporter.LogFail("VerifyJournalFormSubmitTransferTypeFullTest", e.getMessage());
			throw e;
		}
	}
}