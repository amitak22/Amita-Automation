package baird.LiquidOffice.TestSuite;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInfo;
import org.springframework.util.Assert;

import baird.LiquidOffice.Automation.BusinessLayer.CTAachFormTestLogic;

/**
 * @author AmitaKumari
 */

public class CTAachRetailTests extends TestBase {

	CTAachFormTestLogic TestLogic = null;

	@BeforeEach
	public void TestInitialize(TestInfo info) {
		log.LogDebug(info.getDisplayName());
		TestLogic = new CTAachFormTestLogic(commonapi, testSettings);
	}

	void NavigateToACHFormPage() throws Exception {
		TestLogic.OpenCTApage("SignIn");
		TestLogic.GetClientInfo("59127215", "ACH Request");
		TestLogic.ClickContinueOnClientInfo();
	}

	void NavigatetoWorkQueue() throws Exception {
		TestLogic.NavigatetoWorkQueueACH("SignIn");
	}

	// Test Case 1
	@Test
	public void VerifyACHFormWarningMessageWithInvalidAccNoTest() throws Exception {
		try {
			TestLogic.OpenCTApage("SignIn");
			TestLogic.GetClientInfo("abcdefgh", "ACH Request");
			Assert.isTrue(TestLogic.VerifyErrorMessageWithInvalidAccount("Invalid character(s)"),
					"Error PopUp Verified");
			reporter.LogSuccess("VerifyACHFormWarningMessageWithInvalidAccNoTest", "Warning Message Verified");
		} catch (Exception e) {
			reporter.LogFail("VerifyACHFormWarningMessageWithInvalidAccNoTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 2
	@Test
	public void VerifyACHFormOpeningTest() throws Exception {
		try {
			NavigateToACHFormPage();
			Assert.isTrue(TestLogic.VerifyRetrievedClientTitle(), "Page Title Verified");
			reporter.LogSuccess("VerifyACHFormOpeningTest", "Page Title Verified");
		} catch (Exception e) {
			reporter.LogFail("VerifyACHFormOpeningTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 3
	@Test
	public void VerifyACHAccountNumberTest() throws Exception {
		try {
			NavigateToACHFormPage();
			Assert.isTrue(TestLogic.VerifyAccountNumber(), "Account Verified");
			reporter.LogSuccess("VerifyACHAccountNumberTest", "Account Verified");
		} catch (Exception e) {
			reporter.LogFail("VerifyACHAccountNumberTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 4
	@Test
	public void VerifyACHInstructionsSelectionTest() throws Exception {
		try {
			NavigateToACHFormPage();
			Assert.isTrue(TestLogic.VerifyACHInstruction1(), "ACH Instruction Selection Verified");
			reporter.LogSuccess("VerifyACHInstructionsSelectionTest", "ACH Instruction Selection Verified");
		} catch (Exception e) {
			reporter.LogFail("VerifyACHInstructionsSelectionTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 5
	@Test
	public void VerifyACHInstructionsTest() throws Exception {
		try {
			NavigateToACHFormPage();
			Assert.isTrue(TestLogic.VerifyACHInstructions(), "Bank Customer Name Verified");
			reporter.LogSuccess("VerifyACHInstructionsSelectionTest", "Bank Customer Name Verified");
		} catch (Exception e) {
			reporter.LogFail("VerifyACHInstructionsSelectionTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 6
	@Test
	public void VerifyACHFormClearBankInformationTest() throws Exception {
		try {
			NavigateToACHFormPage();
			Assert.isTrue(TestLogic.VerifyClearBankInformation(), "Clear Bank Information Verified");
			reporter.LogSuccess("VerifyACHFormClearBankInformationTest", "Clear Bank Information Verified");
		} catch (Exception e) {
			reporter.LogFail("VerifyACHFormClearBankInformationTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 7
	@Test
	public void VerifyACHFormErrorPopUpForInvalidAmountTest() throws Exception {
		try {
			NavigateToACHFormPage();
			Assert.isTrue(TestLogic.VerifyInvalidAmount("jj", "Format is invalid, format with numeric characters only"),
					"Error PopUp Verified For Invalid Amount");
			reporter.LogSuccess("VerifyACHFormErrorPopUpForInvalidAmountTest",
					"Error PopUp Verified for Invalid Amount");
		} catch (Exception e) {
			reporter.LogFail("VerifyACHFormErrorPopUpForInvalidAmountTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 8
	@Test
	public void VerifyACHCurrentIssueDateTest() throws Exception {
		try {
			NavigateToACHFormPage();
			Assert.isTrue(TestLogic.VerifyACHIssueDateForCurrentDate(), "Verified");
			reporter.LogSuccess("VerifyACHCurrentIssueDateTest", "ACH Issue Date Verified");
		} catch (Exception e) {
			reporter.LogFail("VerifyACHCurrentIssueDateTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 9
	@Test
	public void VerifyACHFormSubmitUsingFutureIssueDateTest() throws Exception {
		try {
			NavigateToACHFormPage();
			TestLogic.VerifyACHIssueDateForFutureDate(IssueDate7DaysFromCurrentDate());
			TestLogic.CreateACHRequestTypeA(".10", "Cash", "AK");
			if (TestLogic.VerifyErrorMessageForDuplicateRecord() == false) {
				TestLogic.SendACHRequest();
				NavigateToACHFormPage();
				TestLogic.VerifyACHIssueDateForFutureDate(IssueDate7DaysFromCurrentDate());
				TestLogic.CreateACHRequestTypeA(".10", "Cash", "AK");
				if (TestLogic.VerifyErrorMessageForDuplicateRecord()) {
					TestLogic.SendACHRequest();
				} else {
					throw new Exception("Failed");
				}
			}
			reporter.LogSuccess("VerifyACHFormSubmitUsingFutureIssueDateTest",
					"Successfully ACH Request Submission For Future ACH Issue Date");
		} catch (Exception e) {
			reporter.LogFail("VerifyACHFormSubmitUsingFutureIssueDateTest", e.getMessage());
			throw e;
		}
	}

	public String IssueDate7DaysFromCurrentDate() {
		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		Calendar cal = Calendar.getInstance();
		cal.setTime(new Date());
		cal.add(Calendar.DATE, 7);
		String newDate = dateFormat.format(cal.getTime());
		return newDate;
	}

	// Test Case 10
	@Test
	public void VerifyWarningPopUpForACHIssueDate15DaysFromCurrentDateTest() throws Exception {
		try {
			NavigateToACHFormPage();
			TestLogic.VerifyACHIssueDateForFutureDate(IssueDate15DaysFromCurrentDate());
			Assert.isTrue(TestLogic.VerifyWarningPopUpforACHIssueDate("The ach issue date exceeds 10 business days."),
					"Warning PopUp Verified For ACH Issue Date is After 10 days From Current Date");
			reporter.LogSuccess("VerifyWarningPopUpForACHIssueDate15DaysFromCurrentDateTest",
					"Warning PopUp Verified For ACH Issue Date is After 10 days From Current Date");
		} catch (Exception e) {
			reporter.LogFail("VerifyWarningPopUpForACHIssueDate15DaysFromCurrentDateTest", e.getMessage());
			throw e;
		}
	}

	public String IssueDate15DaysFromCurrentDate() {
		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		Calendar cal = Calendar.getInstance();
		cal.setTime(new Date());
		cal.add(Calendar.DATE, 15);
		String newDate = dateFormat.format(cal.getTime());
		return newDate;
	}

	// Test Case 11
	@Test
	public void VerifyACHResetButtonTest() throws Exception {
		try {
			NavigateToACHFormPage();
			Assert.isTrue(TestLogic.VerifyExistingInstruction(), "ACH Instruction # 1 should notbe displayed");
			reporter.LogSuccess("VerifyACHResetButtonTest", "ACH Instruction # 1 should notbe displayed");
		} catch (Exception e) {
			reporter.LogFail("VerifyACHResetButtonTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 12
	@Test
	public void VerifyACHSaveFormFucntionalityTest() throws Exception {
		try {
			NavigateToACHFormPage();
			Assert.isTrue(TestLogic.VerifySaveFunctionality(), "Save ACH Form Functionality Verified");
			reporter.LogSuccess("VerifyACHSaveFormFucntionalityTest", "Save ACH Form Functionality Verified");
		} catch (Exception e) {
			reporter.LogFail("VerifyACHSaveFormFucntionalityTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 13
	@Test
	public void VerifyACHBackButtonTest() throws Exception {
		try {
			NavigateToACHFormPage();
			Assert.isTrue(TestLogic.VerifyBackButton(), "User Navigated Back to Client Info Page");
			reporter.LogSuccess("VerifyACHBackButtonTest", "User Navigated Back to Client Info Page");
		} catch (Exception e) {
			reporter.LogFail("VerifyACHBackButtonTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 14
	@Test
	public void VerifyACHBankInformationTest() throws Exception {
		try {
			NavigateToACHFormPage();
			Assert.isTrue(TestLogic.VerifyACHInstructionsField(),
					"Bank Customer Name, Bank Name, Bank ABA and Bank Acc No Verified");
			reporter.LogSuccess("VerifyACHBankInformationTest",
					"Bank Customer Name, Bank Name, Bank ABA and Bank Acc No Verified");
		} catch (Exception e) {
			reporter.LogFail("VerifyACHBankInformationTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 15
	@Test
	public void VerifyACHFormSubmitTypeAUsingCashTest() throws Exception {
		try {
			NavigateToACHFormPage();
			TestLogic.CreateACHRequestTypeA(".20", "Cash", "AK");
			if (TestLogic.VerifyErrorMessageForDuplicateRecord() == false) {
				TestLogic.SendACHRequest();
				NavigateToACHFormPage();
				TestLogic.CreateACHRequestTypeA(".20", "Cash", "AK");
				if (TestLogic.VerifyErrorMessageForDuplicateRecord()) {
					TestLogic.SendACHRequest();
				} else {
					throw new Exception("Failed");
				}
			}
			reporter.LogSuccess("VerifyACHFormSubmitTypeAUsingCashTest",
					"Successfully ACH Request Submission Using Cash");
		} catch (Exception e) {
			reporter.LogFail("VerifyACHFormSubmitTypeAUsingCashTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 16
	@Test
	public void VerifyACHFormSubmitTypeBUsingCashTest() throws Exception {
		try {
			NavigateToACHFormPage();
			TestLogic.CreateACHRequestTypeB(".31", "Cash", "autotest", "AK");
			if (TestLogic.VerifyErrorMessageForDuplicateRecord() == false) {
				TestLogic.SendACHRequest();
				NavigatetoWorkQueue();
				TestLogic.ApproveClientServicesACHqueueProcess();
				NavigateToACHFormPage();
				TestLogic.CreateACHRequestTypeB(".31", "Cash", "autotest", "AK");
				if (TestLogic.VerifyErrorMessageForDuplicateRecord()) {
					TestLogic.SendACHRequest();
					NavigatetoWorkQueue();
					TestLogic.ApproveClientServicesACHqueueProcess();
				} else {
					throw new Exception("Failed");
				}
			}
			reporter.LogSuccess("VerifyACHFormSubmitTypeAUsingCashTest",
					"Successfully ACH Request Submission Using Cash");
		} catch (Exception e) {
			reporter.LogFail("VerifyACHFormSubmitTypeAUsingCashTest", e.getMessage());
			throw e;
		}
	}

	void NavigateToACHFormPageMMF() throws Exception {
		TestLogic.OpenCTApage("SignIn");
		TestLogic.GetClientInfo("19602591", "ACH Request");
		TestLogic.ClickContinueOnClientInfo();
	}

	// Test Case 17
	@Test
	public void VerifyACHFormSubmitTypeDUsingCashTest() throws Exception {
		try {
			NavigateToACHFormPageMMF();
			TestLogic.CreateACHRequestTypeD(".32", "Cash", "autotest", "AK");
			if (TestLogic.VerifyErrorMessageForDuplicateRecord() == false) {
				TestLogic.SendACHRequest();
				NavigatetoWorkQueue();
				TestLogic.SendToNextApprovalqueueProcess("Automatically Route to Next Approval");
				NavigateToACHFormPageMMF();
				TestLogic.CreateACHRequestTypeD(".30", "Cash", "autotest", "AK");
				if (TestLogic.VerifyErrorMessageForDuplicateRecord()) {
					TestLogic.SendACHRequest();
					NavigatetoWorkQueue();
					TestLogic.SendToNextApprovalqueueProcess("Automatically Route to Next Approval");
				} else {
					throw new Exception("Failed");
				}
			}
			reporter.LogSuccess("VerifyACHFormSubmitTypeDUsingCashTest",
					"Successfully ACH Request Submission Using Cash");
		} catch (Exception e) {
			reporter.LogFail("VerifyACHFormSubmitTypeDUsingCashTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 18
	@Test
	public void VerifyWarningPopUpForNoACHInstructionSelectionTest() throws Exception {
		try {
			NavigateToACHFormPage();
			Assert.isTrue(
					TestLogic.VerifyACHInstruction(
							"You need to select an ACH Instruction before you can submit the form."),
					"Error PopUp Verified No Selection of ACH Insctruction");
			reporter.LogSuccess("VerifyWarningPopUpForNoACHInstructionSelectionTest",
					"Error PopUp Verified No Selection of ACH Insctruction");
		} catch (Exception e) {
			reporter.LogFail("VerifyWarningPopUpForNoACHInstructionSelectionTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 19
	@Test
	public void VerifyWarningPopUpForNoAmountTest() throws Exception {
		try {
			NavigateToACHFormPageMMF();
			TestLogic.CreateACHRequestTypeAusingMMF("", "Cash", "AK");
			Assert.isTrue(TestLogic.VerifyWarningPopUp("Required Information Missing:"),
					"Error PopUp Verified For No Requested Amount");
			reporter.LogSuccess("VerifyWarningPopUpForNoAmountTest", "Error PopUp Verified For No Requested Amount");
		} catch (Exception e) {
			reporter.LogFail("VerifyWarningPopUpForNoAmountTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 20
	@Test
	public void VerifyWarningPopUpForNoAttestationTest() throws Exception {
		try {
			NavigateToACHFormPageMMF();
			TestLogic.CreateACHRequestTypeAusingMMF(".1", "Cash", "");
			Assert.isTrue(TestLogic.VerifyWarningPopUp("Required Information Missing:"),
					"Error PopUp Verified For No Attestation");
			reporter.LogSuccess("VerifyWarningPopUpForNoAttestationTest", "Error PopUp Verified For No Attestation");
		} catch (Exception e) {
			reporter.LogFail("VerifyWarningPopUpForNoAttestationTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 21
	@Test
	public void VerifyWarningPopUpForNoThirdPartyTest() throws Exception {
		try {
			NavigateToACHFormPage();
			TestLogic.CreateACHRequestTypeB(".1", "Cash", "", "AK");
			Assert.isTrue(TestLogic.VerifyWarningPopUp("A required field was found empty!"),
					"Error PopUp Verified For No Third Party");
			reporter.LogSuccess("VerifyWarningPopUpForNoThirdPartyTest", "Error PopUp Verified For No Third Party");
		} catch (Exception e) {
			reporter.LogFail("VerifyWarningPopUpForNoThirdPartyTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 22
	@Test
	public void VerifyWarningPopUpWithoutThirdPartyRadioBtnTest() throws Exception {
		try {
			NavigateToACHFormPage();
			TestLogic.CreateACHRequestTypeBWithoutThirdPartyRadioBtn(".1", "Cash", "autotest", "AK");
			Assert.isTrue(TestLogic.VerifyWarningPopUp("A required field was found empty!"),
					"Error PopUp Verified For No Third Party");
			reporter.LogSuccess("VerifyWarningPopUpWithoutThirdPartyRadioBtnTest",
					"Error PopUp Verified For No Third Party");
		} catch (Exception e) {
			reporter.LogFail("VerifyWarningPopUpWithoutThirdPartyRadioBtnTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 23
	@Test
	public void VerifyACHFormSubmitTypeAUsingMMFTest() throws Exception {
		try {
			NavigateToACHFormPageMMF();
			TestLogic.CreateACHRequestTypeAusingMMF(".60", "ID3", "AK");
			if (TestLogic.VerifyErrorMessageForDuplicateRecord() == false) {
				TestLogic.SendACHRequest();
				NavigateToACHFormPageMMF();
				TestLogic.CreateACHRequestTypeAusingMMF(".60", "ID3", "AK");
				if (TestLogic.VerifyErrorMessageForDuplicateRecord()) {
					TestLogic.SendACHRequest();
				} else {
					throw new Exception("Failed");
				}
			}
			reporter.LogSuccess("VerifyACHFormSubmitTypeAUsingMMFTest",
					"Successfully ACH Request Submission Using MMF");
		} catch (Exception e) {
			reporter.LogFail("VerifyACHFormSubmitTypeAUsingMMFTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 24
	@Test
	public void VerifyIRATypeTest() throws Exception {
		try {
			NavigateToACHFormPage();
			Assert.isTrue(TestLogic.VerifyIRAType(), "IRA Type Verified");
			reporter.LogSuccess("VerifyIRATypeTest", "IRA Type Verified");
		} catch (Exception e) {
			reporter.LogFail("VerifyIRATypeTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 25
	@Test
	public void VerifyACHFormSubmitTypeDUsingMMFTest() throws Exception {
		try {
			NavigateToACHFormPageMMF();
			TestLogic.CreateACHRequestTypeD(".50", "ID3", "autotest", "AK");
			if (TestLogic.VerifyErrorMessageForDuplicateRecord() == false) {
				TestLogic.SendACHRequest();
				NavigateToACHFormPageMMF();
				TestLogic.CreateACHRequestTypeD(".50", "ID3", "autotest", "AK");
				if (TestLogic.VerifyErrorMessageForDuplicateRecord()) {
					TestLogic.SendACHRequest();
				} else {
					throw new Exception("Failed");
				}
			}
			reporter.LogSuccess("VerifyACHFormSubmitTypeDUsingMMFTest",
					"Successfully ACH Request Submission Using MMF");
		} catch (Exception e) {
			reporter.LogFail("VerifyACHFormSubmitTypeDUsingMMFTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 26
	@Test
	public void VerifyACHAccountTypeMarginSelectionTest() throws Exception {
		try {
			NavigateToACHFormPageMMF();
			Assert.isTrue(TestLogic.VerifyWarningPopUpforMargin("ID3", "If Account Type is Margin"),
					"Error PopUp Verified");
			Assert.isTrue(TestLogic.VerifyCashAutoPopulatesForMargin(), "Cash Verified");
			reporter.LogSuccess("VerifyACHAccountTypeMarginSelectionTest", "Acc Type Margin Selected");
		} catch (Exception e) {
			reporter.LogFail("VerifyACHAccountTypeMarginSelectionTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 27
	@Test
	public void VerifyACHWarningPopUpForNoAccountTest() throws Exception {
		try {
			NavigateToACHFormPageMMF();
			TestLogic.VerifyWarningPopUpforNoAccount("2", "Cash");
			Assert.isTrue(TestLogic.VerifyWarningPopUp("Required Information Missing:"),
					"Error PopUp Verified For No Account Transefer Selected");
			reporter.LogSuccess("VerifyACHWarningPopUpForNoAccountTest",
					"Error PopUp Verified For No Account Transefer Selected");
		} catch (Exception e) {
			reporter.LogFail("VerifyACHWarningPopUpForNoAccountTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 28
	@Test
	public void VerifyACHWarningPopUpForIntoBairdSelectionTest() throws Exception {
		try {
			NavigateToACHFormPageMMF();
			TestLogic.VerifyWarningPopUpforIntoBairdSelection();
			Assert.isTrue(
					TestLogic.VerifyWarningPopUp("Are you sure you want to transfer funds INTO this Baird account?"),
					"Error PopUp Verified For In to Baird Selection");
			reporter.LogSuccess("VerifyACHWarningPopUpForIntoBairdSelectionTest",
					"Error PopUp Verified For In to Baird Selection");
		} catch (Exception e) {
			reporter.LogFail("VerifyACHWarningPopUpForIntoBairdSelectionTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 29
	@Test
	public void VerifyACHWarningPopUpWithoutAdvisoryAccountSelectionTest() throws Exception {
		try {
			NavigateToACHFormPageMMF();
			TestLogic.VerifyWarningPopUpWithoutAdvisoryAccount(".70", "Cash", "AK");
			Assert.isTrue(TestLogic.VerifyWarningPopUp("Required Information Missing:"),
					"Error PopUp Verified if Advisory Account Radio Button Not Selected");
			reporter.LogSuccess("VerifyACHWarningPopUpWithoutAdvisoryAccountSelectionTest",
					"Error PopUp Verified if Advisory Account Radio Button Not Selected");
		} catch (Exception e) {
			reporter.LogFail("VerifyACHWarningPopUpWithoutAdvisoryAccountSelectionTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 30
	@Test
	public void VerifyACHWarningPopUpForYesRadioBtnSelectionAdvisoryAccountTest() throws Exception {
		try {
			NavigateToACHFormPageMMF();
			TestLogic.VerifyWarningPopUpforYesRadionBtnAdvisoryAccount();
			Assert.isTrue(
					TestLogic.VerifyWarningPopUp("You have indicated that you are submitting a Program/Manager/Model/"),
					"Error PopUp Verified For Yes Radio Button Selection For Advisory Account");
			reporter.LogSuccess("VerifyACHWarningPopUpForYesRadioBtnSelectionAdvisoryAccountTest",
					"Error PopUp Verified For Yes Radio Button Selection For Advisory Account");
		} catch (Exception e) {
			reporter.LogFail("VerifyACHWarningPopUpForYesRadioBtnSelectionAdvisoryAccountTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 31
	@Test
	public void VerifyACHFormSubmitTypeAUsingSLOATest() throws Exception {
		try {
			NavigateToACHFormPage();
			TestLogic.CreateACHRequestTypeAwithSLOA(".70", "Cash", "M&I", "AK");
			if (TestLogic.VerifyErrorMessageForDuplicateRecord() == false) {
				TestLogic.SendACHRequest();
				NavigateToACHFormPage();
				TestLogic.CreateACHRequestTypeAwithSLOA(".70", "Cash", "M&I", "AK");
				if (TestLogic.VerifyErrorMessageForDuplicateRecord()) {
					TestLogic.SendACHRequest();
				} else {
					throw new Exception("Failed");
				}
			}
			reporter.LogSuccess("VerifyACHFormSubmitTypeAUsingSLOATest",
					"Successfully ACH Request Submission Using SLOA");
		} catch (Exception e) {
			reporter.LogFail("VerifyACHFormSubmitTypeAUsingSLOATest", e.getMessage());
			throw e;
		}
	}

	// Test Case 32
	@Test
	public void VerifyACHCancelButtonOnProcessACHPageTest() throws Exception {
		try {
			NavigateToACHFormPage();
			TestLogic.CreateACHRequestTypeA(".90", "Cash", "AK");
			TestLogic.VerifyCancelBtnOnACHProcess();
			reporter.LogSuccess("VerifyACHCancelButtonOnProcessACHPageTest", "Cancel Button successfully Clicked");
		} catch (Exception e) {
			reporter.LogFail("VerifyACHCancelButtonOnProcessACHPageTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 33
	@Test
	public void VerifyACHFormSubmitTypeAUsingMarginTest() throws Exception {
		try {
			NavigateToACHFormPage();
			TestLogic.CreateACHRequestTypeAMargin(".80", "Cash", "AK");
			if (TestLogic.VerifyErrorMessageForDuplicateRecord() == false) {
				TestLogic.SendACHRequest();
				NavigateToACHFormPage();
				TestLogic.CreateACHRequestTypeAMargin(".80", "Cash", "AK");
				if (TestLogic.VerifyErrorMessageForDuplicateRecord()) {
					TestLogic.SendACHRequest();
				} else {
					throw new Exception("Failed");
				}
			}
			reporter.LogSuccess("VerifyACHFormSubmitTypeAUsingCashTest",
					"Successfully ACH Request Submission Using Margin Selection");
		} catch (Exception e) {
			reporter.LogFail("VerifyACHFormSubmitTypeAUsingMarginTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 34
	@Test
	public void VerifyErrorPopUpWhenNoAttachmentTypeDTest() throws Exception {
		try {
			NavigateToACHFormPageMMF();
			TestLogic.CreateACHRequestTypeDWithoutAttachment(".4", "Cash", "AutoTest", "AK");
			Assert.isTrue(
					TestLogic.VerifyWarningPopUp("This ACH requires the attachment of a letter of authorization (or"),
					"Error PopUp Verified For No Attachment For TypeD");
			reporter.LogSuccess("VerifyErrorPopUpWhenNoAttachmentTest",
					"Error Pop Verified For No Attachment For TypeD");
		} catch (Exception e) {
			reporter.LogFail("VerifyErrorPopUpWhenNoAttachmentTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 35
	@Test
	public void VerifyErrorPopUpWhenNoAttachmentTypeBTest() throws Exception {
		try {
			NavigateToACHFormPage();
			TestLogic.CreateACHRequestTypeBWithoutAttachment(".4", "Cash", "AutoTest", "AK");
			Assert.isTrue(
					TestLogic.VerifyWarningPopUp("This ACH requires the attachment of a letter of authorization (or"),
					"Error PopUp Verified For No Attachment For TypeB");
			reporter.LogSuccess("VerifyErrorPopUpWhenNoAttachmentTypeBTest",
					"Error Pop Verified For No Attachment For TypeB");
		} catch (Exception e) {
			reporter.LogFail("VerifyErrorPopUpWhenNoAttachmentTypeBTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 36
	@Test
	public void VerifyACHBackButtonOnProcessACHPageTest() throws Exception {
		try {
			NavigateToACHFormPage();
			TestLogic.CreateACHRequestTypeA(".87", "Cash", "AK");
			TestLogic.VerifyBackBtnOnACHProcess();
			Assert.isTrue(TestLogic.VerifyRetrievedClientTitle(), "Page Title Verified");
			reporter.LogSuccess("VerifyACHBackButtonOnProcessACHPageTest", "Back Button Successfully Clicked");
		} catch (Exception e) {
			reporter.LogFail("VerifyACHBackButtonOnProcessACHPageTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 37
	@Test
	public void VerifyACHFormSubmitTypeAUsingIntoBairdAccountTest() throws Exception {
		try {
			NavigateToACHFormPageMMF();
			TestLogic.CreateACHRequestTypeAwithIntoBaird("1.17", "Cash", "Funds");
			if (TestLogic.VerifyErrorMessageForDuplicateRecord() == false) {
				TestLogic.SendACHRequest();
				NavigatetoWorkQueue();
				TestLogic.ApproveClientServicesACHqueueWithMMFProcess("ID3");
				NavigateToACHFormPageMMF();
				TestLogic.CreateACHRequestTypeAwithIntoBaird("1.17", "Cash", "Funds");
				if (TestLogic.VerifyErrorMessageForDuplicateRecord()) {
					TestLogic.SendACHRequest();
					NavigatetoWorkQueue();
					TestLogic.ApproveClientServicesACHqueueWithMMFProcess("ID3");
				} else {
					throw new Exception("Failed");
				}
			}
			reporter.LogSuccess("VerifyACHFormSubmitTypeAUsingIntoBairdAccountTest",
					"Successfully ACH Request Submission Using Into Baird Account For Type A");
		} catch (Exception e) {
			reporter.LogFail("VerifyACHFormSubmitTypeAUsingIntoBairdAccountTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 38
	@Test
	public void VerifyACHFormSubmitTypeDUsingIntoBairdAccountTest() throws Exception {
		try {
			NavigateToACHFormPageMMF();
			TestLogic.CreateACHRequestTypeDwithIntoBaird("1.47", "Cash", "AutoTest", "Funds");
			if (TestLogic.VerifyErrorMessageForDuplicateRecord() == false) {
				TestLogic.SendACHRequest();
				NavigatetoWorkQueue();
				TestLogic.RejectClientServicesACHqueueProcess("Reject");
				Assert.isTrue(TestLogic.VerifyReqAmountRejectedProcess(),
						"Requested Amount Verified For Rejected Process");
				NavigateToACHFormPageMMF();
				TestLogic.CreateACHRequestTypeDwithIntoBaird("1.47", "Cash", "AutoTest", "Funds");
				if (TestLogic.VerifyErrorMessageForDuplicateRecord()) {
					TestLogic.SendACHRequest();
					NavigatetoWorkQueue();
					TestLogic.RejectClientServicesACHqueueProcess("Reject");
					Assert.isTrue(TestLogic.VerifyReqAmountRejectedProcess(),
							"Requested Amount Verified For Rejected Process");
				} else {
					throw new Exception("Failed");
				}
			}
			reporter.LogSuccess("VerifyACHFormSubmitTypeDUsingIntoBairdAccountTest",
					"Successfully ACH Request Submission Using Into Baird Account For Type D");
		} catch (Exception e) {
			reporter.LogFail("VerifyACHFormSubmitTypeDUsingIntoBairdAccountTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 39
	@Test
	public void VerifyACHFormSubmitTypeBUsingIntoBairdAccountTest() throws Exception {
		try {
			NavigateToACHFormPage();
			TestLogic.CreateACHRequestTypeBwithIntoBaird("1.47", "Cash", "AutoTest");
			if (TestLogic.VerifyErrorMessageForDuplicateRecord() == false) {
				TestLogic.SendACHRequest();
				NavigatetoWorkQueue();
				TestLogic.RejectClientServicesACHqueueProcess("Reject");
				Assert.isTrue(TestLogic.VerifyReqAmountRejectedProcess(),
						"Requested Amount Verified For Rejected Process");
				NavigateToACHFormPage();
				TestLogic.CreateACHRequestTypeBwithIntoBaird("1.47", "Cash", "AutoTest");
				if (TestLogic.VerifyErrorMessageForDuplicateRecord()) {
					TestLogic.SendACHRequest();
					NavigatetoWorkQueue();
					TestLogic.RejectClientServicesACHqueueProcess("Reject");
					Assert.isTrue(TestLogic.VerifyReqAmountRejectedProcess(),
							"Requested Amount Verified For Rejected Process");
				} else {
					throw new Exception("Failed");
				}
			}
			reporter.LogSuccess("VerifyACHFormSubmitTypeBUsingIntoBairdAccountTest",
					"Successfully ACH Request Submission Using Into Baird Account For Type B");
		} catch (Exception e) {
			reporter.LogFail("VerifyACHFormSubmitTypeBUsingIntoBairdAccountTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 40
	@Test
	public void VerifyACHFormSubmitTypeAUsingIntoBairdMMFTest() throws Exception {
		try {
			NavigateToACHFormPageMMF();
			TestLogic.CreateACHRequestTypeAwithIntoBaird("1.4", "ID3", "Funds");
			if (TestLogic.VerifyErrorMessageForDuplicateRecord() == false) {
				TestLogic.SendACHRequest();
				NavigateToACHFormPageMMF();
				TestLogic.CreateACHRequestTypeAwithIntoBaird("1.4", "ID3", "Funds");
				if (TestLogic.VerifyErrorMessageForDuplicateRecord()) {
					TestLogic.SendACHRequest();
				} else {
					throw new Exception("Failed");
				}
			}
			reporter.LogSuccess("VerifyACHFormSubmitTypeAUsingIntoBairdMMFTest",
					"Successfully ACH Request Submission Using Into Baird Account For Type A Using MMF");
		} catch (Exception e) {
			reporter.LogFail("VerifyACHFormSubmitTypeAUsingIntoBairdMMFTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 41
	@Test
	public void VerifyClientNameTest() throws Exception {
		try {
			NavigateToACHFormPage();
			Assert.isTrue(TestLogic.VerifyClientName(), "Client Name Verified");
			reporter.LogSuccess("VerifyClientNameTest", "Client Name Verified");
		} catch (Exception e) {
			reporter.LogFail("VerifyClientNameTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 41
	@Test
	public void VerifyACHFormSubmitTypeDsendToDelayQueueTest() throws Exception {
		try {
			NavigateToACHFormPageMMF();
			TestLogic.CreateACHRequestTypeDwithIntoBaird("1.47", "Cash", "AutoTest", "Funds");
			if (TestLogic.VerifyErrorMessageForDuplicateRecord() == false) {
				TestLogic.SendACHRequest();
				NavigatetoWorkQueue();
				TestLogic.RejectClientServicesACHqueueProcess("Reject");
				Assert.isTrue(TestLogic.VerifyReqAmountRejectedProcess(),
						"Requested Amount Verified For Rejected Process");
				NavigateToACHFormPageMMF();
				TestLogic.CreateACHRequestTypeDwithIntoBaird("1.47", "Cash", "AutoTest", "Funds");
				if (TestLogic.VerifyErrorMessageForDuplicateRecord()) {
					TestLogic.SendACHRequest();
					NavigatetoWorkQueue();
					TestLogic.RejectClientServicesACHqueueProcess("Reject");
					Assert.isTrue(TestLogic.VerifyReqAmountRejectedProcess(),
							"Requested Amount Verified For Rejected Process");
				} else {
					throw new Exception("Failed");
				}
			}
			reporter.LogSuccess("VerifyACHFormSubmitTypeDUsingIntoBairdAccountTest",
					"Successfully ACH Request Submission Using Into Baird Account For Type D");
		} catch (Exception e) {
			reporter.LogFail("VerifyACHFormSubmitTypeDUsingIntoBairdAccountTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 42
	@Test
	public void VerifyACHFormSubmitTypeDSendToDelayQueueTest() throws Exception {
		try {
			NavigateToACHFormPageMMF();
			TestLogic.CreateACHRequestTypeDwithIntoBaird("1.28", "Cash", "AutoTest", "Funds");
			if (TestLogic.VerifyErrorMessageForDuplicateRecord() == false) {
				TestLogic.SendACHRequest();
				NavigatetoWorkQueue();
				TestLogic.SendToDelayqueueProcess();
			} else {
				throw new Exception("Failed");
			}
			reporter.LogSuccess("VerifyACHFormSubmitTypeDSendToDelayQueueTest",
					"Successfully ACH Request Submission Using For Type B and Sending to Delay Queue");
		} catch (Exception e) {
			reporter.LogFail("VerifyACHFormSubmitTypeDSendToDelayQueueTest", e.getMessage());
			throw e;
		}
	}
}
