package baird.LiquidOffice.TestSuite;

import static org.junit.platform.engine.discovery.DiscoverySelectors.selectPackage;
import static org.junit.platform.engine.discovery.DiscoverySelectors.selectClass;
import static org.junit.platform.engine.discovery.DiscoverySelectors.selectMethod;

import org.junit.platform.launcher.Launcher;
import org.junit.platform.launcher.LauncherDiscoveryRequest;
import org.junit.platform.launcher.core.LauncherDiscoveryRequestBuilder;
import org.junit.platform.launcher.core.LauncherFactory;
import org.junit.platform.launcher.listeners.SummaryGeneratingListener;
import org.junit.platform.launcher.listeners.TestExecutionSummary;

/**
 * @author AmitaKumari
 */

public class TestController {

	public static void main(String[] args) {
		System.out.println("Running test cases NOW!");
		LauncherDiscoveryRequest request = LauncherDiscoveryRequestBuilder.request()
				.selectors(
						selectPackage("baird.LiquidOffice.TestSuite")
						//selectClass(CTAcheckIRATests.class),
						//selectClass(CTAcheckRetailTests.class)
						//selectClass(CTAachRetailTests.class),
						//selectClass(CTAachIRATests.class)
						//selectClass(CTAjournalRetailTests.class),
						//selectClass(CTAjournalIRATests.class),
						//selectClass(CTAjournalRetailToIRATests.class)
						/*selectMethod("baird.LiquidOffice.TestSuite.CTAcheckRetailTests#VerifyWarningPopUpForCheckIssueDate15DaysFromCurrentDateTest")
						selectMethod("baird.LiquidOffice.TestSuite.CTAcheckRetailTests#VerifyCheckFormSubmitTypeF1withMMFTest"),
						selectMethod("baird.LiquidOffice.TestSuite.CTAcheckRetailTests#VerifyCheckFormSubmitTypeF2withMMFTest"),
						selectMethod("baird.LiquidOffice.TestSuite.CTAcheckRetailTests#VerifyCheckFormSubmitTypeBwithCashTest"),
						selectMethod("baird.LiquidOffice.TestSuite.CTAcheckRetailTests#VerifyBackButtonOnProcessCheckPageTest"),
						selectMethod("baird.LiquidOffice.TestSuite.CTAcheckRetailTests#VerifyCheckFormSubmitTypeDwithMMFTest"),
						selectMethod("baird.LiquidOffice.TestSuite.CTAcheckRetailTests#VerifyCheckFormSubmitTypeEwithMMFTest"),
						selectMethod("baird.LiquidOffice.TestSuite.CTAcheckRetailTests#VerifyCheckFormSubmitTypeF2withCashTest"),
						selectMethod("baird.LiquidOffice.TestSuite.CTAcheckRetailTests#VerifyCheckFormSubmitTypeF2withCashTest")	*/
				).build();
		Launcher launcher = LauncherFactory.create();
		SummaryGeneratingListener listener = new SummaryGeneratingListener();
		launcher.registerTestExecutionListeners(listener);
		launcher.discover(request);

		launcher.execute(request);

		TestExecutionSummary summary = listener.getSummary();

		System.out.println("Tests Discover: " + summary.getTestsFoundCount());

		System.out.println("DONE!");
	}

}
