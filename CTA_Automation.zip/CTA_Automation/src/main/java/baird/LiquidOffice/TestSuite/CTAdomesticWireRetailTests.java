package baird.LiquidOffice.TestSuite;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInfo;
import org.springframework.util.Assert;

import baird.LiquidOffice.Automation.BusinessLayer.CTAdomesticWireFormTestLogic;

/**
 * @author AmitaKumari
 */

public class CTAdomesticWireRetailTests extends TestBase {

	CTAdomesticWireFormTestLogic TestLogic = null;

	@BeforeEach
	public void TestInitialize(TestInfo info) {
		log.LogDebug(info.getDisplayName());
		TestLogic = new CTAdomesticWireFormTestLogic(commonapi, testSettings);
	}

	void NavigateToDomesticWirePage() throws Exception {
		TestLogic.OpenCTApage("SignIn");
		TestLogic.GetClientInfo("59127215", "Domestic Wire Transfer");
		TestLogic.ClickContinueOnClientInfo();
	}

	void NavigateToDomesticWireBankInfo() throws Exception {
		TestLogic.OpenCTApage("SignIn");
		TestLogic.GetClientInfo("54535457", "Domestic Wire Transfer");
		TestLogic.ClickContinueOnClientInfo();
	}

	void NavigateToDomesticWirePageMMF() throws Exception {
		TestLogic.OpenCTApage("SignIn");
		TestLogic.GetClientInfo("34780866", "Domestic Wire Transfer");
		TestLogic.ClickContinueOnClientInfo();
	}

	// Test Case 1
	@Test
	public void VerifyDomesticWireWarningPopUpWithInvalidAccNoTest() throws Exception {
		try {
			TestLogic.OpenCTApage("SignIn");
			TestLogic.GetClientInfo("abcdefgh", "Domestic Wire Transfer");
			Assert.isTrue(TestLogic.VerifyWarningMessage("Invalid character(s)"), "Error PopUp Verified");
			reporter.LogSuccess("VerifyDomesticWireWarningPopUpWithInvalidAccNoTest", "Warning Message Verified");
		} catch (Exception e) {
			reporter.LogFail("VerifyDomesticWireWarningPopUpWithInvalidAccNoTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 2
	@Test
	public void VerifyDomesticWireFormOpeningTest() throws Exception {
		try {
			NavigateToDomesticWirePage();
			Assert.isTrue(TestLogic.VerifyWireInformationTitle(), "Page Title Verified");
			reporter.LogSuccess("VerifyDomesticWireFormOpeningTest", "Page Title Verified");
		} catch (Exception e) {
			reporter.LogFail("VerifyDomesticWireFormOpeningTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 3
	@Test
	public void VerifyDomesticWireAccountNumberTest() throws Exception {
		try {
			NavigateToDomesticWirePage();
			Assert.isTrue(TestLogic.VerifyAccountNumber(), "Account Verified");
			reporter.LogSuccess("VerifyDomesticWireAccountNumberTest", "Account Verified");
		} catch (Exception e) {
			reporter.LogFail("VerifyDomesticWireAccountNumberTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 4
	@Test
	public void VerifyWireBankInformationTest() throws Exception {
		try {
			NavigateToDomesticWireBankInfo();
			Assert.isTrue(TestLogic.VerifyWireBankInformationField(),
					"Account Name, Bank Name, Bank ABA, Bank Acc No, City, State Verified");
			reporter.LogSuccess("VerifyWireBankInformationTest",
					"Account Name, Bank Name, Bank ABA, Bank Acc No, City, State Verified");
		} catch (Exception e) {
			reporter.LogFail("VerifyWireBankInformationTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 5
	@Test
	public void VerifyNewWireInstructionTest() throws Exception {
		try {
			NavigateToDomesticWirePage();
			Assert.isTrue(TestLogic.VerifyWireInformationTitle(), "New Wire Instruction Title Verified");
			reporter.LogSuccess("VerifyDomesticWireFormOpeningTest", "New Wire Instruction Title Verified");
		} catch (Exception e) {
			reporter.LogFail("VerifyDomesticWireFormOpeningTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 6
	@Test
	public void VerifyChargeWireFAradioButtonTest() throws Exception {
		try {
			NavigateToDomesticWirePage();
			Assert.isTrue(TestLogic.VerifyChargeWireFeeFARadioButton(), "Charge Wire Fee FA Radio Button Verified");
			reporter.LogSuccess("VerifyChargeWireFAradioButtonTest", "Charge Wire Fee FA Radio Button Verified");
		} catch (Exception e) {
			reporter.LogFail("VerifyChargeWireFAradioButtonTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 7
	@Test
	public void VerifyChargeWireClientradioButtonTest() throws Exception {
		try {
			NavigateToDomesticWirePage();
			Assert.isTrue(TestLogic.VerifyChargeWireFeeClientRadioButton(),
					"Charge Wire Fee Client Radio Button Verified");
			reporter.LogSuccess("VerifyChargeWireClientradioButtonTest",
					"Charge Wire Fee Client Radio Button Verified");
		} catch (Exception e) {
			reporter.LogFail("VerifyChargeWireClientradioButtonTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 8
	@Test
	public void VerifyWireErrorPopUpForInvalidAmountTest() throws Exception {
		try {
			NavigateToDomesticWirePage();
			Assert.isTrue(TestLogic.VerifyInvalidAmount("jj", "Format is invalid, format with numeric characters only"),
					"Error PopUp Verified For Invalid Amount");
			reporter.LogSuccess("VerifyWireErrorPopUpForInvalidAmountTest", "Error PopUp Verified for Invalid Amount");
		} catch (Exception e) {
			reporter.LogFail("VerifyWireErrorPopUpForInvalidAmountTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 9
	@Test
	public void VerifyWireCurrentIssueDateTest() throws Exception {
		try {
			NavigateToDomesticWirePage();
			Assert.isTrue(TestLogic.VerifyWireIssueDateForCurrentDate(), "Wire Issue Date Verified");
			reporter.LogSuccess("VerifyWireCurrentIssueDateTest", "Wire Issue Date Verified");
		} catch (Exception e) {
			reporter.LogFail("VerifyWireCurrentIssueDateTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 10
	@Test
	public void VerifyDomesticWireReqSubmitUsingFutureIssueDateTest() throws Exception {
		try {
			NavigateToDomesticWirePage();
			TestLogic.VerifyWireIssueDateForFutureDate(IssueDate7DaysFromCurrentDate());
			TestLogic.CreateWireRequest(".10", "", "Amita", "Baird", "123456789", "987654321", "Milwaukee", "WI",
					"Beneficiary has the same name & address as the brokerage acc holder", "", "bairdtest", "AK");
			if (TestLogic.VerifyErrorMessageForDuplicateRecord() == false) {
				TestLogic.SendWireRequest();
				NavigateToDomesticWirePage();
				TestLogic.VerifyWireIssueDateForFutureDate(IssueDate7DaysFromCurrentDate());
				TestLogic.CreateWireRequest(".10", "", "Amita", "Baird", "123456789", "987654321", "Milwaukee", "WI",
						"Beneficiary has the same name & address as the brokerage acc holder", "", "bairdtest", "AK");
				if (TestLogic.VerifyErrorMessageForDuplicateRecord()) {
					TestLogic.SendWireRequest();
				} else {
					throw new Exception("Failed");
				}
			}
			reporter.LogSuccess("VerifyDomesticWireReqSubmitUsingFutureIssueDateTest",
					"Successfully Domestic Wire Request Submission For Future Wire Issue Date");
		} catch (Exception e) {
			reporter.LogFail("VerifyDomesticWireReqSubmitUsingFutureIssueDateTest", e.getMessage());
			throw e;
		}
	}

	public String IssueDate7DaysFromCurrentDate() {
		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		Calendar cal = Calendar.getInstance();
		cal.setTime(new Date());
		cal.add(Calendar.DATE, 7);
		String newDate = dateFormat.format(cal.getTime());
		return newDate;
	}

	// Test Case 11
	@Test
	public void VerifyWarningPopUpForWireIssueDate10DaysFromCurrentDateTest() throws Exception {
		try {
			NavigateToDomesticWirePage();
			TestLogic.VerifyDomWireIssueDateForFutureDate(IssueDate10WorkingDaysFromCurrentDate());
			Assert.isTrue(TestLogic.VerifyWarningMessage("The wire issue date exceeds 10 business days."),
					"Warning PopUp Verified For Wire Issue Date is After 10 days From Current Date");
			reporter.LogSuccess("VerifyWarningPopUpForWireIssueDate10DaysFromCurrentDateTest",
					"Warning PopUp Verified For Wire Issue Date is After 10 days From Current Date");
		} catch (Exception e) {
			reporter.LogFail("VerifyWarningPopUpForWireIssueDate10DaysFromCurrentDateTest", e.getMessage());
			throw e;
		}
	}

	public String IssueDate10WorkingDaysFromCurrentDate() {
		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		Calendar cal = Calendar.getInstance();
		cal.setTime(new Date());
		cal.add(Calendar.DATE, 15);
		String newDate = dateFormat.format(cal.getTime());
		return newDate;
	}

	// Test Case 12
	@Test
	public void VerifyDomWireResetButtonTest() throws Exception {
		try {
			NavigateToDomesticWirePage();
			TestLogic.EnterBankInstructions("Amita", "Baird", "123456789", "987654321", "Milwaukee", "WI");
			Assert.isTrue(TestLogic.VerifyBankInstruction(), "Bank Information should be Cleared Out");
			reporter.LogSuccess("VerifyDomWireResetButtonTest", "Bank Information should be Cleared Out");
		} catch (Exception e) {
			reporter.LogFail("VerifyDomWireResetButtonTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 13
	@Test
	public void VerifyDomWireSaveFormFucntionalityTest() throws Exception {
		try {
			NavigateToDomesticWirePage();
			Assert.isTrue(
					TestLogic.VerifySaveFunctionality("Amita", "Baird", "123456789", "987654321", "Milwaukee", "WI"),
					"Save Wire Request Functionality Verified");
			reporter.LogSuccess("VerifyDomWireSaveFormFucntionalityTest", "Save Wire Request Functionality Verified");
		} catch (Exception e) {
			reporter.LogFail("VerifyDomWireSaveFormFucntionalityTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 14
	@Test
	public void VerifyDomWireBackButtonTest() throws Exception {
		try {
			NavigateToDomesticWirePage();
			Assert.isTrue(TestLogic.VerifyBackButton(), "User Navigated Back to Client Info Page");
			reporter.LogSuccess("VerifyDomWireBackButtonTest", "User Navigated Back to Client Info Page");
		} catch (Exception e) {
			reporter.LogFail("VerifyDomWireBackButtonTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 15
	@Test
	public void VerifyDomesticWireReqSubmitUsingChargeWireFeeClientTest() throws Exception {
		try {
			NavigateToDomesticWirePage();
			TestLogic.CreateWireRequestWithChargeWireFeeClient(".20", "", "Amita", "Baird", "123456789", "987654321",
					"Milwaukee", "WI", "Beneficiary has the same name & address as the brokerage acc holder", "",
					"bairdtest", "AK");
			if (TestLogic.VerifyErrorMessageForDuplicateRecord() == false) {
				TestLogic.SendWireRequest();
				NavigateToDomesticWirePage();
				TestLogic.CreateWireRequestWithChargeWireFeeClient(".20", "", "Amita", "Baird", "123456789",
						"987654321", "Milwaukee", "WI",
						"Beneficiary has the same name & address as the brokerage acc holder", "", "bairdtest", "AK");
				if (TestLogic.VerifyErrorMessageForDuplicateRecord()) {
					TestLogic.SendWireRequest();
				} else {
					throw new Exception("Failed");
				}
			}
			reporter.LogSuccess("VerifyDomesticWireReqSubmitUsingChargeWireFeeClientTest",
					"Successfully Domestic Wire Request Submission With Client Charge Wire Fee");
		} catch (Exception e) {
			reporter.LogFail("VerifyDomesticWireReqSubmitUsingChargeWireFeeClientTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 16
	@Test
	public void VerifyDomesticWireReqSubmitMarginAccTypeTest() throws Exception {
		try {
			NavigateToDomesticWirePage();
			TestLogic.CreateWireRequestWithMarginAccType(".30", "", "Amita", "Baird", "123456789", "987654321",
					"Milwaukee", "WI", "Beneficiary has the same name & address as the brokerage acc holder", "",
					"777E", "AK");
			if (TestLogic.VerifyErrorMessageForDuplicateRecord() == false) {
				TestLogic.SendWireRequest();
				NavigateToDomesticWirePage();
				TestLogic.CreateWireRequestWithMarginAccType(".30", "", "Amita", "Baird", "123456789", "987654321",
						"Milwaukee", "WI", "Beneficiary has the same name & address as the brokerage acc holder", "",
						"777E", "AK");
				if (TestLogic.VerifyErrorMessageForDuplicateRecord()) {
					TestLogic.SendWireRequest();
				} else {
					throw new Exception("Failed");
				}
			}
			reporter.LogSuccess("VerifyDomesticWireReqSubmitUsingChargeWireFeeClientTest",
					"Successfully Domestic Wire Request Submission With Client Charge Wire Fee");
		} catch (Exception e) {
			reporter.LogFail("VerifyDomesticWireReqSubmitUsingChargeWireFeeClientTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 17
	@Test
	public void VerifyPreferredHomePhoneTest() throws Exception {
		try {
			NavigateToDomesticWirePage();
			Assert.isTrue(TestLogic.VerifyPreferredHomePhone("Beneficiary is a third party domestic individual"),
					"Preferred Home Phone Number Verified");
			reporter.LogSuccess("VerifyPreferredHomePhoneTest", "Preferred Home Phone Number Verified");
		} catch (Exception e) {
			reporter.LogFail("VerifyPreferredHomePhoneTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 18
	@Test
	public void VerifyFAradioButtonTest() throws Exception {
		try {
			NavigateToDomesticWirePage();
			Assert.isTrue(TestLogic.VerifyFAradioButton("Beneficiary is a third party domestic individual"),
					"Options for If this wire is payable to a third party, is this party known to the FA? is verified");
			reporter.LogSuccess("VerifyFAradioButtonTest",
					"Options for If this wire is payable to a third party, is this party known to the FA? is verified");
		} catch (Exception e) {
			reporter.LogFail("VerifyFAradioButtonTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 19
	@Test
	public void VerifyDomesticWireReqSubmitDomIndividualTest() throws Exception {
		try {
			NavigateToDomesticWirePage();
			TestLogic.CreateWireRequestDomForeignIndividual(".40", "", "Amita", "Baird", "123456789", "987654321",
					"Milwaukee", "WI", "Beneficiary is a third party domestic individual", "", "777E", "AK");
			if (TestLogic.VerifyErrorMessageForDuplicateRecord() == false) {
				TestLogic.SendWireRequest();
				NavigateToDomesticWirePage();
				TestLogic.CreateWireRequestDomForeignIndividual(".40", "", "Amita", "Baird", "123456789", "987654321",
						"Milwaukee", "WI", "Beneficiary is a third party domestic individual", "", "777E", "AK");
				if (TestLogic.VerifyErrorMessageForDuplicateRecord()) {
					TestLogic.SendWireRequest();
				} else {
					throw new Exception("Failed");
				}
			}
			reporter.LogSuccess("VerifyDomesticWireReqSubmitDomIndividualTest",
					"Successfully Domestic Wire Request Submission For Beneficiary is a third party domestic individual ");
		} catch (Exception e) {
			reporter.LogFail("VerifyDomesticWireReqSubmitDomIndividualTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 20
	@Test
	public void VerifyDomesticWireReqSubmitForeignIndividualTest() throws Exception {
		try {
			NavigateToDomesticWirePage();
			TestLogic.CreateWireRequestDomForeignIndividual(".50", "", "Amita", "Baird", "123456789", "987654321",
					"Milwaukee", "WI", "Beneficiary is a third-party foreign individual", "", "777E", "AK");
			if (TestLogic.VerifyErrorMessageForDuplicateRecord() == false) {
				TestLogic.SendWireRequest();
				NavigateToDomesticWirePage();
				TestLogic.CreateWireRequestDomForeignIndividual(".50", "", "Amita", "Baird", "123456789", "987654321",
						"Milwaukee", "WI", "Beneficiary is a third-party foreign individual", "", "777E", "AK");
				if (TestLogic.VerifyErrorMessageForDuplicateRecord()) {
					TestLogic.SendWireRequest();
				} else {
					throw new Exception("Failed");
				}
			}
			reporter.LogSuccess("VerifyDomesticWireReqSubmitForeignIndividualTest",
					"Successfully Domestic Wire Request Submission For Beneficiary is a third party foreign individual ");
		} catch (Exception e) {
			reporter.LogFail("VerifyDomesticWireReqSubmitForeignIndividualTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 21
	@Test
	public void VerifyDomesticWireReqSubmitDomInstitutionTest() throws Exception {
		try {
			NavigateToDomesticWirePage();
			TestLogic.CreateWireRequestDomForeignIndividual("1.50", "", "Amita", "Baird", "123456789", "987654321",
					"Milwaukee", "WI", "Beneficiary is a third-party domestic institution", "", "777E", "AK");
			if (TestLogic.VerifyErrorMessageForDuplicateRecord() == false) {
				TestLogic.SendWireRequest();
				NavigateToDomesticWirePage();
				TestLogic.CreateWireRequestDomForeignIndividual("1.50", "", "Amita", "Baird", "123456789", "987654321",
						"Milwaukee", "WI", "Beneficiary is a third-party domestic institution", "", "777E", "AK");
				if (TestLogic.VerifyErrorMessageForDuplicateRecord()) {
					TestLogic.SendWireRequest();
				} else {
					throw new Exception("Failed");
				}
			}
			reporter.LogSuccess("VerifyDomesticWireReqSubmitDomInstitutionTest",
					"Successfully Domestic Wire Request Submission For Beneficiary is a third-party domestic institution");
		} catch (Exception e) {
			reporter.LogFail("VerifyDomesticWireReqSubmitDomInstitutionTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 22
	@Test
	public void VerifyDomesticWireReqSubmitForeignInstitutionTest() throws Exception {
		try {
			NavigateToDomesticWirePage();
			TestLogic.CreateWireRequestDomForeignIndividual("2.50", "", "Amita", "Baird", "123456789", "987654321",
					"Milwaukee", "WI", "Beneficiary is a third-party foreign institution", "", "777E", "AK");
			if (TestLogic.VerifyErrorMessageForDuplicateRecord() == false) {
				TestLogic.SendWireRequest();
				NavigateToDomesticWirePage();
				TestLogic.CreateWireRequestDomForeignIndividual("2.50", "", "Amita", "Baird", "123456789", "987654321",
						"Milwaukee", "WI", "Beneficiary is a third-party foreign institution", "", "777E", "AK");
				if (TestLogic.VerifyErrorMessageForDuplicateRecord()) {
					TestLogic.SendWireRequest();
				} else {
					throw new Exception("Failed");
				}
			}
			reporter.LogSuccess("VerifyDomesticWireReqSubmitForeignInstitutionTest",
					"Successfully Domestic Wire Request Submission For Beneficiary is a third-party foreign institution");
		} catch (Exception e) {
			reporter.LogFail("VerifyDomesticWireReqSubmitForeignInstitutionTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 23
	@Test
	public void VerifyWarningPopUpNoAmountTest() throws Exception {
		try {
			NavigateToDomesticWirePage();
			Assert.isTrue(
					TestLogic.VerifyWarningPopUp("", "", "Amita", "Baird", "123456789", "987654321", "Milwaukee", "WI",
							"Beneficiary is a third-party foreign institution", "",
							"You must enter an amount for this wire."),
					"Warning PopUp Verified When Requested Amount Is Not Entered");
			reporter.LogSuccess("VerifyWarningPopUpNoAmountTest",
					"Warning PopUp Verified When Requested Amount Is Not Entered");
		} catch (Exception e) {
			reporter.LogFail("VerifyWarningPopUpNoAmountTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 24
	@Test
	public void VerifyWarningPopUpAccountTypeIsNotSelectedTest() throws Exception {
		try {
			NavigateToDomesticWirePage();
			Assert.isTrue(TestLogic.VerifyWarningPopUpNoAccType("1", "", "Amita", "Baird", "123456789", "987654321",
					"Milwaukee", "WI", "Beneficiary is a third-party foreign institution", "",
					"Account Type is required;"), "Warning PopUp Verified When Account Type Is Not Selected");
			reporter.LogSuccess("VerifyWarningPopUpAccountTypeIsNotSelectedTest",
					"Warning PopUp Verified When Account Type Is Not Selected");
		} catch (Exception e) {
			reporter.LogFail("VerifyWarningPopUpAccountTypeIsNotSelectedTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 25
	@Test
	public void VerifyWarningPopUpChargeWireFeeNotSelectedTest() throws Exception {
		try {
			NavigateToDomesticWirePage();
			Assert.isTrue(
					TestLogic.VerifyWarningPopUpNoChargeWireFee("1", "", "Amita", "Baird", "123456789", "987654321",
							"Milwaukee", "WI", "Beneficiary has the same name & address as the brokerage acc holder",
							"", "Charge Wire Fee is required;"),
					"Warning PopUp Verified When Charge Wire Fee Is Not Selected");
			reporter.LogSuccess("VerifyWarningPopUpChargeWireFeeNotSelectedTest",
					"Warning PopUp Verified When Charge Wire Fee Is Not Selected");
		} catch (Exception e) {
			reporter.LogFail("VerifyWarningPopUpChargeWireFeeNotSelectedTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 26
	@Test
	public void VerifyWarningPopUpForInvalidBankABATest() throws Exception {
		try {
			NavigateToDomesticWirePage();
			Assert.isTrue(TestLogic.VerifyWarningPopUpForInvalidBankABA("abcdefghi", "Invalid character(s)."),
					"Warning PopUp Verified For Invalid Bank ABA");
			reporter.LogSuccess("VerifyWarningPopUpForInvalidBankABATest",
					"Warning PopUp Verified For Invalid Bank ABA");
		} catch (Exception e) {
			reporter.LogFail("VerifyWarningPopUpForInvalidBankABATest", e.getMessage());
			throw e;
		}
	}

	// Test Case 27
	@Test
	public void VerifyWarningPopUpBankInfoNotEnteredTest() throws Exception {
		try {
			NavigateToDomesticWirePage();
			Assert.isTrue(TestLogic.VerifyWarningPopUpBankInfoNotEntered("1",
					"Beneficiary has the same name & address as the brokerage acc holder", "Bank Name is required;"),
					"Warning PopUp Verified When Bank Information Not Entered");
			reporter.LogSuccess("VerifyWarningPopUpBankInfoNotEnteredTest",
					"Warning PopUp Verified When Bank Information Not Entered");
		} catch (Exception e) {
			reporter.LogFail("VerifyWarningPopUpBankInfoNotEnteredTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 28
	@Test
	public void VerifyWarningPopUpFAoptionNotSelectedTest() throws Exception {
		try {
			NavigateToDomesticWirePage();
			Assert.isTrue(
					TestLogic.VerifyWarningPopUpWhenFAOptionNotSelected("1", "", "Amita", "Baird", "123456789",
							"987654321", "Milwaukee", "WI", "Beneficiary is a third-party foreign institution",
							"If the check is payable to a third party, is this party known to the FA?"),
					"Warning PopUp Verified When FA Radio Button Is Not Selected");
			reporter.LogSuccess("VerifyWarningPopUpFAoptionNotSelectedTest",
					"Warning PopUp Verified When FA Radio Button Is Not Selected");
		} catch (Exception e) {
			reporter.LogFail("VerifyWarningPopUpFAoptionNotSelectedTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 29
	@Test
	public void VerifyWarningPopUpHomePhoneSelectedTest() throws Exception {
		try {
			NavigateToDomesticWirePage();
			Assert.isTrue(TestLogic.VerifyWarningPopUpHomePhoneSelected("1", "Amita", "Baird", "123456789", "987654321",
					"Milwaukee", "WI", "Beneficiary is a third-party foreign institution",
					"Phone number is not available. Please select a radio button with an available phone number. "),
					"Warning PopUp Verified When Home Phone No Is Not Entered");
			reporter.LogSuccess("VerifyWarningPopUpHomePhoneSelectedTest",
					"Warning PopUp Verified When Home Phone No Is Not Entered");
		} catch (Exception e) {
			reporter.LogFail("VerifyWarningPopUpHomePhoneSelectedTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 30
	@Test
	public void VerifyWarningPopUpThirdPartyAddNotEnteredTest() throws Exception {
		try {
			NavigateToDomesticWirePage();
			Assert.isTrue(
					TestLogic.VerifyWarningPopUpThirdPartyAddNotEntered(".30", "", "Amita", "Baird", "123456789",
							"987654321", "Milwaukee", "WI", "Beneficiary is a third-party foreign institution", "",
							"AK", "The Beneficiary Type is a third party. Please provide the Third Party Address."),
					"Warning PopUp Verified When Third Party Address Is Not Entered");
			reporter.LogSuccess("VerifyWarningPopUpThirdPartyAddNotEnteredTest",
					"Warning PopUp Verified When Third Party Address Is Not Entered");
		} catch (Exception e) {
			reporter.LogFail("VerifyWarningPopUpThirdPartyAddNotEnteredTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 31
	@Test
	public void VerifyWarningPopUpAccountLengthNotSelectedTest() throws Exception {
		try {
			NavigateToDomesticWirePage();
			Assert.isTrue(
					TestLogic.VerifyWarningPopUpAccountLengthNotSelected(".30", "", "Amita", "Baird", "123456789",
							"987654321", "Milwaukee", "WI", "Beneficiary is a third-party foreign institution", "AK",
							"777E", "Account Open Length;"),
					"Warning PopUp Verified When Account Length Is Not Selected");
			reporter.LogSuccess("VerifyWarningPopUpAccountLengthNotSelectedTest",
					"Warning PopUp Verified When Account Length Is Not Selected");
		} catch (Exception e) {
			reporter.LogFail("VerifyWarningPopUpAccountLengthNotSelectedTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 32
	@Test
	public void VerifyWarningPopUpWithoutAttestationTest() throws Exception {
		try {
			NavigateToDomesticWirePage();
			Assert.isTrue(
					TestLogic.VerifyWarningPopUpWithoutAttestation(".30", "", "Amita", "Baird", "123456789",
							"987654321", "Milwaukee", "WI", "Beneficiary is a third-party foreign institution", "AK",
							"777E", "Required Information Missing:"),
					"Warning PopUp Verified When Form Is Not Attested");
			reporter.LogSuccess("VerifyWarningPopUpWithoutAttestationTest",
					"Warning PopUp Verified When Form Is Not Attested");
		} catch (Exception e) {
			reporter.LogFail("VerifyWarningPopUpWithoutAttestationTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 33
	@Test
	public void VerifyWarningPopUpForInvalidBankAccNoTest() throws Exception {
		try {
			NavigateToDomesticWirePage();
			Assert.isTrue(TestLogic.VerifyWarningPopUpForInvalidBankAccNo("@@", "Invalid character(s)."),
					"Warning PopUp Verified For Invalid Bank Account Number");
			reporter.LogSuccess("VerifyWarningPopUpForInvalidBankAccNoTest",
					"Warning PopUp Verified For Invalid Bank Account Number");
		} catch (Exception e) {
			reporter.LogFail("VerifyWarningPopUpForInvalidBankAccNoTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 34
	@Test
	public void VerifyWarningPopUpBankABALessThan9digitsTest() throws Exception {
		try {
			NavigateToDomesticWirePage();
			Assert.isTrue(TestLogic.VerifyWarningPopUpWhenFAOptionNotSelected("1", "", "Amita", "Baird", "1234",
					"987654321", "Milwaukee", "WI",
					"Beneficiary has the same name & address as the brokerage acc holder", "ABA# must be 9 digits;"),
					"Warning PopUp Verified When Bank ABA Is Less Than 9 Digits");
			reporter.LogSuccess("VerifyWarningPopUpBankABALessThan9digitsTest",
					"Warning PopUp Verified When Bank ABA Is Less Than 9 Digits");
		} catch (Exception e) {
			reporter.LogFail("VerifyWarningPopUpBankABALessThan9digitsTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 35
	@Test
	public void VerifyWarningPopUpWithoutSLOAattachmentTest() throws Exception {
		try {
			NavigateToDomesticWirePage();
			Assert.isTrue(TestLogic.VerifyWarningPopUpThirdPartyAddNotEntered(".30", "", "Amita", "Baird", "123456789",
					"987654321", "Milwaukee", "WI", "Beneficiary is a third-party domestic individual", "AK", "777E",
					"Standing LOA"), "Warning PopUp Verified When Form Is Not Attested");
			reporter.LogSuccess("VerifyWarningPopUpWithoutSLOAattachmentTest",
					"Warning PopUp Verified When Form Is Not Attested");
		} catch (Exception e) {
			reporter.LogFail("VerifyWarningPopUpWithoutSLOAattachmentTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 36
	@Test
	public void VerifyAccountNoOnRetrivedClientInfoPage2Test() throws Exception {
		try {
			NavigateToDomesticWirePage();
			Assert.isTrue(
					TestLogic.VerifyAccountNoOnRetrivedClientInfoPage2(".30", "", "Amita", "Baird", "123456789",
							"987654321", "Milwaukee", "WI",
							"Beneficiary has the same name & address as the brokerage account holder"),
					"Warning PopUp Verified When Form Is Not Attested");
			reporter.LogSuccess("VerifyAccountNoOnRetrivedClientInfoPage2Test",
					"Warning PopUp Verified When Form Is Not Attested");
		} catch (Exception e) {
			reporter.LogFail("VerifyAccountNoOnRetrivedClientInfoPage2Test", e.getMessage());
			throw e;
		}
	}

	// Test Case 37
	@Test
	public void VerifyFinalAccountNoNameOnRetrivedClientInfoPage2Test() throws Exception {
		try {
			NavigateToDomesticWirePage();
			Assert.isTrue(TestLogic.VerifyFinalAccountNoNameOnRetrivedClientInfoPage2(".30", "", "Amita", "Baird",
					"123456789", "987654321", "Milwaukee", "WI",
					"Beneficiary has the same name & address as the brokerage account holder", "1234", "AmitaK"),
					"Final Account Number and Final Name Verified On Retrived Client Info Page2");
			reporter.LogSuccess("VerifyFinalAccountNoNameOnRetrivedClientInfoPage2Test",
					"Final Account Number and Final Name Verified On Retrived Client Info Page2");
		} catch (Exception e) {
			reporter.LogFail("VerifyFinalAccountNoNameOnRetrivedClientInfoPage2Test", e.getMessage());
			throw e;
		}
	}

	// Test Case 38
	@Test
	public void VerifyDomesticWireReqSubmitUsingMMFTest() throws Exception {
		try {
			NavigateToDomesticWirePageMMF();
			TestLogic.CreateWireRequestUsingMMF("1.6", "ID3", "Amita", "Baird", "123456789", "987654321", "Milwaukee",
					"WI", "Beneficiary has the same name & address as the brokerage acc holder", "", "777E", "AK");
			if (TestLogic.VerifyErrorMessageForDuplicateRecord() == false) {
				TestLogic.SendWireRequest();
				NavigateToDomesticWirePageMMF();
				TestLogic.CreateWireRequestUsingMMF("1.6", "ID3", "Amita", "Baird", "123456789", "987654321",
						"Milwaukee", "WI", "Beneficiary has the same name & address as the brokerage acc holder", "",
						"777E", "AK");
				if (TestLogic.VerifyErrorMessageForDuplicateRecord()) {
					TestLogic.SendWireRequest();
				} else {
					throw new Exception("Failed");
				}
			}
			reporter.LogSuccess("VerifyDomesticWireReqSubmitUsingMMFTest",
					"Successfully Domestic Wire Request Submission With MMF");
		} catch (Exception e) {
			reporter.LogFail("VerifyDomesticWireReqSubmitUsingMMFTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 39
	@Test
	public void VerifyDomesticWireReqSubmitDomIndividualMMFTest() throws Exception {
		try {
			NavigateToDomesticWirePageMMF();
			TestLogic.CreateWireRequestDomForeignIndividualUsingMMF("1.40", "ID3", "Amita", "Baird", "123456789",
					"987654321", "Milwaukee", "WI", "Beneficiary is a third party domestic individual", "", "777E",
					"AK");
			if (TestLogic.VerifyErrorMessageForDuplicateRecord() == false) {
				TestLogic.SendWireRequest();
				NavigateToDomesticWirePageMMF();
				TestLogic.CreateWireRequestDomForeignIndividualUsingMMF("1.40", "ID3", "Amita", "Baird", "123456789",
						"987654321", "Milwaukee", "WI", "Beneficiary is a third party domestic individual", "", "777E",
						"AK");
				if (TestLogic.VerifyErrorMessageForDuplicateRecord()) {
					TestLogic.SendWireRequest();
				} else {
					throw new Exception("Failed");
				}
			}
			reporter.LogSuccess("VerifyDomesticWireReqSubmitDomIndividualTest",
					"Successfully Domestic Wire Request Submission When Beneficiary is a third party domestic individual Using MMF");
		} catch (Exception e) {
			reporter.LogFail("VerifyDomesticWireReqSubmitDomIndividualTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 40
	@Test
	public void VerifyDomesticWireReqSubmitForeignIndividualMMFTest() throws Exception {
		try {
			NavigateToDomesticWirePageMMF();
			TestLogic.CreateWireRequestDomForeignIndividualUsingMMF("1.50", "ID3", "Amita", "Baird", "123456789",
					"987654321", "Milwaukee", "WI", "Beneficiary is a third-party foreign individual", "", "777E",
					"AK");
			if (TestLogic.VerifyErrorMessageForDuplicateRecord() == false) {
				TestLogic.SendWireRequest();
				NavigateToDomesticWirePageMMF();
				TestLogic.CreateWireRequestDomForeignIndividualUsingMMF("1.50", "ID3", "Amita", "Baird", "123456789",
						"987654321", "Milwaukee", "WI", "Beneficiary is a third-party foreign individual", "", "777E",
						"AK");
				if (TestLogic.VerifyErrorMessageForDuplicateRecord()) {
					TestLogic.SendWireRequest();
				} else {
					throw new Exception("Failed");
				}
			}
			reporter.LogSuccess("VerifyDomesticWireReqSubmitForeignIndividualTest",
					"Successfully Domestic Wire Request Submission When Beneficiary is a third party foreign individual Using MMF ");
		} catch (Exception e) {
			reporter.LogFail("VerifyDomesticWireReqSubmitForeignIndividualTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 41
	@Test
	public void VerifyDomesticWireReqSubmitDomInstitutionMMFTest() throws Exception {
		try {
			NavigateToDomesticWirePageMMF();
			TestLogic.CreateWireRequestDomForeignIndividualUsingMMF("1.70", "ID3", "Amita", "Baird", "123456789",
					"987654321", "Milwaukee", "WI", "Beneficiary is a third-party domestic institution", "", "777E",
					"AK");
			if (TestLogic.VerifyErrorMessageForDuplicateRecord() == false) {
				TestLogic.SendWireRequest();
				NavigateToDomesticWirePageMMF();
				TestLogic.CreateWireRequestDomForeignIndividualUsingMMF("1.70", "ID3", "Amita", "Baird", "123456789",
						"987654321", "Milwaukee", "WI", "Beneficiary is a third-party domestic institution", "", "777E",
						"AK");
				if (TestLogic.VerifyErrorMessageForDuplicateRecord()) {
					TestLogic.SendWireRequest();
				} else {
					throw new Exception("Failed");
				}
			}
			reporter.LogSuccess("VerifyDomesticWireReqSubmitDomInstitutionTest",
					"Successfully Domestic Wire Request Submission When Beneficiary is a third-party domestic institution Using MMF");
		} catch (Exception e) {
			reporter.LogFail("VerifyDomesticWireReqSubmitDomInstitutionTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 42
	@Test
	public void VerifyDomesticWireReqSubmitForeignInstitutionMMFTest() throws Exception {
		try {
			NavigateToDomesticWirePageMMF();
			TestLogic.CreateWireRequestDomForeignIndividualUsingMMF("2.50", "ID3", "Amita", "Baird", "123456789",
					"987654321", "Milwaukee", "WI", "Beneficiary is a third-party foreign institution", "", "777E",
					"AK");
			if (TestLogic.VerifyErrorMessageForDuplicateRecord() == false) {
				TestLogic.SendWireRequest();
				NavigateToDomesticWirePageMMF();
				TestLogic.CreateWireRequestDomForeignIndividualUsingMMF("2.50", "ID3", "Amita", "Baird", "123456789",
						"987654321", "Milwaukee", "WI", "Beneficiary is a third-party foreign institution", "", "777E",
						"AK");
				if (TestLogic.VerifyErrorMessageForDuplicateRecord()) {
					TestLogic.SendWireRequest();
				} else {
					throw new Exception("Failed");
				}
			}
			reporter.LogSuccess("VerifyDomesticWireReqSubmitForeignInstitutionTest",
					"Successfully Domestic Wire Request Submission When Beneficiary is a third-party foreign institution Using MMF");
		} catch (Exception e) {
			reporter.LogFail("VerifyDomesticWireReqSubmitForeignInstitutionTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 43
	@Test
	public void VerifyDomesticWireReqSubmitYesAdvisoryTest() throws Exception {
		try {
			NavigateToDomesticWirePageMMF();
			TestLogic.VerifyDomesticWireReqSubmitYesAdvisory("2.6", "ID3", "Amita", "Baird", "123456789", "987654321",
					"Milwaukee", "WI", "Beneficiary has the same name & address as the brokerage acc holder", "",
					"777E", "AK");
			if (TestLogic.VerifyErrorMessageForDuplicateRecord() == false) {
				TestLogic.SendWireRequest();
				NavigateToDomesticWirePageMMF();
				TestLogic.VerifyDomesticWireReqSubmitYesAdvisory("2.6", "ID3", "Amita", "Baird", "123456789",
						"987654321", "Milwaukee", "WI",
						"Beneficiary has the same name & address as the brokerage acc holder", "", "777E", "AK");
				if (TestLogic.VerifyErrorMessageForDuplicateRecord()) {
					TestLogic.SendWireRequest();
				} else {
					throw new Exception("Failed");
				}
			}
			reporter.LogSuccess("VerifyDomesticWireReqSubmitYesAdvisoryTest",
					"Successfully Domestic Wire Request Submission With Yes Advisory Account");
		} catch (Exception e) {
			reporter.LogFail("VerifyDomesticWireReqSubmitYesAdvisoryTest", e.getMessage());
			throw e;
		}
	}
}
