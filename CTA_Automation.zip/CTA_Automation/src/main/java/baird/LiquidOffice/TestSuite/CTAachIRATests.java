package baird.LiquidOffice.TestSuite;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInfo;
import org.springframework.util.Assert;

import baird.LiquidOffice.Automation.BusinessLayer.CTAachFormTestLogic;

/**
 * @author AmitaKumari
 */

public class CTAachIRATests extends TestBase {

	CTAachFormTestLogic TestLogic = null;

	@BeforeEach
	public void TestInitialize(TestInfo info) {
		log.LogDebug(info.getDisplayName());
		TestLogic = new CTAachFormTestLogic(commonapi, testSettings);
	}

	void NavigateToACHFormPage() throws Exception {
		TestLogic.OpenCTApage("SignIn");
		TestLogic.GetClientInfo("86997083", "ACH Request");
		TestLogic.ClickContinueOnClientInfo();
	}

	void NavigateToACHFormPageAdvisory() throws Exception {
		TestLogic.OpenCTApage("SignIn");
		TestLogic.GetClientInfo("16869265", "ACH Request");
		TestLogic.ClickContinueOnClientInfo();
	}

	// Test Case 1
	@Test
	public void VerifyACHAccountNoClientNameTest() throws Exception {
		try {
			NavigateToACHFormPage();
			Assert.isTrue(TestLogic.VerifyAccountNoClientName(), "Account No and Client Name Verified");
			reporter.LogSuccess("VerifyACHAccountNoClientNameTest", "Account No and Client Name Verified");
		} catch (Exception e) {
			reporter.LogFail("VerifyACHAccountNoClientNameTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 2
	@Test
	public void VerifyACHInstructionsSelectionTest() throws Exception {
		try {
			NavigateToACHFormPage();
			Assert.isTrue(TestLogic.VerifyACHInstruction1(), "ACH Instruction Selection Verified");
			reporter.LogSuccess("VerifyACHInstructionsSelectionTest", "ACH Instruction Selection Verified");
		} catch (Exception e) {
			reporter.LogFail("VerifyACHInstructionsSelectionTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 3
	@Test
	public void VerifyACHResetButtonTest() throws Exception {
		try {
			NavigateToACHFormPage();
			Assert.isTrue(TestLogic.VerifyExistingInstruction(), "ACH Instruction # 1 should notbe displayed");
			reporter.LogSuccess("VerifyACHResetButtonTest", "ACH Instruction # 1 should notbe displayed");
		} catch (Exception e) {
			reporter.LogFail("VerifyACHResetButtonTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 4
	@Test
	public void VerifyACHBankInformationTest() throws Exception {
		try {
			NavigateToACHFormPage();
			Assert.isTrue(TestLogic.VerifyACHInstructionsFields(),
					"Bank Customer Name, Bank Name, Bank ABA and Bank Acc No Verified");
			reporter.LogSuccess("VerifyACHBankInformationTest",
					"Bank Customer Name, Bank Name, Bank ABA and Bank Acc No Verified");
		} catch (Exception e) {
			reporter.LogFail("VerifyACHBankInformationTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 5
	@Test
	public void VerifyWithholdingInformationTitleTest() throws Exception {
		try {
			NavigateToACHFormPage();
			Assert.isTrue(TestLogic.VerifyWithholdingInformationTitle(),
					"Withholding Information Title Verified For an IRA Account");
			reporter.LogSuccess("VerifyWithholdingInformationTitleTest",
					"Withholding Information Title Verified For an IRA Account");
		} catch (Exception e) {
			reporter.LogFail("VerifyWithholdingInformationTitleTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 6
	@Test
	public void VerifyWarningPopUpFederalTaxLessThan10Test() throws Exception {
		try {
			NavigateToACHFormPage();
			Assert.isTrue(TestLogic.VerifyWarningPopUpFederalTax("Federal Withholding cannot be less than 10%"),
					"Error PopUp Verified For Federal Tax less than 10%");
			reporter.LogSuccess("VerifyWarningPopUpFederalTaxLessThan10Test",
					"Error Pop Verified For Federal Tax less than 10%");
		} catch (Exception e) {
			reporter.LogFail("VerifyWarningPopUpFederalTaxLessThan10Test", e.getMessage());
			throw e;
		}
	}

	// Test Case 7
	@Test
	public void VerifyFinalAmountAfterEnteringStateTaxTest() throws Exception {
		try {
			NavigateToACHFormPage();
			Assert.isTrue(TestLogic.VerifyFinalAmountWithStateTax(),
					"Final Amount Verfied After Entering State Tax 7%");
			reporter.LogSuccess("VerifyFinalAmountAfterEnteringStateTaxTest",
					"FInal Amount Verfied After Entering State Tax 7%");
		} catch (Exception e) {
			reporter.LogFail("VerifyFinalAmountAfterEnteringStateTaxTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 8
	@Test
	public void VerifyFinalAmountAfterEnteringStateFederalTaxTest() throws Exception {
		try {
			NavigateToACHFormPage();
			Assert.isTrue(TestLogic.VerifyFinalAmountWithStateandFederalTax(),
					"Final Amount Verfied After Entering Federal and State Tax");
			reporter.LogSuccess("VerifyFinalAmountAfterEnteringStateFederalTaxTest",
					"FInal Amount Verfied After Entering Federal and State Tax");
		} catch (Exception e) {
			reporter.LogFail("VerifyFinalAmountAfterEnteringStateFederalTaxTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 9
	@Test
	public void VerifyFedWithholdingTaxTest() throws Exception {
		try {
			NavigateToACHFormPage();
			Assert.isTrue(TestLogic.VerifyFedWithholding(), "Fed Withholding Verfied When Dist Record Is Selected");
			reporter.LogSuccess("VerifyFedWithholdingTaxTest", "Fed Withholding Verfied When Dist Record Is Selected");
		} catch (Exception e) {
			reporter.LogFail("VerifyFedWithholdingTaxTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 10
	@Test
	public void VerifyStateWithholdingTest() throws Exception {
		try {
			NavigateToACHFormPage();
			Assert.isTrue(TestLogic.VerifyStateWithholding(), "State Withholding Verfied When Dist Record Is Selected");
			reporter.LogSuccess("VerifyStateWithholdingTest", "State Withholding Verfied When Dist Record Is Selected");
		} catch (Exception e) {
			reporter.LogFail("VerifyStateWithholdingTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 11
	@Test
	public void VerifyRequestedAmountFieldUnderWithholdingSectionTest() throws Exception {
		try {
			NavigateToACHFormPage();
			Assert.isTrue(TestLogic.VerifyRequestedAmountWithholding(),
					"Requested Amount Verfied Under Withholdin Section");
			reporter.LogSuccess("VerifyRequestedAmountFieldUnderWithholdingSectionTest",
					"Requested Amount Verfied Under Withholding Section");
		} catch (Exception e) {
			reporter.LogFail("VerifyRequestedAmountFieldUnderWithholdingSectionTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 12
	@Test
	public void VerifyACHFormSubmitTypeAwithFederalTaxIRATest() throws Exception {
		try {
			NavigateToACHFormPage();
			TestLogic.CreateACHIRARequestTypeA(".1", "10", "0", "REG", "AK");
			if (TestLogic.VerifyErrorMessageForDuplicateRecord() == false) {
				TestLogic.SendACHRequest();
				NavigateToACHFormPage();
				TestLogic.CreateACHIRARequestTypeA(".1", "10", "0", "REG", "AK");
				if (TestLogic.VerifyErrorMessageForDuplicateRecord()) {
					TestLogic.SendACHRequest();
				} else {
					throw new Exception("Failed");
				}
			}
			reporter.LogSuccess("VerifyACHFormSubmitTypeAwithFederalTaxIRATest",
					"Successfully ACH IRA Request Submission for Type A with Federal Tax");
		} catch (Exception e) {
			reporter.LogFail("VerifyACHFormSubmitTypeAwithFederalTaxIRATest", e.getMessage());
			throw e;
		}
	}

	// Test Case 13
	@Test
	public void VerifyACHFormSubmitTypeAwithStateTaxIRATest() throws Exception {
		try {
			NavigateToACHFormPage();
			TestLogic.CreateACHIRARequestTypeA(".3", "0", "10", "REG", "AK");
			if (TestLogic.VerifyErrorMessageForDuplicateRecord() == false) {
				TestLogic.SendACHRequest();
				NavigateToACHFormPage();
				TestLogic.CreateACHIRARequestTypeA(".3", "0", "10", "REG", "AK");
				if (TestLogic.VerifyErrorMessageForDuplicateRecord()) {
					TestLogic.SendACHRequest();
				} else {
					throw new Exception("Failed");
				}
			}
			reporter.LogSuccess("VerifyACHFormSubmitTypeAwithStateTaxIRATest",
					"Successfully ACH IRA Request Submission for Type A with State Tax");
		} catch (Exception e) {
			reporter.LogFail("VerifyACHFormSubmitTypeAwithStateTaxIRATest", e.getMessage());
			throw e;
		}
	}

	// Test Case 14
	@Test
	public void VerifyACHFormSubmitTypeBwithFederalTaxIRATest() throws Exception {
		try {
			NavigateToACHFormPage();
			TestLogic.CreateIRAACHRequestTypeB(".4", "10", "0", "REG", "AK", "autotest");
			if (TestLogic.VerifyErrorMessageForDuplicateRecord() == false) {
				TestLogic.SendACHRequest();
				NavigateToACHFormPage();
				TestLogic.CreateIRAACHRequestTypeB(".4", "10", "0", "REG", "AK", "autotest");
				if (TestLogic.VerifyErrorMessageForDuplicateRecord()) {
					TestLogic.SendACHRequest();
				} else {
					throw new Exception("Failed");
				}
			}
			reporter.LogSuccess("VerifyACHFormSubmitTypeAwithFederalTaxIRATest",
					"Successfully ACH IRA Request Submission for Type B with Federal Tax");
		} catch (Exception e) {
			reporter.LogFail("VerifyACHFormSubmitTypeAwithFederalTaxIRATest", e.getMessage());
			throw e;
		}
	}

	// Test Case 15
	@Test
	public void VerifyACHFormSubmitTypeBwithStateTaxIRATest() throws Exception {
		try {
			NavigateToACHFormPage();
			TestLogic.CreateIRAACHRequestTypeB(".4", "0", "10", "REG", "AK", "autotest");
			if (TestLogic.VerifyErrorMessageForDuplicateRecord() == false) {
				TestLogic.SendACHRequest();
				NavigateToACHFormPage();
				TestLogic.CreateIRAACHRequestTypeB(".4", "0", "10", "REG", "AK", "autotest");
				if (TestLogic.VerifyErrorMessageForDuplicateRecord()) {
					TestLogic.SendACHRequest();
				} else {
					throw new Exception("Failed");
				}
			}
			reporter.LogSuccess("VerifyACHFormSubmitTypeBwithStateTaxIRATest",
					"Successfully ACH IRA Request Submission for Type B with State Tax");
		} catch (Exception e) {
			reporter.LogFail("VerifyACHFormSubmitTypeBwithStateTaxIRATest", e.getMessage());
			throw e;
		}
	}

	// Test Case 16
	@Test
	public void VerifyACHFormSubmitTypeAwithFederalandStateTaxIRATest() throws Exception {
		try {
			NavigateToACHFormPage();
			TestLogic.CreateACHIRARequestTypeA("3.1", "10", "10", "REG", "AK");
			if (TestLogic.VerifyErrorMessageForDuplicateRecord() == false) {
				TestLogic.SendACHRequest();
				NavigateToACHFormPage();
				TestLogic.CreateACHIRARequestTypeA("3.1", "10", "10", "REG", "AK");
				if (TestLogic.VerifyErrorMessageForDuplicateRecord()) {
					TestLogic.SendACHRequest();
				} else {
					throw new Exception("Failed");
				}
			}
			reporter.LogSuccess("VerifyACHFormSubmitTypeAwithFederalandStateTaxIRATest",
					"Successfully ACH IRA Request Submission for Type A with Federal and State Tax");
		} catch (Exception e) {
			reporter.LogFail("VerifyACHFormSubmitTypeAwithFederalandStateTaxIRATest", e.getMessage());
			throw e;
		}
	}

	// Test Case 17
	@Test
	public void VerifyACHFormSubmitTypeBwithFederalandStateTaxIRATest() throws Exception {
		try {
			NavigateToACHFormPage();
			TestLogic.CreateIRAACHRequestTypeB("3.2", "10", "10", "REG", "AK", "autotest");
			if (TestLogic.VerifyErrorMessageForDuplicateRecord() == false) {
				TestLogic.SendACHRequest();
				NavigateToACHFormPage();
				TestLogic.CreateIRAACHRequestTypeB("3.2", "10", "10", "REG", "AK", "autotest");
				if (TestLogic.VerifyErrorMessageForDuplicateRecord()) {
					TestLogic.SendACHRequest();
				} else {
					throw new Exception("Failed");
				}
			}
			reporter.LogSuccess("VerifyACHFormSubmitTypeBwithFederalandStateTaxIRATest",
					"Successfully ACH IRA Request Submission for Type B with Federal and State Tax");
		} catch (Exception e) {
			reporter.LogFail("VerifyACHFormSubmitTypeBwithFederalandStateTaxIRATest", e.getMessage());
			throw e;
		}
	}

	// Test Case 18
	@Test
	public void VerifyACHBackButtonOnProcessACHPageTest() throws Exception {
		try {
			NavigateToACHFormPage();
			TestLogic.CreateACHIRARequestTypeA("4", "10", "10", "REG", "AK");
			TestLogic.VerifyBackBtnOnACHProcess();
			Assert.isTrue(TestLogic.VerifyReqAmount(), "Requested Amount Verified");
			reporter.LogSuccess("VerifyACHBackButtonOnProcessACHPageTest",
					"Back Button Successfully Clicked and Requested Amount Verified");
		} catch (Exception e) {
			reporter.LogFail("VerifyACHBackButtonOnProcessACHPageTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 19
	@Test
	public void VerifyDistributionTypeTest() throws Exception {
		try {
			NavigateToACHFormPage();
			TestLogic.CreateACHIRARequestTypeA("4", "10", "10", "REG", "AK");
			TestLogic.VerifyBackBtnOnACHProcess();
			Assert.isTrue(TestLogic.VerifyDistributionType(), "Distribution Type Verified");
			reporter.LogSuccess("VerifyDistributionTypeTest",
					"Back Button Successfully Clicked and Distribution Type Verified");
		} catch (Exception e) {
			reporter.LogFail("VerifyDistributionTypeTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 20
	@Test
	public void VerifyDistributionTypeWithAttachmentTest() throws Exception {
		try {
			NavigateToACHFormPage();
			Assert.isTrue(TestLogic.VerifyDistributionTypeWithAttachment("3.2", "10", "10", "REG", "AK", "autotest"),
					"Distribution Type Verified");
			reporter.LogSuccess("VerifyDistributionTypeTest",
					"Back Button Successfully Clicked and Distribution Type Verified");
		} catch (Exception e) {
			reporter.LogFail("VerifyDistributionTypeTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 21
	@Test
	public void VerifyACHFormSubmitTypeDwithStateTaxIRATest() throws Exception {
		try {
			NavigateToACHFormPage();
			TestLogic.CreateACHIRARequestTypeD("4.4", "0", "10", "REG", "AK", "autotest");
			if (TestLogic.VerifyErrorMessageForDuplicateRecord() == false) {
				TestLogic.SendACHRequest();
				NavigateToACHFormPage();
				TestLogic.CreateACHIRARequestTypeD("4.4", "0", "10", "REG", "AK", "autotest");
				if (TestLogic.VerifyErrorMessageForDuplicateRecord()) {
					TestLogic.SendACHRequest();
				} else {
					throw new Exception("Failed");
				}
			}
			reporter.LogSuccess("VerifyACHFormSubmitTypeDwithStateTaxIRATest",
					"Successfully ACH IRA Request Submission for Type D with State Tax");
		} catch (Exception e) {
			reporter.LogFail("VerifyACHFormSubmitTypeDwithStateTaxIRATest", e.getMessage());
			throw e;
		}
	}

	// Test Case 22
	@Test
	public void VerifyACHFormSubmitTypeDwithFederalandStateTaxIRATest() throws Exception {
		try {
			NavigateToACHFormPage();
			TestLogic.CreateACHIRARequestTypeD("4.5", "10", "10", "REG", "AK", "autotest");
			if (TestLogic.VerifyErrorMessageForDuplicateRecord() == false) {
				TestLogic.SendACHRequest();
				NavigateToACHFormPage();
				TestLogic.CreateACHIRARequestTypeD("4.5", "10", "10", "REG", "AK", "autotest");
				if (TestLogic.VerifyErrorMessageForDuplicateRecord()) {
					TestLogic.SendACHRequest();
				} else {
					throw new Exception("Failed");
				}
			}
			reporter.LogSuccess("VerifyACHFormSubmitTypeDwithFederalandStateTaxIRATest",
					"Successfully ACH IRA Request Submission for Type D with Federal and State Tax");
		} catch (Exception e) {
			reporter.LogFail("VerifyACHFormSubmitTypeDwithFederalandStateTaxIRATest", e.getMessage());
			throw e;
		}
	}

	// Test Case 23
	@Test
	public void VerifyACHFormSubmitTypeDwithFederalTaxIRATest() throws Exception {
		try {
			NavigateToACHFormPage();
			TestLogic.CreateACHIRARequestTypeD("4.6", "10", "0", "REG", "AK", "autotest");
			if (TestLogic.VerifyErrorMessageForDuplicateRecord() == false) {
				TestLogic.SendACHRequest();
				NavigateToACHFormPage();
				TestLogic.CreateACHIRARequestTypeD("4.6", "10", "0", "REG", "AK", "autotest");
				if (TestLogic.VerifyErrorMessageForDuplicateRecord()) {
					TestLogic.SendACHRequest();
				} else {
					throw new Exception("Failed");
				}
			}
			reporter.LogSuccess("VerifyACHFormSubmitTypeDwithFederalTaxIRATest",
					"Successfully ACH IRA Request Submission for Type D with Federal Tax");
		} catch (Exception e) {
			reporter.LogFail("VerifyACHFormSubmitTypeDwithFederalTaxIRATest", e.getMessage());
			throw e;
		}
	}

	// Test Case 24
	@Test
	public void VerifyRequestedAmountFieldUnderBankInfoTest() throws Exception {
		try {
			NavigateToACHFormPage();
			Assert.isTrue(TestLogic.VerifyRequestedAmountWithholding(),
					"Requested Amount Verfied Under Bank Information");
			reporter.LogSuccess("VerifyRequestedAmountFieldUnderBankInfoTest",
					"Requested Amount Verfied Under Bank Information");
		} catch (Exception e) {
			reporter.LogFail("VerifyRequestedAmountFieldUnderBankInfoTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 25
	@Test
	public void VerifyWarningPopUpforYesAdvisoryAccountIRATest() throws Exception {
		try {
			NavigateToACHFormPageAdvisory();
			Assert.isTrue(TestLogic.VerifyWarningPopUpforYesRadionBtnAdvisoryAccountIRA(
					"You have indicated that you are submitting a Program/Manager/Model/Allocation change for this account."),
					"Warning PopUp Verified For Advisory Acc Withdrawal Info Yes");
			reporter.LogSuccess("VerifyWarningPopUpforYesAdvisoryAccountTest",
					"Warning PopUp Verified For Advisory Acc Withdrawal Info Yes");
		} catch (Exception e) {
			reporter.LogFail("VerifyWarningPopUpforYesAdvisoryAccountTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 26
	@Test
	public void VerifyWarningPopUpforNoDistributionTypeIRATest() throws Exception {
		try {
			NavigateToACHFormPageAdvisory();
			Assert.isTrue(TestLogic.VerifyWarningPopUpforYesRadionBtnAdvisoryAccountIRA(
					"You have indicated that you are submitting a Program/Manager/Model/Allocation change for this account."),
					"Warning PopUp Verified For Advisory Acc Withdrawal Info Yes");
			reporter.LogSuccess("VerifyWarningPopUpforNoDistributionTypeIRATest",
					"Warning PopUp Verified For Advisory Acc Withdrawal Info Yes");
		} catch (Exception e) {
			reporter.LogFail("VerifyWarningPopUpforNoDistributionTypeIRATest", e.getMessage());
			throw e;
		}
	}

	// Test Case 27
	@Test
	public void VerifyACHFormSubmitTypeAwithAdvisoryAccIRATest() throws Exception {
		try {
			NavigateToACHFormPageAdvisory();
			TestLogic.CreateACHIRARequestAdvisoryAccTypeA("5.1", "", "10", "10", "BCHK", "AK");
			if (TestLogic.VerifyErrorMessageForDuplicateRecord() == false) {
				TestLogic.SendACHRequest();
				NavigateToACHFormPageAdvisory();
				TestLogic.CreateACHIRARequestAdvisoryAccTypeA("5.1", "", "10", "10", "BCHK", "AK");
				if (TestLogic.VerifyErrorMessageForDuplicateRecord()) {
					TestLogic.SendACHRequest();
				} else {
					throw new Exception("Failed");
				}
			}
			reporter.LogSuccess("VerifyACHFormSubmitTypeAwithAdvisoryAccIRATest",
					"Successfully ACH IRA Request Submission for Type A with Advisory Account");
		} catch (Exception e) {
			reporter.LogFail("VerifyACHFormSubmitTypeAwithAdvisoryAccIRATest", e.getMessage());
			throw e;
		}
	}

	// Test Case 28
	@Test
	public void VerifyACHFormSubmitTypeBwithAdvisoryAccIRATest() throws Exception {
		try {
			NavigateToACHFormPageAdvisory();
			TestLogic.CreateACHIRARequestAdvisoryAccTypeB("5.2", "10", "10", "BCHK", "AK", "AutoTest");
			if (TestLogic.VerifyErrorMessageForDuplicateRecord() == false) {
				TestLogic.SendACHRequest();
				NavigateToACHFormPageAdvisory();
				TestLogic.CreateACHIRARequestAdvisoryAccTypeB("5.2", "10", "10", "BCHK", "AK", "AutoTest");
				if (TestLogic.VerifyErrorMessageForDuplicateRecord()) {
					TestLogic.SendACHRequest();
				} else {
					throw new Exception("Failed");
				}
			}
			reporter.LogSuccess("VerifyACHFormSubmitTypeBwithAdvisoryAccIRATest",
					"Successfully ACH IRA Request Submission for Type B with Advisory Account");
		} catch (Exception e) {
			reporter.LogFail("VerifyACHFormSubmitTypeBwithAdvisoryAccIRATest", e.getMessage());
			throw e;
		}
	}

	// Test Case 29
	@Test
	public void VerifyACHFormSubmitTypeDwithAdvisoryAccIRATest() throws Exception {
		try {
			NavigateToACHFormPageAdvisory();
			TestLogic.CreateACHIRARequestAdvisoryAccTypeD("5.2", "10", "10", "BCHK", "AK", "AutoTest");
			if (TestLogic.VerifyErrorMessageForDuplicateRecord() == false) {
				TestLogic.SendACHRequest();
				NavigateToACHFormPageAdvisory();
				TestLogic.CreateACHIRARequestAdvisoryAccTypeD("5.2", "10", "10", "BCHK", "AK", "AutoTest");
				if (TestLogic.VerifyErrorMessageForDuplicateRecord()) {
					TestLogic.SendACHRequest();
				} else {
					throw new Exception("Failed");
				}
			}
			reporter.LogSuccess("VerifyACHFormSubmitTypeDwithAdvisoryAccIRATest",
					"Successfully ACH IRA Request Submission for Type D with Advisory Account");
		} catch (Exception e) {
			reporter.LogFail("VerifyACHFormSubmitTypeDwithAdvisoryAccIRATest", e.getMessage());
			throw e;
		}
	}

	// Test Case 30
	@Test
	public void VerifyACHContributionTypeSelectionIRATest() throws Exception {
		try {
			NavigateToACHFormPageAdvisory();
			Assert.isTrue(TestLogic.VerifyIntoBairdSelection("ROLI"),
					"Contribution Type Verified For In to Baird Selection");
			reporter.LogSuccess("VerifyACHContributionTypeSelectionIRATest",
					"Contribution Type Verified For In to Baird Selection");
		} catch (Exception e) {
			reporter.LogFail("VerifyACHContributionTypeSelectionIRATest", e.getMessage());
			throw e;
		}
	}

	// Test Case 31
	@Test
	public void VerifyACHFormSubmitTypeAUsingIntoBairdIRATest() throws Exception {
		try {
			NavigateToACHFormPage();
			TestLogic.CreateACHRequestTypeAwithIntoBairdIRA("2.21", "ROLI", "AK");
			if (TestLogic.VerifyErrorMessageForDuplicateRecord() == false) {
				TestLogic.SendACHRequest();
				NavigateToACHFormPage();
				TestLogic.CreateACHRequestTypeAwithIntoBairdIRA("2.21", "ROLI", "AK");
				if (TestLogic.VerifyErrorMessageForDuplicateRecord()) {
					TestLogic.SendACHRequest();
				} else {
					throw new Exception("Failed");
				}
			}
			reporter.LogSuccess("VerifyACHFormSubmitTypeAUsingIntoBairdIRATest",
					"Successfully ACH Request Submission Using Into Baird Account For Type A");
		} catch (Exception e) {
			reporter.LogFail("VerifyACHFormSubmitTypeAUsingIntoBairdIRATest", e.getMessage());
			throw e;
		}
	}

	// Test Case 32
	@Test
	public void VerifyWarningPopUpForDescriptionDropdownTest() throws Exception {
		try {
			NavigateToACHFormPageAdvisory();
			TestLogic.CreateACHRequestTypeAwithIntoBairdIRA("1", "ROLI", "AK");
			Assert.isTrue(TestLogic.VerifyErrorMessageWithInvalidAccount("A description for this deposit is required."),
					"Error Pop Verified When Select Description Dropdown Is Not Selected");
			reporter.LogSuccess("VerifyWarningPopUpForDescriptionDropdownTest",
					"Error Pop Verified When Select Description Dropdown Is Not Selected");
		} catch (Exception e) {
			reporter.LogFail("VerifyWarningPopUpForDescriptionDropdownTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 33
	@Test
	public void VerifyWarningPopUpNoContributionTypeTest() throws Exception {
		try {
			NavigateToACHFormPage();
			TestLogic.CreateACHRequestTypeAwithIntoBairdIRA("1", "", "AK");
			Assert.isTrue(TestLogic.VerifyErrorMessageWithInvalidAccount("Required Information Missing:"),
					"Error Pop Verified When Contribution Type Is Not Selected");
			reporter.LogSuccess("VerifyWarningPopUpNoContributionTypeTest",
					"Error Pop Verified When Contribution Type Is Not Selected");
		} catch (Exception e) {
			reporter.LogFail("VerifyWarningPopUpNoContributionTypeTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 34
	@Test
	public void VerifyACHFormSubmitTypeAwithSLOAIRATest() throws Exception {
		try {
			NavigateToACHFormPageAdvisory();
			TestLogic.CreateACHIRARequestAdvisoryAccTypeA("6.1", "Baird", "10", "10", "BCHK", "AK");
			if (TestLogic.VerifyErrorMessageForDuplicateRecord() == false) {
				TestLogic.SendACHRequest();
				NavigateToACHFormPageAdvisory();
				TestLogic.CreateACHIRARequestAdvisoryAccTypeA("6.1", "Baird", "10", "10", "BCHK", "AK");
				if (TestLogic.VerifyErrorMessageForDuplicateRecord()) {
					TestLogic.SendACHRequest();
				} else {
					throw new Exception("Failed");
				}
			}
			reporter.LogSuccess("VerifyACHFormSubmitTypeAwithSLOAIRATest",
					"Successfully ACH IRA Request Submission for Type A with SLOA");
		} catch (Exception e) {
			reporter.LogFail("VerifyACHFormSubmitTypeAwithSLOAIRATest", e.getMessage());
			throw e;
		}
	}

	// Test Case 35
	@Test
	public void VerifyWarningPopUpWithoutFederalTaxTest() throws Exception {
		try {
			NavigateToACHFormPageAdvisory();
			TestLogic.CreateACHIRARequestAdvisoryAccTypeA("6.1", "", "", "", "BCHK", "AK");
			Assert.isTrue(TestLogic.VerifyErrorMessageWithInvalidAccount(
					"Please complete the amounts to be withheld from the ACH.  If nothing is to be withheld, indicate zero in the fields."),
					"Error Pop Verified When Federal Tax Is Not Selected");
			reporter.LogSuccess("VerifyWarningPopUpWithoutFederalTaxTest",
					"Error Pop Verified When Federal Tax Is Not Selected");
		} catch (Exception e) {
			reporter.LogFail("VerifyWarningPopUpWithoutFederalTaxTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 36
	@Test
	public void VerifyWarningPopUpWithoutStateTaxTest() throws Exception {
		try {
			NavigateToACHFormPageAdvisory();
			TestLogic.CreateACHIRARequestAdvisoryAccTypeA("6.1", "", "", "", "BCHK", "AK");
			Assert.isTrue(TestLogic.VerifyErrorMessageWithInvalidAccount(
					"Please complete the percentage or amounts to be withheld from the ACH.  If nothing is to be withheld, indicate zero in the fields."),
					"Error Pop Verified When State Tax Is Not Selected");
			reporter.LogSuccess("VerifyWarningPopUpWithoutStateTaxTest",
					"Error Pop Verified When State Tax Is Not Selected");
		} catch (Exception e) {
			reporter.LogFail("VerifyWarningPopUpWithoutStateTaxTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 37
	@Test
	public void VerifyWarningPopUpWithoutAttestationTest() throws Exception {
		try {
			NavigateToACHFormPageAdvisory();
			TestLogic.CreateACHIRARequestAdvisoryAccTypeA("6.1", "", "10", "", "BCHK", "AK");
			Assert.isTrue(TestLogic.VerifyErrorMessageWithInvalidAccount(
					"Please complete the amounts to be withheld from the ACH.  If nothing is to be withheld, indicate zero in the fields."),
					"Error Pop Verified When State Tax Is Not Selected");
			reporter.LogSuccess("VerifyWarningPopUpWithoutAttestationTest",
					"Error Pop Verified When State Tax Is Not Selected");
		} catch (Exception e) {
			reporter.LogFail("VerifyWarningPopUpWithoutAttestationTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 38
	@Test
	public void VerifyWarningPopUpForInvalidFederalTaxTest() throws Exception {
		try {
			NavigateToACHFormPageAdvisory();
			TestLogic.VerifyWarningPopUpForInvalidFederalTax("6", "abcd");
			Assert.isTrue(
					TestLogic.VerifyErrorMessageWithInvalidAccount(
							"Format is invalid, format with numeric characters only"),
					"Error Pop Verified When Federal Tax Is Invalid");
			reporter.LogSuccess("VerifyWarningPopUpForInvalidFederalTaxTest",
					"Error Pop Verified When Federal Tax Is Invalid");
		} catch (Exception e) {
			reporter.LogFail("VerifyWarningPopUpForInvalidFederalTaxTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 39
	@Test
	public void VerifyWarningPopUpForInvalidStateTaxTest() throws Exception {
		try {
			NavigateToACHFormPageAdvisory();
			TestLogic.VerifyWarningPopUpForInvalidStateTax("6", "10", "abcd");
			Assert.isTrue(
					TestLogic.VerifyErrorMessageWithInvalidAccount(
							"Format is invalid, format with numeric characters only"),
					"Error Pop Verified When Federal Tax Is Invalid");
			reporter.LogSuccess("VerifyWarningPopUpForInvalidStateTaxTest",
					"Error Pop Verified When Federal Tax Is Invalid");
		} catch (Exception e) {
			reporter.LogFail("VerifyWarningPopUpForInvalidStateTaxTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 40
	@Test
	public void VerifyWarningPopUpWithoutAttachmentTest() throws Exception {
		try {
			NavigateToACHFormPageAdvisory();
			TestLogic.CreateACHIRARequestTypeBWithoutAttachment("5", "10", "10", "BCHK", "AK", "AutoTest");
			Assert.isTrue(
					TestLogic.VerifyErrorMessageWithInvalidAccount(
							"This ACH requires an IRA Distribution and Withholding Election Form"),
					"Error Pop Verified When Attachment Is Not Attached");
			reporter.LogSuccess("VerifyWarningPopUpWithoutAttachmentTest",
					"Error Pop Verified When Attachment Is Not Attached");
		} catch (Exception e) {
			reporter.LogFail("VerifyWarningPopUpWithoutAttachmentTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 41
	@Test
	public void VerifyIRATypeFieldTest() throws Exception {
		try {
			NavigateToACHFormPageAdvisory();
			Assert.isTrue(TestLogic.VerifyIRATypeField(), "IRA Type Field Verified");
			reporter.LogSuccess("VerifyIRATypeFieldTest", "IRA Type Field Verified");
		} catch (Exception e) {
			reporter.LogFail("VerifyIRATypeFieldTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 42
	@Test
	public void VerifyACHIRAFormSubmitDistRecordTypeATest() throws Exception {
		try {
			NavigateToACHFormPage();
			TestLogic.CreateDistRecordTypeA(".1", "AK");
			if (TestLogic.VerifyErrorMessageForDuplicateRecord() == false) {
				TestLogic.SendACHRequest();
				NavigateToACHFormPage();
				TestLogic.CreateDistRecordTypeA(".1", "AK");
				if (TestLogic.VerifyErrorMessageForDuplicateRecord()) {
					TestLogic.SendACHRequest();
				} else {
					throw new Exception("Failed");
				}
			}
			reporter.LogSuccess("VerifyACHIRAFormSubmitDistRecordTypeATest",
					"Successfully ACH IRA Request Submission for Dist Type A");
		} catch (Exception e) {
			reporter.LogFail("VerifyACHIRAFormSubmitDistRecordTypeATest", e.getMessage());
			throw e;
		}
	}

	// Test Case 43
	@Test
	public void VerifyACHIRAFormSubmitDistRecordTypeBTest() throws Exception {
		try {
			NavigateToACHFormPage();
			TestLogic.CreateDistRecordTypeB(".2", "AK", "Test");
			if (TestLogic.VerifyErrorMessageForDuplicateRecord() == false) {
				TestLogic.SendACHRequest();
				NavigateToACHFormPage();
				TestLogic.CreateDistRecordTypeB(".2", "AK", "Test");
				if (TestLogic.VerifyErrorMessageForDuplicateRecord()) {
					TestLogic.SendACHRequest();
				} else {
					throw new Exception("Failed");
				}
			}
			reporter.LogSuccess("VerifyACHIRAFormSubmitDistRecordTypeATest",
					"Successfully ACH IRA Request Submission for Dist Type B");
		} catch (Exception e) {
			reporter.LogFail("VerifyACHIRAFormSubmitDistRecordTypeATest", e.getMessage());
			throw e;
		}
	}

	// Test Case 44
	@Test
	public void VerifyACHIRAFormSubmitDistRecordTypeCTest() throws Exception {
		try {
			NavigateToACHFormPage();
			TestLogic.CreateDistRecordTypeC(".3", "AK", "Test");
			if (TestLogic.VerifyErrorMessageForDuplicateRecord() == false) {
				TestLogic.SendACHRequest();
				NavigateToACHFormPage();
				TestLogic.CreateDistRecordTypeC(".3", "AK", "Test");
				if (TestLogic.VerifyErrorMessageForDuplicateRecord()) {
					TestLogic.SendACHRequest();
				} else {
					throw new Exception("Failed");
				}
			}
			reporter.LogSuccess("VerifyACHIRAFormSubmitDistRecordTypeATest",
					"Successfully ACH IRA Request Submission for Dist Type C");
		} catch (Exception e) {
			reporter.LogFail("VerifyACHIRAFormSubmitDistRecordTypeATest", e.getMessage());
			throw e;
		}
	}

	// Test Case 45
	@Test
	public void VerifyACHIRAFormSubmitDistRecordTypeDTest() throws Exception {
		try {
			NavigateToACHFormPage();
			TestLogic.CreateDistRecordTypeD(".4", "AK", "Test");
			if (TestLogic.VerifyErrorMessageForDuplicateRecord() == false) {
				TestLogic.SendACHRequest();
				NavigateToACHFormPage();
				TestLogic.CreateDistRecordTypeD(".4", "AK", "Test");
				if (TestLogic.VerifyErrorMessageForDuplicateRecord()) {
					TestLogic.SendACHRequest();
				} else {
					throw new Exception("Failed");
				}
			}
			reporter.LogSuccess("VerifyACHIRAFormSubmitDistRecordTypeATest",
					"Successfully ACH IRA Request Submission for Dist Type D");
		} catch (Exception e) {
			reporter.LogFail("VerifyACHIRAFormSubmitDistRecordTypeATest", e.getMessage());
			throw e;
		}
	}

	// Test Case 46
	@Test
	public void VerifyACHIRAFormSubmitDistRecordTypeETest() throws Exception {
		try {
			NavigateToACHFormPage();
			TestLogic.CreateDistRecordTypeE(".5", "AK", "Test");
			if (TestLogic.VerifyErrorMessageForDuplicateRecord() == false) {
				TestLogic.SendACHRequest();
				NavigateToACHFormPage();
				TestLogic.CreateDistRecordTypeE(".5", "AK", "Test");
				if (TestLogic.VerifyErrorMessageForDuplicateRecord()) {
					TestLogic.SendACHRequest();
				} else {
					throw new Exception("Failed");
				}
			}
			reporter.LogSuccess("VerifyACHIRAFormSubmitDistRecordTypeATest",
					"Successfully ACH IRA Request Submission for Dist Type A");
		} catch (Exception e) {
			reporter.LogFail("VerifyACHIRAFormSubmitDistRecordTypeATest", e.getMessage());
			throw e;
		}
	}

	// Test Case 47
	@Test
	public void VerifyACHIRAFormSubmitDistRecordTypeFTest() throws Exception {
		try {
			NavigateToACHFormPage();
			TestLogic.CreateDistRecordTypeF(".6", "AK", "Test");
			if (TestLogic.VerifyErrorMessageForDuplicateRecord() == false) {
				TestLogic.SendACHRequest();
				NavigateToACHFormPage();
				TestLogic.CreateDistRecordTypeF(".6", "AK", "Test");
				if (TestLogic.VerifyErrorMessageForDuplicateRecord()) {
					TestLogic.SendACHRequest();
				} else {
					throw new Exception("Failed");
				}
			}
			reporter.LogSuccess("VerifyACHIRAFormSubmitDistRecordTypeATest",
					"Successfully ACH IRA Request Submission for Dist Type A");
		} catch (Exception e) {
			reporter.LogFail("VerifyACHIRAFormSubmitDistRecordTypeATest", e.getMessage());
			throw e;
		}
	}

	// Test Case 48
	@Test
	public void VerifyACHIRAFormSubmitDistRecordTypeGTest() throws Exception {
		try {
			NavigateToACHFormPage();
			TestLogic.CreateDistRecordTypeG(".7", "AK", "Test");
			if (TestLogic.VerifyErrorMessageForDuplicateRecord() == false) {
				TestLogic.SendACHRequest();
				NavigateToACHFormPage();
				TestLogic.CreateDistRecordTypeG(".7", "AK", "Test");
				if (TestLogic.VerifyErrorMessageForDuplicateRecord()) {
					TestLogic.SendACHRequest();
				} else {
					throw new Exception("Failed");
				}
			}
			reporter.LogSuccess("VerifyACHIRAFormSubmitDistRecordTypeATest",
					"Successfully ACH IRA Request Submission for Dist Type G");
		} catch (Exception e) {
			reporter.LogFail("VerifyACHIRAFormSubmitDistRecordTypeATest", e.getMessage());
			throw e;
		}
	}

	// Test Case 49
	@Test
	public void VerifyACHIRAFormSubmitDistRecordTypeAWithFederalStateTaxTest() throws Exception {
		try {
			NavigateToACHFormPageAdvisory();
			TestLogic.CreateDistRecordTypeAwithTax("2", "AK");
			if (TestLogic.VerifyErrorMessageForDuplicateRecord() == false) {
				TestLogic.SendACHRequest();
				NavigateToACHFormPageAdvisory();
				TestLogic.CreateDistRecordTypeAwithTax("2", "AK");
				if (TestLogic.VerifyErrorMessageForDuplicateRecord()) {
					TestLogic.SendACHRequest();
				} else {
					throw new Exception("Failed");
				}
			}
			reporter.LogSuccess("VerifyACHIRAFormSubmitDistRecordTypeAWithFederalStateTaxTest",
					"Successfully ACH IRA Request Submission for Dist Type A and 10% Federal & State Tax");
		} catch (Exception e) {
			reporter.LogFail("VerifyACHIRAFormSubmitDistRecordTypeAWithFederalStateTaxTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 50
	@Test
	public void VerifyACHIRAFormSubmitDistRecordTypeBWithFederalStateTaxTest() throws Exception {
		try {
			NavigateToACHFormPageAdvisory();
			TestLogic.CreateDistRecordTypeBwithTax(".9", "AK", "Test");
			if (TestLogic.VerifyErrorMessageForDuplicateRecord() == false) {
				TestLogic.SendACHRequest();
				NavigateToACHFormPageAdvisory();
				TestLogic.CreateDistRecordTypeBwithTax(".9", "AK", "Test");
				if (TestLogic.VerifyErrorMessageForDuplicateRecord()) {
					TestLogic.SendACHRequest();
				} else {
					throw new Exception("Failed");
				}
			}
			reporter.LogSuccess("VerifyACHIRAFormSubmitDistRecordTypeBWithFederalStateTaxTest",
					"Successfully ACH IRA Request Submission for Dist Type B and 10% Federal & State Tax");
		} catch (Exception e) {
			reporter.LogFail("VerifyACHIRAFormSubmitDistRecordTypeBWithFederalStateTaxTest", e.getMessage());
			throw e;
		}
	}
}
