package baird.LiquidOffice.TestSuite;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInfo;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ArgumentsSource;
import org.springframework.util.Assert;

import baird.LiquidOffice.Automation.BusinessLayer.CTAcheckFormTestLogic;
import baird.LiquidOffice.Automation.Resources.AccNoTypeData;
import baird.LiquidOffice.Automation.Resources.CTAformData;
import baird.core.Automation.Loggers.LogLevel;

/**
 * @author AmitaKumari
 */

public class CTAcheckRetailTests extends TestBase {

	CTAcheckFormTestLogic TestLogic = null;

	@BeforeEach
	public void TestInitialize(TestInfo info) {
		log.LogDebug(info.getDisplayName());
		TestLogic = new CTAcheckFormTestLogic(commonapi, testSettings);
	}

	// Test Case 1,2
	@ParameterizedTest
	@ArgumentsSource(CTAformData.class)
	public void VerifyCTAOpeningTest(CTAformData object) throws Exception {
		try {
			TestLogic.OpenCTApage(object.LoginMethod);
			Assert.isTrue(TestLogic.VerifySignInSuccess(), "Successfull Navigation Through " + object.LoginMethod);
			reporter.LogSuccess("VerifyCTAOpeningTest", "Successfull Navigation Through " + object.LoginMethod);
		} catch (Exception e) {
			reporter.LogFail("VerifyCTAOpeningTest",
					"Failed Navigation Through " + object.LoginMethod + " " + e.getMessage());
			throw e;
		}
	}

	@Test
	public void VerifyCTAOpeningThroughLogoTest() throws Exception {
		try {
			TestLogic.OpenCTApage("Logo");
			Assert.isTrue(TestLogic.VerifySignInSuccess(), "Successfull Navigation Through Logo");
			reporter.LogSuccess("VerifyCTAOpeningThroughLogoTest", "Successfull Navigation Through Logo");
		} catch (Exception e) {
			reporter.LogFail("VerifyCTAOpeningThroughLogoTest", e.getMessage());
			throw e;
		}
	}

	@Test
	public void VerifyCTAOpeningThroughSignInTest() throws Exception {
		try {
			TestLogic.OpenCTApage("SignIn");
			Assert.isTrue(TestLogic.VerifySignInSuccess(), "Successfull Navigation Through SignIn");
			reporter.LogSuccess("VerifyCTAOpeningThroughSignInTest", "Successfull Navigation to CTA Through SignIn");
		} catch (Exception e) {
			reporter.LogFail("VerifyCTAOpeningThroughSignInTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 3,4,5,6
	@ParameterizedTest
	@ArgumentsSource(AccNoTypeData.class)
	public void VerifyAccNumberTypeFieldTest(AccNoTypeData object) throws Exception {
		try {
			log.Log("Data Values" + object.AccNo, LogLevel.DEBUG);
			TestLogic.OpenCTApage("SignIn");
			TestLogic.GetClientInfo(object.AccNo, object.Type);
			// TestLogic.ClickContinueOnClientInfo();
			if (object.AccNo.isEmpty() && object.Type == null) {
				TestLogic.ClickContinueOnClientInfo();
				Assert.isTrue(TestLogic.VerifyErrorMessageWithNoAccount("A required field was found empty!"),
						"Error PopUp Verified with No Acc No");
				reporter.LogSuccess("VerifyAccNumberTypeFieldWithoutAccNoTest", "Error PopUp Verified for No Acc Type");
			} else if (object.AccNo.contains("abcdefgh") && object.Type == null) {
				TestLogic.ClickContinueOnClientInfo();
				Assert.isTrue(TestLogic.VerifyErrorMessageWithInvalidAccount("Invalid character(s)"),
						"Error PopUp Verified with Invalid Acc No");
				reporter.LogSuccess("VerifyErrorMessageWithInvalidAccNoTest",
						"Error PopUp Verified for Invalid Acc No");
			} else if (object.AccNo.contains("21212142") && object.Type == null) {
				TestLogic.ClickContinueOnClientInfo();
				Assert.isTrue(TestLogic.VerifyErrorMessageWithNoType("A required field was found empty!"),
						"Error PopUp Verified with No Type");
				reporter.LogSuccess("VerifyErrorMessageWithNoTypeTest", "Error PopUp Verified for No Type");
			} else if (object.AccNo.contains("54535457") && object.Type.contains("Check Request")) {
				TestLogic.ClickContinueOnClientInfo();
				Assert.isTrue(TestLogic.VerifyRetrievedClientTitle(), "Page Title Verified");
				reporter.LogSuccess("VerifyRetrievedClientInfoPageOpeningTest", "Page Title Verified");
			}
		} catch (Exception e) {
			if (object.AccNo.isEmpty() && object.Type == null) {
				reporter.LogFail("VerifyAccNumberTypeFieldWithoutAccNoTest", e.getMessage());
			} else if (object.AccNo.contains("abcdefgh") && object.Type == null) {
				reporter.LogFail("VerifyErrorMessageWithInvalidAccNoTest", e.getMessage());
			} else if (object.AccNo.contains("21212142") && object.Type == null) {
				reporter.LogFail("VerifyErrorMessageWithNoTypeTest", e.getMessage());
			} else if (object.AccNo.contains("54535457") && object.Type.contains("Check Request")) {
				reporter.LogFail("VerifyRetrievedClientInfoPageOpeningTest", e.getMessage());
			}
			throw e;
		}
	}

	@Test
	public void VerifyAccNumberTypeFieldWithoutAccNoTest() throws Exception {
		try {
			TestLogic.OpenCTApage("SignIn");
			TestLogic.GetClientInfo("", null);
			TestLogic.ClickContinueOnClientInfo();
			Assert.isTrue(TestLogic.VerifyErrorMessageWithNoAccount("A required field was found empty!"),
					"Error PopUp Verified with No Acc No");
			reporter.LogSuccess("VerifyAccNumberTypeFieldWithoutAccNoTest", "Error PopUp Verified with No Acc No");
		} catch (Exception e) {
			reporter.LogFail("VerifyAccNumberTypeFieldWithoutAccNoTest", e.getMessage());
			throw e;
		}
	}

	@Test
	public void VerifyErrorMessageWithInvalidAccNoTest() throws Exception {
		try {
			TestLogic.OpenCTApage("SignIn");
			TestLogic.GetClientInfo("abcdefgh", null);
			TestLogic.ClickContinueOnClientInfo();
			Assert.isTrue(TestLogic.VerifyErrorMessageWithInvalidAccount("Invalid character(s)"),
					"Error PopUp Verified with Invalid Acc No");
			reporter.LogSuccess("VerifyErrorMessageWithInvalidAccNoTest", "Error PopUp Verified with Invalid Acc No");
		} catch (Exception e) {
			reporter.LogFail("VerifyErrorMessageWithInvalidAccNoTest", e.getMessage());
			throw e;
		}
	}

	@Test
	public void VerifyErrorMessageWithNoTypeTest() throws Exception {
		try {
			TestLogic.OpenCTApage("SignIn");
			TestLogic.GetClientInfo("21212142", null);
			TestLogic.ClickContinueOnClientInfo();
			Assert.isTrue(TestLogic.VerifyErrorMessageWithNoType("A required field was found empty!"),
					"Error PopUp Verified with No Type");
			reporter.LogSuccess("VerifyErrorMessageWithNoTypeTest", "Error PopUp Verified with No Type");
		} catch (Exception e) {
			reporter.LogFail("VerifyErrorMessageWithNoTypeTest", e.getMessage());
			throw e;
		}
	}

	@Test
	public void VerifyRetrievedClientInfoPageOpeningTest() throws Exception {
		try {
			TestLogic.OpenCTApage("SignIn");
			TestLogic.GetClientInfo("54535457", "Check Request");
			TestLogic.ClickContinueOnClientInfo();
			Assert.isTrue(TestLogic.VerifyRetrievedClientTitle(), "Page Title Verified");
			reporter.LogSuccess("VerifyRetrievedClientInfoPageOpeningTest", "Page Title Verified");
		} catch (Exception e) {
			reporter.LogFail("VerifyRetrievedClientInfoPageOpeningTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 7
	@Test
	public void VerifyAccRegistrationFieldTest() throws Exception {
		try {
			TestLogic.OpenCTApage("SignIn");
			TestLogic.GetClientInfo("34780866", "Check Request");
			Assert.isTrue(TestLogic.VerifyAccountRegistration(),
					"Ciient Name and Address Verified Under Account Registration");
			reporter.LogSuccess("VerifyAccRegistrationFieldTest",
					"Ciient Name and Address Verified Under Account Registration");
		} catch (Exception e) {
			reporter.LogFail("VerifyAccRegistrationFieldTest", e.getMessage());
			throw e;
		}
	}

	void NavigateToCheckFormPage() throws Exception {
		TestLogic.OpenCTApage("SignIn");
		TestLogic.GetClientInfo("34780866", "Check Request");
		TestLogic.ClickContinueOnClientInfo();
	}

	// Test Case 8
	@Test
	public void VerifyCashAmountAutoPopulateTest() throws Exception {
		try {
			TestLogic.OpenCTApage("SignIn");
			TestLogic.GetClientInfo("21212142", "Check Request");
			TestLogic.ClickContinueOnClientInfo();
			Assert.isTrue(TestLogic.VerifyCashAmount(), "Cash Verified");
			reporter.LogSuccess("VerifyDeliveryMethodSelectionTest", "Delivery Method Selected");
		} catch (Exception e) {
			reporter.LogFail("VerifyDeliveryMethodSelectionTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 9
	@Test
	public void VerifyCashMoneySelectionFromDropdownTest() throws Exception {
		try {
			NavigateToCheckFormPage();
			TestLogic.SelectCashorIDPfund("Cash");
			reporter.LogSuccess("VerifyCashMoneySelectionFromDropdownTest", "Cash Selected From the Dropdown");
		} catch (Exception e) {
			reporter.LogFail("VerifyCashMoneySelectionFromDropdownTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 10
	@Test
	public void VerifyAccTypeMarginSelectionTest() throws Exception {
		try {
			NavigateToCheckFormPage();
			Assert.isTrue(TestLogic.VerifyWarningPopUpforMargin("ID3", "If Account Type is Margin"), "Error PopUp Verified");
			Assert.isTrue(TestLogic.VerifyCashAutoPopulatesForMargin(), "Cash Verified");
			reporter.LogSuccess("VerifyAccTypeMarginSelectionTest", "Acc Type Margin Selected");
		} catch (Exception e) {
			reporter.LogFail("VerifyAccTypeMarginSelectionTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 11
	@Test
	public void VerifyCurrentCheckIssueDateTest() throws Exception {
		try {
			NavigateToCheckFormPage();
			Assert.isTrue(TestLogic.VerifyCheckIssueDateForCurrentDate(), "Current Check Issue Date Verified");
			reporter.LogSuccess("VerifyCurrentCheckIssueDateTest", "Current Check Issue Date Verified");
		} catch (Exception e) {
			reporter.LogFail("VerifyCurrentCheckIssueDateTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 12
	@Test
	public void VerifyFutureCheckIssueDateTest() throws Exception {
		try {
			NavigateToCheckFormPage();
			TestLogic.VerifyCheckIssueDateForFutureDate(IssueDate7DaysFromCurrentDate());
			TestLogic.CreateCheckRequestTypeA(".33", "Cash", "Check Issued", "AK");
			if (TestLogic.VerifyErrorMessageForDuplicateRecord() == false) {
				TestLogic.SendCheckRequest();
				NavigateToCheckFormPage();
				TestLogic.VerifyCheckIssueDateForFutureDate(IssueDate7DaysFromCurrentDate());
				TestLogic.CreateCheckRequestTypeA(".33", "Cash", "Check Issued", "AK");
				if (TestLogic.VerifyErrorMessageForDuplicateRecord()) {
					TestLogic.SendCheckRequest();
				} else {
					throw new Exception("Failed");
				}
			}
			reporter.LogSuccess("VerifyFutureCheckIssueDateTest",
					"Successfully Check Request Submission For Future Check Issue Date");
		} catch (Exception e) {
			reporter.LogFail("VerifyFutureCheckIssueDateTest", e.getMessage());
			throw e;
		}
	}

	public String IssueDate7DaysFromCurrentDate() {
		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		Calendar cal = Calendar.getInstance();
		cal.setTime(new Date());
		cal.add(Calendar.DATE, 7);
		String newDate = dateFormat.format(cal.getTime());
		return newDate;
	}

	// Test Case 13
	@Test
	public void VerifyWarningPopUpForCheckIssueDate15DaysFromCurrentDateTest() throws Exception {
		try {
			NavigateToCheckFormPage();
			TestLogic.VerifyCheckIssueDateForFutureDate(IssueDate15DaysFromCurrentDate());
			Assert.isTrue(
					TestLogic.VerifyWarningPopUpforCheckIssueDate("The check issed date exceeds 10 business days."),
					"Warning PopUp Verified For Check Issue Date is After 10 days From Current Date");
			reporter.LogSuccess("VerifyWarningPopUpForCheckIssueDate15DaysFromCurrentDateTest",
					"Warning PopUp Verified For Check Issue Date is After 10 days From Current Date");
		} catch (Exception e) {
			reporter.LogFail("VerifyWarningPopUpForCheckIssueDate15DaysFromCurrentDateTest", e.getMessage());
			throw e;
		}
	}

	public String IssueDate15DaysFromCurrentDate() {
		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		Calendar cal = Calendar.getInstance();
		cal.setTime(new Date());
		cal.add(Calendar.DATE, 15);
		String newDate = dateFormat.format(cal.getTime());
		return newDate;
	}

	// Test Case 14
	@Test
	public void VerifyDeliveryMethodAutoPopulatesTest() throws Exception {
		try {
			NavigateToCheckFormPage();
			Assert.isTrue(TestLogic.VerifyDeliveryMethod(), "Sent to Payee");
			reporter.LogSuccess("VerifyDeliveryMethodAutoPopulatesTest", "Delivery Method Auto Populated");
		} catch (Exception e) {
			reporter.LogFail("VerifyDeliveryMethodAutoPopulatesTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 15,16
	@Test
	public void VerifyPrintLocationBranchTest() throws Exception {
		try {
			NavigateToCheckFormPage();
			Assert.isTrue(TestLogic.VerifyPrintLocBranch("AA - Milwaukee Sales"), "Print to different location?");
			reporter.LogSuccess("VerifyPrintLocationBranchTest", "Branch Code Entered");
		} catch (Exception e) {
			reporter.LogFail("VerifyPrintLocationBranchTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 17
	@Test
	public void VerifyIDPMoneySelectionFromDropdownTest() throws Exception {
		try {
			NavigateToCheckFormPage();
			TestLogic.SelectCashorIDPfund("IDP");
			reporter.LogSuccess("VerifyIDPMoneySelectionFromDropdownTest", "IDP Fund Selected From the Dropdown");
		} catch (Exception e) {
			reporter.LogFail("VerifyIDPMoneySelectionFromDropdownTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 18
	@Test
	public void VerifyDeliveryMethodSelectionTest() throws Exception {
		try {
			NavigateToCheckFormPage();
			TestLogic.SelectDeliveryMethod("Mailed to Client");
			reporter.LogSuccess("VerifyDeliveryMethodSelectionTest", "Delivery Method Selected Successfully");
		} catch (Exception e) {
			reporter.LogFail("VerifyDeliveryMethodSelectionTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 21
	@Test
	public void VerifyErrorPopUpForInvalidAmountTest() throws Exception {
		try {
			NavigateToCheckFormPage();
			TestLogic.VerifyInvalidAmount("jj");
			Assert.isTrue(
					TestLogic.VerifyErrorMessageWithInvalidAmount(
							"Format is invalid, format with numeric characters only"),
					"Error PopUp Verified For Invalid Amount");
			reporter.LogSuccess("VerifyErrorPopUpForInvalidAmountTest", "Error PopUp Verified for Invalid Amount");
		} catch (Exception e) {
			reporter.LogFail("VerifyErrorPopUpForInvalidAmountTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 22
	@Test
	public void VerifyCheckPayeeInformationTest() throws Exception {
		try {
			NavigateToCheckFormPage();
			Assert.isTrue(TestLogic.VerifyPayeeInformation(), "Payee Information Verified");
			reporter.LogSuccess("VerifyPayeeInformationTest", "Payee Information Verified");
		} catch (Exception e) {
			reporter.LogFail("VerifyPayeeInformationTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 23,19,20
	@Test
	public void VerifyCheckFormSubmitTypeAwithCashTest() throws Exception {
		try {
			NavigateToCheckFormPage();
			TestLogic.CreateCheckRequestTypeA(".11", "Cash", "Check Issued", "AK");
			if (TestLogic.VerifyErrorMessageForDuplicateRecord() == false) {
				TestLogic.SendCheckRequest();
				NavigateToCheckFormPage();
				TestLogic.CreateCheckRequestTypeA(".11", "Cash", "Check Issued", "AK");
				if (TestLogic.VerifyErrorMessageForDuplicateRecord()) {
					TestLogic.SendCheckRequest();
				} else {
					throw new Exception("Failed");
				}
			}
			reporter.LogSuccess("VerifyCheckFormSubmitTypeAwithCashTest",
					"Successfully Check Request Submission for Type A with Cash Money");
		} catch (Exception e) {
			reporter.LogFail("VerifyCheckFormSubmitTypeAwithCashTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 24
	@Test
	public void VerifyCheckFormSubmitTypeAwithMMFTest() throws Exception {
		try {
			NavigateToCheckFormPage();
			TestLogic.CreateCheckRequestTypeA(".3", "ID3", "Check Issued", "AK");
			if (TestLogic.VerifyErrorMessageForDuplicateRecord() == false) {
				TestLogic.SendCheckRequest();
				NavigateToCheckFormPage();
				TestLogic.CreateCheckRequestTypeA(".3", "ID3", "Check Issued", "AK");
				if (TestLogic.VerifyErrorMessageForDuplicateRecord()) {
					TestLogic.SendCheckRequest();
				} else {
					throw new Exception("Failed");
				}
			}
			reporter.LogSuccess("VerifyCheckFormSubmitTypeAwithMMFTest",
					"Successfully Check Request Submission for Type A with IDP Fund");
		} catch (Exception e) {
			reporter.LogFail("VerifyCheckFormSubmitTypeAwithMMFTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 25
	@Test
	public void VerifyErrorPopUpforTypeCWithYesThirdPartyInfoTest() throws Exception {
		try {
			NavigateToCheckFormPage();
			TestLogic.VerifyErrorPopUpforTypeC(".5", "ID3", "Check Issued", "AK", "C");
			Assert.isTrue(
					TestLogic.VerifyErrorMessage("The following attachments are required for this check request:"),
					"Error PopUp Verified For Yes Third Party Information for Type C");
			reporter.LogSuccess("VerifyErrorPopUpforTypeCWithYesThirdPartyInfoTest",
					"Error PopUp Verified For Yes Third Party Information for Type C");
		} catch (Exception e) {
			reporter.LogFail("VerifyErrorPopUpforTypeCWithYesThirdPartyInfoTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 26
	@Test
	public void VerifyCheckFormSubmitTypeAwithSLOATest() throws Exception {
		try {
			NavigateToCheckFormPage();
			TestLogic.SelectSLOA("Auto Test");
			TestLogic.CreateCheckRequestTypeA(".6", "ID3", "Check Issued", "AK");
			if (TestLogic.VerifyErrorMessageForDuplicateRecord() == false) {
				TestLogic.SendCheckRequest();
				NavigateToCheckFormPage();
				TestLogic.SelectSLOA("Auto Test");
				TestLogic.CreateCheckRequestTypeA(".6", "ID3", "Check Issued", "AK");
				if (TestLogic.VerifyErrorMessageForDuplicateRecord()) {
					TestLogic.SendCheckRequest();
				} else {
					throw new Exception("Failed");
				}
			}
			reporter.LogSuccess("VerifyCheckFormSubmitTypeAwithSLOATest",
					"Successfully Check Request Submission for Type A with SLOA");
		} catch (Exception e) {
			reporter.LogFail("VerifyCheckFormSubmitTypeAwithSLOATest", e.getMessage());
			throw e;
		}
	}

	// Test Case 27
	@Test
	public void VerifyErrorPopUpforTypeDwithNoThirdPartyInfoTest() throws Exception {
		try {
			NavigateToCheckFormPage();
			TestLogic.VerifyErrorPopUpforTypeD(".4", "ID3", "Check Issued", "AK", "D");
			Assert.isTrue(
					TestLogic.VerifyErrorMessage("The following attachments are required for this check request:"),
					"Error PopUp Verified For No Third Party Information for Type D");
			reporter.LogSuccess("VerifyErrorPopUpforTypeDwithNoThirdPartyInfoTest",
					"Error PopUp Verified For No Third Party Information for Type D");
		} catch (Exception e) {
			reporter.LogFail("VerifyErrorPopUpforTypeDwithNoThirdPartyInfoTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 28
	@Test
	public void VerifyCheckFormSubmitTypeDwithCashTest() throws Exception {
		try {
			NavigateToCheckFormPage();
			TestLogic.CreateCheckRequestTypeB_C_D_E_F1(".9", "Cash", "Check Issued", "AK", "D");
			if (TestLogic.VerifyErrorMessageForDuplicateRecord() == false) {
				TestLogic.SendCheckRequest();
				NavigateToCheckFormPage();
				TestLogic.CreateCheckRequestTypeB_C_D_E_F1(".9", "Cash", "Check Issued", "AK", "D");
				if (TestLogic.VerifyErrorMessageForDuplicateRecord()) {
					TestLogic.SendCheckRequest();
				} else {
					throw new Exception("Failed");
				}
			}
			reporter.LogSuccess("VerifyCheckFormSubmitTypeDwithCashTest",
					"Successfully Check Request Submission for Type D with Cash Money");
		} catch (Exception e) {
			reporter.LogFail("VerifyCheckFormSubmitTypeDwithCashTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 29
	@Test
	public void VerifyWarningPopUpforYesAdvisoryAccountWithdrawalInfoTest() throws Exception {
		try {
			NavigateToCheckFormPage();
			Assert.isTrue(TestLogic.VerifyErrorMessageforYesAdvisoryAccount(
					"You have indicated that you are submitting a Program/Manager/Model/Allocation change for this account."),
					"Warning PopUp Verified For Advisory Acc Withdrawal Info Yes");
			reporter.LogSuccess("VerifyWarningPopUpforYesAdvisoryAccountWithdrawalInfoTest",
					"Warning PopUp Verified For Advisory Acc Withdrawal Info Yes");
		} catch (Exception e) {
			reporter.LogFail("VerifyWarningPopUpforYesAdvisoryAccountWithdrawalInfoTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 30
	@Test
	public void VerifyClearPayeeInformationTest() throws Exception {
		try {
			NavigateToCheckFormPage();
			Assert.isTrue(TestLogic.VerifyClearPayeeInformation(), "Clear Payee Information Verified");
			reporter.LogSuccess("VerifyClearPayeeInformationTest", "Clear Payee Information Verified");
		} catch (Exception e) {
			reporter.LogFail("VerifyClearPayeeInformationTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 31,32
	@Test
	public void VerifyCheckFormSubmitWithPayeeInstructionTest() throws Exception {
		try {
			NavigateToCheckFormPage();
			TestLogic.CreateCheckReqWithPayeeInstruction(".32", "Cash", "Check Issued", "AK");
			if (TestLogic.VerifyErrorMessageForDuplicateRecord() == false) {
				TestLogic.SendCheckRequest();
				NavigateToCheckFormPage();
				TestLogic.CreateCheckReqWithPayeeInstruction(".32", "Cash", "Check Issued", "AK");
				if (TestLogic.VerifyErrorMessageForDuplicateRecord()) {
					TestLogic.SendCheckRequest();
				} else {
					throw new Exception("Failed");
				}
			}
			reporter.LogSuccess("VerifyCheckFormSubmitWithPayeeInstructionTest",
					"Successfully Check Request Submission by adding Payee Instruction");
		} catch (Exception e) {
			reporter.LogFail("VerifyCheckFormSubmitWithPayeeInstructionTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 33
	@Test
	public void VerifyCheckFormSubmitWithAdditionalMemoLinesTest() throws Exception {
		try {
			NavigateToCheckFormPage();
			TestLogic.EnterAdditionalMemoLines("Automation Memo Lines");
			TestLogic.CreateCheckRequestTypeA(".31", "Cash", "Check Issued", "AK");
			if (TestLogic.VerifyErrorMessageForDuplicateRecord() == false) {
				TestLogic.SendCheckRequest();
				NavigateToCheckFormPage();
				TestLogic.EnterAdditionalMemoLines("Automation Memo Lines");
				TestLogic.CreateCheckRequestTypeA(".31", "Cash", "Check Issued", "AK");
				if (TestLogic.VerifyErrorMessageForDuplicateRecord()) {
					TestLogic.SendCheckRequest();
				} else {
					throw new Exception("Failed");
				}
			}
			reporter.LogSuccess("VerifyCheckFormSubmitWithAdditionalMemoLinesTest",
					"Successfully Check Request Submission with Additional Memo Lines");
		} catch (Exception e) {
			reporter.LogFail("VerifyCheckFormSubmitWithAdditionalMemoLinesTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 34
	@Test
	public void VerifyCheckFormSubmitTypeCwithMMFTest() throws Exception {
		try {
			NavigateToCheckFormPage();
			TestLogic.CreateCheckRequestTypeB_C_D_E_F1("1.1", "ID3", "Check Issued", "AK", "C");
			if (TestLogic.VerifyErrorMessageForDuplicateRecord() == false) {
				TestLogic.SendCheckRequest();
				NavigateToCheckFormPage();
				TestLogic.CreateCheckRequestTypeB_C_D_E_F1("1.1", "ID3", "Check Issued", "AK", "C");
				if (TestLogic.VerifyErrorMessageForDuplicateRecord()) {
					TestLogic.SendCheckRequest();
				} else {
					throw new Exception("Failed");
				}
			}
			reporter.LogSuccess("VerifyCheckFormSubmitTypeCwithMMFTest",
					"Successfully Check Request Submission for Type C with IDP Fund");
		} catch (Exception e) {
			reporter.LogFail("VerifyCheckFormSubmitTypeCwithMMFTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 35
	@Test
	public void VerifyCheckFormSubmitTypeCwithSLOATest() throws Exception {
		try {
			NavigateToCheckFormPage();
			TestLogic.SelectSLOA("Auto Test");
			TestLogic.CreateCheckRequestTypeB_C_D_E_F1("1.2", "Cash", "Check Issued", "AK", "C");
			if (TestLogic.VerifyErrorMessageForDuplicateRecord() == false) {
				TestLogic.SendCheckRequest();
				NavigateToCheckFormPage();
				TestLogic.SelectSLOA("Auto Test");
				TestLogic.CreateCheckRequestTypeB_C_D_E_F1("1.2", "Cash", "Check Issued", "AK", "C");
				if (TestLogic.VerifyErrorMessageForDuplicateRecord()) {
					TestLogic.SendCheckRequest();
				} else {
					throw new Exception("Failed");
				}
			}
			reporter.LogSuccess("VerifyCheckFormSubmitTypeCwithSLOATest",
					"Successfully Check Request Submission for Type C using SLOA");
		} catch (Exception e) {
			reporter.LogFail("VerifyCheckFormSubmitTypeCwithSLOATest", e.getMessage());
			throw e;
		}
	}

	// Test Case 36
	@Test
	public void VerifyErrorPopUpWhenNoAttestationTest() throws Exception {
		try {
			NavigateToCheckFormPage();
			TestLogic.VerifyErrorPopUpWithoutAttestation(".4", "Cash", "Check Issued", "A");
			Assert.isTrue(TestLogic.VerifyErrorMessage("Required Information Missing:"),
					"Error PopUp Verified For No Attestation");
			reporter.LogSuccess("VerifyErrorPopUpWhenNoAttestationTest", "Error Pop Verified For No Attestation");
		} catch (Exception e) {
			reporter.LogFail("VerifyErrorPopUpWhenNoAttestationTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 37
	@Test
	public void VerifyCheckFormSubmitTypeBwithCashTest() throws Exception {
		try {
			NavigateToCheckFormPage();
			TestLogic.CreateCheckRequestTypeB_C_D_E_F1("1.4", "Cash", "Check Issued", "AK", "B");
			if (TestLogic.VerifyErrorMessageForDuplicateRecord() == false) {
				TestLogic.SendCheckRequest();
				NavigateToCheckFormPage();
				TestLogic.CreateCheckRequestTypeB_C_D_E_F1("1.4", "Cash", "Check Issued", "AK", "B");
				if (TestLogic.VerifyErrorMessageForDuplicateRecord()) {
					TestLogic.SendCheckRequest();
				} else {
					throw new Exception("Failed");
				}
			}
			reporter.LogSuccess("VerifyCheckFormSubmitTypeBwithCashTest",
					"Successfully Check Request Submission for Type B with Cash Money");
		} catch (Exception e) {
			reporter.LogFail("VerifyCheckFormSubmitTypeBwithCashTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 38
	@Test
	public void VerifyCheckFormSubmitTypeBwithMMFTest() throws Exception {
		try {
			NavigateToCheckFormPage();
			TestLogic.CreateCheckRequestTypeB_C_D_E_F1("1.3", "ID3", "Check Issued", "AK", "B");
			if (TestLogic.VerifyErrorMessageForDuplicateRecord() == false) {
				TestLogic.SendCheckRequest();
				NavigateToCheckFormPage();
				TestLogic.CreateCheckRequestTypeB_C_D_E_F1("1.3", "ID3", "Check Issued", "AK", "B");
				if (TestLogic.VerifyErrorMessageForDuplicateRecord()) {
					TestLogic.SendCheckRequest();
				} else {
					throw new Exception("Failed");
				}
			}
			reporter.LogSuccess("VerifyCheckFormSubmitTypeBwithMMFTest",
					"Successfully Check Request Submission for Type B with IDP Fund");
		} catch (Exception e) {
			reporter.LogFail("VerifyCheckFormSubmitTypeBwithMMFTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 39
	@Test
	public void VerifyCheckFormSubmitTypeEwithCashTest() throws Exception {
		try {
			NavigateToCheckFormPage();
			TestLogic.CreateCheckRequestTypeB_C_D_E_F1("1.6", "Cash", "Check Issued", "AK", "E");
			if (TestLogic.VerifyErrorMessageForDuplicateRecord() == false) {
				TestLogic.SendCheckRequest();
				NavigateToCheckFormPage();
				TestLogic.CreateCheckRequestTypeB_C_D_E_F1("1.6", "Cash", "Check Issued", "AK", "E");
				if (TestLogic.VerifyErrorMessageForDuplicateRecord()) {
					TestLogic.SendCheckRequest();
				} else {
					throw new Exception("Failed");
				}
			}
			reporter.LogSuccess("VerifyCheckFormSubmitTypeEwithCashTest",
					"Successfully Check Request Submission for Type E with Cash Money");
		} catch (Exception e) {
			reporter.LogFail("VerifyCheckFormSubmitTypeEwithCashTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 40
	@Test
	public void VerifyCheckFormSubmitTypeEwithMMFTest() throws Exception {
		try {
			NavigateToCheckFormPage();
			TestLogic.CreateCheckRequestTypeB_C_D_E_F1("1.5", "IDP", "Check Issued", "AK", "E");
			if (TestLogic.VerifyErrorMessageForDuplicateRecord() == false) {
				TestLogic.SendCheckRequest();
				NavigateToCheckFormPage();
				TestLogic.CreateCheckRequestTypeB_C_D_E_F1("1.5", "IDP", "Check Issued", "AK", "E");
				if (TestLogic.VerifyErrorMessageForDuplicateRecord()) {
					TestLogic.SendCheckRequest();
				} else {
					throw new Exception("Failed");
				}
			}
			reporter.LogSuccess("VerifyCheckFormSubmitTypeEwithMMFTest",
					"Successfully Check Request Submission for Type E with IDP Fund");
		} catch (Exception e) {
			reporter.LogFail("VerifyCheckFormSubmitTypeEwithMMFTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 41
	@Test
	public void VerifyCheckFormSubmitTypeF1withCashTest() throws Exception {
		try {
			NavigateToCheckFormPage();
			TestLogic.EnterPayeeInformation("Automation", "17th Floor 777E", "", "Milwaukee", "WI", "53202");
			TestLogic.CreateCheckRequestTypeF1("2.6", "Cash", "Check Issued", "AK", "F1");
			if (TestLogic.VerifyErrorMessageForDuplicateRecord() == false) {
				TestLogic.SendCheckRequest();
				NavigateToCheckFormPage();
				TestLogic.EnterPayeeInformation("Automation", "17th Floor 777E", "", "Milwaukee", "WI", "53202");
				TestLogic.CreateCheckRequestTypeF1("2.6", "Cash", "Check Issued", "AK", "F1");
				if (TestLogic.VerifyErrorMessageForDuplicateRecord()) {
					TestLogic.SendCheckRequest();
				} else {
					throw new Exception("Failed");
				}
			}
			reporter.LogSuccess("VerifyCheckFormSubmitTypeF1withCashTest",
					"Successfully Check Request Submission for Type F1 with Cash Money");
		} catch (Exception e) {
			reporter.LogFail("VerifyCheckFormSubmitTypeF1withCashTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 42
	@Test
	public void VerifyCheckFormSubmitTypeF1withMMFTest() throws Exception {
		try {
			NavigateToCheckFormPage();
			TestLogic.CreateCheckRequestTypeB_C_D_E_F1("1.5", "IDP", "Check Issued", "AK", "F1");
			if (TestLogic.VerifyErrorMessageForDuplicateRecord() == false) {
				TestLogic.SendCheckRequest();
				NavigateToCheckFormPage();
				TestLogic.CreateCheckRequestTypeB_C_D_E_F1("1.5", "IDP", "Check Issued", "AK", "F1");
				if (TestLogic.VerifyErrorMessageForDuplicateRecord()) {
					TestLogic.SendCheckRequest();
				} else {
					throw new Exception("Failed");
				}
			}
			reporter.LogSuccess("VerifyCheckFormSubmitTypeF1withMMFTest",
					"Successfully Check Request Submission for Type F1 with IDP Fund");
		} catch (Exception e) {
			reporter.LogFail("VerifyCheckFormSubmitTypeF1withMMFTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 43
	@Test
	public void VerifyCheckFormSubmitTypeF2withCashTest() throws Exception {
		try {
			NavigateToCheckFormPage();
			TestLogic.CreateCheckRequestTypeF2("1.7", "Cash", "Sent to Bank", "Check Issued", "F2", "AK");
			if (TestLogic.VerifyErrorMessageForDuplicateRecord() == false) {
				TestLogic.SendCheckRequest();
				NavigateToCheckFormPage();
				TestLogic.CreateCheckRequestTypeF2("1.7", "Cash", "Sent to Bank", "Check Issued", "F2", "AK");
				if (TestLogic.VerifyErrorMessageForDuplicateRecord()) {
					TestLogic.SendCheckRequest();
				} else {
					throw new Exception("Failed");
				}
			}
			reporter.LogSuccess("VerifyCheckFormSubmitTypeF2withCashTest",
					"Successfully Check Request Submission for Type F3 with Cash Money");
		} catch (Exception e) {
			reporter.LogFail("VerifyCheckFormSubmitTypeF2withCashTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 44
	@Test
	public void VerifyCheckFormSubmitTypeF2withMMFTest() throws Exception {
		try {
			NavigateToCheckFormPage();
			TestLogic.CreateCheckRequestTypeF2("1.8", "ID3", "Sent to Bank", "Check Issued", "F2", "AK");
			if (TestLogic.VerifyErrorMessageForDuplicateRecord() == false) {
				TestLogic.SendCheckRequest();
				NavigateToCheckFormPage();
				TestLogic.CreateCheckRequestTypeF2("1.8", "ID3", "Sent to Bank", "Check Issued", "F2", "AK");
				if (TestLogic.VerifyErrorMessageForDuplicateRecord()) {
					TestLogic.SendCheckRequest();
				} else {
					throw new Exception("Failed");
				}
			}
			reporter.LogSuccess("VerifyCheckFormSubmitTypeF2withMMFTest",
					"Successfully Check Request Submission for Type F3 with IDP Fund");
		} catch (Exception e) {
			reporter.LogFail("VerifyCheckFormSubmitTypeF2withMMFTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 45
	@Test
	public void VerifyCheckFormSubmitTypeF3withCashTest() throws Exception {
		try {
			NavigateToCheckFormPage();
			TestLogic.CreateCheckRequestTypeF3(".8", "Cash", "Sent to Bank", "Check Issued", "F3", "AK");
			if (TestLogic.VerifyErrorMessageForDuplicateRecord() == false) {
				TestLogic.SendCheckRequest();
				NavigateToCheckFormPage();
				TestLogic.CreateCheckRequestTypeF3(".8", "Cash", "Sent to Bank", "Check Issued", "F3", "AK");
				if (TestLogic.VerifyErrorMessageForDuplicateRecord()) {
					TestLogic.SendCheckRequest();
				} else {
					throw new Exception("Failed");
				}
			}
			reporter.LogSuccess("VerifyCheckFormSubmitTypeF3withCashTest",
					"Successfully Check Request Submission for Type F3 with Cash");
		} catch (Exception e) {
			reporter.LogFail("VerifyCheckFormSubmitTypeF3withCashTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 46
	@Test
	public void VerifyCheckFormSubmitTypeF3withMMFTest() throws Exception {
		try {
			NavigateToCheckFormPage();
			TestLogic.CreateCheckRequestTypeF3(".7", "ID3", "Sent to Bank", "Check Issued", "F3", "AK");
			if (TestLogic.VerifyErrorMessageForDuplicateRecord() == false) {
				TestLogic.SendCheckRequest();
				NavigateToCheckFormPage();
				TestLogic.CreateCheckRequestTypeF3(".7", "ID3", "Sent to Bank", "Check Issued", "F3", "AK");
				if (TestLogic.VerifyErrorMessageForDuplicateRecord()) {
					TestLogic.SendCheckRequest();
				} else {
					throw new Exception("Failed");
				}
			}
			reporter.LogSuccess("VerifyCheckFormSubmitTypeF3withMMFTest",
					"Successfully Check Request Submission for Type F3 with IDP Fund");
		} catch (Exception e) {
			reporter.LogFail("VerifyCheckFormSubmitTypeF3withMMFTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 47
	@Test
	public void VerifyBackButtonTest() throws Exception {
		try {
			NavigateToCheckFormPage();
			TestLogic.VerifyBackButton();
			Assert.isTrue(TestLogic.VerifySignInSuccess(), "User Navigated Back to Client Info Page");
			reporter.LogSuccess("VerifyBackButtonTest", "User Navigated Back to Client Info Page");
		} catch (Exception e) {
			reporter.LogFail("VerifyBackButtonTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 48
	@Test
	public void VerifyResetButtonTest() throws Exception {
		try {
			NavigateToCheckFormPage();
			Assert.isTrue(TestLogic.VerifyPayeeInformationBlankFields(), "Payee Information Section is Blank");
			reporter.LogSuccess("VerifyResetButtonTest", "Reset Button Verified");
		} catch (Exception e) {
			reporter.LogFail("VerifyResetButtonTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 49
	@Test
	public void VerifySaveFormFucntionalityTest() throws Exception {
		try {
			NavigateToCheckFormPage();
			Assert.isTrue(TestLogic.VerifySaveFunctionality(), "Save Check Form Functionality Verified");
			reporter.LogSuccess("VerifySaveFormFucntionalityTest", "Save Check Form Functionality Verified");
		} catch (Exception e) {
			reporter.LogFail("VerifySaveFormFucntionalityTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 50
	@Test
	public void VerifyCheckFormSubmitwithPrintLocTest() throws Exception {
		try {
			NavigateToCheckFormPage();
			TestLogic.VerifyPrintLocBranch("AA - Milwaukee Sales");
			TestLogic.CreateCheckRequestTypeA(".2", "ID3", "Check Issued", "AK");
			if (TestLogic.VerifyErrorMessageForDuplicateRecord() == false) {
				TestLogic.SendCheckRequest();
				NavigateToCheckFormPage();
				TestLogic.CreateCheckRequestTypeA(".2", "ID3", "Check Issued", "AK");
				if (TestLogic.VerifyErrorMessageForDuplicateRecord()) {
					TestLogic.SendCheckRequest();
				} else {
					throw new Exception("Failed");
				}
			}
			reporter.LogSuccess("VerifyCheckFormSubmitwithPrintLocTest",
					"Successfully Check Request Submission with Diff Print Location");
		} catch (Exception e) {
			reporter.LogFail("VerifyCheckFormSubmitwithPrintLocTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 51
	@Test
	public void VerifyBackButtonOnProcessCheckPageTest() throws Exception {
		try {
			NavigateToCheckFormPage();
			TestLogic.CreateCheckRequestTypeA(".41", "Cash", "Check Issued", "AK");
			TestLogic.VerifyBackBtnOnCheckProcess();
			Assert.isTrue(TestLogic.VerifyRetrievedClientTitle(), "Page Title Verified");
			reporter.LogSuccess("VerifyBackButtonOnProcessCheckPageTest",
					"Back Button successfully Clicked and User Navigated Back to Client Info Page");
		} catch (Exception e) {
			reporter.LogFail("VerifyBackButtonOnProcessCheckPageTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 52
	@Test
	public void VerifyCheckCancelButtonOnProcessCheckPageTest() throws Exception {
		try {
			NavigateToCheckFormPage();
			TestLogic.CreateCheckRequestTypeA(".12", "Cash", "Check Issued", "AK");
			TestLogic.VerifyCancelBtnOnCheckProcess();
			reporter.LogSuccess("VerifyCheckCancelButtonOnProcessCheckPageTest", "Cancel Button successfully Clicked");
		} catch (Exception e) {
			reporter.LogFail("VerifyCheckCancelButtonOnProcessCheckPageTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 53
	@Test
	public void VerifyTypeofPayeeforMkeAccTransactionTest() throws Exception {
		try {
			NavigateToCheckFormPage();
			TestLogic.VerifyPayeeTypeF2("ID3", "F2");
			reporter.LogSuccess("VerifyTypeofPayeeforMkeAccTransactionTest",
					"Sent to Payee Auto-Populated When Milwaukee Acc Transaction is Selected ");
		} catch (Exception e) {
			reporter.LogFail("VerifyTypeofPayeeforMkeAccTransactionTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 54
	@Test
	public void VerifyErrorPopUpforTypeDwithYesThirdPartyInfoTest() throws Exception {
		try {
			NavigateToCheckFormPage();
			TestLogic.VerifyErrorPopUpforTypeD("2.4", "ID3", "Check Issued", "AK", "D");
			Assert.isTrue(
					TestLogic.VerifyErrorMessage("The following attachments are required for this check request:"),
					"Error PopUp Verified For Yes Third Party Information");
			reporter.LogSuccess("VerifyErrorPopUpforTypeDwithYesThirdPartyInfoTest",
					"Error PopUp Verified For Yes Third Party Information");
		} catch (Exception e) {
			reporter.LogFail("VerifyErrorPopUpforTypeDwithYesThirdPartyInfoTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 55
	@Test
	public void VerifyCheckFormSubmitTypeDwithMMFTest() throws Exception {
		try {
			NavigateToCheckFormPage();
			TestLogic.CreateCheckRequestTypeB_C_D_E_F1("2.7", "ID3", "Check Issued", "AK", "D");
			if (TestLogic.VerifyErrorMessageForDuplicateRecord() == false) {
				TestLogic.SendCheckRequest();
				NavigateToCheckFormPage();
				TestLogic.CreateCheckRequestTypeB_C_D_E_F1("2.7", "ID3", "Check Issued", "AK", "D");
				if (TestLogic.VerifyErrorMessageForDuplicateRecord()) {
					TestLogic.SendCheckRequest();
				} else {
					throw new Exception("Failed");
				}
			}
			reporter.LogSuccess("VerifyCheckFormSubmitTypeDwithMMFTest",
					"Successfully Check Request Submission for Type D With IDP Fund");
		} catch (Exception e) {
			reporter.LogFail("VerifyCheckFormSubmitTypeDwithMMFTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 56
	@Test
	public void VerifyAddressline2Test() throws Exception {
		try {
			NavigateToCheckFormPage();
			Assert.isTrue(TestLogic.SelectPayeeInstructionForAddressLine2(), "Address Line 2  Verified");
			reporter.LogSuccess("VerifyAddressline2Test", "Address Line 2 Verified");
		} catch (Exception e) {
			reporter.LogFail("VerifyAddressline2Test", e.getMessage());
			throw e;
		}
	}
}
