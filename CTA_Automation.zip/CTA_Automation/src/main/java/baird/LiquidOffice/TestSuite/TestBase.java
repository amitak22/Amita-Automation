package baird.LiquidOffice.TestSuite;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.stream.JsonReader;

import baird.LiquidOffice.Automation.Resources.TestSettings;
import baird.core.Automation.CommonAPI.CommonAPI;
import baird.core.Automation.CommonAPI.ICommonAPI;
import baird.core.Automation.CustomReporters.ICustomReporter;
import baird.core.Automation.Loggers.Logger;

/**
 * @author AmitaKumari
 */

public class TestBase {

	public static ICommonAPI commonapi = null;
	public static TestSettings testSettings = null;
	protected static Logger log;
	protected static ICustomReporter reporter;

	@BeforeAll
	public static void BeforeAll() {
		IEnvironmentType envType = EnvironmentType.UAT;

		if (commonapi == null) {
			InputStream is = envType.getSettingsFile();

			testSettings = getSettingsFromJson(is);

			try {
				is.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			commonapi = new CommonAPI(testSettings.CoreSettings);
		}

		log = commonapi.getLogger();
		reporter = commonapi.getReporter();
		reporter.startReport("Windows", testSettings.Browser.toString());
		System.out.println(testSettings.ReportFilePrefix);
	}

	@AfterAll
	public static void AfterAll() {
		commonapi.getBrowser().Close();
		reporter.flush();
	}

	@AfterEach
	void tearThis() {
		commonapi.getBrowser().Close();
	}

	public static TestSettings getSettingsFromJson(InputStream is) {
		try {
			Gson gson = new GsonBuilder().create();
			JsonReader reader = new JsonReader(new InputStreamReader(is));
			return gson.fromJson(reader, TestSettings.class);

		} catch (Exception e) {
			System.out.println(e.getMessage());
			return null;
		}
	}
}

interface IEnvironmentType {
	InputStream getSettingsFile();
}

enum EnvironmentType implements IEnvironmentType {

	SIT {
		public InputStream getSettingsFile() {
			InputStream is = this.getClass().getResourceAsStream("/AppSettings.SIT.json");
			return is;
		}
	},
	UAT {
		public InputStream getSettingsFile() {
			InputStream is = this.getClass().getResourceAsStream("/AppSettings.UAT.json");

			return is;
		}
	}
}
