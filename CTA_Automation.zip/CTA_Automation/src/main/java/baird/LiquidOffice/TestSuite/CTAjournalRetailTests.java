package baird.LiquidOffice.TestSuite;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInfo;
import org.springframework.util.Assert;

import baird.LiquidOffice.Automation.BusinessLayer.CTAjournalFormTestLogic;

/**
 * @author AmitaKumari
 */

public class CTAjournalRetailTests extends TestBase {

	CTAjournalFormTestLogic TestLogic = null;

	@BeforeEach
	public void TestInitialize(TestInfo info) {
		log.LogDebug(info.getDisplayName());
		TestLogic = new CTAjournalFormTestLogic(commonapi, testSettings);
	}

	void NavigateToJournalFormPage() throws Exception {
		TestLogic.OpenCTApage("SignIn");
		TestLogic.GetClientInfo("59127215", "Journal Request");
		TestLogic.ClickContinueOnClientInfo();
	}

	void NavigateToJournalFormPageMMF() throws Exception {
		TestLogic.OpenCTApage("SignIn");
		TestLogic.GetClientInfo("34780866", "Journal Request");
		TestLogic.ClickContinueOnClientInfo();
	}

	void NavigateToJournalFormMMFNonAdvisory() throws Exception {
		TestLogic.OpenCTApage("SignIn");
		TestLogic.GetClientInfo("10795202", "Journal Request");
		TestLogic.ClickContinueOnClientInfo();
	}

	void NavigateToJournalFormPageMMFAdvisory() throws Exception {
		TestLogic.OpenCTApage("SignIn");
		TestLogic.GetClientInfo("22866272", "Journal Request");
		TestLogic.ClickContinueOnClientInfo();
	}

	// Test Case 1
	@Test
	public void VerifyJournalFormOpeningTest() throws Exception {
		try {
			NavigateToJournalFormPage();
			Assert.isTrue(TestLogic.VerifyJournalInfoTitle(), "Journal Information Title Verified");
			reporter.LogSuccess("VerifyJournalFormOpeningTest", "Journal Information Title Verified");
		} catch (Exception e) {
			reporter.LogFail("VerifyJournalFormOpeningTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 2
	@Test
	public void VerifyWarningPopUpForInvalidTransfertoAccTest() throws Exception {
		try {
			NavigateToJournalFormPage();
			Assert.isTrue(
					TestLogic.VerifyWarningPopUpInvalidAcc("abcd",
							"An error occurred during the Account lookup for abcd- return code = "),
					"Error Pop Verified For Invalid Trasfer to Account Number");
			reporter.LogSuccess("VerifyWarningPopUpForInvalidTransfertoAccTest",
					"Error Pop Verified For Invalid Trasfer to Account Number");
		} catch (Exception e) {
			reporter.LogFail("VerifyWarningPopUpForInvalidTransfertoAccTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 3
	@Test
	public void VerifyTransferCurrentDateTest() throws Exception {
		try {
			NavigateToJournalFormPage();
			Assert.isTrue(TestLogic.VerifyTransferCurrentDate(), "Verified");
			reporter.LogSuccess("VerifyTransferCurrentDateTest", "ACH Issue Date Verified");
		} catch (Exception e) {
			reporter.LogFail("VerifyTransferCurrentDateTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 4
	@Test
	public void VerifyWarningPopUpForTypeATest() throws Exception {
		try {
			NavigateToJournalFormPage();
			Assert.isTrue(
					TestLogic.VerifyWarningPopUpForTypeA("34780866", "A",
							"The from-account and to-account owner's TaxID does not match."),
					"Error Pop Verified For Beneficiary Type A");
			reporter.LogSuccess("VerifyWarningPopUpForTypeATest", "Error Pop Verified For Beneficiary Type A");
		} catch (Exception e) {
			reporter.LogFail("VerifyWarningPopUpForTypeATest", e.getMessage());
			throw e;
		}
	}

	// Test Case 5
	@Test
	public void VerifyTotalfromValuationsTest() throws Exception {
		try {
			NavigateToJournalFormPage();
			Assert.isTrue(TestLogic.VerifyTotalfromValuations("34780866", "B", "2"), "Total from Valuations Verified");
			reporter.LogSuccess("VerifyTotalfromValuationsTest", "Total from Valuations Verified");
		} catch (Exception e) {
			reporter.LogFail("VerifyTotalfromValuationsTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 6
	@Test
	public void VerifyWarningPopUpForQuestionMarkTest() throws Exception {
		try {
			NavigateToJournalFormPage();
			Assert.isTrue(
					TestLogic.VerifyWarningPopUpForQuestionMark("34780866", "B",
							"Security transfers between individuals and/or entities may be"),
					"Error PopUp Verified For Question Mark Icon");
			reporter.LogSuccess("VerifyWarningPopUpForQuestionMarkTest", "Error PopUp Verified For Question Mark Icon");
		} catch (Exception e) {
			reporter.LogFail("VerifyWarningPopUpForQuestionMarkTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 7
	@Test
	public void VerifyWarningPopUpWithoutTransferDateTest() throws Exception {
		try {
			NavigateToJournalFormPage();
			Assert.isTrue(
					TestLogic.VerifyTransferDateForFutureDate("The transfer date must be in the same calendar year."),
					"Warning PopUp Verified When Journal Transfer Date Is Cleared Out");
			reporter.LogSuccess("VerifyWarningPopUpWithoutTransferDateTest",
					"Warning PopUp Verified When Journal Transfer Date Is Cleared Out");
		} catch (Exception e) {
			reporter.LogFail("VerifyWarningPopUpWithoutTransferDateTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 8
	@Test
	public void VerifyWarningPopUpForSameTransferToAccTest() throws Exception {
		try {
			NavigateToJournalFormPage();
			Assert.isTrue(TestLogic.VerifyWarningPopUpInvalidAcc("59127215",
					"Duplicate account error; the 'from' and 'to' accounts must be unique account numbers.  Please select a different account to journal to."),
					"Error Pop Verified When Transfer To Account Is Same As Acc No");
			reporter.LogSuccess("VerifyWarningPopUpForSameTransferToAccTest",
					"Error Pop Verified When Transfer To Account Is Same As Acc No");
		} catch (Exception e) {
			reporter.LogFail("VerifyWarningPopUpForSameTransferToAccTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 9
	@Test
	public void VerifySummaryOfJournalPageOpeningTest() throws Exception {
		try {
			NavigateToJournalFormPage();
			Assert.isTrue(TestLogic.VerifySummaryOfJournalTitle("34780866", "B", "2"),
					"Summary Of Journal Page Opening Verified");
			reporter.LogSuccess("VerifySummaryOfJournalPageOpeningTest", "Summary Of Journal Page Opening Verified");
		} catch (Exception e) {
			reporter.LogFail("VerifySummaryOfJournalPageOpeningTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 10
	@Test
	public void VerifyJournalFormSubmitTypeBTest() throws Exception {
		try {
			NavigateToJournalFormPage();
			TestLogic.VerifyJournalFormSubmitTypeB_C_D_E("34780866", "B", "2");
			reporter.LogSuccess("VerifyJournalFormSubmitTypeBTest",
					"Successfully Journal Request Submission With Type B Beneficiary");
		} catch (Exception e) {
			reporter.LogFail("VerifyJournalFormSubmitTypeBTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 11
	@Test
	public void VerifyJournalBackButtonTest() throws Exception {
		try {
			NavigateToJournalFormPage();
			Assert.isTrue(TestLogic.VerifyBackButton(), "User Navigated Back to Client Info Page");
			reporter.LogSuccess("VerifyJournalBackButtonTest", "User Navigated Back to Client Info Page");
		} catch (Exception e) {
			reporter.LogFail("VerifyJournalBackButtonTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 12
	@Test
	public void VerifyJournalSaveFormFucntionalityTest() throws Exception {
		try {
			NavigateToJournalFormPage();
			Assert.isTrue(TestLogic.VerifySaveFunctionality(), "Save Journal Form Functionality Verified");
			reporter.LogSuccess("VerifyJournalSaveFormFucntionalityTest", "Save Journal Form Functionality Verified");
		} catch (Exception e) {
			reporter.LogFail("VerifyJournalSaveFormFucntionalityTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 13
	@Test
	public void VerifyTotalfromAllSelectionsTest() throws Exception {
		try {
			NavigateToJournalFormPage();
			Assert.isTrue(TestLogic.VerifyTotalfromAllSelections("34780866", "B", "2"),
					"Total from All Selections Verified");
			reporter.LogSuccess("VerifyTotalfromAllSelectionsTest", "Total from All Selections Verified");
		} catch (Exception e) {
			reporter.LogFail("VerifyTotalfromAllSelectionsTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 14
	@Test
	public void VerifyTotalfromAllPositionsTest() throws Exception {
		try {
			NavigateToJournalFormPage();
			Assert.isTrue(TestLogic.VerifyTotalfromPositions("34780866", "B", "2"),
					"Total from All Positions Verified");
			reporter.LogSuccess("VerifyTotalfromValuationsTest", "Total from All Positions Verified");
		} catch (Exception e) {
			reporter.LogFail("VerifyTotalfromValuationsTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 15
	@Test
	public void VerifyPageNoTest() throws Exception {
		try {
			NavigateToJournalFormPage();
			Assert.isTrue(TestLogic.VerifyTransferDesc("34780866"), "Page Number Verified");
			reporter.LogSuccess("VerifyPageNoTest", "Page Number Verified");
		} catch (Exception e) {
			reporter.LogFail("VerifyPageNoTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 16
	@Test
	public void VerifyTransferDescTest() throws Exception {
		try {
			NavigateToJournalFormPage();
			Assert.isTrue(TestLogic.VerifyTransferDesc("34780866"), "Transfer Description Verified");
			reporter.LogSuccess("VerifyTransferDescTest", "Transfer Description Verified");
		} catch (Exception e) {
			reporter.LogFail("VerifyTransferDescTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 17
	@Test
	public void VerifyJournalFormSubmitTypeATest() throws Exception {
		try {
			NavigateToJournalFormPage();
			TestLogic.VerifyJournalFormSubmitTypeA("19401744", "2");
			reporter.LogSuccess("VerifyJournalFormSubmitTypeATest",
					"Successfully Journal Request Submission With Type A Beneficiary");
		} catch (Exception e) {
			reporter.LogFail("VerifyJournalFormSubmitTypeATest", e.getMessage());
			throw e;
		}
	}

	// Test Case 18
	@Test
	public void VerifyTypeFieldTest() throws Exception {
		try {
			NavigateToJournalFormPage();
			Assert.isTrue(TestLogic.VerifyTransferDesc("34780866"), "Cash Info Type Field Verified");
			reporter.LogSuccess("VerifyTypeFieldTest", "Cash Info Type Field Verified");
		} catch (Exception e) {
			reporter.LogFail("VerifyTypeFieldTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 19
	@Test
	public void VerifyTotalValueWithTransferValueTest() throws Exception {
		try {
			NavigateToJournalFormPage();
			Assert.isTrue(TestLogic.VerifyTotalValueWithTransferValue("34780866"),
					"Total Value and Transfer Value are Same When All Selected");
			reporter.LogSuccess("VerifyTotalValueWithTransferValueTest",
					"Total Value and Transfer Value are Same When All Selected");
		} catch (Exception e) {
			reporter.LogFail("VerifyTotalValueWithTransferValueTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 20
	@Test
	public void VerifyTotalValueWhenNoneRadioBtnSelectedTest() throws Exception {
		try {
			NavigateToJournalFormPage();
			Assert.isTrue(TestLogic.VerifyTotalValueWithNoneBtn("34780866"),
					"Total Value and Transfer Value are Same When All Selected");
			reporter.LogSuccess("VerifyTotalValueWhenNoneRadioBtnSelectedTest",
					"Total Value and Transfer Value are Same When All Selected");
		} catch (Exception e) {
			reporter.LogFail("VerifyTotalValueWhenNoneRadioBtnSelectedTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 21
	@Test
	public void VerifyTypeFieldMMFTest() throws Exception {
		try {
			NavigateToJournalFormPageMMF();
			Assert.isTrue(TestLogic.VerifyTypeandValueForMMF(), "Cash Info Type Field Verified");
			reporter.LogSuccess("VerifyTypeFieldTest", "Cash Info Type Field Verified");
		} catch (Exception e) {
			reporter.LogFail("VerifyTypeFieldTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 22
	@Test
	public void VerifyJournalFormSubmitTypeDTest() throws Exception {
		try {
			NavigateToJournalFormPage();
			TestLogic.VerifyJournalFormSubmitTypeB_C_D_E("34780866", "D", "2");
			reporter.LogSuccess("VerifyJournalFormSubmitTypeDTest",
					"Successfully Journal Request Submission With Type D Beneficiary");
		} catch (Exception e) {
			reporter.LogFail("VerifyJournalFormSubmitTypeDTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 23
	@Test
	public void VerifyJournalFormSubmitTypeCTest() throws Exception {
		try {
			NavigateToJournalFormPage();
			TestLogic.VerifyJournalFormSubmitTypeB_C_D_E("34780866", "C", "2");
			reporter.LogSuccess("VerifyJournalFormSubmitTypeCTest",
					"Successfully Journal Request Submission With Type C Beneficiary");
		} catch (Exception e) {
			reporter.LogFail("VerifyJournalFormSubmitTypeCTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 24
	@Test
	public void VerifyJournalFormSubmitTypeETest() throws Exception {
		try {
			NavigateToJournalFormPage();
			TestLogic.VerifyJournalFormSubmitTypeB_C_D_E("34780866", "E", "1");
			reporter.LogSuccess("VerifyJournalFormSubmitTypeETest",
					"Successfully Journal Request Submission With Type E Beneficiary");
		} catch (Exception e) {
			reporter.LogFail("VerifyJournalFormSubmitTypeETest", e.getMessage());
			throw e;
		}
	}

	// Test Case 25
	@Test
	public void VerifyPreviousBtnTest() throws Exception {
		try {
			NavigateToJournalFormPage();
			Assert.isTrue(TestLogic.VerifyPreviousBtn("34780866", "C", "2"), "Page Title Verified");
			reporter.LogSuccess("VerifyPreviousBtnTest", "Page Title Verified");
		} catch (Exception e) {
			reporter.LogFail("VerifyPreviousBtnTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 26
	@Test
	public void VerifySaveforLaterTest() throws Exception {
		try {
			NavigateToJournalFormPage();
			Assert.isTrue(TestLogic.VerifySaveforLater("34780866", "B", "2"), "Save for Later Functionality Verified");
			reporter.LogSuccess("VerifySaveforLaterTest", "Save for Later Functionality Verified");
		} catch (Exception e) {
			reporter.LogFail("VerifySaveforLaterTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 27
	@Test
	public void VerifyTransferDescMMFTest() throws Exception {
		try {
			NavigateToJournalFormPageMMF();
			Assert.isTrue(TestLogic.VerifyTransferDescMMF("19602591"), "Transfer Description Verified For MMF Account");
			reporter.LogSuccess("VerifyTransferDescMMFTest", "Transfer Description Verified For MMF Account");
		} catch (Exception e) {
			reporter.LogFail("VerifyTransferDescMMFTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 28
	@Test
	public void VerifyTotalfromAllSelectionsMMFTest() throws Exception {
		try {
			NavigateToJournalFormPageMMF();
			Assert.isTrue(TestLogic.VerifyTotalfromAllSelectionsMMF("19401744", "B", "4"),
					"Total from All Selections Verified Which Had MMF");
			reporter.LogSuccess("VerifyTotalfromAllSelectionsMMFTest",
					"Total from All Selections Verified Which Had MMF");
		} catch (Exception e) {
			reporter.LogFail("VerifyTotalfromAllSelectionsMMFTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 29
	@Test
	public void VerifyAdvisoryAccWithdrawalTitleTest() throws Exception {
		try {
			NavigateToJournalFormPageMMF();
			Assert.isTrue(TestLogic.VerifyAdvisoryAccWithdrawalTitle("19602591", "B", "4"),
					"Advisory Account Withdrawal Information Title Verified");
			reporter.LogSuccess("VerifyAdvisoryAccWithdrawalTitleTest",
					"Advisory Account Withdrawal Information Title Verified");
		} catch (Exception e) {
			reporter.LogFail("VerifyAdvisoryAccWithdrawalTitleTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 30
	@Test
	public void VerifyJournalWarningPopUpForYesRadioBtnSelectionAdvisoryAccountTest() throws Exception {
		try {
			NavigateToJournalFormPageMMF();
			Assert.isTrue(
					TestLogic.VerifyWarningPopUpforYesRadionBtnAdvisoryAccount("19602591", "B", "4",
							"You have indicated that you are submitting a Program/Manager/Model/"),
					"Error PopUp Verified For Yes Radio Button Selection For Advisory Account");
			reporter.LogSuccess("VerifyJournalWarningPopUpForYesRadioBtnSelectionAdvisoryAccountTest",
					"Error PopUp Verified For Yes Radio Button Selection For Advisory Account");
		} catch (Exception e) {
			reporter.LogFail("VerifyJournalWarningPopUpForYesRadioBtnSelectionAdvisoryAccountTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 31
	@Test
	public void VerifyJournalDropdownTest() throws Exception {
		try {
			NavigateToJournalFormPageMMF();
			Assert.isTrue(TestLogic.VerifyJournalDropdown("19602591", "B", "2", "Journal"),
					"Journal Dropdown Verified");
			reporter.LogSuccess("VerifyJournalDropdownTest", "Journal Dropdown Verified");
		} catch (Exception e) {
			reporter.LogFail("VerifyJournalDropdownTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 32
	@Test
	public void VerifyJournalWarningPopUpNoBeneficiaryTypeTest() throws Exception {
		try {
			NavigateToJournalFormPageMMF();
			Assert.isTrue(
					TestLogic.VerifyJournalWarningPopUpNoBeneficiaryTypeAccount("19602591", "", "4",
							"The following fields need to be completed before continuing:"),
					"Error PopUp Verified When Beneficiary Acc Not Selected");
			reporter.LogSuccess("VerifyJournalWarningPopUpNoBeneficiaryTypeTest",
					"Error PopUp Verified When Beneficiary Acc Not Selected");
		} catch (Exception e) {
			reporter.LogFail("VerifyJournalWarningPopUpNoBeneficiaryTypeTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 33
	@Test
	public void VerifyJournalWarningPopUpNoGiftQuestionTest() throws Exception {
		try {
			NavigateToJournalFormPageMMF();
			Assert.isTrue(
					TestLogic.VerifyJournalWarningPopUpNoGiftforTax("19602591", "B", "4",
							"The following fields need to be completed before continuing:"),
					"Error PopUp Verified When Radio Botton for Gift Question Not Selected");
			reporter.LogSuccess("VerifyJournalWarningPopUpNoGiftQuestionTest",
					"Error PopUp Verified When Radio Botton for Gift Question Not Selected");
		} catch (Exception e) {
			reporter.LogFail("VerifyJournalWarningPopUpNoGiftQuestionTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 34
	@Test
	public void VerifyJournalWarningPopUpNoJournalTest() throws Exception {
		try {
			NavigateToJournalFormPageMMF();
			Assert.isTrue(TestLogic.VerifyJournalWarningPopUpNoJournal("19602591", "B", "",
					"Please indicate what you would like to journal."), "Error PopUp Verified Without Journal");
			reporter.LogSuccess("VerifyJournalWarningPopUpNoJournalTest", "Error PopUp Verified Without Journal");
		} catch (Exception e) {
			reporter.LogFail("VerifyJournalWarningPopUpNoJournalTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 35
	@Test
	public void VerifyJournalWarningPopWhenNoAttachmentTypeBTest() throws Exception {
		try {
			NavigateToJournalFormPage();
			Assert.isTrue(TestLogic.VerifyJournalWarningPopWhenNoAttachmentTypeB("19602591", "B", "4",
					"There is 1 attachment required."), "Error PopUp Verified For No Attachment For TypeB");
			reporter.LogSuccess("VerifyJournalWarningPopWhenNoAttachmentTypeBTest",
					"Error PopUp Verified For No Attachment For TypeB");
		} catch (Exception e) {
			reporter.LogFail("VerifyJournalWarningPopWhenNoAttachmentTypeBTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 36
	@Test
	public void VerifyJournalFormSubmitTypeBMMFNonAdvisoryTest() throws Exception {
		try {
			NavigateToJournalFormMMFNonAdvisory();
			TestLogic.VerifyJournalFormSubmitMMFNonAdvisory("19602591", "B", "2");
			reporter.LogSuccess("VerifyJournalFormSubmitTypeBMMFNonAdvisoryTest",
					"Successfully Journal Request Submission With Type B Beneficiary For Non Advisory Account");
		} catch (Exception e) {
			reporter.LogFail("VerifyJournalFormSubmitTypeBMMFNonAdvisoryTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 37
	@Test
	public void VerifyJournalFormSubmitTypeDMMFNonAdvisoryTest() throws Exception {
		try {
			NavigateToJournalFormMMFNonAdvisory();
			TestLogic.VerifyJournalFormSubmitMMFNonAdvisory("19602591", "D", "1");
			reporter.LogSuccess("VerifyJournalFormSubmitTypeDMMFNonAdvisoryTest",
					"Successfully Journal Request Submission With Type D Beneficiary For Non Advisory Account");
		} catch (Exception e) {
			reporter.LogFail("VerifyJournalFormSubmitTypeDMMFNonAdvisoryTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 38
	@Test
	public void VerifyJournalFormSubmitTypeCMMFAdvisoryTest() throws Exception {
		try {
			NavigateToJournalFormPageMMF();
			TestLogic.VerifyJournalFormSubmitMMFAdvisory("19602591", "C", "3");
			reporter.LogSuccess("VerifyJournalFormSubmitTypeCMMFAdvisoryTest",
					"Successfully Journal Request Submission With Type C Beneficiary For Advisory Account");
		} catch (Exception e) {
			reporter.LogFail("VerifyJournalFormSubmitTypeCMMFAdvisoryTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 39
	@Test
	public void VerifyJournalFormSubmitTypeEMMFAdvisoryTest() throws Exception {
		try {
			NavigateToJournalFormPageMMF();
			TestLogic.VerifyJournalFormSubmitMMFAdvisory("19602591", "E", "3.5");
			reporter.LogSuccess("VerifyJournalFormSubmitTypeEMMFAdvisoryTest",
					"Successfully Journal Request Submission With Type E Beneficiary For Advisory Account");
		} catch (Exception e) {
			reporter.LogFail("VerifyJournalFormSubmitTypeEMMFAdvisoryTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 40
	@Test
	public void VerifyJournalTotalValueWhenNoneRadioBtnSelectedMMFTest() throws Exception {
		try {
			NavigateToJournalFormPage();
			Assert.isTrue(TestLogic.VerifyTotalValueWithNoneBtnMMF("19602591"),
					"Total Value and Transfer Value are Same When All Selected");
			reporter.LogSuccess("VerifyJournalTotalValueWhenNoneRadioBtnSelectedMMFTest",
					"Total Value and Transfer Value are Same When All Selected");
		} catch (Exception e) {
			reporter.LogFail("VerifyJournalTotalValueWhenNoneRadioBtnSelectedMMFTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 41
	@Test
	public void VerifyJournalFormSubmitSLOATypeDTest() throws Exception {
		try {
			NavigateToJournalFormPage();
			TestLogic.VerifyJournalFormSubmitSLOATypeD("19401744", "D", "Amita", "1.5");
			reporter.LogSuccess("VerifyJournalFormSubmitSLOATypeDTest",
					"Successfully Journal Request Submission With Type D With SLOA");
		} catch (Exception e) {
			reporter.LogFail("VerifyJournalFormSubmitSLOATypeDTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 42
	@Test
	public void VerifyJournalWarningPopWhenNoneRadioBtnSelectedTest() throws Exception {
		try {
			NavigateToJournalFormPage();
			Assert.isTrue(
					TestLogic.VerifyJournalWarningPopUpWhenNoneRadioBtnSelected("19602591", "B",
							"Please indicate what you would like to journal."),
					"Error PopUp Verified When None Radio Button Selected");
			reporter.LogSuccess("VerifyJournalWarningPopWhenNoneRadioBtnSelectedTest",
					"Error PopUp Verified When None Radio Button Selected");
		} catch (Exception e) {
			reporter.LogFail("VerifyJournalWarningPopWhenNoneRadioBtnSelectedTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 43
	@Test
	public void VerifyJournalFormSubmitTypeAQuantityAllTest() throws Exception {
		try {
			NavigateToJournalFormPage();
			TestLogic.VerifyJournalFormSubmitQuantityAll("19401744", "4000");
			reporter.LogSuccess("VerifyJournalFormSubmitTypeAQuantityAllTest",
					"Successfully Journal Request Submission With Type A Beneficiary");
		} catch (Exception e) {
			reporter.LogFail("VerifyJournalFormSubmitTypeAQuantityAllTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 44
	@Test
	public void VerifyTransferToAccDescriptionTest() throws Exception {
		try {
			NavigateToJournalFormPage();
			Assert.isTrue(TestLogic.TransferToAccDescription("19401744"),
					"Transfer to Account Description Verified");
			reporter.LogSuccess("VerifyTransferToAccDescriptionTest",
					"Transfer to Account Description Verified");
		} catch (Exception e) {
			reporter.LogFail("VerifyTransferToAccDescriptionTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 45
	@Test
	public void VerifyTotalfromValuationsTypeFullTest() throws Exception {
		try {
			NavigateToJournalFormPage();
			Assert.isTrue(TestLogic.VerifyTotalfromValuationsTransferTypeFull("19401744"),
					"Total from Valuations Verified");
			reporter.LogSuccess("VerifyTotalfromValuationsTypeFullTest",
					"Total from Valuations Verified When Transfer Type Is Full");
		} catch (Exception e) {
			reporter.LogFail("VerifyTotalfromValuationsTypeFullTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 46
	@Test
	public void VerifyNextandPrePageTest() throws Exception {
		try {
			NavigateToJournalFormMMFNonAdvisory();
			Assert.isTrue(TestLogic.VerifyNextandPreviousPage(), "Next and Previous Page Verified");
			reporter.LogSuccess("VerifyNextandPrePageTest", "Next and Previous Page Verified");
		} catch (Exception e) {
			reporter.LogFail("VerifyNextandPrePageTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 47
	@Test
	public void VerifyJournalWarningPopForTaxLotTest() throws Exception {
		try {
			NavigateToJournalFormPageMMF();
			Assert.isTrue(
					TestLogic.VerifyJournalWarningPopForTaxLot("19602591", "D", "1",
							"There is only one tax lot for this security.  No tax lot selection required."),
					"Error PopUp Verified For Tax Lot TypeD");
			reporter.LogSuccess("VerifyJournalWarningPopForTaxLotTest", "Error PopUp Verified For Tax Lot TypeD");
		} catch (Exception e) {
			reporter.LogFail("VerifyJournalWarningPopForTaxLotTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 48
	@Test
	public void VerifyJournalFormSubmitTypeDWithSecuritiesTest() throws Exception {
		try {
			NavigateToJournalFormPageMMF();
			TestLogic.VerifyJournalFormSubmitSecurities("19602591", "D", "1");
			reporter.LogSuccess("VerifyJournalFormSubmitTypeDWithSecuritiesTest",
					"Successfully Journal Request Submission With Securities Type D ");
		} catch (Exception e) {
			reporter.LogFail("VerifyJournalFormSubmitTypeDWithSecuritiesTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 49
	@Test
	public void VerifyJournalFormSubmitTypeBWithAllSecuritiesTest() throws Exception {
		try {
			NavigateToJournalFormPageMMF();
			TestLogic.VerifyJournalFormSubmitAllSecurities("19602591", "B", "");
			reporter.LogSuccess("VerifyJournalFormSubmitTypeBWithAllSecuritiesTest",
					"Successfully Journal Request Submission With All Securities Type B ");
		} catch (Exception e) {
			reporter.LogFail("VerifyJournalFormSubmitTypeBWithAllSecuritiesTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 50
	@Test
	public void VerifyJournalFormSubmitTypeBWithSecurityandCashTest() throws Exception {
		try {
			NavigateToJournalFormPageMMF();
			TestLogic.VerifyJournalFormSubmitSecurityandCash("19602591", "B", "1", "2");
			reporter.LogSuccess("VerifyJournalFormSubmitTypeBWithSecurityandCashTest",
					"Successfully Journal Request Submission With Cash and Security Type B ");
		} catch (Exception e) {
			reporter.LogFail("VerifyJournalFormSubmitTypeBWithSecurityandCashTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 51
	@Test
	public void VerifyJournalFormSubmitTypeAWithSecurityandCashTest() throws Exception {
		try {
			NavigateToJournalFormPage();
			TestLogic.VerifyJournalFormSubmitTypeAWithSecurityandCash("19401744", "2", "1");
			reporter.LogSuccess("VerifyJournalFormSubmitTypeATest",
					"Successfully Journal Request Submission With Cash and Security Type B");
		} catch (Exception e) {
			reporter.LogFail("VerifyJournalFormSubmitTypeATest", e.getMessage());
			throw e;
		}
	}

	// Test Case 52
	@Test
	public void VerifyJournalFormSubmitTypeDWithSecurityandCashTest() throws Exception {
		try {
			NavigateToJournalFormPageMMF();
			TestLogic.VerifyJournalFormSubmitSecurityandCash("19602591", "D", "1", "2");
			reporter.LogSuccess("VerifyJournalFormSubmitTypeDWithSecurityandCashTest",
					"Successfully Journal Request Submission With Cash and Security Type D");
		} catch (Exception e) {
			reporter.LogFail("VerifyJournalFormSubmitTypeDWithSecurityandCashTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 53
	@Test
	public void VerifyJournalFormSubmitTypeBWithMMFandCashTest() throws Exception {
		try {
			NavigateToJournalFormPageMMF();
			TestLogic.VerifyJournalFormSubmitSecurityandCash("19602591", "B", "1", "2");
			reporter.LogSuccess("VerifyJournalFormSubmitTypeBWithMMFandCashTest",
					"Successfully Journal Request Submission With Cash and MMF Type B");
		} catch (Exception e) {
			reporter.LogFail("VerifyJournalFormSubmitTypeBWithMMFandCashTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 54
	@Test
	public void VerifyJournalFormSubmitTypeDMMFandSecurityTest() throws Exception {
		try {
			NavigateToJournalFormMMFNonAdvisory();
			TestLogic.VerifyJournalFormSubmitTypeDMMFandSecurity("19602591", "D", "1", "2");
			reporter.LogSuccess("VerifyJournalFormSubmitTypeDMMFandSecurityTest",
					"Successfully Journal Request Submission With Security and MMF Type D");
		} catch (Exception e) {
			reporter.LogFail("VerifyJournalFormSubmitTypeDMMFandSecurityTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 55
	@Test
	public void VerifyTotalValueWithTransferValueSecurityTest() throws Exception {
		try {
			NavigateToJournalFormPage();
			Assert.isTrue(TestLogic.VerifyTotalValueWithTransferValueSecurity("34780866", "1"),
					"Total Value and Transfer Value are Same When All Selected");
			reporter.LogSuccess("VerifyTotalPriceWithTransferValueSecurityTest",
					"Total Value and Transfer Value are Same When All Selected");
		} catch (Exception e) {
			reporter.LogFail("VerifyTotalPriceWithTransferValueSecurityTest", e.getMessage());
			throw e;
		}
	}

}
