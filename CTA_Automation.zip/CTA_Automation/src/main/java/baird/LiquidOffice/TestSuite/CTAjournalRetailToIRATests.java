
package baird.LiquidOffice.TestSuite;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInfo;
import org.springframework.util.Assert;

import baird.LiquidOffice.Automation.BusinessLayer.CTAjournalFormTestLogic;

/**
 * @author AmitaKumari
 */

public class CTAjournalRetailToIRATests extends TestBase {

	CTAjournalFormTestLogic TestLogic = null;

	@BeforeEach
	public void TestInitialize(TestInfo info) {
		log.LogDebug(info.getDisplayName());
		TestLogic = new CTAjournalFormTestLogic(commonapi, testSettings);
	}

	void NavigateToJournalFormPage() throws Exception {
		TestLogic.OpenCTApage("SignIn");
		TestLogic.GetClientInfo("59127215", "Journal Request");
		TestLogic.ClickContinueOnClientInfo();
	}

	void NavigateToJournalFormPageMMF() throws Exception {
		TestLogic.OpenCTApage("SignIn");
		TestLogic.GetClientInfo("16869265", "Journal Request");
		TestLogic.ClickContinueOnClientInfo();
	}

	void NavigateToJournalFormTypeA() throws Exception {
		TestLogic.OpenCTApage("SignIn");
		TestLogic.GetClientInfo("34780866", "Journal Request");
		TestLogic.ClickContinueOnClientInfo();
	}

	void NavigateToJournalFormNoCash() throws Exception {
		TestLogic.OpenCTApage("SignIn");
		TestLogic.GetClientInfo("48616390", "Journal Request");
		TestLogic.ClickContinueOnClientInfo();
	}

	void NavigateToJournalFormCash() throws Exception {
		TestLogic.OpenCTApage("SignIn");
		TestLogic.GetClientInfo("86997083", "Journal Request");
		TestLogic.ClickContinueOnClientInfo();
	}

	// Test Case 1
	@Test
	public void VerifyTransferDescRetailtoIRATest() throws Exception {
		try {
			NavigateToJournalFormPage();
			Assert.isTrue(TestLogic.VerifyTransferDescRetailtoIRA("48616390"),
					"Transfer Description Verified For Retail to IRA");
			reporter.LogSuccess("VerifyTransferDescRetailtoIRATest", "Transfer Description Verified For Retail to IRA");
		} catch (Exception e) {
			reporter.LogFail("VerifyTransferDescRetailtoIRATest", e.getMessage());
			throw e;
		}
	}

	// Test Case 2
	@Test
	public void VerifyTransferToAccDescriptionRetailToIRATest() throws Exception {
		try {
			NavigateToJournalFormPage();
			Assert.isTrue(TestLogic.TransferToAccDescription("48616390"), "Transfer to Account Description Verified");
			reporter.LogSuccess("VerifyTransferToAccDescriptionRetailToIRATest",
					"Transfer to Account Description Verified");
		} catch (Exception e) {
			reporter.LogFail("VerifyTransferToAccDescriptionRetailToIRATest", e.getMessage());
			throw e;
		}
	}

	// Test Case 3
	@Test
	public void VerifyTransferFromAccDescriptionTest() throws Exception {
		try {
			NavigateToJournalFormPage();
			Assert.isTrue(TestLogic.VerifyTransferDescRetailtoIRA("48616390"),
					"Transfer from Account Description Verified");
			reporter.LogSuccess("VerifyTransferFromAccDescriptionTest", "Transfer from Account Description Verified");
		} catch (Exception e) {
			reporter.LogFail("VerifyTransferFromAccDescriptionTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 4
	@Test
	public void VerifyTransferToAccDescriptionTest() throws Exception {
		try {
			NavigateToJournalFormPage();
			Assert.isTrue(TestLogic.VerifyTransferDescRetailtoIRA("48616390"),
					"Transfer to Account Description Verified");
			reporter.LogSuccess("VerifyTransferToAccDescriptionTest", "Transfer to Account Description Verified");
		} catch (Exception e) {
			reporter.LogFail("VerifyTransferToAccDescriptionTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 5
	@Test
	public void VerifyRetailToIRAJournalFormSubmitTypeBTest() throws Exception {
		try {
			NavigateToJournalFormPage();
			TestLogic.VerifyRetailToIRAJournalFormSubmit("48616390", "B", "", "0.5", "EMPRP");
			reporter.LogSuccess("VerifyRetailToIRAJournalFormSubmitTypeBTest",
					"Successfully Journal Request Submission With Type B");
		} catch (Exception e) {
			reporter.LogFail("VerifyRetailToIRAJournalFormSubmitTypeBTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 6
	@Test
	public void VerifyRetailToIRAJournalFormSubmitTypeCTest() throws Exception {
		try {
			NavigateToJournalFormPage();
			TestLogic.VerifyRetailToIRAJournalFormSubmit("48616390", "C", "", "1", "EMPRC");
			reporter.LogSuccess("VerifyRetailToIRAJournalFormSubmitTypeCTest",
					"Successfully Journal Request Submission With Type C");
		} catch (Exception e) {
			reporter.LogFail("VerifyRetailToIRAJournalFormSubmitTypeCTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 7
	@Test
	public void VerifyRetailToIRAJournalFormSubmitTypeDTest() throws Exception {
		try {
			NavigateToJournalFormPage();
			TestLogic.VerifyRetailToIRAJournalFormSubmit("48616390", "D", "", "1.5", "IRACP");
			reporter.LogSuccess("VerifyRetailToIRAJournalFormSubmitTypeDTest",
					"Successfully Journal Request Submission With Type D");
		} catch (Exception e) {
			reporter.LogFail("VerifyRetailToIRAJournalFormSubmitTypeDTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 8
	@Test
	public void VerifyRetailToIRAJournalFormSubmitTypeETest() throws Exception {
		try {
			NavigateToJournalFormPage();
			TestLogic.VerifyRetailToIRAJournalFormSubmit("48616390", "E", "", "2", "IRACC");
			reporter.LogSuccess("VerifyRetailToIRAJournalFormSubmitTypeETest",
					"Successfully Journal Request Submission With Type E");
		} catch (Exception e) {
			reporter.LogFail("VerifyRetailToIRAJournalFormSubmitTypeETest", e.getMessage());
			throw e;
		}
	}

	// Test Case 9
	@Test
	public void VerifyRetailToIRAJournalFormSubmitTypeATest() throws Exception {
		try {
			NavigateToJournalFormTypeA();
			TestLogic.VerifyRetailToIRAJournalFormSubmitA("16869265", "2", "IRACC");
			reporter.LogSuccess("VerifyRetailToIRAJournalFormSubmitTypeATest",
					"Successfully Journal Request Submission With Type A");
		} catch (Exception e) {
			reporter.LogFail("VerifyRetailToIRAJournalFormSubmitTypeATest", e.getMessage());
			throw e;
		}
	}

	// Test Case 10
	@Test
	public void VerifyTransferDescTest() throws Exception {
		try {
			NavigateToJournalFormTypeA();
			Assert.isTrue(TestLogic.VerifyTransferDescRetailToIRA("16869265"),
					"Transfer Description Verified For Retail to IRA");
			reporter.LogSuccess("VerifyTransferDescTest", "Transfer Description Verified For Retail to IRA");
		} catch (Exception e) {
			reporter.LogFail("VerifyTransferDescTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 11
	@Test
	public void VerifyRetailToIRAJournalFormSubmitTypeBSLOATest() throws Exception {
		try {
			NavigateToJournalFormPage();
			TestLogic.VerifyRetailToIRAJournalFormSubmit("74116970", "B", "Amita", "0.7", "EMPRP");
			reporter.LogSuccess("VerifyRetailToIRAJournalFormSubmitTypeBSLOATest",
					"Successfully Journal Request Submission With Type B and SLOA");
		} catch (Exception e) {
			reporter.LogFail("VerifyRetailToIRAJournalFormSubmitTypeBSLOATest", e.getMessage());
			throw e;
		}
	}

	// Test Case 12
	@Test
	public void VerifyRetailToIRAJournalFormSubmitTypeDFullTest() throws Exception {
		try {
			NavigateToJournalFormPage();
			TestLogic.VerifyRetailToIRAJournalFormSubmitFull("74116970", "D", "EMPRP");
			reporter.LogSuccess("VerifyRetailToIRAJournalFormSubmitTypeDFullTest",
					"Successfully Journal Request Submission With Type D and Full Transfer Type");
		} catch (Exception e) {
			reporter.LogFail("VerifyRetailToIRAJournalFormSubmitTypeDFullTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 13
	@Test
	public void VerifyRetailToIRAJournalWarningPopWhenNoAttachmentTest() throws Exception {
		try {
			NavigateToJournalFormPage();
			Assert.isTrue(
					TestLogic.VerifyJournalWarningPopWhenNoAttachment("74116970", "B", "0.7", "EMPRP",
							"There is 1 attachment required."),
					"Error PopUp Verified For No Attachment For a Retail to IRA Journal");
			reporter.LogSuccess("VerifyRetailToIRAJournalWarningPopWhenNoAttachmentTest",
					"Error PopUp Verified For No Attachment For a Retail to IRA Journal");
		} catch (Exception e) {
			reporter.LogFail("VerifyRetailToIRAJournalWarningPopWhenNoAttachmentTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 14
	@Test
	public void VerifyIRAtoRetailTransferDescTest() throws Exception {
		try {
			NavigateToJournalFormPageMMF();
			Assert.isTrue(TestLogic.VerifyTransferDescIRAtoRetail("19401744"),
					"Transfer Description Verified For IRA to Retail");
			reporter.LogSuccess("VerifyIRAtoRetailTransferDescTest", "Transfer Description Verified For IRA to Retail");
		} catch (Exception e) {
			reporter.LogFail("VerifyIRAtoRetailTransferDescTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 15
	@Test
	public void VerifyFromAccountTypeTest() throws Exception {
		try {
			NavigateToJournalFormPageMMF();
			Assert.isTrue(TestLogic.VerifyIRAAccInfoFieldsForIRAtoRetail("19401744", "B", "1"),
					"From Account Type Verified For IRA to Retail");
			reporter.LogSuccess("VerifyFromAccountTypeTest", "From Account Type Verified For IRA to Retail");
		} catch (Exception e) {
			reporter.LogFail("VerifyFromAccountTypeTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 16
	@Test
	public void VerifyToAccountTypeTest() throws Exception {
		try {
			NavigateToJournalFormPageMMF();
			Assert.isTrue(TestLogic.VerifyIRAAccInfoFieldsForIRAtoRetail("19401744", "B", "1"),
					"To Account Type Verified For IRA to Retail");
			reporter.LogSuccess("VerifyToAccountTypeTest", "To Account Type Verified For IRA to Retail");
		} catch (Exception e) {
			reporter.LogFail("VerifyToAccountTypeTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 17
	@Test
	public void VerifyToAccountNumberTest() throws Exception {
		try {
			NavigateToJournalFormPageMMF();
			Assert.isTrue(TestLogic.VerifyIRAAccInfoFieldsForIRAtoRetail("19401744", "B", "1"),
					"To Account Number Verified For IRA to Retail");
			reporter.LogSuccess("VerifyToAccountNumberTest", "To Account Number Verified For IRA to Retail");
		} catch (Exception e) {
			reporter.LogFail("VerifyToAccountNumberTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 18
	@Test
	public void VerifyIRAtoRetailJournalFormSubmitTypeBTest() throws Exception {
		try {
			NavigateToJournalFormPageMMF();
			TestLogic.VerifyIRAtoRetailJournalFormSubmit("19401744", "B", "", "0.5", "BCHK", "", "");
			reporter.LogSuccess("VerifyIRAtoRetailJournalFormSubmitTypeBTest",
					"Successfully Journal Request Submission With Type B");
		} catch (Exception e) {
			reporter.LogFail("VerifyIRAtoRetailJournalFormSubmitTypeBTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 19
	@Test
	public void VerifyIRAtoRetailJournalFormSubmitWithFederalTaxTest() throws Exception {
		try {
			NavigateToJournalFormPageMMF();
			TestLogic.VerifyIRAtoRetailJournalFormSubmit("19401744", "D", "", "1", "BCHK", "10", "");
			reporter.LogSuccess("VerifyIRAtoRetailJournalFormSubmitWithFederalTaxTest",
					"Successfully Journal Request Submission Type D With Federal Tax 10%");
		} catch (Exception e) {
			reporter.LogFail("VerifyIRAtoRetailJournalFormSubmitWithFederalTaxTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 20
	@Test
	public void VerifyIRAtoRetailJournalFormSubmitWithStateTaxTest() throws Exception {
		try {
			NavigateToJournalFormPageMMF();
			TestLogic.VerifyIRAtoRetailJournalFormSubmit("19401744", "C", "", "1", "BCHK", "", "10");
			reporter.LogSuccess("VerifyIRAtoRetailJournalFormSubmitWithStateTaxTest",
					"Successfully Journal Request Submission Type C With State Tax 10%");
		} catch (Exception e) {
			reporter.LogFail("VerifyIRAtoRetailJournalFormSubmitWithStateTaxTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 21
	@Test
	public void VerifyIRAtoRetailJournalFormSubmitWithStateFederalTaxTest() throws Exception {
		try {
			NavigateToJournalFormPageMMF();
			TestLogic.VerifyIRAtoRetailJournalFormSubmit("19401744", "E", "", "2", "BCHK", "10", "10");
			reporter.LogSuccess("VerifyIRAtoRetailJournalFormSubmitWithStateFederalTaxTest",
					"Successfully Journal Request Submission Type E With Federal and State Tax 10%");
		} catch (Exception e) {
			reporter.LogFail("VerifyIRAtoRetailJournalFormSubmitWithStateFederalTaxTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 22
	@Test
	public void VerifyFinalAmountAfterEnteringStateTaxTest() throws Exception {
		try {
			NavigateToJournalFormPageMMF();
			Assert.isTrue(TestLogic.VerifyWithholdingFieldsWithFederalTax("19401744", "C", "", "2", "BCHK", "10", ""),
					"Final Amount Verfied After Entering Federal Tax 10%");
			reporter.LogSuccess("VerifyFinalAmountAfterEnteringStateTaxTest",
					"Final Amount Verfied After Entering Federal Tax 10%");
		} catch (Exception e) {
			reporter.LogFail("VerifyFinalAmountAfterEnteringStateTaxTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 23
	@Test
	public void VerifyFedWithholdingWithFederalTaxTest() throws Exception {
		try {
			NavigateToJournalFormPageMMF();
			Assert.isTrue(TestLogic.VerifyWithholdingFieldsWithFederalTax("19401744", "B", "", "2", "BCHK", "10", ""),
					"Fed Withholding Amount Verfied After Entering Federal Tax 10%");
			reporter.LogSuccess("VerifyFedWithholdingWithFederalTaxTest",
					"Fed Withholding Amount Verfied After Entering Federal Tax 10%");
		} catch (Exception e) {
			reporter.LogFail("VerifyFedWithholdingWithFederalTaxTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 24
	@Test
	public void VerifyStateWithholdingWithFederalTaxTest() throws Exception {
		try {
			NavigateToJournalFormPageMMF();
			Assert.isTrue(TestLogic.VerifyWithholdingFieldsWithFederalTax("19401744", "D", "", "2", "BCHK", "10", ""),
					"State Withholding Amount Verfied After Entering Federal Tax 10%");
			reporter.LogSuccess("VerifyStateWithholdingWithFederalTaxTest",
					"State Withholding Amount Verfied After Entering Federal Tax 10%");
		} catch (Exception e) {
			reporter.LogFail("VerifyStateWithholdingWithFederalTaxTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 25
	@Test
	public void VerifyFedWithholdingWithStateTaxTest() throws Exception {
		try {
			NavigateToJournalFormPageMMF();
			Assert.isTrue(TestLogic.VerifyWithholdingFieldsWithStateTax("19401744", "B", "", "2", "BCHK", "", "10"),
					"Fed Withholding Amount Verfied After Entering State Tax 10%");
			reporter.LogSuccess("VerifyFedWithholdingWithStateTaxTest",
					"Fed Withholding Amount Verfied After Entering State Tax 10%");
		} catch (Exception e) {
			reporter.LogFail("VerifyFedWithholdingWithStateTaxTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 26
	@Test
	public void VerifyFinalAmountWithStateTaxTest() throws Exception {
		try {
			NavigateToJournalFormPageMMF();
			Assert.isTrue(TestLogic.VerifyWithholdingFieldsWithStateTax("19401744", "B", "", "2", "BCHK", "", "10"),
					"Final Amount Verfied After Entering State Tax 10%");
			reporter.LogSuccess("VerifyFinalAmountWithStateTaxTest",
					"Final Amount Verfied After Entering State Tax 10%");
		} catch (Exception e) {
			reporter.LogFail("VerifyFinalAmountWithStateTaxTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 27
	@Test
	public void VerifyStateWithholdingWithStateTaxTest() throws Exception {
		try {
			NavigateToJournalFormPageMMF();
			Assert.isTrue(TestLogic.VerifyWithholdingFieldsWithStateTax("19401744", "B", "", "2", "BCHK", "", "10"),
					"State Withholding Verfied After Entering State Tax 10%");
			reporter.LogSuccess("VerifyStateWithholdingWithStateTaxTest",
					"State Withholding Verfied After Entering State Tax 10%");
		} catch (Exception e) {
			reporter.LogFail("VerifyStateWithholdingWithStateTaxTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 28
	@Test
	public void VerifyWarningPopUpForInvalidStateTaxTest() throws Exception {
		try {
			NavigateToJournalFormPageMMF();
			Assert.isTrue(
					TestLogic.VerifyWarningPopUpForInvalidStateTax("19401744", "B", "", "2", "BCHK", "", "abcd",
							"Format is invalid, format with numeric characters only"),
					"Error Pop Verified When State Tax Is Invalid");
			reporter.LogSuccess("VerifyWarningPopUpForInvalidStateTaxTest",
					"Error Pop Verified When State Tax Is Invalid");
		} catch (Exception e) {
			reporter.LogFail("VerifyWarningPopUpForInvalidStateTaxTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 29
	@Test
	public void VerifyWarningPopUpForInvalidFederalTaxTest() throws Exception {
		try {
			NavigateToJournalFormPageMMF();
			Assert.isTrue(
					TestLogic.VerifyWarningPopUpForInvalidFederalTax("19401744", "B", "", "2", "BCHK", "", "abcd",
							"Format is invalid, format with numeric characters only"),
					"Error Pop Verified When Federal Tax Is Invalid");
			reporter.LogSuccess("VerifyWarningPopUpForInvalidFederalTaxTest",
					"Error Pop Verified When Federal Tax Is Invalid");
		} catch (Exception e) {
			reporter.LogFail("VerifyWarningPopUpForInvalidFederalTaxTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 30
	@Test
	public void VerifyIRAtoRetailJournalFormSubmitWithSLOATest() throws Exception {
		try {
			NavigateToJournalFormPageMMF();
			TestLogic.VerifyIRAtoRetailJournalFormSubmit("19401744", "B", "Amita", "2", "BCHK", "", "");
			reporter.LogSuccess("VerifyIRAtoRetailJournalFormSubmitWithSLOATest",
					"Successfully Journal Request Submission Type B With SLOA");
		} catch (Exception e) {
			reporter.LogFail("VerifyIRAtoRetailJournalFormSubmitWithSLOATest", e.getMessage());
			throw e;
		}
	}

	// Test Case 31
	@Test
	public void VerifyIRAtoRetailJournalFormSubmitWithoutAdvisoryTest() throws Exception {
		try {
			NavigateToJournalFormPageMMF();
			TestLogic.VerifyIRAtoRetailJournalFormSubmit("19401744", "D", "", "2", "BCHK", "", "");
			reporter.LogSuccess("VerifyIRAtoRetailJournalFormSubmitWithoutAdvisoryTest",
					"Successfully Journal Request Submission Type B With Cash");
		} catch (Exception e) {
			reporter.LogFail("VerifyIRAtoRetailJournalFormSubmitWithoutAdvisoryTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 32
	@Test
	public void VerifyIRAtoRetailJournalFormSubmitTypeBWithCashTest() throws Exception {
		try {
			NavigateToJournalFormCash();
			TestLogic.VerifyIRAtoRetailJournalFormSubmitCash("34780866", "D", "1", "BCHK", "", "");
			reporter.LogSuccess("VerifyIRAtoRetailJournalFormSubmitTypeBWithCashTest",
					"Successfully Journal Request Submission Type B With Cash");
		} catch (Exception e) {
			reporter.LogFail("VerifyIRAtoRetailJournalFormSubmitTypeBWithCashTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 33
	@Test
	public void VerifyIRAtoRetailJournalFormSubmitTypeDWithCashTest() throws Exception {
		try {
			NavigateToJournalFormCash();
			TestLogic.VerifyIRAtoRetailJournalFormSubmitCash("34780866", "D", "1", "BCHK", "15", "");
			reporter.LogSuccess("VerifyIRAtoRetailJournalFormSubmitTypeDWithCashTest",
					"Successfully Journal Request Submission Type D With Cash and Federal Tax 15%");
		} catch (Exception e) {
			reporter.LogFail("VerifyIRAtoRetailJournalFormSubmitTypeDWithCashTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 34
	@Test
	public void VerifyIRAtoRetailJournalFormSubmitTypeCWithCashTest() throws Exception {
		try {
			NavigateToJournalFormCash();
			TestLogic.VerifyIRAtoRetailJournalFormSubmitCash("34780866", "C", "1", "BCHK", "", "7");
			reporter.LogSuccess("VerifyIRAtoRetailJournalFormSubmitTypeCWithCashTest",
					"Successfully Journal Request Submission Type C With Cash and State Tax 7%");
		} catch (Exception e) {
			reporter.LogFail("VerifyIRAtoRetailJournalFormSubmitTypeCWithCashTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 35
	@Test
	public void VerifyIRAtoRetailJournalFormSubmitTypeEWithCashTest() throws Exception {
		try {
			NavigateToJournalFormCash();
			TestLogic.VerifyIRAtoRetailJournalFormSubmitCash("34780866", "E", "1", "BCHK", "", "7");
			reporter.LogSuccess("VerifyIRAtoRetailJournalFormSubmitTypeEWithCashTest",
					"Successfully Journal Request Submission Type E With Cash");
		} catch (Exception e) {
			reporter.LogFail("VerifyIRAtoRetailJournalFormSubmitTypeEWithCashTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 36
	@Test
	public void VerifyWarningPopUpForFederalTaxLessThan10Test() throws Exception {
		try {
			NavigateToJournalFormPageMMF();
			Assert.isTrue(
					TestLogic.VerifyWarningPopUpForInvalidFederalTax("19401744", "B", "", "2", "BCHK", "", "5",
							"Federal Withholding cannot be less than 10%"),
					"Error Pop Verified When Federal Tax Is Less Than 10");
			reporter.LogSuccess("VerifyWarningPopUpForFederalTaxLessThan10Test",
					"Error Pop Verified When Federal Tax Is Less Than 10");
		} catch (Exception e) {
			reporter.LogFail("VerifyWarningPopUpForFederalTaxLessThan10Test", e.getMessage());
			throw e;
		}
	}

	// Test Case 37
	@Test
	public void VerifyTransferDescIRAtoRetailTest() throws Exception {
		try {
			NavigateToJournalFormCash();
			Assert.isTrue(TestLogic.VerifyTransDescIRAtoRetail("34780866"),
					"Transfer Description Verified For IRA To Retail");
			reporter.LogSuccess("VerifyTransferDescIRAtoRetailTest", "Transfer Description Verified For IRA To Retail");
		} catch (Exception e) {
			reporter.LogFail("VerifyTransferDescIRAtoRetailTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 38
	@Test
	public void VerifyIRAtoRetailJournalFormSubmitFullTransferTest() throws Exception {
		try {
			NavigateToJournalFormCash();
			TestLogic.VerifyIRAtoRetailJournalFormSubmitFullTransfer("34780866", "B", "1", "BCHK", "", "");
			reporter.LogSuccess("VerifyIRAtoRetailJournalFormSubmitTypeEWithCashTest",
					"Successfully Journal Request Submission With Full Cash Transfer");
		} catch (Exception e) {
			reporter.LogFail("VerifyIRAtoRetailJournalFormSubmitTypeEWithCashTest", e.getMessage());
			throw e;
		}
	}

}