package baird.LiquidOffice.TestSuite;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInfo;
import org.springframework.util.Assert;

import baird.LiquidOffice.Automation.BusinessLayer.CTAcheckFormTestLogic;

/**
 * @author AmitaKumari
 */

public class CTAcheckIRATests extends TestBase {

	CTAcheckFormTestLogic TestLogic = null;

	@BeforeEach
	public void TestInitialize(TestInfo info) {
		log.LogDebug(info.getDisplayName());
		TestLogic = new CTAcheckFormTestLogic(commonapi, testSettings);
	}

	void NavigateToCheckFormPageNonAdvisoryAcc() throws Exception {
		TestLogic.OpenCTApage("SignIn");
		TestLogic.GetClientInfo("86997083", "Check Request");
		TestLogic.ClickContinueOnClientInfo();
	}

	// Test Case 1
	@Test
	public void VerifyCheckIRAWithholdingTitleTest() throws Exception {
		try {
			NavigateToCheckFormPageNonAdvisoryAcc();
			Assert.isTrue(TestLogic.VerifyIRAWithholdingTitleTest(),
					"IRA Withholding/Distribution Information Title Verified");
			reporter.LogSuccess("VerifyCheckIRAWithholdingTitleTest",
					"IRA Withholding/Distribution Information Title Verified");
		} catch (Exception e) {
			reporter.LogFail("VerifyCheckIRAWithholdingTitleTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 2
	@Test
	public void VerifyCheckIRAFormSubmitOneTimeTypeATest() throws Exception {
		try {
			NavigateToCheckFormPageNonAdvisoryAcc();
			TestLogic.CreateIRACheckRequestOneTimeTypeA(".2", "Check Issued", "0", "0", "REG", "AK");
			if (TestLogic.VerifyErrorMessageForDuplicateRecord() == false) {
				TestLogic.SendCheckRequest();
				NavigateToCheckFormPageNonAdvisoryAcc();
				TestLogic.CreateIRACheckRequestOneTimeTypeA(".2", "Check Issued", "0", "0", "REG", "AK");
				if (TestLogic.VerifyErrorMessageForDuplicateRecord()) {
					TestLogic.SendCheckRequest();
				} else {
					throw new Exception("Failed");
				}
			}
			reporter.LogSuccess("VerifyCheckIRAFormSubmitOneTimeTypeATest",
					"Successfully IRA Check Request Submission For Request Type One Time & Type A");
		} catch (Exception e) {
			reporter.LogFail("VerifyCheckIRAFormSubmitOneTimeTypeATest", e.getMessage());
			throw e;
		}
	}

	// Test Case 3
	@Test
	public void VerifyCheckIRAFormSubmitOneTimeTypeBTest() throws Exception {
		try {
			NavigateToCheckFormPageNonAdvisoryAcc();
			TestLogic.CreateIRACheckRequestOneTimeTypeBCDEF(".1", "Check Issued", "0", "0", "REG", "Automation",
					"17th Floor 777E", "Baird", "Milwaukee", "WI", "53202", "B", "AK");
			if (TestLogic.VerifyErrorMessageForDuplicateRecord() == false) {
				TestLogic.SendCheckRequest();
				NavigateToCheckFormPageNonAdvisoryAcc();
				TestLogic.CreateIRACheckRequestOneTimeTypeBCDEF(".1", "Check Issued", "0", "0", "REG", "Automation",
						"17th Floor 777E", "Baird", "Milwaukee", "WI", "53202", "B", "AK");
				if (TestLogic.VerifyErrorMessageForDuplicateRecord()) {
					TestLogic.SendCheckRequest();
				} else {
					throw new Exception("Failed");
				}
			}
			reporter.LogSuccess("VerifyCheckIRAFormSubmitOneTimeTypeBTest",
					"Successfully IRA Check Request Submission for Type B with Distribution Form On File");
		} catch (Exception e) {
			reporter.LogFail("VerifyCheckIRAFormSubmitOneTimeTypeBTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 4
	@Test
	public void VerifyCheckIRAFormSubmitOneTimeTypeCTest() throws Exception {
		try {
			NavigateToCheckFormPageNonAdvisoryAcc();
			TestLogic.CreateIRACheckRequestOneTimeTypeBCDEF(".2", "Check Issued", "0", "0", "REG", "Automation",
					"17th Floor 777E", "Baird", "Milwaukee", "WI", "53202", "C", "AK");
			if (TestLogic.VerifyErrorMessageForDuplicateRecord() == false) {
				TestLogic.SendCheckRequest();
				NavigateToCheckFormPageNonAdvisoryAcc();
				TestLogic.CreateIRACheckRequestOneTimeTypeBCDEF(".2", "Check Issued", "0", "0", "REG", "Automation",
						"17th Floor 777E", "Baird", "Milwaukee", "WI", "53202", "C", "AK");
				if (TestLogic.VerifyErrorMessageForDuplicateRecord()) {
					TestLogic.SendCheckRequest();
				} else {
					throw new Exception("Failed");
				}
			}
			reporter.LogSuccess("VerifyCheckIRAFormSubmitOneTimeTypeCTest",
					"Successfully IRA Check Request Submission for Type C with Distribution Form On File");
		} catch (Exception e) {
			reporter.LogFail("VerifyCheckIRAFormSubmitOneTimeTypeCTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 5
	@Test
	public void VerifyCheckIRAFormSubmitOneTimeTypeDTest() throws Exception {
		try {
			NavigateToCheckFormPageNonAdvisoryAcc();
			TestLogic.CreateIRACheckRequestOneTimeTypeBCDEF(".3", "Check Issued", "0", "0", "REG", "Automation",
					"17th Floor 777E", "Baird", "Milwaukee", "WI", "53202", "D", "AK");
			if (TestLogic.VerifyErrorMessageForDuplicateRecord() == false) {
				TestLogic.SendCheckRequest();
				NavigateToCheckFormPageNonAdvisoryAcc();
				TestLogic.CreateIRACheckRequestOneTimeTypeBCDEF(".3", "Check Issued", "0", "0", "REG", "Automation",
						"17th Floor 777E", "Baird", "Milwaukee", "WI", "53202", "D", "AK");
				if (TestLogic.VerifyErrorMessageForDuplicateRecord()) {
					TestLogic.SendCheckRequest();
				} else {
					throw new Exception("Failed");
				}
			}
			reporter.LogSuccess("VerifyCheckIRAFormSubmitOneTimeTypeDTest",
					"Successfully IRA Check Request Submission for Type D with Distribution Form On File");
		} catch (Exception e) {
			reporter.LogFail("VerifyCheckIRAFormSubmitOneTimeTypeCTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 6
	@Test
	public void VerifyCheckIRAFormSubmitOneTimeTypeETest() throws Exception {
		try {
			NavigateToCheckFormPageNonAdvisoryAcc();
			TestLogic.CreateIRACheckRequestOneTimeTypeBCDEF(".3", "Check Issued", "0", "0", "REG", "Automation",
					"17th Floor 777E", "Baird", "Milwaukee", "WI", "53202", "E", "AK");
			if (TestLogic.VerifyErrorMessageForDuplicateRecord() == false) {
				TestLogic.SendCheckRequest();
				NavigateToCheckFormPageNonAdvisoryAcc();
				TestLogic.CreateIRACheckRequestOneTimeTypeBCDEF(".3", "Check Issued", "0", "0", "REG", "Automation",
						"17th Floor 777E", "Baird", "Milwaukee", "WI", "53202", "E", "AK");
				if (TestLogic.VerifyErrorMessageForDuplicateRecord()) {
					TestLogic.SendCheckRequest();
				} else {
					throw new Exception("Failed");
				}
			}
			reporter.LogSuccess("VerifyCheckIRAFormSubmitOneTimeTypeETest",
					"Successfully IRA Check Request Submission for Type E with Distribution Form On File");
		} catch (Exception e) {
			reporter.LogFail("VerifyCheckIRAFormSubmitOneTimeTypeETest", e.getMessage());
			throw e;
		}
	}

	// Test Case 7
	@Test
	public void VerifyCheckIRAFormSubmitOneTimeTypeF1Test() throws Exception {
		try {
			NavigateToCheckFormPageNonAdvisoryAcc();
			TestLogic.CreateIRACheckRequestOneTimeTypeBCDEF(".4", "Check Issued", "0", "0", "REG", "Automation",
					"17th Floor 777E", "Baird", "Milwaukee", "WI", "53202", "F1", "AK");
			if (TestLogic.VerifyErrorMessageForDuplicateRecord() == false) {
				TestLogic.SendCheckRequest();
				NavigateToCheckFormPageNonAdvisoryAcc();
				TestLogic.CreateIRACheckRequestOneTimeTypeBCDEF(".4", "Check Issued", "0", "0", "REG", "Automation",
						"17th Floor 777E", "Baird", "Milwaukee", "WI", "53202", "F1", "AK");
				if (TestLogic.VerifyErrorMessageForDuplicateRecord()) {
					TestLogic.SendCheckRequest();
				} else {
					throw new Exception("Failed");
				}
			}
			reporter.LogSuccess("VerifyCheckIRAFormSubmitOneTimeTypeF1Test",
					"Successfully IRA Check Request Submission for Type F1 with Distribution Form On File");
		} catch (Exception e) {
			reporter.LogFail("VerifyCheckIRAFormSubmitOneTimeTypeF1Test", e.getMessage());
			throw e;
		}
	}

	// Test Case 8
	@Test
	public void VerifyCheckIRAFormSubmitOneTimeTypeF2Test() throws Exception {
		try {
			NavigateToCheckFormPageNonAdvisoryAcc();
			TestLogic.CreateIRACheckRequestOneTimeTypeBCDEF(".5", "Check Issued", "0", "0", "REG", "Automation",
					"17th Floor 777E", "Baird", "Milwaukee", "WI", "53202", "F2", "AK");
			if (TestLogic.VerifyErrorMessageForDuplicateRecord() == false) {
				TestLogic.SendCheckRequest();
				NavigateToCheckFormPageNonAdvisoryAcc();
				TestLogic.CreateIRACheckRequestOneTimeTypeBCDEF(".5", "Check Issued", "0", "0", "REG", "Automation",
						"17th Floor 777E", "Baird", "Milwaukee", "WI", "53202", "F2", "AK");
				if (TestLogic.VerifyErrorMessageForDuplicateRecord()) {
					TestLogic.SendCheckRequest();
				} else {
					throw new Exception("Failed");
				}
			}
			reporter.LogSuccess("VerifyCheckIRAFormSubmitOneTimeTypeF2Test",
					"Successfully IRA Check Request Submission for Type F2 with Distribution Form On File");
		} catch (Exception e) {
			reporter.LogFail("VerifyCheckIRAFormSubmitOneTimeTypeF2Test", e.getMessage());
			throw e;
		}
	}

	// Test Case 9
	@Test
	public void VerifyCheckIRAFormSubmitOneTimeTypeF3Test() throws Exception {
		try {
			NavigateToCheckFormPageNonAdvisoryAcc();
			TestLogic.CreateIRACheckRequestOneTimeTypeBCDEF(".6", "Check Issued", "0", "0", "REG", "Automation",
					"17th Floor 777E", "Baird", "Milwaukee", "WI", "53202", "F2", "AK");
			if (TestLogic.VerifyErrorMessageForDuplicateRecord() == false) {
				TestLogic.SendCheckRequest();
				NavigateToCheckFormPageNonAdvisoryAcc();
				TestLogic.CreateIRACheckRequestOneTimeTypeBCDEF(".6", "Check Issued", "0", "0", "REG", "Automation",
						"17th Floor 777E", "Baird", "Milwaukee", "WI", "53202", "F3", "AK");
				if (TestLogic.VerifyErrorMessageForDuplicateRecord()) {
					TestLogic.SendCheckRequest();
				} else {
					throw new Exception("Failed");
				}
			}
			reporter.LogSuccess("VerifyCheckIRAFormSubmitOneTimeTypeF3Test",
					"Successfully IRA Check Request Submission for Type F3 with Distribution Form On File");
		} catch (Exception e) {
			reporter.LogFail("VerifyCheckIRAFormSubmitOneTimeTypeF3Test", e.getMessage());
			throw e;
		}
	}

	void NavigateToCheckFormNoDistRecord() throws Exception {
		TestLogic.OpenCTApage("SignIn");
		TestLogic.GetClientInfo("13269855", "Check Request");
		TestLogic.ClickContinueOnClientInfo();
	}

	// Test Case 10
	@Test
	public void VerifyCheckIRAWarningPopUpWithoutDistRecordTest() throws Exception {
		try {
			NavigateToCheckFormNoDistRecord();

			Assert.isTrue(TestLogic.VerifyWarningPopUpWithoutDistRecord(".6",
					"There is no Distribution record on file for this account. Please change your request one time"),
					"Warning PopUp Verified When No Distribution Record");
			reporter.LogSuccess("VerifyCheckIRAWarningPopUpWithoutDistRecordTest",
					"Warning PopUp Verified When No Distribution Record");
		} catch (Exception e) {
			reporter.LogFail("VerifyCheckIRAWarningPopUpWithoutDistRecordTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 11
	@Test
	public void VerifyCheckIRAFormSubmitOnDemandTypeATest() throws Exception {
		try {
			NavigateToCheckFormPageNonAdvisoryAcc();
			TestLogic.CreateIRACheckRequestOnDemandTypeA(".7", "Check Issued", "0", "0", "AK");
			if (TestLogic.VerifyErrorMessageForDuplicateRecord() == false) {
				TestLogic.SendCheckRequest();
				NavigateToCheckFormPageNonAdvisoryAcc();
				TestLogic.CreateIRACheckRequestOnDemandTypeA(".7", "Check Issued", "0", "0", "AK");
				if (TestLogic.VerifyErrorMessageForDuplicateRecord()) {
					TestLogic.SendCheckRequest();
				} else {
					throw new Exception("Failed");
				}
			}
			reporter.LogSuccess("VerifyCheckIRAFormSubmitOnDemandTypeATest",
					"Successfully IRA Check Request Submission for Type A with Distribution Form On Demand");
		} catch (Exception e) {
			reporter.LogFail("VerifyCheckIRAFormSubmitOnDemandTypeATest", e.getMessage());
			throw e;
		}
	}

	// Test Case 12
	@Test
	public void VerifyCheckIRAFormSubmitOnDemandTypeBTest() throws Exception {
		try {
			NavigateToCheckFormPageNonAdvisoryAcc();
			TestLogic.CreateIRACheckRequestOnDemandTypeB(".8", "Check Issued", "0", "0", "Automation",
					"17th Floor 777E", "Baird", "Milwaukee", "WI", "53202", "AK");
			if (TestLogic.VerifyErrorMessageForDuplicateRecord() == false) {
				TestLogic.SendCheckRequest();
				NavigateToCheckFormPageNonAdvisoryAcc();
				TestLogic.CreateIRACheckRequestOnDemandTypeB(".8", "Check Issued", "0", "0", "Automation",
						"17th Floor 777E", "Baird", "Milwaukee", "WI", "53202", "AK");
				if (TestLogic.VerifyErrorMessageForDuplicateRecord()) {
					TestLogic.SendCheckRequest();
				} else {
					throw new Exception("Failed");
				}
			}
			reporter.LogSuccess("VerifyCheckIRAFormSubmitOnDemandTypeBTest",
					"Successfully IRA Check Request Submission for Type B with Distribution Form On Demand");
		} catch (Exception e) {
			reporter.LogFail("VerifyCheckIRAFormSubmitOnDemandTypeBTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 13
	@Test
	public void VerifyCheckIRAFormSubmitOnDemandTypeCTest() throws Exception {
		try {
			NavigateToCheckFormPageNonAdvisoryAcc();
			TestLogic.CreateIRACheckRequestOnDemandTypeC(".9", "Check Issued", "0", "0", "Automation",
					"17th Floor 777E", "Baird", "Milwaukee", "WI", "53202", "AK");
			if (TestLogic.VerifyErrorMessageForDuplicateRecord() == false) {
				TestLogic.SendCheckRequest();
				NavigateToCheckFormPageNonAdvisoryAcc();
				TestLogic.CreateIRACheckRequestOnDemandTypeC(".9", "Check Issued", "0", "0", "Automation",
						"17th Floor 777E", "Baird", "Milwaukee", "WI", "53202", "AK");
				if (TestLogic.VerifyErrorMessageForDuplicateRecord()) {
					TestLogic.SendCheckRequest();
				} else {
					throw new Exception("Failed");
				}
			}
			reporter.LogSuccess("VerifyCheckIRAFormSubmitOnDemandTypeCTest",
					"Successfully IRA Check Request Submission for Type C with Distribution Form On Demand");
		} catch (Exception e) {
			reporter.LogFail("VerifyCheckIRAFormSubmitOnDemandTypeCTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 14
	@Test
	public void VerifyCheckIRAFormSubmitOnDemandTypeDTest() throws Exception {
		try {
			NavigateToCheckFormPageNonAdvisoryAcc();
			TestLogic.CreateIRACheckRequestOnDemandTypeD("1", "Check Issued", "0", "0", "Automation", "17th Floor 777E",
					"Baird", "Milwaukee", "WI", "53202", "AK");
			if (TestLogic.VerifyErrorMessageForDuplicateRecord() == false) {
				TestLogic.SendCheckRequest();
				NavigateToCheckFormPageNonAdvisoryAcc();
				TestLogic.CreateIRACheckRequestOnDemandTypeD("1", "Check Issued", "0", "0", "Automation",
						"17th Floor 777E", "Baird", "Milwaukee", "WI", "53202", "AK");
				if (TestLogic.VerifyErrorMessageForDuplicateRecord()) {
					TestLogic.SendCheckRequest();
				} else {
					throw new Exception("Failed");
				}
			}
			reporter.LogSuccess("VerifyCheckIRAFormSubmitOnDemandTypeDTest",
					"Successfully IRA Check Request Submission for Type D with Distribution Form On Demand");
		} catch (Exception e) {
			reporter.LogFail("VerifyCheckIRAFormSubmitOnDemandTypeDTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 15
	@Test
	public void VerifyCheckIRAFormSubmitOnDemandTypeETest() throws Exception {
		try {
			NavigateToCheckFormPageNonAdvisoryAcc();
			TestLogic.CreateIRACheckRequestOnDemandTypeE("1.1", "Check Issued", "0", "0", "Automation",
					"17th Floor 777E", "Baird", "Milwaukee", "WI", "53202", "AK");
			if (TestLogic.VerifyErrorMessageForDuplicateRecord() == false) {
				TestLogic.SendCheckRequest();
				NavigateToCheckFormPageNonAdvisoryAcc();
				TestLogic.CreateIRACheckRequestOnDemandTypeE("1.1", "Check Issued", "0", "0", "Automation",
						"17th Floor 777E", "Baird", "Milwaukee", "WI", "53202", "AK");
				if (TestLogic.VerifyErrorMessageForDuplicateRecord()) {
					TestLogic.SendCheckRequest();
				} else {
					throw new Exception("Failed");
				}
			}
			reporter.LogSuccess("VerifyCheckIRAFormSubmitOnDemandTypeETest",
					"Successfully IRA Check Request Submission for Type E with Distribution Form On Demand");
		} catch (Exception e) {
			reporter.LogFail("VerifyCheckIRAFormSubmitOnDemandTypeETest", e.getMessage());
			throw e;
		}
	}

	// Test Case 16
	@Test
	public void VerifyCheckIRAFormSubmitOnDemandTypeF1Test() throws Exception {
		try {
			NavigateToCheckFormPageNonAdvisoryAcc();
			TestLogic.CreateIRACheckRequestOnDemandTypeF1("1.2", "Check Issued", "0", "0", "Automation",
					"17th Floor 777E", "Baird", "Milwaukee", "WI", "53202", "AK");
			if (TestLogic.VerifyErrorMessageForDuplicateRecord() == false) {
				TestLogic.SendCheckRequest();
				NavigateToCheckFormPageNonAdvisoryAcc();
				TestLogic.CreateIRACheckRequestOnDemandTypeF1("1.2", "Check Issued", "0", "0", "Automation",
						"17th Floor 777E", "Baird", "Milwaukee", "WI", "53202", "AK");
				if (TestLogic.VerifyErrorMessageForDuplicateRecord()) {
					TestLogic.SendCheckRequest();
				} else {
					throw new Exception("Failed");
				}
			}
			reporter.LogSuccess("VerifyCheckIRAFormSubmitOnDemandTypeF1Test",
					"Successfully IRA Check Request Submission for Type F1 with Distribution Form On Demand");
		} catch (Exception e) {
			reporter.LogFail("VerifyCheckIRAFormSubmitOnDemandTypeF1Test", e.getMessage());
			throw e;
		}
	}

	// Test Case 17
	@Test
	public void VerifyCheckIRAWarningPopUpDistRecordNotSelectedTest() throws Exception {
		try {
			NavigateToCheckFormPageNonAdvisoryAcc();

			Assert.isTrue(
					TestLogic.VerifyWarningPopUpDistRecordNotSelected("1.1", "Check Issued", "BCHK", "0", "0",
							"Automation", "17th Floor 777E", "Baird", "Milwaukee", "WI", "53202", "A", "AK",
							"Select an on file distribution record"),
					"Warning PopUp Verified When Distribution Record Is Not Selected");
			reporter.LogSuccess("VerifyCheckIRAWarningPopUpDistRecordNotSelectedTest",
					"Warning PopUp Verified When Distribution Record Is Not Selected");
		} catch (Exception e) {
			reporter.LogFail("VerifyCheckIRAWarningPopUpDistRecordNotSelectedTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 18
	@Test
	public void VerifyCheckIRAFormSubmitQCDTypeDTest() throws Exception {
		try {
			NavigateToCheckFormPageNonAdvisoryAcc();
			TestLogic.CreateIRACheckRequestQCDTypeD("1.3", "Check Issued", "0", "0", "REG", "D", "AK");
			if (TestLogic.VerifyErrorMessageForDuplicateRecord() == false) {
				TestLogic.SendCheckRequest();
				NavigateToCheckFormPageNonAdvisoryAcc();
				TestLogic.CreateIRACheckRequestQCDTypeD("1.3", "Check Issued", "0", "0", "REG", "D", "AK");
				if (TestLogic.VerifyErrorMessageForDuplicateRecord()) {
					TestLogic.SendCheckRequest();
				} else {
					throw new Exception("Failed");
				}
			}
			reporter.LogSuccess("VerifyCheckIRAFormSubmitQCDTypeDTest",
					"Successfully IRA Check Request Submission for Type D with Distribution Form QCD");
		} catch (Exception e) {
			reporter.LogFail("VerifyCheckIRAFormSubmitQCDTypeDTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 19
	@Test
	public void VerifyCheckIRATypeOfPayeeDdistQCDTest() throws Exception {
		try {
			NavigateToCheckFormPageNonAdvisoryAcc();
			Assert.isTrue(TestLogic.VerifyforQCDTypeOfPayeeD(), "Type Of Payee D Verified for QCD Distribution Form");
			reporter.LogSuccess("VerifyCheckIRATypeOfPayeeDdistQCDTest",
					"Type Of Payee D Verified for QCD Distribution Form");
		} catch (Exception e) {
			reporter.LogFail("VerifyCheckIRATypeOfPayeeDdistQCDTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 20
	@Test
	public void VerifyCheckIRAfirstWarningPopUpForQCDdistTest() throws Exception {
		try {
			NavigateToCheckFormPageNonAdvisoryAcc();
			Assert.isTrue(TestLogic.VerifyWarningMessageforQCDdist(
					"For a Qualified Charitable Distribution, the type of payee must be a domestic institution"),
					"Error PopUp Verified For QCD IRA Distribution");
			reporter.LogSuccess("VerifyCheckIRAWarningPopUpForQCDdistTest",
					"Error PopUp Verified For QCD IRA Distribution");
		} catch (Exception e) {
			reporter.LogFail("VerifyCheckIRAWarningPopUpForQCDdistTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 21
	@Test
	public void VerifyCheckIRAsecondWarningPopUpForQCDdistTest() throws Exception {
		try {
			NavigateToCheckFormPageNonAdvisoryAcc();
			Assert.isTrue(TestLogic.VerifysecondWarningMessageforQCDdist(
					"For a Qualified Charitable Distribution, the distribution type you selected is not allowed"),
					"Warning PopUp Verified For QCD IRA Distribution");
			reporter.LogSuccess("VerifyCheckIRAsecondWarningPopUpForQCDdistTest",
					"Warning PopUp Verified For QCD IRA Distribution");
		} catch (Exception e) {
			reporter.LogFail("VerifyCheckIRAsecondWarningPopUpForQCDdistTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 22
	@Test
	public void VerifyCheckIRAFormSubmitQCDwithFederalTaxTest() throws Exception {
		try {
			NavigateToCheckFormPageNonAdvisoryAcc();
			TestLogic.CreateIRACheckRequestQCDTypeD("1.4", "Check Issued", "10", "0", "REG", "D", "AK");
			if (TestLogic.VerifyErrorMessageForDuplicateRecord() == false) {
				TestLogic.SendCheckRequest();
				NavigateToCheckFormPageNonAdvisoryAcc();
				TestLogic.CreateIRACheckRequestQCDTypeD("1.4", "Check Issued", "10", "0", "REG", "D", "AK");
				if (TestLogic.VerifyErrorMessageForDuplicateRecord()) {
					TestLogic.SendCheckRequest();
				} else {
					throw new Exception("Failed");
				}
			}
			reporter.LogSuccess("VerifyCheckIRAFormSubmitQCDwithFederalTaxTest",
					"Successfully IRA Check Request Submission with Distribution Form QCD and Federal Tax 10%");
		} catch (Exception e) {
			reporter.LogFail("VerifyCheckIRAFormSubmitQCDwithFederalTaxTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 23
	@Test
	public void VerifyCheckIRAFormSubmitQCDwithStateTaxTest() throws Exception {
		try {
			NavigateToCheckFormPageNonAdvisoryAcc();
			TestLogic.CreateIRACheckRequestQCDTypeD("1.5", "Check Issued", "0", "10", "REG", "D", "AK");
			if (TestLogic.VerifyErrorMessageForDuplicateRecord() == false) {
				TestLogic.SendCheckRequest();
				NavigateToCheckFormPageNonAdvisoryAcc();
				TestLogic.CreateIRACheckRequestQCDTypeD("1.5", "Check Issued", "0", "10", "REG", "D", "AK");
				if (TestLogic.VerifyErrorMessageForDuplicateRecord()) {
					TestLogic.SendCheckRequest();
				} else {
					throw new Exception("Failed");
				}
			}
			reporter.LogSuccess("VerifyCheckIRAFormSubmitQCDwithStateTaxTest",
					"Successfully IRA Check Request Submission with Distribution Form QCD and State Tax 10%");
		} catch (Exception e) {
			reporter.LogFail("VerifyCheckIRAFormSubmitQCDwithStateTaxTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 24
	@Test
	public void VerifyCheckIRAFormSubmitQCDwithStateFederalTaxTest() throws Exception {
		try {
			NavigateToCheckFormPageNonAdvisoryAcc();
			TestLogic.CreateIRACheckRequestQCDTypeD("2", "Check Issued", "10", "10", "REG", "D", "AK");
			if (TestLogic.VerifyErrorMessageForDuplicateRecord() == false) {
				TestLogic.SendCheckRequest();
				NavigateToCheckFormPageNonAdvisoryAcc();
				TestLogic.CreateIRACheckRequestQCDTypeD("2", "Check Issued", "10", "10", "REG", "D", "AK");
				if (TestLogic.VerifyErrorMessageForDuplicateRecord()) {
					TestLogic.SendCheckRequest();
				} else {
					throw new Exception("Failed");
				}
			}
			reporter.LogSuccess("VerifyCheckIRAFormSubmitQCDwithStateFederalTaxTest",
					"Successfully IRA Check Request Submission with Distribution Form QCD and Federal/State Tax 10%");
		} catch (Exception e) {
			reporter.LogFail("VerifyCheckIRAFormSubmitQCDwithStateFederalTaxTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 25
	@Test
	public void VerifyCheckIRAErrorPopUpFederalTaxLessThan10perTest() throws Exception {
		try {
			NavigateToCheckFormPageNonAdvisoryAcc();
			Assert.isTrue(TestLogic.VerifyErrorPopUpFederalTax("9", "Federal Withholding cannot be less than 10%"),
					"Error PopUp Verified For Federal Tax less than 10%");
			reporter.LogSuccess("VerifyCheckIRAErrorPopUpFederalTaxLessThan10perTest",
					"Error Pop Verified For Federal Tax less than 10%");
		} catch (Exception e) {
			reporter.LogFail("VerifyCheckIRAErrorPopUpFederalTaxLessThan10perTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 26
	@Test
	public void VerifyCheckIRAFinalAmountAfterEnteringStateTaxTest() throws Exception {
		try {
			NavigateToCheckFormPageNonAdvisoryAcc();
			Assert.isTrue(TestLogic.VerifyFinalAmountWithStateTax(), "Final Amount Verfied After Entering State Tax");
			reporter.LogSuccess("VerifyCheckIRAFinalAmountAfterEnteringStateTaxTest",
					"Final Amount Verfied After Entering State Tax");
		} catch (Exception e) {
			reporter.LogFail("VerifyCheckIRAFinalAmountAfterEnteringStateTaxTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 27
	@Test
	public void VerifyFinalAmountAfterEnteringStateFederalTaxTest() throws Exception {
		try {
			NavigateToCheckFormPageNonAdvisoryAcc();
			Assert.isTrue(TestLogic.VerifyFinalAmountWithStateandFederalTax(),
					"Final Amount Verfied After Entering State & Federal Tax");
			reporter.LogSuccess("VerifyFinalAmountAfterEnteringStateFederalTaxTest",
					"Final Amount Verfied After Entering State & Federal Tax");
		} catch (Exception e) {
			reporter.LogFail("VerifyFinalAmountAfterEnteringStateFederalTaxTest", e.getMessage());
			throw e;
		}
	}

	void NavigateToCheckFormPageAdvisoryAcc() throws Exception {
		TestLogic.OpenCTApage("SignIn");
		TestLogic.GetClientInfo("16869265", "Check Request");
		TestLogic.ClickContinueOnClientInfo();
	}

	// Test Case 28
	@Test
	public void VerifyCheckIRAFormSubmitTypeAusingMMFTest() throws Exception {
		try {
			NavigateToCheckFormPageAdvisoryAcc();
			TestLogic.CreateIRACheckRequestOneTimeAdvisoryAccTypeA(".2", "Check Issued", "0", "0", "BCHK", "Automation",
					"17th Floor 777E", "Baird", "Milwaukee", "WI", "53202", "A", "AK");
			if (TestLogic.VerifyErrorMessageForDuplicateRecord() == false) {
				TestLogic.SendCheckRequest();
				NavigateToCheckFormPageAdvisoryAcc();
				TestLogic.CreateIRACheckRequestOneTimeAdvisoryAccTypeA(".2", "Check Issued", "0", "0", "BCHK",
						"Automation", "17th Floor 777E", "Baird", "Milwaukee", "WI", "53202", "A", "AK");
				if (TestLogic.VerifyErrorMessageForDuplicateRecord()) {
					TestLogic.SendCheckRequest();
				} else {
					throw new Exception("Failed");
				}
			}
			reporter.LogSuccess("VerifyCheckIRAFormSubmitTypeAusingMMFTest",
					"Successfully IRA Check Request Submission for Type A with MMF");
		} catch (Exception e) {
			reporter.LogFail("VerifyCheckIRAFormSubmitTypeAusingMMFTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 29
	@Test
	public void VerifyCheckIRAFormSubmitTypeBusingMMFTest() throws Exception {
		try {
			NavigateToCheckFormPageAdvisoryAcc();
			TestLogic.CreateIRACheckRequestOneTimeAdvisoryAccTypeB(".3", "Check Issued", "10", "10", "BCHK",
					"Automation", "17th Floor 777E", "Baird", "Milwaukee", "WI", "53202", "B", "AK");
			if (TestLogic.VerifyErrorMessageForDuplicateRecord() == false) {
				TestLogic.SendCheckRequest();
				NavigateToCheckFormPageAdvisoryAcc();
				TestLogic.CreateIRACheckRequestOneTimeAdvisoryAccTypeB(".3", "Check Issued", "10", "10", "BCHK",
						"Automation", "17th Floor 777E", "Baird", "Milwaukee", "WI", "53202", "B", "AK");
				if (TestLogic.VerifyErrorMessageForDuplicateRecord()) {
					TestLogic.SendCheckRequest();
				} else {
					throw new Exception("Failed");
				}
			}
			reporter.LogSuccess("VerifyCheckIRAFormSubmitTypeBusingMMFTest",
					"Successfully IRA Check Request Submission for Type B with MMF");
		} catch (Exception e) {
			reporter.LogFail("VerifyCheckIRAFormSubmitTypeBusingMMFTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 30
	@Test
	public void VerifyCheckIRAWarningPopUpforYesAdvisoryAccTest() throws Exception {
		try {
			NavigateToCheckFormPageAdvisoryAcc();
			Assert.isTrue(TestLogic.VerifyErrorMessageforYesAdvisoryAccount(
					"You have indicated that you are submitting a Program/Manager/Model/Allocation change for this account."),
					"Warning PopUp Verified For Advisory Acc Withdrawal Info Yes");
			reporter.LogSuccess("VerifyCheckIRAWarningPopUpforYesAdvisoryAccTest",
					"Warning PopUp Verified For Advisory Acc Withdrawal Info Yes");
		} catch (Exception e) {
			reporter.LogFail("VerifyCheckIRAWarningPopUpforYesAdvisoryAccTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 31
	@Test
	public void VerifyCheckIRAFormSubmitTypeDusingMMFTest() throws Exception {
		try {
			NavigateToCheckFormPageAdvisoryAcc();
			TestLogic.CreateIRACheckRequestOneTimeAdvisoryAccTypeB(".4", "Check Issued", "10", "10", "BCHK",
					"Automation", "17th Floor 777E", "Baird", "Milwaukee", "WI", "53202", "D", "AK");
			if (TestLogic.VerifyErrorMessageForDuplicateRecord() == false) {
				TestLogic.SendCheckRequest();
				NavigateToCheckFormPageAdvisoryAcc();
				TestLogic.CreateIRACheckRequestOneTimeAdvisoryAccTypeB(".4", "Check Issued", "10", "10", "BCHK",
						"Automation", "17th Floor 777E", "Baird", "Milwaukee", "WI", "53202", "D", "AK");
				if (TestLogic.VerifyErrorMessageForDuplicateRecord()) {
					TestLogic.SendCheckRequest();
				} else {
					throw new Exception("Failed");
				}
			}
			reporter.LogSuccess("VerifyCheckIRAFormSubmitTypeDusingMMFTest",
					"Successfully IRA Check Request Submission for Type D with MMF");
		} catch (Exception e) {
			reporter.LogFail("VerifyCheckIRAFormSubmitTypeDusingMMFTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 32
	@Test
	public void VerifyCheckIRAFedWithholdingAfterEnteringFederalTaxTest() throws Exception {
		try {
			NavigateToCheckFormPageNonAdvisoryAcc();
			Assert.isTrue(TestLogic.VerifyFedWithholding(), "Fed Withholding Verfied After Entering Federal Tax 10%");
			reporter.LogSuccess("VerifyCheckIRAFedWithholdingAfterEnteringFederalTaxTest",
					"Fed Withholding Verfied After Entering Federal Tax 10%");
		} catch (Exception e) {
			reporter.LogFail("VerifyCheckIRAFedWithholdingAfterEnteringFederalTaxTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 33
	@Test
	public void VerifyCheckIRAStateWithholdingAfterEnteringStateTaxTest() throws Exception {
		try {
			NavigateToCheckFormPageNonAdvisoryAcc();
			Assert.isTrue(TestLogic.VerifyStateWithholding(),
					"State Withholding Verfied After Entering Federal Tax 10%");
			reporter.LogSuccess("VerifyCheckIRAStateWithholdingAfterEnteringStateTaxTest",
					"State Withholding Verfied After Entering State Tax 10%");
		} catch (Exception e) {
			reporter.LogFail("VerifyCheckIRAStateWithholdingAfterEnteringStateTaxTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 34
	@Test
	public void VerifyCheckIRARequestedAmountTest() throws Exception {
		try {
			NavigateToCheckFormPageNonAdvisoryAcc();
			Assert.isTrue(TestLogic.VerifyRequestedAmount(), "Requested Amount Verified Under IRA Section");
			reporter.LogSuccess("VerifyCheckIRARequestedAmountTest", "Requested Amount Verified Under IRA Section");
		} catch (Exception e) {
			reporter.LogFail("VerifyCheckIRARequestedAmountTest", e.getMessage());
			throw e;
		}
	}

	// Test Case 35
	@Test
	public void VerifyCheckIRAWarningPopUpForQuestionMarkAddLine2Test() throws Exception {
		try {
			NavigateToCheckFormPageNonAdvisoryAcc();
			TestLogic.ClickQuestionMark();
			Assert.isTrue(
					TestLogic.VerifyErrorMessage("If payee name lines 4 is being used payee address line 2 will be"),
					"Error PopUp Verified For Question Mark Icon");
			reporter.LogSuccess("VerifyCheckIRAWarningPopUpForQuestionMarkAddLine2Test",
					"Error PopUp Verified For Question Mark Icon");
		} catch (Exception e) {
			reporter.LogFail("VerifyCheckIRAWarningPopUpForQuestionMarkAddLine2Test", e.getMessage());
			throw e;
		}
	}
}
