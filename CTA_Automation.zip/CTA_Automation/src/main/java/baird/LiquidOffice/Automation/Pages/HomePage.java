package baird.LiquidOffice.Automation.Pages;

import org.openqa.selenium.support.ui.ExpectedConditions;

import baird.LiquidOffice.Automation.Models.HomePageModel;
import baird.LiquidOffice.Automation.Resources.TestSettings;
import baird.core.Automation.CommonAPI.ICommonAPI;

/**
 * @author AmitaKumari
 */

public class HomePage extends BasePage<HomePageModel> {

	public HomePage(ICommonAPI commonApi, TestSettings Settings) {
		super(commonApi, Settings);
		PageElements = new HomePageModel(_browser);
	}

	@Override
	public void navigateTopage() {
		PageElements.init();
	}

	public void clientServicesClick() {
		_explicitwait.until(ExpectedConditions.visibilityOfAllElements(PageElements.getLnk_clientservices()));
		PageElements.getLnk_clientservices().click();
	}
	
	public void clientServicesClickSIT() {
		_explicitwait.until(ExpectedConditions.visibilityOfAllElements(PageElements.getLnk_sitclientservices()));
		PageElements.getLnk_sitclientservices().click();
	}
}
