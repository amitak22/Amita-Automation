package baird.LiquidOffice.Automation.Resources;

import java.io.FileReader;
import java.net.URL;
import java.util.ArrayList;
import java.util.stream.Stream;

import org.junit.jupiter.api.extension.ExtensionContext;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.ArgumentsProvider;

import com.google.gson.stream.JsonReader;

/**
 * @author AmitaKumari
 */

public abstract class TestArgumentBase<T> implements ArgumentsProvider {

	@Override
	public Stream<? extends Arguments> provideArguments(ExtensionContext context) throws Exception {
		String SourceFileName = new TestDataFile().getSettingsFile(this.getClass());
		JsonReader reader = new JsonReader(new FileReader(SourceFileName));

		T[] jsonResults = getClassListfromJson(reader);

		ArrayList<Arguments> list = new ArrayList<Arguments>();

		for (T jsonv : jsonResults) {
			list.add(Arguments.of(jsonv));
		}

		return list.stream();
	}

	// child class override method for getting class list
	public abstract T[] getClassListfromJson(JsonReader reader);
}

class TestDataFile {
	public String getSettingsFile(Class<?> targetType) {

		ClassLoader classLoader = getClass().getClassLoader();
		// check for json with same as class name
		URL resource = classLoader.getResource(targetType.getSimpleName() + ".json");
		return resource.getPath();
	}
}