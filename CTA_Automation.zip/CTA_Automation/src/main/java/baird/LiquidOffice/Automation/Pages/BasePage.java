package baird.LiquidOffice.Automation.Pages;

import java.time.Duration;
import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import baird.LiquidOffice.Automation.Resources.TestSettings;
import baird.core.Automation.CommonAPI.ICommonAPI;
import baird.core.Automation.WebDrivers.Browser;

/**
 * @author AmitaKumari
 */

public abstract class BasePage<T> {

	T PageElements;
	protected Browser _browser;
	protected WebDriverWait _explicitwait;
	protected Wait<WebDriverWait> _fluentwait;
	protected TestSettings _Settings = null;

	protected BasePage(ICommonAPI commonApi, TestSettings Settings) {
		_browser = commonApi.getBrowser();
		_Settings = Settings;
		_explicitwait = new WebDriverWait(_browser._browserDriver, 30, 1000);

		_fluentwait = new FluentWait(_browser._browserDriver).withTimeout(Duration.ofSeconds(30))
				.pollingEvery(Duration.ofSeconds(1))
				.ignoring(NoSuchElementException.class, StaleElementReferenceException.class);
	}

	public abstract void navigateTopage();

	String parentWindowHandler = "";

	// Switch to immediate pop-up window
	protected void SwitchToPopupWindow() {

		parentWindowHandler = _browser._browserDriver.getWindowHandle(); // Store your parent window
		String subWindowHandler = null;

		Set<String> handles = _browser._browserDriver.getWindowHandles(); // Get all window handles
		Iterator<String> iterator = handles.iterator();
		while (iterator.hasNext()) {
			subWindowHandler = iterator.next();
		}
		_browser._browserDriver.switchTo().window(subWindowHandler); // Switch to pop-up window
	}

	// Switch to immediate parent window
	protected void SwitchToParentWindow() {
		// Switch back to parent window
		if (parentWindowHandler != "") {
			_browser._browserDriver.switchTo().window(parentWindowHandler);
		}
		parentWindowHandler = "";
	}
}
