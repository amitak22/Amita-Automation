package baird.LiquidOffice.Automation.Pages;

import baird.LiquidOffice.Automation.Models.ProcessFormCheckModel;
import baird.LiquidOffice.Automation.Resources.TestSettings;
import baird.core.Automation.CommonAPI.ICommonAPI;

/**
 * @author AmitaKumari
 */

public class ProcessFormCheckPage extends BasePage<ProcessFormCheckModel> {

	public ProcessFormCheckPage(ICommonAPI commonApi, TestSettings Settings) {
		super(commonApi, Settings);
		PageElements = new ProcessFormCheckModel(_browser);
	}

	@Override
	public void navigateTopage() {
		SwitchToPopupWindow();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		PageElements.init();
	}

	public void clickSendBtn() {
		PageElements.getBtn_send().click();
	}

	public void clickBackBtn() {
		PageElements.getBtn_back().click();
	}

	public void clickCancelBtn() {
		PageElements.getBtn_cancel().click();
	}
	
	public void clickSubmitBtn() {
		PageElements.getBtn_submit().click();
	}
	
	public String getSummaryOfJournalTitle() {
		return PageElements.getTxt_summaryofjournaltitle().getText();
	}
	
	public void clickPreviousBtn() {
		PageElements.getBtn_Previous().click();
	}
}
