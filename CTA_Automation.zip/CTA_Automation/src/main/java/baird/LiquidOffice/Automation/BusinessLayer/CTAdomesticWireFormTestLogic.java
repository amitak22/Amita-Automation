package baird.LiquidOffice.Automation.BusinessLayer;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.openqa.selenium.Alert;
import org.openqa.selenium.NoAlertPresentException;

import baird.LiquidOffice.Automation.Pages.AchFormPage;
import baird.LiquidOffice.Automation.Pages.CTAPage;
import baird.LiquidOffice.Automation.Pages.CheckFormPage;
import baird.LiquidOffice.Automation.Pages.ClientServicesPage;
import baird.LiquidOffice.Automation.Pages.DomesticWirePage;
import baird.LiquidOffice.Automation.Pages.HomePage;
import baird.LiquidOffice.Automation.Pages.JournalFormPage;
import baird.LiquidOffice.Automation.Pages.NewAttachmentPage;
import baird.LiquidOffice.Automation.Pages.ProcessFormCheckPage;
import baird.LiquidOffice.Automation.Pages.SignInPage;
import baird.LiquidOffice.Automation.Resources.TestSettings;
import baird.core.Automation.CommonAPI.ICommonAPI;

/**
 * @author AmitaKumari
 */

public class CTAdomesticWireFormTestLogic extends BaseTestLogic {

	SignInPage signinPage = null;
	HomePage homePage = null;
	ClientServicesPage clientServices = null;
	CTAPage ctaPage = null;
	CheckFormPage checkPage = null;
	ProcessFormCheckPage processFormcheckPage = null;
	AchFormPage achPage = null;
	JournalFormPage journalPage = null;
	DomesticWirePage domesticWirePage = null;
	NewAttachmentPage newAttachmentPage = null;

	public CTAdomesticWireFormTestLogic(ICommonAPI commonApi, TestSettings Settings) {
		super(commonApi, Settings);

		signinPage = new SignInPage(commonApi, Settings);
		homePage = new HomePage(commonApi, Settings);
		clientServices = new ClientServicesPage(commonApi, Settings);
		ctaPage = new CTAPage(commonApi, Settings);
		checkPage = new CheckFormPage(commonApi, Settings);
		processFormcheckPage = new ProcessFormCheckPage(commonApi, Settings);
		newAttachmentPage = new NewAttachmentPage(commonApi, Settings);
		achPage = new AchFormPage(commonApi, Settings);
		journalPage = new JournalFormPage(commonApi, Settings);
		domesticWirePage = new DomesticWirePage(commonApi, Settings);
	}

	public void NavigateToSignInPage() {
		signinPage.navigateTopage();
	}

	// Action method for login using Logo or SignIn
	public void LoginToHomePage(String LoginMethod) throws Exception {
		if (LoginMethod.contains("Logo")) {
			signinPage.signInClickLogo();
		} else if (LoginMethod.contains("SignIn")) {
			signinPage.signInClick();
		} else {
			throw new Exception("Invalid Login Method");
		}
	}

	public void LoadHomePage() {
		homePage.navigateTopage();
	}

	public void LoadClientServices() {
		clientServices.navigateTopage();
	}

	// Action method for opening CTA form in UAT
	public void OpenCTApage(String LoginMethod) throws Exception {
		NavigateToSignInPage();
		LoginToHomePage(LoginMethod);
		LoadHomePage();
		homePage.clientServicesClick();
		LoadClientServices();
		clientServices.ctaClick();
		ctaPage.navigateTopage();
	}

	// Action method for opening CTA form in SIT
	public void OpenCTApageSIT(String LoginMethod) throws Exception {
		NavigateToSignInPage();
		LoginToHomePage(LoginMethod);
		LoadHomePage();
		homePage.clientServicesClickSIT();
		LoadClientServices();
		clientServices.ctaClickSIT();
		ctaPage.navigateTopage();
	}

	// Action method to get Client Info
	public void GetClientInfo(String AccountNo, String Type) throws InterruptedException {
		ctaPage.enterAccNumber(AccountNo);
		Thread.sleep(2000);
		ctaPage.selectDomesticWireradiobtn();
	}

	// Action method to click on Continue button on Client Info
	public void ClickContinueOnClientInfo() throws InterruptedException {
		ctaPage.clickContinueBtn();
		domesticWirePage.navigateTopage();
	}

	public boolean VerifyWarningMessage(String errorText) {
		if (ctaPage.getInvalidCharErrorMessage().contains(errorText)) {
			return true;
		} else
			return false;
	}

	public boolean VerifyWireInformationTitle() {
		if (domesticWirePage.checkWireInformationTitle("Wire Information")
				&& domesticWirePage.checkNewWireInstructionTitle("New WIRE Instruction")) {
			return true;
		} else
			return false;
	}

	public boolean VerifyAccountNumber() {
		if (domesticWirePage.getAccountNumber("59127215")) {
			return true;
		} else
			return false;
	}

	public boolean VerifyWireBankInformationField() {
		domesticWirePage.selectWireInstructions();
		domesticWirePage.selectRecordTypeA();
		if (domesticWirePage.checkNameOfAccount("LOUISE") && (domesticWirePage.checkBankName("GEEZ"))
				&& (domesticWirePage.checkBankABA("111993776")) && (domesticWirePage.checkBankAccNumber("12548965"))
				&& (domesticWirePage.checkCity("CHICAGO")) && (domesticWirePage.checkState("IL"))) {
			return true;
		} else
			return false;
	}

	public boolean VerifyChargeWireFeeFARadioButton() {
		domesticWirePage.selectFAradioBtn();
		return true;
	}

	public boolean VerifyChargeWireFeeClientRadioButton() {
		domesticWirePage.selectClientradioBtn();
		if (domesticWirePage.getTextChargeWireFeeClient("25.00$(Wire Fee charged to client)")) {
			return true;
		} else
			return false;
	}

	public boolean VerifyInvalidAmount(String Amount, String errorText) {
		domesticWirePage.enterAmount(Amount);
		domesticWirePage.selectFAradioBtn();
		if (domesticWirePage.getInvalidCharErrorMessage().contains(errorText)) {
			return true;
		} else
			return false;
	}

	public boolean VerifyWireIssueDateForCurrentDate() {
		domesticWirePage.getIssueDate().equals(FetchCurrentDate());
		return true;
	}

	public String FetchCurrentDate() {
		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		Date date = new Date();
		String currentDate = dateFormat.format(date);
		return currentDate;
	}

	public boolean VerifyWireIssueDateForFutureDate(String FutureDate) {
		domesticWirePage.clickIssueDate(FutureDate);
		return true;
	}

	/* Action method to verify the duplicate record pop up */

	public boolean VerifyErrorMessageForDuplicateRecord() throws InterruptedException {
		try {
			Alert a = _browser._browserDriver.switchTo().alert();
			if (a != null) {
				a.accept();
				Thread.sleep(2000);
				domesticWirePage.selectNoDuplicateChkbox();
				domesticWirePage.clickSubmitBtn();
				processFormcheckPage.navigateTopage();
				return true;
			} else
				return false;
		} catch (NoAlertPresentException e) {
			return false;
		}
	}

	public void CreateWireRequest(String Amount, String Fund, String BankCustomerName, String BankName, String BankABA,
			String BankAccNumber, String City, String State, String BeneficiaryType, String SLOA, String ThirdParty,
			String AttestorName) throws InterruptedException {
		domesticWirePage.enterAmount(Amount);
		domesticWirePage.selectCashorMMF(Fund);
		domesticWirePage.selectAccTypeCash();
		domesticWirePage.selectFAradioBtn();
		domesticWirePage.enterBankInformation(BankCustomerName, BankName, BankABA, BankAccNumber, City, State);
		domesticWirePage.selectBeneficiaryType(BeneficiaryType);
		domesticWirePage.selectStandingInstruction(SLOA);
		domesticWirePage.clickAttachmentBtn();
		newAttachmentPage.navigateTopage();
		newAttachmentPage.addAttachments();
		Thread.sleep(1000);
		domesticWirePage.clickContinueBtn();
		processFormcheckPage.navigateTopage();
		domesticWirePage.enterThirdParty(ThirdParty);
		domesticWirePage.selectAccountLength2();
		domesticWirePage.selectAttestationChkbox();
		domesticWirePage.enterAttestorName(AttestorName);
		domesticWirePage.clickSubmitBtn();
		processFormcheckPage.navigateTopage();
	}

	public void SendWireRequest() throws InterruptedException {
		domesticWirePage.clickSendBtn();
	}

	public boolean VerifyDomWireIssueDateForFutureDate(String FutureDate) {
		domesticWirePage.clickIssueDate(FutureDate);
		domesticWirePage.selectFAradioBtn();
		return true;
	}

	public void EnterBankInstructions(String BankCustomerName, String BankName, String BankABA, String BankAccNumber,
			String City, String State) throws InterruptedException {
		domesticWirePage.enterBankInformation(BankCustomerName, BankName, BankABA, BankAccNumber, City, State);
	}

	public boolean VerifyBankInstruction() throws InterruptedException {
		domesticWirePage.clickResetButton();
		if (domesticWirePage.checkNameOfAccount("") && (domesticWirePage.checkBankName(""))
				&& (domesticWirePage.checkBankABA("")) && (domesticWirePage.checkBankAccNumber(""))
				&& (domesticWirePage.checkCity("")) && (domesticWirePage.checkState(""))) {
			return true;
		} else
			return false;
	}

	public boolean VerifySaveFunctionality(String BankCustomerName, String BankName, String BankABA,
			String BankAccNumber, String City, String State) throws InterruptedException {
		domesticWirePage.enterBankInformation(BankCustomerName, BankName, BankABA, BankAccNumber, City, State);
		domesticWirePage.clickSaveButton();
		return true;
	}

	public boolean VerifyBackButton() {
		domesticWirePage.clickBackButton();
		if (ctaPage.getClientInfotext().toLowerCase().contains("client information")) {
			return true;
		} else
			return false;
	}

	public void CreateWireRequestWithChargeWireFeeClient(String Amount, String Fund, String BankCustomerName,
			String BankName, String BankABA, String BankAccNumber, String City, String State, String BeneficiaryType,
			String SLOA, String ThirdParty, String AttestorName) throws InterruptedException {
		domesticWirePage.enterAmount(Amount);
		domesticWirePage.selectCashorMMF(Fund);
		domesticWirePage.selectAccTypeCash();
		domesticWirePage.selectClientradioBtn();
		domesticWirePage.enterBankInformation(BankCustomerName, BankName, BankABA, BankAccNumber, City, State);
		domesticWirePage.selectBeneficiaryType(BeneficiaryType);
		domesticWirePage.selectStandingInstruction(SLOA);
		domesticWirePage.clickAttachmentBtn();
		newAttachmentPage.navigateTopage();
		newAttachmentPage.addAttachments();
		Thread.sleep(1000);
		domesticWirePage.clickContinueBtn();
		processFormcheckPage.navigateTopage();
		domesticWirePage.enterThirdParty(ThirdParty);
		domesticWirePage.selectAccountLength2();
		domesticWirePage.selectAttestationChkbox();
		domesticWirePage.enterAttestorName(AttestorName);
		domesticWirePage.clickSubmitBtn();
		processFormcheckPage.navigateTopage();
	}

	public void CreateWireRequestWithMarginAccType(String Amount, String Fund, String BankCustomerName, String BankName,
			String BankABA, String BankAccNumber, String City, String State, String BeneficiaryType, String SLOA,
			String ThirdParty, String AttestorName) throws InterruptedException {
		domesticWirePage.enterAmount(Amount);
		domesticWirePage.selectCashorMMF(Fund);
		domesticWirePage.selectAccTypeMargin();
		domesticWirePage.selectClientradioBtn();
		domesticWirePage.enterBankInformation(BankCustomerName, BankName, BankABA, BankAccNumber, City, State);
		domesticWirePage.selectBeneficiaryType(BeneficiaryType);
		domesticWirePage.selectStandingInstruction(SLOA);
		domesticWirePage.clickAttachmentBtn();
		newAttachmentPage.navigateTopage();
		newAttachmentPage.addAttachments();
		Thread.sleep(1000);
		domesticWirePage.clickContinueBtn();
		processFormcheckPage.navigateTopage();
		domesticWirePage.enterThirdParty(ThirdParty);
		domesticWirePage.selectAccountLength2();
		domesticWirePage.selectAttestationChkbox();
		domesticWirePage.enterAttestorName(AttestorName);
		domesticWirePage.clickSubmitBtn();
		processFormcheckPage.navigateTopage();
	}

	public void CreateWireRequestDomForeignIndividual(String Amount, String Fund, String BankCustomerName,
			String BankName, String BankABA, String BankAccNumber, String City, String State, String BeneficiaryType,
			String SLOA, String ThirdParty, String AttestorName) throws InterruptedException {
		domesticWirePage.enterAmount(Amount);
		domesticWirePage.selectCashorMMF(Fund);
		domesticWirePage.selectAccTypeCash();
		domesticWirePage.selectClientradioBtn();
		domesticWirePage.enterBankInformation(BankCustomerName, BankName, BankABA, BankAccNumber, City, State);
		domesticWirePage.selectBeneficiaryType(BeneficiaryType);
		domesticWirePage.selectStandingInstruction(SLOA);
		Thread.sleep(1000);
		domesticWirePage.selectYesFAradioBtn();
		domesticWirePage.clickAttachmentBtn();
		newAttachmentPage.navigateTopage();
		newAttachmentPage.addAttachments();
		Thread.sleep(2000);
		domesticWirePage.clickContinueBtn();
		processFormcheckPage.navigateTopage();
		domesticWirePage.enterThirdParty(ThirdParty);
		domesticWirePage.selectAccountLength2();
		domesticWirePage.selectAttestationChkbox();
		domesticWirePage.enterAttestorName(AttestorName);
		domesticWirePage.clickSubmitBtn();
		processFormcheckPage.navigateTopage();
	}

	public boolean VerifyFAradioButton(String BeneficiaryType) {
		domesticWirePage.selectBeneficiaryType(BeneficiaryType);
		domesticWirePage.selectYesFAradioBtn();
		return true;
	}

	public boolean VerifyPreferredHomePhone(String BeneficiaryType) {
		domesticWirePage.selectBeneficiaryType(BeneficiaryType);
		if (domesticWirePage.getHomePhoneNo("(414) 555-1234")) {
			return true;
		} else
			return false;
	}

	public boolean VerifyWarningPopUp(String Amount, String Fund, String BankCustomerName, String BankName,
			String BankABA, String BankAccNumber, String City, String State, String BeneficiaryType, String SLOA,
			String errorText) throws InterruptedException {
		domesticWirePage.enterAmount(Amount);
		domesticWirePage.selectCashorMMF(Fund);
		domesticWirePage.selectAccTypeCash();
		domesticWirePage.selectClientradioBtn();
		domesticWirePage.enterBankInformation(BankCustomerName, BankName, BankABA, BankAccNumber, City, State);
		domesticWirePage.selectBeneficiaryType(BeneficiaryType);
		domesticWirePage.selectStandingInstruction(SLOA);
		Thread.sleep(1000);
		domesticWirePage.selectYesFAradioBtn();
		domesticWirePage.clickContinueBtn();
		if (domesticWirePage.getInvalidCharErrorMessage().contains(errorText)) {
			return true;
		} else
			return false;
	}

	public boolean VerifyWarningPopUpNoAccType(String Amount, String Fund, String BankCustomerName, String BankName,
			String BankABA, String BankAccNumber, String City, String State, String BeneficiaryType, String SLOA,
			String errorText) throws InterruptedException {
		domesticWirePage.enterAmount(Amount);
		domesticWirePage.selectCashorMMF(Fund);
		domesticWirePage.selectClientradioBtn();
		domesticWirePage.enterBankInformation(BankCustomerName, BankName, BankABA, BankAccNumber, City, State);
		domesticWirePage.selectBeneficiaryType(BeneficiaryType);
		domesticWirePage.selectStandingInstruction(SLOA);
		Thread.sleep(1000);
		domesticWirePage.selectYesFAradioBtn();
		domesticWirePage.clickContinueBtn();
		if (domesticWirePage.getInvalidCharErrorMessage().contains(errorText)) {
			return true;
		} else
			return false;
	}

	public boolean VerifyWarningPopUpNoChargeWireFee(String Amount, String Fund, String BankCustomerName,
			String BankName, String BankABA, String BankAccNumber, String City, String State, String BeneficiaryType,
			String SLOA, String errorText) throws InterruptedException {
		domesticWirePage.enterAmount(Amount);
		domesticWirePage.selectCashorMMF(Fund);
		domesticWirePage.selectAccTypeCash();
		domesticWirePage.enterBankInformation(BankCustomerName, BankName, BankABA, BankAccNumber, City, State);
		domesticWirePage.selectBeneficiaryType(BeneficiaryType);
		domesticWirePage.selectStandingInstruction(SLOA);
		Thread.sleep(1000);
		domesticWirePage.clickContinueBtn();
		if (domesticWirePage.getInvalidCharErrorMessage().contains(errorText)) {
			return true;
		} else
			return false;
	}

	public boolean VerifyWarningPopUpForInvalidBankABA(String BankABA, String errorText) {
		domesticWirePage.enterBankABA(BankABA);
		domesticWirePage.selectAccTypeCash();
		if (domesticWirePage.getInvalidCharErrorMessage().contains(errorText)) {
			return true;
		} else
			return false;
	}

	public boolean VerifyWarningPopUpBankInfoNotEntered(String Amount, String BeneficiaryType, String errorText) {
		domesticWirePage.enterAmount(Amount);
		domesticWirePage.selectAccTypeCash();
		domesticWirePage.selectClientradioBtn();
		domesticWirePage.selectBeneficiaryType(BeneficiaryType);
		domesticWirePage.clickContinueBtn();
		if (domesticWirePage.getInvalidCharErrorMessage().contains(errorText)) {
			return true;
		} else
			return false;
	}

	public boolean VerifyWarningPopUpWhenFAOptionNotSelected(String Amount, String Fund, String BankCustomerName,
			String BankName, String BankABA, String BankAccNumber, String City, String State, String BeneficiaryType,
			String errorText) throws InterruptedException {
		domesticWirePage.enterAmount(Amount);
		domesticWirePage.selectCashorMMF(Fund);
		domesticWirePage.selectAccTypeCash();
		domesticWirePage.selectClientradioBtn();
		domesticWirePage.enterBankInformation(BankCustomerName, BankName, BankABA, BankAccNumber, City, State);
		domesticWirePage.selectBeneficiaryType(BeneficiaryType);
		Thread.sleep(1000);
		domesticWirePage.clickContinueBtn();
		if (domesticWirePage.getInvalidCharErrorMessage().contains(errorText)) {
			return true;
		} else
			return false;
	}

	public boolean VerifyWarningPopUpHomePhoneSelected(String Amount, String BankCustomerName, String BankName,
			String BankABA, String BankAccNumber, String City, String State, String BeneficiaryType, String errorText)
			throws InterruptedException {
		domesticWirePage.enterAmount(Amount);
		domesticWirePage.selectAccTypeCash();
		domesticWirePage.selectClientradioBtn();
		domesticWirePage.enterBankInformation(BankCustomerName, BankName, BankABA, BankAccNumber, City, State);
		domesticWirePage.selectBeneficiaryType(BeneficiaryType);
		domesticWirePage.selectYesFAradioBtn();
		domesticWirePage.selectBusinessPhoneNo();
		Thread.sleep(1000);
		if (domesticWirePage.getInvalidCharErrorMessage().contains(errorText)) {
			return true;
		} else
			return false;
	}

	public boolean VerifyWarningPopUpThirdPartyAddNotEntered(String Amount, String Fund, String BankCustomerName,
			String BankName, String BankABA, String BankAccNumber, String City, String State, String BeneficiaryType, String ThirdParty,
			String AttestorName, String errorText) throws InterruptedException {
		domesticWirePage.enterAmount(Amount);
		domesticWirePage.selectCashorMMF(Fund);
		domesticWirePage.selectAccTypeCash();
		domesticWirePage.selectClientradioBtn();
		domesticWirePage.enterBankInformation(BankCustomerName, BankName, BankABA, BankAccNumber, City, State);
		domesticWirePage.selectBeneficiaryType(BeneficiaryType);
		domesticWirePage.selectYesFAradioBtn();
		Thread.sleep(1000);
		domesticWirePage.clickContinueBtn();
		processFormcheckPage.navigateTopage();
		domesticWirePage.enterThirdParty(ThirdParty);
		domesticWirePage.selectAccountLength2();
		domesticWirePage.selectAttestationChkbox();
		domesticWirePage.enterAttestorName(AttestorName);
		domesticWirePage.clickSubmitBtn();
		if (domesticWirePage.getInvalidCharErrorMessage().contains(errorText)) {
			return true;
		} else
			return false;
	}

	public boolean VerifyWarningPopUpAccountLengthNotSelected(String Amount, String Fund, String BankCustomerName,
			String BankName, String BankABA, String BankAccNumber, String City, String State, String BeneficiaryType,
			String ThirdParty, String AttestorName, String errorText) throws InterruptedException {
		domesticWirePage.enterAmount(Amount);
		domesticWirePage.selectCashorMMF(Fund);
		domesticWirePage.selectAccTypeCash();
		domesticWirePage.selectClientradioBtn();
		domesticWirePage.enterBankInformation(BankCustomerName, BankName, BankABA, BankAccNumber, City, State);
		domesticWirePage.selectBeneficiaryType(BeneficiaryType);
		domesticWirePage.selectYesFAradioBtn();
		Thread.sleep(1000);
		domesticWirePage.clickContinueBtn();
		processFormcheckPage.navigateTopage();
		domesticWirePage.enterThirdParty(ThirdParty);
		domesticWirePage.selectAttestationChkbox();
		domesticWirePage.enterAttestorName(AttestorName);
		domesticWirePage.clickSubmitBtn();
		if (domesticWirePage.getInvalidCharErrorMessage().contains(errorText)) {
			return true;
		} else
			return false;
	}
	
	public boolean VerifyWarningPopUpWithoutAttestation(String Amount, String Fund, String BankCustomerName,
			String BankName, String BankABA, String BankAccNumber, String City, String State, String BeneficiaryType,
			String ThirdParty, String AttestorName, String errorText) throws InterruptedException {
		domesticWirePage.enterAmount(Amount);
		domesticWirePage.selectCashorMMF(Fund);
		domesticWirePage.selectAccTypeCash();
		domesticWirePage.selectClientradioBtn();
		domesticWirePage.enterBankInformation(BankCustomerName, BankName, BankABA, BankAccNumber, City, State);
		domesticWirePage.selectBeneficiaryType(BeneficiaryType);
		domesticWirePage.selectYesFAradioBtn();
		Thread.sleep(1000);
		domesticWirePage.clickContinueBtn();
		processFormcheckPage.navigateTopage();
		domesticWirePage.enterThirdParty(ThirdParty);
		domesticWirePage.selectAccountLength2();
		domesticWirePage.enterAttestorName(AttestorName);
		domesticWirePage.clickSubmitBtn();
		if (domesticWirePage.getInvalidCharErrorMessage().contains(errorText)) {
			return true;
		} else
			return false;
	}
	
	public boolean VerifyWarningPopUpForInvalidBankAccNo(String BankAccNumber, String errorText) {
		domesticWirePage.enterBankAccNo(BankAccNumber);
		domesticWirePage.selectAccTypeCash();
		if (domesticWirePage.getInvalidCharErrorMessage().contains(errorText)) {
			return true;
		} else
			return false;
	}	
	
	public boolean VerifyAccountNoOnRetrivedClientInfoPage2(String Amount, String Fund, String BankCustomerName,
			String BankName, String BankABA, String BankAccNumber, String City, String State, String BeneficiaryType) throws InterruptedException {
		domesticWirePage.enterAmount(Amount);
		domesticWirePage.selectCashorMMF(Fund);
		domesticWirePage.selectAccTypeCash();
		domesticWirePage.selectClientradioBtn();
		domesticWirePage.enterBankInformation(BankCustomerName, BankName, BankABA, BankAccNumber, City, State);
		domesticWirePage.selectBeneficiaryType(BeneficiaryType);
		Thread.sleep(1000);
		domesticWirePage.clickContinueBtn();
		processFormcheckPage.navigateTopage();
		if (domesticWirePage.getAccountNo2("59127215")) {
			return true;
		} else
			return false;
	}
	
	public boolean VerifyFinalAccountNoNameOnRetrivedClientInfoPage2(String Amount, String Fund, String BankCustomerName,
			String BankName, String BankABA, String BankAccNumber, String City, String State, String BeneficiaryType, String FinalAccNo, String FinalName) throws InterruptedException {
		domesticWirePage.enterAmount(Amount);
		domesticWirePage.selectCashorMMF(Fund);
		domesticWirePage.selectAccTypeCash();
		domesticWirePage.selectClientradioBtn();
		domesticWirePage.enterBankInformation(BankCustomerName, BankName, BankABA, BankAccNumber, City, State);
		domesticWirePage.selectBeneficiaryType(BeneficiaryType);
		domesticWirePage.enterFinalBeneficiaryAccNoandName(FinalAccNo, FinalName);
		Thread.sleep(1000);
		domesticWirePage.clickContinueBtn();
		processFormcheckPage.navigateTopage();
		if (domesticWirePage.getFinalAccountNo2("1234") && domesticWirePage.getFinalName2("AmitaK")) {
			return true;
		} else
			return false;
	}
	
	public void CreateWireRequestUsingMMF(String Amount, String Fund, String BankCustomerName,
			String BankName, String BankABA, String BankAccNumber, String City, String State, String BeneficiaryType,
			String SLOA, String ThirdParty, String AttestorName) throws InterruptedException {
		domesticWirePage.enterAmount(Amount);
		domesticWirePage.selectCashorMMF(Fund);
		domesticWirePage.selectAccTypeCash();
		domesticWirePage.selectClientradioBtn();
		domesticWirePage.enterBankInformation(BankCustomerName, BankName, BankABA, BankAccNumber, City, State);
		domesticWirePage.selectBeneficiaryType(BeneficiaryType);
		domesticWirePage.selectStandingInstruction(SLOA);
		domesticWirePage.clickAttachmentBtn();
		newAttachmentPage.navigateTopage();
		newAttachmentPage.addAttachments();
		Thread.sleep(1000);
		domesticWirePage.clickContinueBtn();
		processFormcheckPage.navigateTopage();
		domesticWirePage.enterThirdParty(ThirdParty);
		domesticWirePage.selectAccountLength2();
		domesticWirePage.selectAttestationChkbox();
		domesticWirePage.enterAttestorName(AttestorName);
		domesticWirePage.selectNoAdvisoryRadioBtn();
		domesticWirePage.clickSubmitBtn();
		processFormcheckPage.navigateTopage();
	}
	
	public void CreateWireRequestDomForeignIndividualUsingMMF(String Amount, String Fund, String BankCustomerName,
			String BankName, String BankABA, String BankAccNumber, String City, String State, String BeneficiaryType,
			String SLOA, String ThirdParty, String AttestorName) throws InterruptedException {
		domesticWirePage.enterAmount(Amount);
		domesticWirePage.selectCashorMMF(Fund);
		domesticWirePage.selectAccTypeCash();
		domesticWirePage.selectYesFAradioBtnMMF();
		domesticWirePage.enterBankInformation(BankCustomerName, BankName, BankABA, BankAccNumber, City, State);
		domesticWirePage.selectBeneficiaryType(BeneficiaryType);
		domesticWirePage.selectStandingInstruction(SLOA);
		domesticWirePage.selectYesFAradioBtn();
		domesticWirePage.clickAttachmentBtn();
		newAttachmentPage.navigateTopage();
		newAttachmentPage.addAttachments();
		Thread.sleep(1000);
		domesticWirePage.clickContinueBtn();
		processFormcheckPage.navigateTopage();
		domesticWirePage.enterThirdParty(ThirdParty);
		domesticWirePage.selectAccountLength2();
		domesticWirePage.selectAttestationChkbox();
		domesticWirePage.enterAttestorName(AttestorName);
		domesticWirePage.selectNoAdvisoryRadioBtn();
		domesticWirePage.clickSubmitBtn();
		processFormcheckPage.navigateTopage();
	}
	
	public void VerifyDomesticWireReqSubmitYesAdvisory(String Amount, String Fund, String BankCustomerName,
			String BankName, String BankABA, String BankAccNumber, String City, String State, String BeneficiaryType,
			String SLOA, String ThirdParty, String AttestorName) throws InterruptedException {
		domesticWirePage.enterAmount(Amount);
		domesticWirePage.selectCashorMMF(Fund);
		domesticWirePage.selectAccTypeCash();
		domesticWirePage.selectClientradioBtn();
		domesticWirePage.enterBankInformation(BankCustomerName, BankName, BankABA, BankAccNumber, City, State);
		domesticWirePage.selectBeneficiaryType(BeneficiaryType);
		domesticWirePage.selectStandingInstruction(SLOA);
		domesticWirePage.clickAttachmentBtn();
		newAttachmentPage.navigateTopage();
		newAttachmentPage.addAttachments();
		Thread.sleep(1000);
		domesticWirePage.clickContinueBtn();
		processFormcheckPage.navigateTopage();
		domesticWirePage.enterThirdParty(ThirdParty);
		domesticWirePage.selectAccountLength2();
		domesticWirePage.selectAttestationChkbox();
		domesticWirePage.enterAttestorName(AttestorName);
		domesticWirePage.selectYesAdvisoryRadioBtn();
		_browser._browserDriver.switchTo().alert().accept();
		domesticWirePage.clickSubmitBtn();
		processFormcheckPage.navigateTopage();
	}
}
