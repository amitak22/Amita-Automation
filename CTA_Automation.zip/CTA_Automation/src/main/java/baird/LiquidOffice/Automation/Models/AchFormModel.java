package baird.LiquidOffice.Automation.Models;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import baird.core.Automation.WebDrivers.Browser;
import baird.core.Automation.WebDrivers.Elements.HtmlElementImpl;

/**
 * @author AmitaKumari
 */

public class AchFormModel extends BaseModel {

	public AchFormModel(Browser obj) {
		super(obj);
	}

	@FindBy(id = "Text5_2")
	WebElement txt_retrievedclienttitle;

	@FindBy(id = "ACCOUNT_NUMBER")
	WebElement txt_accnumber;

	@FindBy(id = "ACCOUNT_TYPE")
	WebElement txt_iratype;

	@FindBy(id = "CLIENT_NAME")
	WebElement txt_clientname;

	@FindBy(id = "btnExisting")
	WebElement btn_achinstruction;

	@FindBy(id = "DTB__AINS_TBL_0_btnSelect")
	WebElement btn_selectRecordTypeA;

	@FindBy(id = "DTB__AINS_TBL_1_btnSelect")
	WebElement btn_selectRecordTypeBandD;

	@FindBy(id = "DTB__AINS_TBL_9_btnSelect")
	WebElement btn_selectRecordTypeC;
	
	@FindBy(id = "DTB__AINS_TBL_3_btnSelect")
	WebElement btn_selectRecordTypeD;

	@FindBy(id = "DTB__AINS_TBL_11_btnSelect")
	WebElement btn_selectRecordTypeE;
	
	@FindBy(id = "DTB__AINS_TBL_13_btnSelect")
	WebElement btn_selectRecordTypeF;
	
	@FindBy(id = "DTB__AINS_TBL_14_btnSelect")
	WebElement btn_selectRecordTypeG;
	
	@FindBy(id = "AINS_NO")
	WebElement txt_ACHInstruction1;

	@FindBy(id = "DTB__BankInfo_0_BANK_ACCOUNT_NAME")
	WebElement txt_BankCustomerName;

	@FindBy(id = "DTB__BankInfo_0_Bank")
	WebElement txt_BankName;

	@FindBy(id = "DTB__BankInfo_0_Bank_ABA")
	WebElement txt_BankABA;

	@FindBy(id = "DTB__BankInfo_0_CUSTOMER_ACCOUNT")
	WebElement txt_BankAccNumber;

	@FindBy(id = "btnClear")
	WebElement btn_clearbankinfo;

	@FindBy(id = "AMOUNT")
	WebElement txt_amount;

	@FindBy(id = "mmfChoices")
	WebElement txt_cashormmf;

	@FindBy(id = "FUTURE_DATE")
	WebElement txt_date;

	@FindBy(id = "CASH_MARGIN_RadioButton7")
	WebElement radiobtn_cash;

	@FindBy(id = "Incoming_Outgoing_RadioButton2")
	WebElement radiobtn_outofbaird;

	@FindBy(id = "Incoming_Outgoing_RadioButton1")
	WebElement radiobtn_intobaird;

	@FindBy(id = "DTB__verbalConfirm_0_chkACHattest")
	WebElement chkbox_attestation;

	@FindBy(id = "DTB__verbalConfirm_0_Tbl_Attestor_Name")
	WebElement txt_attestorname;

	@FindBy(id = "DTB__ThirdParty_0_Third_Party_Name")
	WebElement txt_thirdpartyname;

	@FindBy(id = "DTB__ThirdParty_0_OFAC_RadioButton5")
	WebElement radiobtn_yesthirdparty;

	@FindBy(id = "DTB__tblAdvisoryAcctInfo_0_SourceAccountModelChange_RadioButton11_5")
	WebElement radiobtn_noadvisoryaccount;

	@FindBy(id = "DTB__tblAdvisoryAcctInfo_0_SourceAccountModelChange_RadioButton10_5")
	WebElement radiobtn_yesadvisoryaccount;

	@FindBy(id = "btnSubmit")
	WebElement btn_submit;

	@FindBy(id = "ATTEST_NO_DUPE")
	WebElement chkbox_noduplicateconfirm;

	@FindBy(id = "btnReset")
	WebElement btn_reset;

	@FindBy(id = "btnSave")
	WebElement btn_save;

	@FindBy(id = "btnBack")
	WebElement btn_back;

	@FindBy(id = "DTB__BankInfo_0_Bank")
	WebElement txt_bankname;

	@FindBy(id = "DTB__BankInfo_0_BANK_ACCOUNT_NAME")
	WebElement txt_bankcustomername;

	@FindBy(id = "DTB__BankInfo_0_Bank_ABA")
	WebElement txt_bankaba;

	@FindBy(id = "DTB__BankInfo_0_CUSTOMER_ACCOUNT")
	WebElement txt_bankaccnumber;

	@FindBy(id = "Attachments")
	WebElement btn_attachment;

	@FindBy(id = "CASH_MARGIN_RadioButton8")
	WebElement radiobtn_margin;

	@FindBy(id = "DTB__BankInfo_0_StandingLOA")
	WebElement drpdwn_standinginst;

	@FindBy(id = "DTB__tblAdvisoryAcctInfo_0_advisoryDepositDescription")
	WebElement drpdwn_advisorydescription;

	@FindBy(id = "Withholding_Calc")
	WebElement txt_withholding;

	@FindBy(id = "DTB__Withholding_0_FED_WITHHOLDING")
	WebElement txt_federaltax;

	@FindBy(id = "DTB__Withholding_0_STATE_WITHHOLDING")
	WebElement txt_statetax;

	@FindBy(id = "DTB__Withholding_0_FINAL_AMT")
	WebElement txt_finalamount;

	@FindBy(id = "DTB__Withholding_0_Fed_Withholding_Amount")
	WebElement txt_fedwithholding;

	@FindBy(id = "DTB__Withholding_0_State_Withholding_Amount")
	WebElement txt_statewithholding;

	@FindBy(id = "DTB__Withholding_0_Requested_Amount")
	WebElement txt_requestedamount;

	@FindBy(id = "DTB__Withholding_0_pecoOut")
	WebElement drpdwn_distributiontype;

	@FindBy(id = "DTB__Withholding_0_pecoIn")
	WebElement drpdwn_contributionype;

	@FindBy(id = "DTB__Withholding_0_btnViewDIST")
	WebElement btn_distrecord;
	
	@FindBy(xpath = "//table[@id='DistRecords']//button[contains(text(),'Select')]")
	WebElement btn_distrecordtype;
	
	@FindBy(xpath = "//tr[2]//td[1]//button[1]")
	WebElement btn_distrecordtypeA;
	
	@FindBy(xpath = "(//tr[@id='bottom_panel_row']//a[@class='items_hmenu'])[3]")
	WebElement tab_workqueuetab;
	
	@FindBy(xpath = "(//tr[@id='bottom_panel_row']//a[@class='items_hmenu'])[1]")
	WebElement tab_inboxtab;
	
	@FindBy(xpath = "//a[contains(text(),'Client_Services_ACH')]")
	WebElement link_clientservicesach;
	
	@FindBy(xpath = "(//a[@class='record_cell_fields']//img[@class='icon'])[1]")
	WebElement link_rejectedachprocess;
	
	@FindBy(xpath = "//a[contains(text(),'BPM_NPA_CONTRIBUTION_WITHDRAWAL')]")
	WebElement link_bpmnpacontriwith;
	
	@FindBy(id = "th_ReceivedDate_WorkQueue")
	WebElement column_received;
		
	@FindBy(className = "record_cell_fields")
	WebElement link_latestachprocess;
	
	@FindBy(xpath = "//div[@id='dialog']//input")
	WebElement btn_closedialogbox;
	
	@FindBy(id = "DFS__GO")
	WebElement btn_go;
	
	@FindBy(id = "DFS__ActionList")
	WebElement txt_sendtonextapproval;
	
	@FindBy(xpath = "//option[contains(text(),'Fund Availability')]")
	WebElement txt_selectreasons;
	
	@FindBy(id = "btnAdd")
	WebElement btn_add;
	
	@FindBy(id = "btnContinue")
	WebElement btn_continue;
	
	public HtmlElementImpl getTxt_retrievedclienttitle() {
		return new HtmlElementImpl(txt_retrievedclienttitle);
	}

	public HtmlElementImpl getTxt_accnumber() {
		return new HtmlElementImpl(txt_accnumber);
	}

	public HtmlElementImpl getTxt_iratype() {
		return new HtmlElementImpl(txt_iratype);
	}

	public HtmlElementImpl getTxt_clientname() {
		return new HtmlElementImpl(txt_clientname);
	}

	public HtmlElementImpl getBtn_achinstruction() {
		return new HtmlElementImpl(btn_achinstruction);
	}

	public HtmlElementImpl getBtn_selectrecordtypeA() {
		return new HtmlElementImpl(btn_selectRecordTypeA);
	}

	public HtmlElementImpl getBtn_selectrecordtypeBandD() {
		return new HtmlElementImpl(btn_selectRecordTypeBandD);
	}

	public HtmlElementImpl getBtn_selectrecordtypeC() {
		return new HtmlElementImpl(btn_selectRecordTypeC);
	}
	
	public HtmlElementImpl getTxt_ACHInstruction1() {
		return new HtmlElementImpl(txt_ACHInstruction1);
	}

	public HtmlElementImpl getTxt_BankCustomerName() {
		return new HtmlElementImpl(txt_BankCustomerName);
	}

	public HtmlElementImpl getTxt_BankName() {
		return new HtmlElementImpl(txt_BankName);
	}

	public HtmlElementImpl getTxt_BankABA() {
		return new HtmlElementImpl(txt_BankABA);
	}

	public HtmlElementImpl getTxt_BankAccNumber() {
		return new HtmlElementImpl(txt_BankAccNumber);
	}

	public HtmlElementImpl getBtn_clearbanlinfo() {
		return new HtmlElementImpl(btn_clearbankinfo);
	}

	public HtmlElementImpl getTxt_amount() {
		return new HtmlElementImpl(txt_amount);
	}

	public HtmlElementImpl getTxt_cashorMMF() {
		return new HtmlElementImpl(txt_cashormmf);
	}

	public HtmlElementImpl getTxt_issuedate() {
		return new HtmlElementImpl(txt_date);
	}

	public HtmlElementImpl getRadiobtn_cash() {
		return new HtmlElementImpl(radiobtn_cash);
	}

	public HtmlElementImpl getRadiobtn_outofbaird() {
		return new HtmlElementImpl(radiobtn_outofbaird);
	}

	public HtmlElementImpl getRadiobtn_intobaird() {
		return new HtmlElementImpl(radiobtn_intobaird);
	}

	public HtmlElementImpl getChkbox_attestation() {
		return new HtmlElementImpl(chkbox_attestation);
	}

	public HtmlElementImpl getTxt_attestorname() {
		return new HtmlElementImpl(txt_attestorname);
	}

	public HtmlElementImpl getTxt_thirdpartyname() {
		return new HtmlElementImpl(txt_thirdpartyname);
	}

	public HtmlElementImpl getRadiobtn_noadvisoryaccount() {
		return new HtmlElementImpl(radiobtn_noadvisoryaccount);
	}

	public HtmlElementImpl getRadiobtn_yesadvisoryaccount() {
		return new HtmlElementImpl(radiobtn_yesadvisoryaccount);
	}

	public HtmlElementImpl getRadiobtn_yesthirdparty() {
		return new HtmlElementImpl(radiobtn_yesthirdparty);
	}

	public HtmlElementImpl getBtn_submit() {
		return new HtmlElementImpl(btn_submit);
	}

	public HtmlElementImpl getChkbox_noduplicateconfirm() {
		return new HtmlElementImpl(chkbox_noduplicateconfirm);
	}

	public HtmlElementImpl getBtn_reset() {
		return new HtmlElementImpl(btn_reset);
	}

	public HtmlElementImpl getBtn_save() {
		return new HtmlElementImpl(btn_save);
	}

	public HtmlElementImpl getBtn_back() {
		return new HtmlElementImpl(btn_back);
	}

	public HtmlElementImpl getTxt_bankname() {
		return new HtmlElementImpl(txt_bankname);
	}

	public HtmlElementImpl getTxt_bankcustomername() {
		return new HtmlElementImpl(txt_bankcustomername);
	}

	public HtmlElementImpl getTxt_bankaba() {
		return new HtmlElementImpl(txt_bankaba);
	}

	public HtmlElementImpl getTxt_bankaccnumber() {
		return new HtmlElementImpl(txt_bankaccnumber);
	}

	public HtmlElementImpl getBtn_attachment() {
		return new HtmlElementImpl(btn_attachment);
	}

	public HtmlElementImpl getRadiobtn_margin() {
		return new HtmlElementImpl(radiobtn_margin);
	}

	public HtmlElementImpl getDrpdwn_standinginst() {
		return new HtmlElementImpl(drpdwn_standinginst);
	}

	public HtmlElementImpl getDrpdwn_advisorydescription() {
		return new HtmlElementImpl(drpdwn_advisorydescription);
	}

	public HtmlElementImpl getTxt_withholding() {
		return new HtmlElementImpl(txt_withholding);
	}

	public HtmlElementImpl getTxt_federaltax() {
		return new HtmlElementImpl(txt_federaltax);
	}

	public HtmlElementImpl getTxt_statetax() {
		return new HtmlElementImpl(txt_statetax);
	}

	public HtmlElementImpl getTxt_finalamount() {
		return new HtmlElementImpl(txt_finalamount);
	}

	public HtmlElementImpl getTxt_fedwithholding() {
		return new HtmlElementImpl(txt_fedwithholding);
	}

	public HtmlElementImpl getTxt_statewithholding() {
		return new HtmlElementImpl(txt_statewithholding);
	}

	public HtmlElementImpl getTxt_requestedamount() {
		return new HtmlElementImpl(txt_requestedamount);
	}

	public HtmlElementImpl getDrpdwn_distributiontype() {
		return new HtmlElementImpl(drpdwn_distributiontype);
	}

	public HtmlElementImpl getDrpdwn_contributiontype() {
		return new HtmlElementImpl(drpdwn_contributionype);
	}

	public HtmlElementImpl getBtn_selectrecordtypeD() {
		return new HtmlElementImpl(btn_selectRecordTypeD);
	}

	public HtmlElementImpl getBtn_selectrecordtypeE() {
		return new HtmlElementImpl(btn_selectRecordTypeE);
	}
	
	public HtmlElementImpl getBtn_selectrecordtypeF() {
		return new HtmlElementImpl(btn_selectRecordTypeF);
	}
	
	public HtmlElementImpl getBtn_selectrecordtypeG() {
		return new HtmlElementImpl(btn_selectRecordTypeG);
	}
	
	public HtmlElementImpl getBtn_distrecord() {
		return new HtmlElementImpl(btn_distrecord);
	}
	
	public HtmlElementImpl getBtn_distrecordtype() {
		return new HtmlElementImpl(btn_distrecordtype);
	}
	
	public HtmlElementImpl getBtn_distrecordtypetypeA() {
		return new HtmlElementImpl(btn_distrecordtypeA);
	}
	
	public HtmlElementImpl getTab_workqueuetab() {
		return new HtmlElementImpl(tab_workqueuetab);
	}
	
	public HtmlElementImpl getLink_clientservicesach() {
		return new HtmlElementImpl(link_clientservicesach);
	}
	
	public HtmlElementImpl getLink_rejectedachprocess() {
		return new HtmlElementImpl(link_rejectedachprocess);
	}
	
	public HtmlElementImpl getLink_bpmnpacontriwith() {
		return new HtmlElementImpl(link_bpmnpacontriwith);
	}
	
	public HtmlElementImpl getColumn_received() {
		return new HtmlElementImpl(column_received);
	}
	
	public HtmlElementImpl getLink_latestachprocess() {
		return new HtmlElementImpl(link_latestachprocess);
	}
	
	public HtmlElementImpl getBtn_closedialogbox() {
		return new HtmlElementImpl(btn_closedialogbox);
	}
		
	public HtmlElementImpl getBtn_go() {
		return new HtmlElementImpl(btn_go);
	}
	
	public HtmlElementImpl getTxt_sendtonextapproval() {
		return new HtmlElementImpl(txt_sendtonextapproval);
	}
	
	public HtmlElementImpl getText_selectreasons() {
		return new HtmlElementImpl(txt_selectreasons);
	}
	
	public HtmlElementImpl getBtn_add() {
		return new HtmlElementImpl(btn_add);
	}
	
	public HtmlElementImpl getBtn_continue() {
		return new HtmlElementImpl(btn_continue);
	}
	
	public HtmlElementImpl getBtn_inboxtab() {
		return new HtmlElementImpl(tab_inboxtab);
	}
}
