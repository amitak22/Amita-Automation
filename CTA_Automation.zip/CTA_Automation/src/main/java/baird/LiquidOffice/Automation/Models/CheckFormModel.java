package baird.LiquidOffice.Automation.Models;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import baird.core.Automation.WebDrivers.Browser;
import baird.core.Automation.WebDrivers.Elements.HtmlElementImpl;

/**
 * @author AmitaKumari
 */

public class CheckFormModel extends BaseModel {

	public CheckFormModel(Browser obj) {
		super(obj);
	}

	@FindBy(id = "Text5_2")
	WebElement txt_retrievedclienttitle;

	@FindBy(id = "AMOUNT")
	WebElement txt_amount;

	@FindBy(id = "CASH_MARGIN_Radio3_1")
	WebElement radiobtn_cash;

	@FindBy(id = "CASH_MARGIN_RadioButton15")
	WebElement radiobtn_margin;

	@FindBy(id = "mmfChoices")
	WebElement txt_cashormmf;

	@FindBy(id = "HTobj__CalLaunch_FUTURE_DATE")
	WebElement icon_calendar;

	@FindBy(id = "FUTURE_DATE")
	WebElement txt_date;

	@FindBy(id = "PRINT_LOCATION_RadioButton1")
	WebElement radiobtn_mkeaccount;

	@FindBy(id = "PRINT_LOCATION_RadioButton7")
	WebElement radiobtn_branch;

	@FindBy(id = "deliveryMethod")
	WebElement drpdwn_deliverymethod;

	@FindBy(id = "purposeType")
	WebElement drpdwn_checkpurpose;
	
	@FindBy(id = "DTB__IRA_Information_0_REQUEST_TYPE_RadioButton18_1")
	WebElement radiobtn_onetime;
	
	@FindBy(id = "DTB__IRA_Information_0_REQUEST_TYPE_RadioButton17_1")
	WebElement radiobtn_ondemand;
	
	@FindBy(id = "DTB__IRA_Information_0_btnViewDIST")
	WebElement btn_distrecord;
	
	@FindBy(id = "DTB__IRA_Information_0_REQUEST_TYPE_RadioButton19")
	WebElement radiobtn_qcd;
	
	@FindBy(id = "printerOption")
	WebElement chkbox_printlocation;

	@FindBy(id = "Text84")
	WebElement txt_printlocation;

	@FindBy(id = "printer-filter-0")
	WebElement txtbox_printlocation;

	@FindBy(id = "USE_ACCT_ADDR")
	WebElement btn_sameaccountreg;

	@FindBy(id = "btnClear")
	WebElement btn_clearpayeeinfo;

	@FindBy(id = "btnExisting")
	WebElement btn_payeeinstruction;

	@FindBy(id = "DTB__PINS_TBL_0_btnSelect")
	WebElement btn_payeeinstructionrecord;

	@FindBy(id = "DTB__PINS_TBL_1_btnSelect")
	WebElement btn_payeeinstructionrecord2;

	@FindBy(xpath = "//tr[1]//td[1]//button[1]")
	WebElement btn_typeA;
	
	@FindBy(xpath = "//tr[2]//td[1]//button[1]")
	WebElement btn_typeC;
	
	@FindBy(xpath = "//tr[3]//td[1]//button[1]")
	WebElement btn_typeD;
	
	@FindBy(xpath = "//tr[7]//td[1]//button[1]")
	WebElement btn_typeB;
	
	@FindBy(xpath = "//tr[4]//td[1]//button[1]")
	WebElement btn_typeE;
	
	@FindBy(xpath = "//tr[6]//td[1]//button[1]")
	WebElement btn_typeF1;
	
	@FindBy(id = "MEMO_1")
	WebElement txtbox_memolines;

	@FindBy(id = "btnExisting")
	WebElement btn_selectpayeeinst;

	@FindBy(id = "PAYEE_NAME_1")
	WebElement txt_payeename;

	@FindBy(id = "PAYEE_ADDRESS_1")
	WebElement txt_payeeaddress;

	@FindBy(id = "PAYEE_ADDRESS_2")
	WebElement txt_payeeaddressline2;

	@FindBy(id = "PAYEE_CITY")
	WebElement txt_payeecity;

	@FindBy(id = "PAYEE_STATE")
	WebElement txt_payeestate;

	@FindBy(id = "PAYEE_ZIP")
	WebElement txt_payeezip;

	@FindBy(id = "tobMain")
	WebElement drpdwn_typeofpayee;

	@FindBy(id = "LoaMain")
	WebElement drpdwn_standinginst;

	@FindBy(id = "DTB__tblThirdParty_0_ofacReview_RadioButton2")
	WebElement yesradiobtn_thirdpartyinfo;

	@FindBy(id = "DTB__tblThirdParty_0_ofacReview_RadioButton3")
	WebElement noradiobtn_thirdpartyinfo;

	@FindBy(id = "DTB__tblAdvisoryAcctWithdrawalInfo_0_SourceAccountModelChange_RadioButton11_5")
	WebElement noradiobtn_advisoryacc;

	@FindBy(id = "DTB__tblAdvisoryAcctWithdrawalInfo_0_SourceAccountModelChange_RadioButton10_5")
	WebElement yesradiobtn_advisoryacc;

	@FindBy(id = "DTB__tblAttest_0_chkAttest")
	WebElement chkbox_attestation;

	@FindBy(id = "DTB__tblAttest_0_ATTESTOR_NAME")
	WebElement txt_attestorname;

	@FindBy(id = "Attachments_1")
	WebElement btn_attachment;

	@FindBy(id = "btnSubmit")
	WebElement btn_submit;

	@FindBy(id = "ATTEST_NO_DUPE")
	WebElement chkbox_noduplicateconfirm;

	@FindBy(id = "btnBack")
	WebElement btn_back;

	@FindBy(id = "btnReset")
	WebElement btn_reset;

	@FindBy(id = "btnSave")
	WebElement btn_save;

	@FindBy(id = "button_CloseWindow")
	WebElement btn_close;

	@FindBy(id = "PayeeAddressLine2Help")
	WebElement icon_question;

	public HtmlElementImpl getTxt_retrievedclienttitle() {
		return new HtmlElementImpl(txt_retrievedclienttitle);
	}

	public HtmlElementImpl getTxt_amount() {
		return new HtmlElementImpl(txt_amount);
	}

	public HtmlElementImpl getRadiobtn_cash() {
		return new HtmlElementImpl(radiobtn_cash);
	}

	public HtmlElementImpl getRadiobtn_margin() {
		return new HtmlElementImpl(radiobtn_margin);
	}

	public HtmlElementImpl getIcon_calendar() {
		return new HtmlElementImpl(icon_calendar);
	}

	public HtmlElementImpl getTxt_cashorMMF() {
		return new HtmlElementImpl(txt_cashormmf);
	}

	public HtmlElementImpl getTxt_issuedate() {
		return new HtmlElementImpl(txt_date);
	}

	public HtmlElementImpl getRadiobtn_mkeaccount() {
		return new HtmlElementImpl(radiobtn_mkeaccount);
	}

	public HtmlElementImpl getRadiobtn_branch() {
		return new HtmlElementImpl(radiobtn_branch);
	}

	public HtmlElementImpl getDrpdwn_deliverymethod() {
		return new HtmlElementImpl(drpdwn_deliverymethod);
	}

	public HtmlElementImpl getDrpdwn_checkpurpose() {
		return new HtmlElementImpl(drpdwn_checkpurpose);
	}
	
	public HtmlElementImpl getRadiobtn_onetime() {
		return new HtmlElementImpl(radiobtn_onetime);
	}
	
	public HtmlElementImpl getRadiobtn_ondemand() {
		return new HtmlElementImpl(radiobtn_ondemand);
	}
	
	public HtmlElementImpl getBtn_distrecord() {
		return new HtmlElementImpl(btn_distrecord);
	}
	
	public HtmlElementImpl getRadiobtn_qcd() {
		return new HtmlElementImpl(radiobtn_qcd);
	}
	
	public HtmlElementImpl getChkbox_printlocation() {
		return new HtmlElementImpl(chkbox_printlocation);
	}

	public HtmlElementImpl getTxt_printlocationChkbox() {
		return new HtmlElementImpl(txt_printlocation);
	}

	public HtmlElementImpl getTxtbox_printlocation() {
		return new HtmlElementImpl(txtbox_printlocation);
	}

	public HtmlElementImpl getBtn_sameaccountreg() {
		return new HtmlElementImpl(btn_sameaccountreg);
	}

	public HtmlElementImpl getBtn_clearpayeeinfo() {
		return new HtmlElementImpl(btn_clearpayeeinfo);
	}

	public HtmlElementImpl getBtn_payeeinstruction() {
		return new HtmlElementImpl(btn_payeeinstruction);
	}

	public HtmlElementImpl getBtn_payeeinstructionrecord() {
		return new HtmlElementImpl(btn_payeeinstructionrecord);
	}

	public HtmlElementImpl getBtn_payeeinstructionrecord2() {
		return new HtmlElementImpl(btn_payeeinstructionrecord2);
	}
	
	public HtmlElementImpl getBtn_typeA() {
		return new HtmlElementImpl(btn_typeA);
	}
	
	public HtmlElementImpl getBtn_typeB() {
		return new HtmlElementImpl(btn_typeB);
	}
	
	public HtmlElementImpl getBtn_typeC() {
		return new HtmlElementImpl(btn_typeC);
	}
	
	public HtmlElementImpl getBtn_typeD() {
		return new HtmlElementImpl(btn_typeD);
	}
	
	public HtmlElementImpl getBtn_typeE() {
		return new HtmlElementImpl(btn_typeE);
	}
	
	public HtmlElementImpl getBtn_typeF1() {
		return new HtmlElementImpl(btn_typeF1);
	}
	
	public HtmlElementImpl getTxtbox_memolines() {
		return new HtmlElementImpl(txtbox_memolines);
	}

	public HtmlElementImpl getBtn_selectpayeeinst() {
		return new HtmlElementImpl(btn_selectpayeeinst);
	}

	public HtmlElementImpl getTxt_payeename() {
		return new HtmlElementImpl(txt_payeename);
	}

	public HtmlElementImpl getTxt_payeeaddress() {
		return new HtmlElementImpl(txt_payeeaddress);
	}

	public HtmlElementImpl getTxt_payeeaddressline2() {
		return new HtmlElementImpl(txt_payeeaddressline2);
	}

	public HtmlElementImpl getTxt_payeecity() {
		return new HtmlElementImpl(txt_payeecity);
	}

	public HtmlElementImpl getTxt_payeestate() {
		return new HtmlElementImpl(txt_payeestate);
	}

	public HtmlElementImpl getTxt_payeezip() {
		return new HtmlElementImpl(txt_payeezip);
	}

	public HtmlElementImpl getDrpdwn_typeofpayee() {
		return new HtmlElementImpl(drpdwn_typeofpayee);
	}

	public HtmlElementImpl getDrpdwn_standinginst() {
		return new HtmlElementImpl(drpdwn_standinginst);
	}

	public HtmlElementImpl getRadiobtnYes_thirdpartyinfo() {
		return new HtmlElementImpl(yesradiobtn_thirdpartyinfo);
	}

	public HtmlElementImpl getRadiobtnNo_thirdpartyinfo() {
		return new HtmlElementImpl(noradiobtn_thirdpartyinfo);
	}

	public HtmlElementImpl getRadiobtnNo_advisoryacc() {
		return new HtmlElementImpl(noradiobtn_advisoryacc);
	}

	public HtmlElementImpl getRadiobtnYes_advisoryacc() {
		return new HtmlElementImpl(yesradiobtn_advisoryacc);
	}

	public HtmlElementImpl getChkbox_attestation() {
		return new HtmlElementImpl(chkbox_attestation);
	}

	public HtmlElementImpl getTxt_attestorname() {
		return new HtmlElementImpl(txt_attestorname);
	}

	public HtmlElementImpl getBtn_attachment() {
		return new HtmlElementImpl(btn_attachment);
	}

	public HtmlElementImpl getBtn_submit() {
		return new HtmlElementImpl(btn_submit);
	}

	public HtmlElementImpl getChkbox_noduplicateconfirm() {
		return new HtmlElementImpl(chkbox_noduplicateconfirm);
	}

	public HtmlElementImpl getBtn_back() {
		return new HtmlElementImpl(btn_back);
	}

	public HtmlElementImpl getBtn_reset() {
		return new HtmlElementImpl(btn_reset);
	}

	public HtmlElementImpl getBtn_save() {
		return new HtmlElementImpl(btn_save);
	}

	public HtmlElementImpl getBtn_close() {
		return new HtmlElementImpl(btn_close);
	}

	// Check IRA

	@FindBy(id = "IRA_Header")
	WebElement txt_irawithholdingtitle;

	@FindBy(id = "DTB__IRA_Information_0_DISTRIBUTION_TYPE")
	WebElement drpdwn_distributiontype;

	@FindBy(id = "DTB__IRA_Information_0_DIST_ATTACHMENT_RadioButton19_1")
	WebElement radiobtn_onfile;

	@FindBy(id = "DTB__IRA_Information_0_Text51_1")
	WebElement radiobtn_attached;

	@FindBy(id = "DTB__IRA_Information_0_FED_PERCENT")
	WebElement txt_federaltax;

	@FindBy(id = "DTB__IRA_Information_0_STATE_PERCENT")
	WebElement txt_statetax;

	@FindBy(id = "DTB__IRA_Information_0_AMT_AFTER_WITHHOLDING")
	WebElement txt_finalamount;

	@FindBy(id = "DTB__IRA_Information_0_FED_WITHHOLDING_AMT")
	WebElement txt_fedwithholding;

	@FindBy(id = "DTB__IRA_Information_0_STATE_WITHHOLDING_AMT")
	WebElement txt_statewithholding;

	@FindBy(id = "DTB__IRA_Information_0_REQUESTED_AMOUNT")
	WebElement txt_requestedamount;

	@FindBy(id = "DTB__tblThirdParty_0_ofacReview_RadioButton3")
	WebElement radiobtn_nothirdpartyinfo;

	@FindBy(id = "DTB__tblAdvisoryAcctWithdrawalInfo_0_SourceAccountModelChange_RadioButton10_5")
	WebElement radiobtn_yesthirdpartyinfo;

	public HtmlElementImpl getTxt_irawithholdingtitle() {
		return new HtmlElementImpl(txt_irawithholdingtitle);
	}

	public HtmlElementImpl getDrpdwn_distributiontype() {
		return new HtmlElementImpl(drpdwn_distributiontype);
	}

	public HtmlElementImpl getRadiobtn_onfile() {
		return new HtmlElementImpl(radiobtn_onfile);
	}

	public HtmlElementImpl getRadiobtn_attached() {
		return new HtmlElementImpl(radiobtn_attached);
	}

	public HtmlElementImpl getTxt_federaltax() {
		return new HtmlElementImpl(txt_federaltax);
	}

	public HtmlElementImpl getTxt_statetax() {
		return new HtmlElementImpl(txt_statetax);
	}

	public HtmlElementImpl getTxt_finalamount() {
		return new HtmlElementImpl(txt_finalamount);
	}

	public HtmlElementImpl getTxt_fedwithholding() {
		return new HtmlElementImpl(txt_fedwithholding);
	}

	public HtmlElementImpl getTxt_statewithholding() {
		return new HtmlElementImpl(txt_statewithholding);
	}

	public HtmlElementImpl getTxt_requestedamount() {
		return new HtmlElementImpl(txt_requestedamount);
	}

	public HtmlElementImpl getRadiobtn_Nothirdpartyinfo() {
		return new HtmlElementImpl(radiobtn_nothirdpartyinfo);
	}

	public HtmlElementImpl getRadiobtn_Yesthirdpartyinfo() {
		return new HtmlElementImpl(radiobtn_yesthirdpartyinfo);
	}

	public HtmlElementImpl getIcon_question() {
		return new HtmlElementImpl(icon_question);
	}
}
