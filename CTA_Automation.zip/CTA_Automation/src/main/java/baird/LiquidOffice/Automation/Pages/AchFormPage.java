package baird.LiquidOffice.Automation.Pages;

import baird.LiquidOffice.Automation.Models.AchFormModel;
import baird.LiquidOffice.Automation.Resources.TestSettings;
import baird.core.Automation.CommonAPI.ICommonAPI;

/**
 * @author AmitaKumari
 */

public class AchFormPage extends BasePage<AchFormModel> {

	public AchFormPage(ICommonAPI commonApi, TestSettings Settings) {
		super(commonApi, Settings);
		PageElements = new AchFormModel(_browser);
	}

	@Override
	public void navigateTopage() {
		SwitchToPopupWindow();
		try {
			Thread.sleep(1000);

		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		PageElements.init();
	}

	public String getRetrievedClientTitle() {
		return PageElements.getTxt_retrievedclienttitle().getText();
	}

	public boolean getAccountNumber(String AccNumber) {
		return PageElements.getTxt_accnumber().getAttribute("value").contains(AccNumber);
	}

	public boolean getIRAType(String IRAtype) {
		return PageElements.getTxt_iratype().getAttribute("value").contains(IRAtype);
	}

	public boolean getClientName(String ClientName) {
		return PageElements.getTxt_clientname().getAttribute("value").contains(ClientName);
	}

	public void selectACHInstructions() {
		PageElements.getBtn_achinstruction().click();
	}

	public void selectRecordTypeA() {
		PageElements.getBtn_selectrecordtypeA().click();
	}

	public void selectRecordTypeBandD() {
		PageElements.getBtn_selectrecordtypeBandD().click();
	}

	public boolean getACHInstruction1Text(String ACHinstruction) {
		return PageElements.getTxt_ACHInstruction1().getAttribute("value").contains(ACHinstruction);
	}

	public boolean getBankCustomerName(String BankCustomerName) {
		return PageElements.getTxt_BankCustomerName().getAttribute("value").contains(BankCustomerName);
	}

	public boolean getBankName(String BankName) {
		return PageElements.getTxt_BankName().getAttribute("value").contains(BankName);
	}

	public boolean getBankABA(String BankABA) {
		return PageElements.getTxt_BankABA().getAttribute("value").contains(BankABA);
	}

	public boolean getBankAccNumber(String BankAccNumber) {
		return PageElements.getTxt_BankAccNumber().getAttribute("value").contains(BankAccNumber);
	}

	public void clickBtnClearBankInfo() {
		PageElements.getBtn_clearbanlinfo().click();
	}

	public void enterAmount(String Amount) {
		PageElements.getTxt_amount().sendKeys(Amount);
	}

	public String getCashorMMF() {
		PageElements.getTxt_cashorMMF().click();
		return PageElements.getTxt_cashorMMF().getText();
	}

	public void selectCashorMMF(String Fund) {
		PageElements.getTxt_cashorMMF().sendKeys(Fund);
	}

	public String getInvalidCharErrorMessage() {
		return _browser._browserDriver.switchTo().alert().getText();
	}

	public String getIssueDate() {
		PageElements.getTxt_issuedate().click();
		return PageElements.getTxt_issuedate().getText();
	}

	public void clickIssueDate(String FutureDate) {
		PageElements.getTxt_issuedate().click();
		PageElements.getTxt_issuedate().clear();
		PageElements.getTxt_issuedate().click();
		PageElements.getTxt_issuedate().sendKeys(FutureDate);
	}

	public void selectAccTypeCash() {
		PageElements.getRadiobtn_cash().click();
	}

	public void selectTransferinOutOfBaird() {
		PageElements.getRadiobtn_outofbaird().click();
	}

	public void selectTransferinIntoBaird() {
		PageElements.getRadiobtn_intobaird().click();
	}

	public void selectAttestationChkbox() {
		PageElements.getChkbox_attestation().click();
	}

	public void enterAttestorName(String AttestorName) {
		PageElements.getTxt_attestorname().sendKeys(AttestorName);
	}

	public void enterThirdPartyName(String ThirdParty) {
		PageElements.getTxt_thirdpartyname().sendKeys(ThirdParty);
	}

	public void selectYesRadioBtnThirdParty() {
		PageElements.getRadiobtn_yesthirdparty().click();
	}

	public void selectNoRadioBtnAdvisoryAcc() {
		PageElements.getRadiobtn_noadvisoryaccount().click();
	}

	public void selectYesRadioBtnAdvisoryAcc() {
		PageElements.getRadiobtn_yesadvisoryaccount().click();
	}

	public void clickSubmitBtn() {
		PageElements.getBtn_submit().click();
	}

	public void selectNoDuplicateChkbox() throws InterruptedException {
		Thread.sleep(1000);
		PageElements.getChkbox_noduplicateconfirm().click();
		Thread.sleep(2000);
	}

	public void clickResetButton() throws InterruptedException {
		PageElements.getBtn_reset().click();
		Thread.sleep(2000);
	}

	public void clickSaveButton() {
		PageElements.getBtn_save().click();
	}

	public void clickBackButton() {
		PageElements.getBtn_back().click();
	}

	public boolean checkBankCustomerName(String BankCustomerName) {
		return PageElements.getTxt_bankcustomername().getAttribute("value").contains(BankCustomerName);
	}

	public boolean checkBankName(String BankName) {
		return PageElements.getTxt_bankname().getAttribute("value").contains(BankName);
	}

	public boolean checkBankABA(String BankABA) {
		return PageElements.getTxt_bankaba().getAttribute("value").contains(BankABA);
	}

	public boolean checkBankAccNumber(String BankAccNumber) {
		return PageElements.getTxt_bankaccnumber().getAttribute("value").contains(BankAccNumber);
	}

	public void clickAttachmentBtn() {
		PageElements.getBtn_attachment().click();
	}

	public void selectAccTypeMargin() {
		PageElements.getRadiobtn_margin().click();
	}

	public void selectStandingInstruction(String SLOA) {
		PageElements.getDrpdwn_standinginst().sendKeys(SLOA);
	}

	public void selectDescriptionDeposit(String Description) {
		PageElements.getDrpdwn_advisorydescription().sendKeys(Description);
	}

	public boolean getWithholdingInfoTitle(String WithholdingTitle) {
		return PageElements.getTxt_withholding().getAttribute("value").contains(WithholdingTitle);
	}

	public void enterFederalTax(String FederalTax) {
		PageElements.getTxt_federaltax().sendKeys(FederalTax);
	}

	public void enterStateTax(String StateTax) {
		PageElements.getTxt_statetax().sendKeys(StateTax);
	}

	public boolean checkFinalAmount(String FinalAmount) throws InterruptedException {
		PageElements.getTxt_finalamount().click();
		Thread.sleep(1000);
		return PageElements.getTxt_finalamount().getAttribute("value").contains(FinalAmount);
	}

	public void selectIRARecordTypeB() {
		PageElements.getBtn_selectrecordtypeA().click();
	}

	public void selectIRARecordTypeC() {
		PageElements.getBtn_selectrecordtypeC().click();
	}
	
	public void selectIRARecordTypeA() {
		PageElements.getBtn_selectrecordtypeBandD().click();
	}

	public boolean achFedWithholding(String FedWithholding) throws InterruptedException {
		PageElements.getTxt_fedwithholding().click();
		Thread.sleep(1000);
		return PageElements.getTxt_fedwithholding().getAttribute("value").contains(FedWithholding);
	}

	public boolean achStateWithholding(String StateWithholding) throws InterruptedException {
		PageElements.getTxt_statewithholding().click();
		Thread.sleep(1000);
		return PageElements.getTxt_statewithholding().getAttribute("value").contains(StateWithholding);
	}

	public boolean requestedAmount(String ReqAmount) throws InterruptedException {
		PageElements.getTxt_statewithholding().click();
		Thread.sleep(1000);
		return PageElements.getTxt_requestedamount().getAttribute("value").contains(ReqAmount);
	}

	public void clickDistributionTypeDrpdwn(String DistributionType) {
		PageElements.getDrpdwn_distributiontype().sendKeys(DistributionType);
	}

	public void clickContributionTypeDrpdwn(String ContributionType) {
		PageElements.getDrpdwn_contributiontype().sendKeys(ContributionType);
	}

	public boolean checkReqAmount(String ReqAmount) throws InterruptedException {
		PageElements.getTxt_amount().click();
		return PageElements.getTxt_amount().getAttribute("value").contains(ReqAmount);
	}

	public void enterReqAmountWithholding(String ReqAmount) {
		PageElements.getTxt_requestedamount().sendKeys(ReqAmount);
	}

	public boolean checkDistributionType(String DistributionType) throws InterruptedException {
		return PageElements.getDrpdwn_distributiontype().getAttribute("value").contains(DistributionType);
	}

	public void selectIRARecordTypeD() {
		PageElements.getBtn_selectrecordtypeD().click();
	}
	
	public void selectIRARecordTypeE() {
		PageElements.getBtn_selectrecordtypeE().click();
	}
	
	public void selectIRARecordTypeF() {
		PageElements.getBtn_selectrecordtypeF().click();
	}
	
	public void selectIRARecordTypeG() {
		PageElements.getBtn_selectrecordtypeG().click();
	}
	
	public void selectDistRecord() throws InterruptedException {
		PageElements.getBtn_distrecord().click();	
		Thread.sleep(2000);
		PageElements.getBtn_distrecordtype().click();
	}
	
	public void selectDistRecordTypeAwithTax() throws InterruptedException {
		PageElements.getBtn_distrecord().click();	
		Thread.sleep(2000);
		PageElements.getBtn_distrecordtypetypeA().click();
	}
	
	public void clickWorkQueuesTab() {
		PageElements.getTab_workqueuetab().click();
	}
	
	public void clickClientServicesACH() {
		PageElements.getLink_clientservicesach().click();
	}
	
	public void openLatestRejectedProcess() {
		PageElements.getLink_rejectedachprocess().click();
	}
	
	public void clickBPMnpaContriWithdrawal() {
		PageElements.getLink_bpmnpacontriwith().click();
	}
	
	public void sortReceivedColoumn() {
		PageElements.getColumn_received().click();
		PageElements.getColumn_received().click();
	}
	
	public void openLatestACHprocess() {
		PageElements.getLink_latestachprocess().click();
	}
	
	public void closeDialbox() throws InterruptedException {
		Thread.sleep(2000);
		PageElements.getBtn_closedialogbox().click();
	}
	
	public void clickGoBtn() {
		PageElements.getBtn_go().click();
	}
	
	public void selectSendToNextApproval(String SendToNextApproval) {
		PageElements.getTxt_sendtonextapproval().sendKeys(SendToNextApproval);
	}
	
	public void selectRejectreason() {
		PageElements.getText_selectreasons().click();
	}
	
	public void clickAddBtn() {
		PageElements.getBtn_add().click();
	}
	
	public void clickContinueBtn() {
		PageElements.getBtn_continue().click();
	}
	
	public void clickInboxTab() {
		PageElements.getBtn_inboxtab().click();
	}
}
