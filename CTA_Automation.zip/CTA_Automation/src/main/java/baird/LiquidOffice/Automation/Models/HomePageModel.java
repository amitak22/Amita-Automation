package baird.LiquidOffice.Automation.Models;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import baird.core.Automation.WebDrivers.Browser;
import baird.core.Automation.WebDrivers.Elements.HtmlElementImpl;


/**
 * @author AmitaKumari
 */

public class HomePageModel extends BaseModel {

	public HomePageModel(Browser obj) {
		super(obj);
	}

	@FindBy(xpath = "//table[@id='FormsRepos_FieldsPanel']//tr[@id='9']//a[@class='record_cell_fields']")
	WebElement lnk_clientservices;

	
	@FindBy(xpath = "//table[@id='FormsRepos_FieldsPanel']//tr[@id='6']//a[@class='record_cell_fields']")
	WebElement lnk_sitclientservices;
	
	public HtmlElementImpl getLnk_clientservices() {
		return new HtmlElementImpl(lnk_clientservices);
	}

	public HtmlElementImpl getLnk_sitclientservices() {
		return new HtmlElementImpl(lnk_sitclientservices);
	}
}
