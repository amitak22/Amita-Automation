package baird.LiquidOffice.Automation.Resources;

import com.google.gson.GsonBuilder;
import com.google.gson.stream.JsonReader;

/**
 * @author AmitaKumari
 */

public class AccNoTypeData extends TestArgumentBase<AccNoTypeData>{

	public String AccNo;
	public String Type;
	
	@Override
	public AccNoTypeData[] getClassListfromJson(JsonReader reader) {
		return new GsonBuilder().create().fromJson(reader, AccNoTypeData[].class);
	}


}
