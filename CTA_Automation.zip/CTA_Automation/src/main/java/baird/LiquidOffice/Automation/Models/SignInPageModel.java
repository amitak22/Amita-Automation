package baird.LiquidOffice.Automation.Models;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import baird.core.Automation.WebDrivers.Browser;
import baird.core.Automation.WebDrivers.Elements.HtmlElementImpl;

/**
 * @author AmitaKumari
 */

public class SignInPageModel extends BaseModel {

	public SignInPageModel(Browser obj) {
		super(obj);
	}

	@FindBy(css = "a.homelogo_header_hmenu")
	WebElement lnk_homelogo;

	/**
	 * @return the lnk_homelogo
	 */
	public HtmlElementImpl getLnk_homelogo() {
		return new HtmlElementImpl(lnk_homelogo);
	}

	@FindBy(className = "top_administration_hmenu")
	WebElement lnk_signIn;

	public HtmlElementImpl getLnk_signIn() {
		return new HtmlElementImpl(lnk_signIn);
	}
}
