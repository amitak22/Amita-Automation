package baird.LiquidOffice.Automation.Pages;

import baird.LiquidOffice.Automation.Models.JournalFormModel;
import baird.LiquidOffice.Automation.Resources.TestSettings;
import baird.core.Automation.CommonAPI.ICommonAPI;

/**
 * @author AmitaKumari
 */

public class JournalFormPage extends BasePage<JournalFormModel> {

	public JournalFormPage(ICommonAPI commonApi, TestSettings Settings) {
		super(commonApi, Settings);
		PageElements = new JournalFormModel(_browser);
	}

	@Override
	public void navigateTopage() {
		SwitchToPopupWindow();
		try {
			Thread.sleep(1000);

		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		PageElements.init();
	}

	public void enterTransferToAcc(String AccountNo) {
		PageElements.getTxt_transfertoacc().sendKeys(AccountNo);
	}

	public void clickTransferDate(String TransferFutureDate) {
		PageElements.getTxt_transferdate().click();
	}

	public void enterTransferDate() {
		PageElements.getTxt_transferdate().click();
		PageElements.getTxt_transferdate().clear();
	}

	public String getTransferDate() {
		PageElements.getTxt_transferdate().click();
		return PageElements.getTxt_transferdate().getText();
	}

	public void selectTypeofPayee(String TypeofPayee) {
		PageElements.getDrpdwn_typeofpayee().sendKeys(TypeofPayee);
	}

	public void selectTransferTypeFull() {
		PageElements.getRadiobtnFull_transfertype().click();
	}

	public void selectTransferTypePartial() {
		PageElements.getRadiobtnPartial_transfertype().click();
	}

	public void selectGiftforTaxYes() {
		PageElements.getRadiobtnYes_giftfortax().click();
	}

	public void selectQuantityPartial() {
		PageElements.getRadiobtnPartial_quantity().click();
	}

	public void selectQuantityPartialMMF() {
		PageElements.getRadiobtnPartialmmf_quantity().click();
	}

	public void selectTransferTypeNoneMMF() {
		PageElements.getRadiobtnNonemmf_quantity().click();
	}

	public void selectQuantityAll() {
		PageElements.getRadiobtnAll_quantity().click();
	}

	public void selectQuantityNone() {
		PageElements.getRadiobtnNone_quantity().click();
	}

	public void selectStandingInstruction(String SLOA) {
		PageElements.getDrpdwn_standinginst().sendKeys(SLOA);
	}

	public void enterTransferValue(String TransferValue) {
		PageElements.getTxt_transfervalue().sendKeys(TransferValue);
	}

	public void enterTransferValueMMF(String TransferValueMMF) {
		PageElements.getTxt_transfervaluemmf().sendKeys(TransferValueMMF);
	}

	public void enterTotalAmountCashWithdrawal(String CashWithdrawal) {
		PageElements.getTxt_cashwithdrawalamount().sendKeys(CashWithdrawal);
	}

	public boolean checkTransferValue(String TransferValue) {
		return PageElements.getTxt_transfervalue().getAttribute("value").contains(TransferValue);
	}

	public boolean checkTotalfromValuations(String TotalfromValuations) {
		return PageElements.getTxt_totalfromvaluations().getAttribute("value").contains(TotalfromValuations);
	}

	public boolean checkTotalfromAllSelections(String TotalfromAllSelections) {
		return PageElements.getTxt_totalfromallselections().getAttribute("value").contains(TotalfromAllSelections);
	}

	public boolean checkTotalfromPositions(String TotalfromPositions) {
		PageElements.getTxt_totalfrompositions().click();
		return PageElements.getTxt_totalfrompositions().getAttribute("value").contains(TotalfromPositions);
	}

	public boolean checkTransferDesc(String TransferDesc) {
		return PageElements.getTxt_transferdesc().getAttribute("value").contains(TransferDesc);
	}

	public boolean checkTransferToAccDescription(String TransferToAccDesc) {
		return PageElements.getTxt_transfertoaccdesc().getAttribute("value").contains(TransferToAccDesc);
	}
	
	public boolean checkCashInfoType(String CashInfoType) {
		return PageElements.getTxt_cashinfotype().getAttribute("value").contains(CashInfoType);
	}

	public boolean checkMMFInfoType(String MMFInfoType) {
		return PageElements.getTxt_mmfinfotype().getAttribute("value").contains(MMFInfoType);
	}

	public boolean checkMMFValue(String MMFValue) {
		return PageElements.getTxt_mmfvalue().getAttribute("value").contains(MMFValue);
	}

	public String getValue() {
		PageElements.getTxt_value().click();
		return PageElements.getTxt_value().getText();
	}

	public String getMMFValue() {
		PageElements.getTxt_mmfvalue().click();
		return PageElements.getTxt_mmfvalue().getText();
	}
	
	public String getTransferValue() {
		PageElements.getTxt_totalfromvaluations().click();
		return PageElements.getTxt_totalfromvaluations().getText();
	}
	
	public String getTransferValueMMF() {
		PageElements.getTxt_transfervaluemmf().click();
		return PageElements.getTxt_transfervaluemmf().getText();
	}
	
	public String getTotalfromValuations() {
		PageElements.getTxt_transfervalue().click();
		return PageElements.getTxt_transfervalue().getText();
	}

	public boolean checkPageNo(String PageNo) {
		return PageElements.getTxt_pageno().getAttribute("value").contains(PageNo);
	}

	public void clickIconQuestion() {
		PageElements.getIcon_question().click();
	}

	public void clickAttachmentBtn() {
		PageElements.getBtn_attachment().click();
	}

	public void clickBackButton() {
		PageElements.getBtn_back().click();
	}

	public void clickSaveButton() {
		PageElements.getBtn_save().click();
	}

	public void clickSaveforLaterButton() {
		PageElements.getBtn_saveforlater().click();
	}

	public void clickNextButton() {
		PageElements.getBtn_next().click();
	}

	public void clickPreviousButton() {
		PageElements.getBtn_previous().click();
	}

	public boolean checkJournalInformationTitle(String JournalInfoTitle) {
		return PageElements.getTxt_journalinfotitle().getAttribute("value").contains(JournalInfoTitle);
	}

	public boolean checkAdvisoryAccTitle(String AdvisoryAccTitle) {
		return PageElements.getTxt_advisoryacctitle().getAttribute("value").contains(AdvisoryAccTitle);
	}

	public void selectYesRadioBtnAdvisoryAcc() {
		PageElements.getRadiobtn_yesadvisoryaccount().click();
	}

	public void selectNoRadioBtnAdvisoryAcc() {
		PageElements.getRadiobtn_noadvisoryaccount().click();
	}
	
	public void selectYesRadioBtnSecuritiesOut() {
		PageElements.getRadiobtn_yessecuritiesout().click();
	}

	public void selectJournalfromDropdown(String Journal) {
		PageElements.getDrpdwn_journal().sendKeys(Journal);
	}

	public void clickContinueBtn() {
		PageElements.getBtn_continue().click();
	}
	
	public void clickContinueBtnIRA() {
		PageElements.getBtn_continueIRA().click();
	}
	
	public void selectSecuritiesPartialQuantity() {
		PageElements.getRadiobtnPartial_securities().click();
	}

	public void selectSecuritiesPartialQuantity2() {
		PageElements.getRadiobtnPartial_securities2().click();
	}

	public void selectSecuritiesAllQuantity() {
		PageElements.getRadiobtnAll_securities().click();
	}

	public void enterNoOfShares(String ShareNo) {
		PageElements.getTxt_shareno().sendKeys(ShareNo);
	}

	public void enterNoOfShares2ndRow(String ShareNo2ndRow) {
		PageElements.getTxt_shareno2().sendKeys(ShareNo2ndRow);
	}

	public void clickTaxLots() {
		PageElements.getBtn_taxlot().click();
	}

	public String getValueSecurity() {
		PageElements.getTxt_valuesecurity().click();
		return PageElements.getTxt_valuesecurity().getText();
	}

	public String getTransferValueSecurity() {
		PageElements.getTxt_transfervaluesecurity().click();
		return PageElements.getTxt_transfervaluesecurity().getText();
	}

	public boolean getIRAContributionInfoTitle(String TransferDesc) {
		PageElements.getTxt_iracontributiontitle().click();
		return PageElements.getTxt_iracontributiontitle().getAttribute("value").contains(TransferDesc);
	}

	public boolean getAccTypeTo(String acctype) {
		return PageElements.getTxt_acctypeto().getAttribute("value").contains(acctype);
	}
	
	public boolean getAccTypeToIRAtoRetail(String acctype) {
		return PageElements.getTxt_acctypetoiratoretail().getAttribute("value").contains(acctype);
	}
	
	public boolean getAccTypeFrom(String acctype) {
		return PageElements.getTxt_acctypefrom().getAttribute("value").contains(acctype);
	}
	
	public boolean getAccNumber(String AccNo) {
		return PageElements.getTxt_accno().getAttribute("value").contains(AccNo);
	}
	
	public boolean getTransferFromAccNumber(String TransferFromAccNo) {
		return PageElements.getTxt_transferfromaccno().getAttribute("value").contains(TransferFromAccNo);
	}
	
	public boolean getTransferToAccNumber(String TransferToAccNo) {
		return PageElements.getTxt_transfertoaccno().getAttribute("value").contains(TransferToAccNo);
	}
	public void clickDepositCodeDrpdwn(String DepositCode) {
		PageElements.getDrpdwn_depositcode().sendKeys(DepositCode);
	}

	public void clickWithdrawalCodeDrpdwn(String WithdrawalCode) {
		PageElements.getDrpdwn_withdrawalcode().sendKeys(WithdrawalCode);
	}
	
	public void selectOnFileDistributionForm() {
		PageElements.getBtn_distributionformonfile().click();
	}
	
	public void selectAttachedDistributionForm() {
		PageElements.getBtn_distributionformattached().click();
	}
	
	public void enterFederalTax(String FederalTax) {
		PageElements.getTxt_federaltax().sendKeys(FederalTax);
	}
	
	public void enterStateTax(String StateTax) {
		PageElements.getTxt_statetax().sendKeys(StateTax);
	}
	
	public boolean getFedWithholding(String FedWithholding) {
		return PageElements.getTxt_fedwithholding().getAttribute("value").contains(FedWithholding);
	}
	
	public boolean getStateWithholding(String StateWithholding) {
		return PageElements.getTxt_statewithholding().getAttribute("value").contains(StateWithholding);
	}
	
	public boolean checkFinalAmount(String FinalAmount) {
		return PageElements.getTxt_finalamount().getAttribute("value").contains(FinalAmount);
	}
}
