package baird.LiquidOffice.Automation.Pages;

import baird.LiquidOffice.Automation.Models.ClientServicesModel;
import baird.LiquidOffice.Automation.Resources.TestSettings;
import baird.core.Automation.CommonAPI.ICommonAPI;

/**
 * @author AmitaKumari
 */

public class ClientServicesPage extends BasePage<ClientServicesModel> {
	public ClientServicesPage(ICommonAPI commonApi, TestSettings Settings) {
		super(commonApi, Settings);
		PageElements = new ClientServicesModel(_browser);
	}

	@Override
	public void navigateTopage() {
		PageElements.init();
	}

	public void ctaClick() {
		PageElements.getLnk_cta().click();
	}

	public void ctaClickSIT() {
		PageElements.getLnk_sitcta().click();
	}
}