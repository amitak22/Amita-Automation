package baird.LiquidOffice.Automation.Resources;

import com.google.gson.GsonBuilder;
import com.google.gson.stream.JsonReader;

/**
 * @author AmitaKumari
 */

public class CTAformData extends TestArgumentBase<CTAformData> {

	public String LoginMethod;

	@Override
	public CTAformData[] getClassListfromJson(JsonReader reader) {
		return new GsonBuilder().create().fromJson(reader, CTAformData[].class);
	}

}
