package baird.LiquidOffice.Automation.BusinessLayer;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.openqa.selenium.Alert;
import org.openqa.selenium.NoAlertPresentException;

import baird.LiquidOffice.Automation.Pages.AchFormPage;
import baird.LiquidOffice.Automation.Pages.CTAPage;
import baird.LiquidOffice.Automation.Pages.CheckFormPage;
import baird.LiquidOffice.Automation.Pages.ClientServicesPage;
import baird.LiquidOffice.Automation.Pages.HomePage;
import baird.LiquidOffice.Automation.Pages.NewAttachmentPage;
import baird.LiquidOffice.Automation.Pages.ProcessFormCheckPage;
import baird.LiquidOffice.Automation.Pages.SignInPage;
import baird.LiquidOffice.Automation.Resources.TestSettings;
import baird.core.Automation.CommonAPI.ICommonAPI;

/**
 * @author AmitaKumari
 */

public class CTAachFormTestLogic extends BaseTestLogic {

	SignInPage signinPage = null;
	HomePage homePage = null;
	ClientServicesPage clientServices = null;
	CTAPage ctaPage = null;
	CheckFormPage checkPage = null;
	ProcessFormCheckPage processFormcheckPage = null;
	AchFormPage achPage = null;
	NewAttachmentPage newAttachmentPage = null;

	public CTAachFormTestLogic(ICommonAPI commonApi, TestSettings Settings) {
		super(commonApi, Settings);

		signinPage = new SignInPage(commonApi, Settings);
		homePage = new HomePage(commonApi, Settings);
		clientServices = new ClientServicesPage(commonApi, Settings);
		ctaPage = new CTAPage(commonApi, Settings);
		checkPage = new CheckFormPage(commonApi, Settings);
		processFormcheckPage = new ProcessFormCheckPage(commonApi, Settings);
		newAttachmentPage = new NewAttachmentPage(commonApi, Settings);
		achPage = new AchFormPage(commonApi, Settings);
	}

	public void NavigateToSignInPage() {
		signinPage.navigateTopage();
	}

	// Action method for login using Logo or SignIn
	public void LoginToHomePage(String LoginMethod) throws Exception {
		if (LoginMethod.contains("Logo")) {
			signinPage.signInClickLogo();
		} else if (LoginMethod.contains("SignIn")) {
			signinPage.signInClick();
		} else {
			throw new Exception("Invalid Login Method");
		}
	}

	public void LoadHomePage() {
		homePage.navigateTopage();
	}

	public void LoadClientServices() {
		clientServices.navigateTopage();
	}

	// Action method for opening CTA form in UAT
	public void OpenCTApage(String LoginMethod) throws Exception {
		NavigateToSignInPage();
		LoginToHomePage(LoginMethod);
		LoadHomePage();
		homePage.clientServicesClick();
		LoadClientServices();
		clientServices.ctaClick();
		ctaPage.navigateTopage();
	}

	// Action method for opening CTA Work Queues in UAT
	public void NavigatetoWorkQueueACH(String LoginMethod) throws Exception {
		NavigateToSignInPage();
		LoginToHomePage(LoginMethod);
		LoadHomePage();
	}

	// Action method for opening CTA form in SIT
	public void OpenCTApageSIT(String LoginMethod) throws Exception {
		NavigateToSignInPage();
		LoginToHomePage(LoginMethod);
		LoadHomePage();
		homePage.clientServicesClickSIT();
		LoadClientServices();
		clientServices.ctaClickSIT();
		ctaPage.navigateTopage();
	}

	// Action method to get Client Info
	public void GetClientInfo(String AccountNo, String Type) throws InterruptedException {
		ctaPage.enterAccNumber(AccountNo);
		Thread.sleep(2000);
		ctaPage.selectACHradiobtn();
	}

	// Action method to click on Continue button on Client Info
	public void ClickContinueOnClientInfo() throws InterruptedException {
		ctaPage.clickContinueBtn();
		achPage.navigateTopage();
	}

	public boolean VerifyErrorMessageWithInvalidAccount(String errorText) {
		if (ctaPage.getInvalidCharErrorMessage().contains(errorText)) {
			return true;
		} else
			return false;
	}

	public boolean VerifyRetrievedClientTitle() {
		if (achPage.getRetrievedClientTitle().toLowerCase().contains("retrieved client information")) {
			return true;
		} else
			return false;
	}

	public boolean VerifyAccountNumber() {
		if (achPage.getAccountNumber("59127215")) {
			return true;
		} else
			return false;
	}

	public boolean VerifyIRAType() {
		if (achPage.getIRAType("Non-IRA")) {
			return true;
		} else
			return false;
	}

	public boolean VerifyClientName() {
		if (achPage.getClientName("AUTOMATIC TEST ACCT, AUTO M TESTER")) {
			return true;
		} else
			return false;
	}

	public boolean VerifyACHInstruction1() {
		achPage.selectACHInstructions();
		achPage.selectRecordTypeA();
		if (achPage.getACHInstruction1Text("ACH Instruction # 1")) {
			return true;
		} else
			return false;
	}

	public boolean VerifyACHInstructions() {
		achPage.selectACHInstructions();
		achPage.selectRecordTypeA();
		if (achPage.getBankCustomerName("AUTO TESTER") && achPage.getBankName("M&I") && achPage.getBankABA("071025661")
				&& achPage.getBankAccNumber("321456987")) {
			return true;
		} else
			return false;
	}

	public boolean VerifyClearBankInformation() throws InterruptedException {
		achPage.selectACHInstructions();
		achPage.selectRecordTypeA();
		achPage.clickBtnClearBankInfo();
		if (achPage.getACHInstruction1Text("ACH Instruction # 1")) {
			return false;
		} else
			return true;
	}

	public boolean VerifyInvalidAmount(String Amount, String errorText) {
		achPage.selectACHInstructions();
		achPage.selectRecordTypeA();
		achPage.enterAmount(Amount);
		achPage.selectAccTypeCash();
		if (achPage.getInvalidCharErrorMessage().contains(errorText)) {
			return true;
		} else
			return false;
	}

	public boolean VerifyACHIssueDateForCurrentDate() {
		achPage.selectACHInstructions();
		achPage.selectRecordTypeA();
		achPage.getIssueDate().equals(FetchCurrentDate());
		return true;
	}

	public String FetchCurrentDate() {
		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		Date date = new Date();
		String currentDate = dateFormat.format(date);
		return currentDate;
	}

	public boolean VerifyACHIssueDateForFutureDate(String FutureDate) {
		achPage.selectACHInstructions();
		achPage.selectRecordTypeA();
		achPage.clickIssueDate(FutureDate);
		return true;
	}

	public void CreateACHRequestTypeA(String Amount, String Fund, String AttestorName) {
		achPage.selectACHInstructions();
		achPage.selectRecordTypeA();
		achPage.enterAmount(Amount);
		achPage.selectCashorMMF(Fund);
		achPage.selectAccTypeCash();
		achPage.selectTransferinOutOfBaird();
		achPage.selectAttestationChkbox();
		achPage.enterAttestorName(AttestorName);
		achPage.clickSubmitBtn();
		processFormcheckPage.navigateTopage();
	}

	public void SendACHRequest() throws InterruptedException {
		Thread.sleep(2000);
		processFormcheckPage.clickSendBtn();
	}

	/* Action method to verify the duplicate record pop up */

	public boolean VerifyErrorMessageForDuplicateRecord() throws InterruptedException {
		try {
			Alert a = _browser._browserDriver.switchTo().alert();
			if (a != null) {
				a.accept();
				Thread.sleep(2000);
				achPage.selectNoDuplicateChkbox();
				achPage.clickSubmitBtn();
				processFormcheckPage.navigateTopage();
				return true;
			} else
				return false;
		} catch (NoAlertPresentException e) {
			return false;
		}
	}

	public boolean VerifyWarningPopUpforACHIssueDate(String errorText) throws InterruptedException {
		achPage.selectAccTypeCash();
		if (checkPage.getErrorPopUp().contains(errorText)) {
			return true;
		} else
			return false;
	}

	public boolean VerifyExistingInstruction() throws InterruptedException {
		achPage.selectACHInstructions();
		achPage.selectRecordTypeA();
		achPage.clickResetButton();
		if (achPage.getACHInstruction1Text("")) {
			return true;
		} else
			return false;
	}

	public boolean VerifySaveFunctionality() throws InterruptedException {
		achPage.selectACHInstructions();
		achPage.selectRecordTypeA();
		achPage.clickSaveButton();
		return true;
	}

	public boolean VerifyBackButton() {
		achPage.clickBackButton();
		if (ctaPage.getClientInfotext().toLowerCase().contains("client information")) {
			return true;
		} else
			return false;
	}

	public boolean VerifyACHInstructionsField() {
		achPage.selectACHInstructions();
		achPage.selectRecordTypeA();
		if (achPage.checkBankCustomerName("AUTO TESTER") && (achPage.checkBankName("M&I"))
				&& (achPage.checkBankABA("071025661")) && (achPage.checkBankAccNumber("321456987"))) {
			return true;
		} else
			return false;
	}

	public boolean VerifyACHInstruction(String errorText) {
		achPage.clickSubmitBtn();
		if (achPage.getInvalidCharErrorMessage().contains(errorText)) {
			return true;
		} else
			return false;
	}

	public boolean VerifyWarningPopUp(String errorText) {
		if (achPage.getInvalidCharErrorMessage().contains(errorText)) {
			return true;
		} else
			return false;
	}

	public void CreateACHRequestTypeB(String Amount, String Fund, String ThirdParty, String AttestorName)
			throws InterruptedException {
		achPage.selectACHInstructions();
		achPage.selectRecordTypeBandD();
		Thread.sleep(1000);
		achPage.enterAmount(Amount);
		achPage.selectCashorMMF(Fund);
		achPage.selectAccTypeCash();
		achPage.selectTransferinOutOfBaird();
		achPage.enterThirdPartyName(ThirdParty);
		achPage.selectYesRadioBtnThirdParty();
		achPage.selectAttestationChkbox();
		achPage.enterAttestorName(AttestorName);
		achPage.clickAttachmentBtn();
		newAttachmentPage.navigateTopage();
		newAttachmentPage.addAttachments();
		Thread.sleep(1000);
		achPage.clickSubmitBtn();
		processFormcheckPage.navigateTopage();
	}

	public void CreateACHRequestTypeBWithoutThirdPartyRadioBtn(String Amount, String Fund, String ThirdParty,
			String AttestorName) throws InterruptedException {
		achPage.selectACHInstructions();
		achPage.selectRecordTypeBandD();
		Thread.sleep(1000);
		achPage.enterAmount(Amount);
		achPage.selectCashorMMF(Fund);
		achPage.selectAccTypeCash();
		achPage.selectTransferinOutOfBaird();
		achPage.enterThirdPartyName(ThirdParty);
		achPage.selectAttestationChkbox();
		achPage.enterAttestorName(AttestorName);
		achPage.clickAttachmentBtn();
		newAttachmentPage.navigateTopage();
		newAttachmentPage.addAttachments();
		Thread.sleep(1000);
		achPage.clickSubmitBtn();
		processFormcheckPage.navigateTopage();
	}

	public void CreateACHRequestTypeD(String Amount, String Fund, String ThirdParty, String AttestorName)
			throws InterruptedException {
		achPage.selectACHInstructions();
		achPage.selectRecordTypeBandD();
		Thread.sleep(1000);
		achPage.enterAmount(Amount);
		achPage.selectCashorMMF(Fund);
		achPage.selectAccTypeCash();
		achPage.selectTransferinOutOfBaird();
		achPage.enterThirdPartyName(ThirdParty);
		achPage.selectYesRadioBtnThirdParty();
		achPage.selectAttestationChkbox();
		achPage.enterAttestorName(AttestorName);
		achPage.clickAttachmentBtn();
		newAttachmentPage.navigateTopage();
		newAttachmentPage.addAttachments();
		Thread.sleep(1000);
		achPage.selectNoRadioBtnAdvisoryAcc();
		achPage.clickSubmitBtn();
		processFormcheckPage.navigateTopage();
	}

	public void CreateACHRequestTypeAusingMMF(String Amount, String Fund, String AttestorName)
			throws InterruptedException {
		achPage.selectACHInstructions();
		achPage.selectRecordTypeA();
		Thread.sleep(1000);
		achPage.enterAmount(Amount);
		achPage.selectCashorMMF(Fund);
		achPage.selectAccTypeCash();
		achPage.selectTransferinOutOfBaird();
		achPage.selectAttestationChkbox();
		achPage.enterAttestorName(AttestorName);
		achPage.selectNoRadioBtnAdvisoryAcc();
		achPage.clickSubmitBtn();
		processFormcheckPage.navigateTopage();
	}

	public boolean VerifyWarningPopUpforMargin(String Fund, String errorText) throws InterruptedException {
		achPage.selectACHInstructions();
		achPage.selectRecordTypeA();
		achPage.selectCashorMMF(Fund);
		achPage.selectAccTypeMargin();
		if (checkPage.getErrorPopUp().contains(errorText)) {
			return true;
		} else
			return false;
	}

	public boolean VerifyCashAutoPopulatesForMargin() {
		_browser._browserDriver.switchTo().alert().accept();
		if (achPage.getCashorMMF().toLowerCase().contains("cash")) {
			return true;
		} else
			return false;
	}

	public void VerifyWarningPopUpforNoAccount(String Amount, String Fund) {
		achPage.selectACHInstructions();
		achPage.selectRecordTypeA();
		achPage.enterAmount(Amount);
		achPage.selectCashorMMF(Fund);
		achPage.clickSubmitBtn();
	}

	public void VerifyWarningPopUpforIntoBairdSelection() {
		achPage.selectACHInstructions();
		achPage.selectRecordTypeA();
		achPage.selectTransferinIntoBaird();
	}

	public void VerifyWarningPopUpforNoAdvisoryAccountSelection() {
		achPage.selectACHInstructions();
		achPage.selectRecordTypeA();
		achPage.selectTransferinOutOfBaird();
		achPage.clickSubmitBtn();
	}

	public void VerifyWarningPopUpforYesRadionBtnAdvisoryAccount() {
		achPage.selectACHInstructions();
		achPage.selectRecordTypeA();
		achPage.selectTransferinOutOfBaird();
		achPage.selectYesRadioBtnAdvisoryAcc();
	}

	public void VerifyWarningPopUpWithoutAdvisoryAccount(String Amount, String Fund, String AttestorName) {
		achPage.selectACHInstructions();
		achPage.selectRecordTypeA();
		achPage.enterAmount(Amount);
		achPage.selectCashorMMF(Fund);
		achPage.selectAccTypeCash();
		achPage.selectTransferinOutOfBaird();
		achPage.selectAttestationChkbox();
		achPage.enterAttestorName(AttestorName);
		achPage.clickSubmitBtn();
	}

	public void CreateACHRequestTypeAwithSLOA(String Amount, String Fund, String SLOA, String AttestorName)
			throws InterruptedException {
		achPage.selectACHInstructions();
		achPage.selectRecordTypeA();
		Thread.sleep(1000);
		achPage.enterAmount(Amount);
		achPage.selectCashorMMF(Fund);
		achPage.selectAccTypeCash();
		achPage.selectTransferinOutOfBaird();
		achPage.selectStandingInstruction(SLOA);
		achPage.selectAttestationChkbox();
		achPage.enterAttestorName(AttestorName);
		achPage.clickSubmitBtn();
		processFormcheckPage.navigateTopage();
	}

	public void VerifyCancelBtnOnACHProcess() {
		processFormcheckPage.clickCancelBtn();
	}

	public void VerifyBackBtnOnACHProcess() throws InterruptedException {
		processFormcheckPage.clickBackBtn();
		Thread.sleep(2000);
	}

	public void CreateACHRequestTypeAMargin(String Amount, String Fund, String AttestorName)
			throws InterruptedException {
		achPage.selectACHInstructions();
		achPage.selectRecordTypeA();
		Thread.sleep(1000);
		achPage.enterAmount(Amount);
		achPage.selectCashorMMF(Fund);
		achPage.selectAccTypeMargin();
		achPage.selectTransferinOutOfBaird();
		achPage.selectAttestationChkbox();
		achPage.enterAttestorName(AttestorName);
		achPage.clickSubmitBtn();
		processFormcheckPage.navigateTopage();
	}

	public void CreateACHRequestTypeDWithoutAttachment(String Amount, String Fund, String ThirdParty,
			String AttestorName) throws InterruptedException {
		achPage.selectACHInstructions();
		achPage.selectRecordTypeBandD();
		Thread.sleep(1000);
		achPage.enterAmount(Amount);
		achPage.selectCashorMMF(Fund);
		achPage.selectAccTypeCash();
		achPage.selectTransferinOutOfBaird();
		achPage.enterThirdPartyName(ThirdParty);
		achPage.selectYesRadioBtnThirdParty();
		achPage.selectAttestationChkbox();
		achPage.enterAttestorName(AttestorName);
		achPage.selectNoRadioBtnAdvisoryAcc();
		achPage.clickSubmitBtn();
		processFormcheckPage.navigateTopage();
	}

	public void CreateACHRequestTypeBWithoutAttachment(String Amount, String Fund, String ThirdParty,
			String AttestorName) throws InterruptedException {
		achPage.selectACHInstructions();
		achPage.selectRecordTypeBandD();
		Thread.sleep(1000);
		achPage.enterAmount(Amount);
		achPage.selectCashorMMF(Fund);
		achPage.selectAccTypeCash();
		achPage.selectTransferinOutOfBaird();
		achPage.enterThirdPartyName(ThirdParty);
		achPage.selectYesRadioBtnThirdParty();
		achPage.selectAttestationChkbox();
		achPage.enterAttestorName(AttestorName);
		achPage.clickSubmitBtn();
		processFormcheckPage.navigateTopage();
	}

	public void CreateACHRequestTypeAwithIntoBaird(String Amount, String Fund, String Description)
			throws InterruptedException {
		achPage.selectACHInstructions();
		achPage.selectRecordTypeA();
		Thread.sleep(1000);
		achPage.enterAmount(Amount);
		achPage.selectCashorMMF(Fund);
		achPage.selectAccTypeCash();
		achPage.selectTransferinIntoBaird();
		_browser._browserDriver.switchTo().alert().accept();
		achPage.selectDescriptionDeposit(Description);
		achPage.clickSubmitBtn();
		processFormcheckPage.navigateTopage();
	}

	public void CreateACHRequestTypeDwithIntoBaird(String Amount, String Fund, String ThirdParty, String Description)
			throws InterruptedException {
		achPage.selectACHInstructions();
		achPage.selectRecordTypeBandD();
		Thread.sleep(1000);
		achPage.enterAmount(Amount);
		achPage.selectCashorMMF(Fund);
		achPage.selectAccTypeCash();
		achPage.selectTransferinIntoBaird();
		_browser._browserDriver.switchTo().alert().accept();
		achPage.enterThirdPartyName(ThirdParty);
		achPage.selectYesRadioBtnThirdParty();
		achPage.selectDescriptionDeposit(Description);
		achPage.clickAttachmentBtn();
		newAttachmentPage.navigateTopage();
		newAttachmentPage.addAttachments();
		Thread.sleep(1000);
		achPage.clickSubmitBtn();
		processFormcheckPage.navigateTopage();
	}

	public void CreateACHRequestTypeBwithIntoBaird(String Amount, String Fund, String ThirdParty)
			throws InterruptedException {
		achPage.selectACHInstructions();
		achPage.selectRecordTypeBandD();
		Thread.sleep(1000);
		achPage.enterAmount(Amount);
		achPage.selectCashorMMF(Fund);
		achPage.selectAccTypeCash();
		achPage.selectTransferinIntoBaird();
		_browser._browserDriver.switchTo().alert().accept();
		achPage.enterThirdPartyName(ThirdParty);
		achPage.selectYesRadioBtnThirdParty();
		achPage.clickAttachmentBtn();
		newAttachmentPage.navigateTopage();
		newAttachmentPage.addAttachments();
		Thread.sleep(1000);
		achPage.clickSubmitBtn();
		processFormcheckPage.navigateTopage();
	}

	// ACH IRA methods

	public boolean VerifyAccountNoClientName() {
		if (achPage.getAccountNumber("86997083")
				&& achPage.getClientName("AUTOMATIC TEST ACCT, FBO AUTO M TESTER IRA")) {
			return true;
		} else
			return false;
	}

	public boolean VerifyACHInstructionsFields() {
		achPage.selectACHInstructions();
		achPage.selectIRARecordTypeB();
		if (achPage.checkBankCustomerName("TEST CLIENT") && (achPage.checkBankName("TEST BANK"))
				&& (achPage.checkBankABA("071025661")) && (achPage.checkBankAccNumber("234589"))) {
			return true;
		} else
			return false;
	}

	public boolean VerifyWithholdingInformationTitle() {
		if (achPage.getWithholdingInfoTitle("Withholding Information")) {
			return true;
		} else
			return false;
	}

	public boolean VerifyWarningPopUpFederalTax(String errorText) throws InterruptedException {
		achPage.selectACHInstructions();
		achPage.selectIRARecordTypeA();
		achPage.enterFederalTax("9");
		achPage.selectTransferinOutOfBaird();
		if (achPage.getInvalidCharErrorMessage().contains(errorText)) {
			return true;
		} else
			return false;
	}

	public boolean VerifyFinalAmountWithStateTax() throws InterruptedException {
		achPage.selectACHInstructions();
		achPage.selectIRARecordTypeA();
		Thread.sleep(2000);
		achPage.enterAmount("4");
		achPage.enterStateTax("7");
		if (achPage.checkFinalAmount("$3.72")) {
			return true;
		} else
			return false;
	}

	public boolean VerifyFinalAmountWithStateandFederalTax() throws InterruptedException {
		achPage.selectACHInstructions();
		achPage.selectIRARecordTypeA();
		Thread.sleep(2000);
		achPage.enterAmount("4");
		achPage.enterFederalTax("11");
		achPage.enterStateTax("7");
		if (achPage.checkFinalAmount("$3.28")) {
			return true;
		} else
			return false;
	}

	public boolean VerifyFedWithholding() throws InterruptedException {
		achPage.selectACHInstructions();
		achPage.selectIRARecordTypeA();
		Thread.sleep(2000);
		achPage.enterAmount("4");
		achPage.selectTransferinOutOfBaird();
		achPage.selectDistRecord();
		if (achPage.achFedWithholding("0")) {
			return true;
		} else
			return false;
	}

	public boolean VerifyStateWithholding() throws InterruptedException {
		achPage.selectACHInstructions();
		achPage.selectIRARecordTypeA();
		Thread.sleep(2000);
		achPage.enterAmount("4");
		achPage.selectTransferinOutOfBaird();
		achPage.selectDistRecord();
		Thread.sleep(1000);
		if (achPage.achStateWithholding("0")) {
			return true;
		} else
			return false;
	}

	public boolean VerifyRequestedAmountWithholding() throws InterruptedException {
		achPage.selectACHInstructions();
		achPage.selectIRARecordTypeA();
		Thread.sleep(2000);
		achPage.enterAmount("4");
		if (achPage.requestedAmount("$4.00")) {
			return true;
		} else
			return false;
	}

	public void CreateACHIRARequestTypeA(String Amount, String FederalTax, String StateTax, String DistributionType,
			String AttestorName) throws InterruptedException {
		achPage.selectACHInstructions();
		achPage.selectIRARecordTypeA();
		Thread.sleep(2000);
		achPage.enterAmount(Amount);
		achPage.selectTransferinOutOfBaird();
		achPage.enterFederalTax(FederalTax);
		achPage.enterStateTax(StateTax);
		achPage.clickDistributionTypeDrpdwn(DistributionType);
		achPage.selectAttestationChkbox();
		achPage.enterAttestorName(AttestorName);
		achPage.clickSubmitBtn();
		processFormcheckPage.navigateTopage();
	}

	public void CreateIRAACHRequestTypeB(String Amount, String FederalTax, String StateTax, String DistributionType,
			String AttestorName, String ThirdParty) throws InterruptedException {
		achPage.selectACHInstructions();
		achPage.selectIRARecordTypeB();
		Thread.sleep(2000);
		achPage.enterAmount(Amount);
		achPage.selectTransferinOutOfBaird();
		achPage.enterFederalTax(FederalTax);
		achPage.enterStateTax(StateTax);
		achPage.clickDistributionTypeDrpdwn(DistributionType);
		achPage.selectAttestationChkbox();
		achPage.enterAttestorName(AttestorName);
		achPage.enterThirdPartyName(ThirdParty);
		achPage.selectYesRadioBtnThirdParty();
		achPage.clickAttachmentBtn();
		newAttachmentPage.navigateTopage();
		newAttachmentPage.addAttachments();
		Thread.sleep(1000);
		achPage.clickSubmitBtn();
		processFormcheckPage.navigateTopage();
	}

	public boolean VerifyReqAmount() throws InterruptedException {
		if (achPage.checkReqAmount("$4.00")) {
			return true;
		} else
			return false;
	}

	public boolean VerifyDistributionType() throws InterruptedException {
		if (achPage.checkDistributionType("REG")) {
			return true;
		} else
			return false;
	}

	public boolean VerifyDistributionTypeWithAttachment(String Amount, String FederalTax, String StateTax,
			String DistributionType, String AttestorName, String ThirdParty) throws InterruptedException {
		achPage.selectACHInstructions();
		achPage.selectIRARecordTypeB();
		Thread.sleep(2000);
		achPage.enterAmount(Amount);
		achPage.selectTransferinOutOfBaird();
		achPage.enterFederalTax(FederalTax);
		achPage.enterStateTax(StateTax);
		achPage.clickDistributionTypeDrpdwn(DistributionType);
		achPage.selectAttestationChkbox();
		achPage.enterAttestorName(AttestorName);
		achPage.enterThirdPartyName(ThirdParty);
		achPage.selectYesRadioBtnThirdParty();
		achPage.clickAttachmentBtn();
		newAttachmentPage.navigateTopage();
		newAttachmentPage.addAttachments();
		Thread.sleep(1000);
		if (achPage.checkDistributionType("REG")) {
			return true;
		} else
			return false;
	}

	public void CreateACHIRARequestTypeD(String Amount, String FederalTax, String StateTax, String DistributionType,
			String AttestorName, String ThirdParty) throws InterruptedException {
		achPage.selectACHInstructions();
		achPage.selectIRARecordTypeD();
		Thread.sleep(2000);
		achPage.enterAmount(Amount);
		achPage.selectTransferinOutOfBaird();
		achPage.enterFederalTax(FederalTax);
		achPage.enterStateTax(StateTax);
		achPage.clickDistributionTypeDrpdwn(DistributionType);
		achPage.selectAttestationChkbox();
		achPage.enterAttestorName(AttestorName);
		achPage.enterThirdPartyName(ThirdParty);
		achPage.selectYesRadioBtnThirdParty();
		achPage.clickAttachmentBtn();
		newAttachmentPage.navigateTopage();
		newAttachmentPage.addAttachments();
		Thread.sleep(1000);
		achPage.clickSubmitBtn();
		processFormcheckPage.navigateTopage();
	}

	public boolean VerifyRequestedAmount() throws InterruptedException {
		achPage.selectACHInstructions();
		achPage.selectIRARecordTypeA();
		Thread.sleep(2000);
		achPage.enterReqAmountWithholding("4");
		if (achPage.checkReqAmount("$4.00")) {
			return true;
		} else
			return false;
	}

	public boolean VerifyWarningPopUpforYesRadionBtnAdvisoryAccountIRA(String errorText) throws InterruptedException {
		achPage.selectACHInstructions();
		achPage.selectIRARecordTypeA();
		Thread.sleep(2000);
		achPage.selectTransferinOutOfBaird();
		achPage.selectYesRadioBtnAdvisoryAcc();
		if (achPage.getInvalidCharErrorMessage().contains(errorText)) {
			return true;
		} else
			return false;
	}

	public void CreateACHIRARequestAdvisoryAccTypeA(String Amount, String SLOA, String FederalTax, String StateTax,
			String DistributionType, String AttestorName) throws InterruptedException {
		achPage.selectACHInstructions();
		achPage.selectIRARecordTypeA();
		Thread.sleep(2000);
		achPage.enterAmount(Amount);
		achPage.selectTransferinOutOfBaird();
		achPage.selectStandingInstruction(SLOA);
		achPage.enterFederalTax(FederalTax);
		achPage.enterStateTax(StateTax);
		achPage.clickDistributionTypeDrpdwn(DistributionType);
		achPage.selectAttestationChkbox();
		achPage.enterAttestorName(AttestorName);
		achPage.selectYesRadioBtnAdvisoryAcc();
		_browser._browserDriver.switchTo().alert().accept();
		achPage.clickSubmitBtn();
		processFormcheckPage.navigateTopage();
	}

	public void CreateACHIRARequestAdvisoryAccTypeB(String Amount, String FederalTax, String StateTax,
			String DistributionType, String AttestorName, String ThirdParty) throws InterruptedException {
		achPage.selectACHInstructions();
		achPage.selectIRARecordTypeB();
		Thread.sleep(2000);
		achPage.enterAmount(Amount);
		achPage.selectTransferinOutOfBaird();
		achPage.enterFederalTax(FederalTax);
		achPage.enterStateTax(StateTax);
		achPage.clickDistributionTypeDrpdwn(DistributionType);
		achPage.selectAttestationChkbox();
		achPage.enterAttestorName(AttestorName);
		achPage.enterThirdPartyName(ThirdParty);
		achPage.selectYesRadioBtnThirdParty();
		achPage.clickAttachmentBtn();
		newAttachmentPage.navigateTopage();
		newAttachmentPage.addAttachments();
		Thread.sleep(1000);
		achPage.selectYesRadioBtnAdvisoryAcc();
		_browser._browserDriver.switchTo().alert().accept();
		achPage.clickSubmitBtn();
		processFormcheckPage.navigateTopage();
	}

	public void CreateACHIRARequestAdvisoryAccTypeD(String Amount, String FederalTax, String StateTax,
			String DistributionType, String AttestorName, String ThirdParty) throws InterruptedException {
		achPage.selectACHInstructions();
		achPage.selectIRARecordTypeB();
		Thread.sleep(2000);
		achPage.enterAmount(Amount);
		achPage.selectTransferinOutOfBaird();
		achPage.enterFederalTax(FederalTax);
		achPage.enterStateTax(StateTax);
		achPage.clickDistributionTypeDrpdwn(DistributionType);
		achPage.selectAttestationChkbox();
		achPage.enterAttestorName(AttestorName);
		achPage.enterThirdPartyName(ThirdParty);
		achPage.selectYesRadioBtnThirdParty();
		achPage.clickAttachmentBtn();
		newAttachmentPage.navigateTopage();
		newAttachmentPage.addAttachments();
		Thread.sleep(1000);
		achPage.selectYesRadioBtnAdvisoryAcc();
		_browser._browserDriver.switchTo().alert().accept();
		achPage.clickSubmitBtn();
		processFormcheckPage.navigateTopage();
	}

	public boolean VerifyIntoBairdSelection(String ContributionType) {
		achPage.selectACHInstructions();
		achPage.selectIRARecordTypeA();
		achPage.selectTransferinIntoBaird();
		_browser._browserDriver.switchTo().alert().accept();
		achPage.clickContributionTypeDrpdwn(ContributionType);
		return true;
	}

	public void CreateACHRequestTypeAwithIntoBairdIRA(String Amount, String ContributionType, String AttestorName)
			throws InterruptedException {
		achPage.selectACHInstructions();
		achPage.selectIRARecordTypeA();
		Thread.sleep(2000);
		achPage.enterAmount(Amount);
		achPage.selectTransferinIntoBaird();
		_browser._browserDriver.switchTo().alert().accept();
		achPage.clickContributionTypeDrpdwn(ContributionType);
		achPage.clickSubmitBtn();
		processFormcheckPage.navigateTopage();
	}

	public void VerifyWarningPopUpForInvalidFederalTax(String Amount, String FederalTax) throws InterruptedException {
		achPage.selectACHInstructions();
		achPage.selectIRARecordTypeB();
		Thread.sleep(1000);
		achPage.enterAmount(Amount);
		achPage.selectTransferinOutOfBaird();
		achPage.enterFederalTax(FederalTax);
		achPage.selectYesRadioBtnAdvisoryAcc();
	}

	public void VerifyWarningPopUpForInvalidStateTax(String Amount, String FederalTax, String StateTax)
			throws InterruptedException {
		achPage.selectACHInstructions();
		achPage.selectIRARecordTypeB();
		Thread.sleep(1000);
		achPage.enterAmount(Amount);
		achPage.selectTransferinOutOfBaird();
		achPage.enterFederalTax(FederalTax);
		achPage.enterStateTax(StateTax);
		achPage.selectYesRadioBtnAdvisoryAcc();
	}

	public void CreateACHIRARequestTypeBWithoutAttachment(String Amount, String FederalTax, String StateTax,
			String DistributionType, String AttestorName, String ThirdParty) throws InterruptedException {
		achPage.selectACHInstructions();
		achPage.selectIRARecordTypeB();
		Thread.sleep(2000);
		achPage.enterAmount(Amount);
		achPage.selectTransferinOutOfBaird();
		achPage.enterFederalTax(FederalTax);
		achPage.enterStateTax(StateTax);
		achPage.clickDistributionTypeDrpdwn(DistributionType);
		achPage.selectAttestationChkbox();
		achPage.enterAttestorName(AttestorName);
		achPage.enterThirdPartyName(ThirdParty);
		achPage.selectYesRadioBtnThirdParty();
		achPage.selectYesRadioBtnAdvisoryAcc();
		_browser._browserDriver.switchTo().alert().accept();
		achPage.clickSubmitBtn();
	}

	public boolean VerifyIRATypeField() {
		if (achPage.getIRAType("IRA")) {
			return true;
		} else
			return false;
	}

	public void CreateDistRecordTypeA(String Amount, String AttestorName) throws InterruptedException {
		achPage.selectACHInstructions();
		achPage.selectIRARecordTypeA();
		Thread.sleep(2000);
		achPage.enterAmount(Amount);
		achPage.selectTransferinOutOfBaird();
		achPage.selectAttestationChkbox();
		achPage.enterAttestorName(AttestorName);
		achPage.selectDistRecord();
		achPage.clickSubmitBtn();
		processFormcheckPage.navigateTopage();
	}

	public void CreateDistRecordTypeB(String Amount, String AttestorName, String ThirdParty)
			throws InterruptedException {
		achPage.selectACHInstructions();
		achPage.selectIRARecordTypeB();
		Thread.sleep(2000);
		achPage.enterAmount(Amount);
		achPage.selectTransferinOutOfBaird();
		achPage.selectAttestationChkbox();
		achPage.enterAttestorName(AttestorName);
		achPage.selectDistRecord();
		achPage.enterThirdPartyName(ThirdParty);
		achPage.selectYesRadioBtnThirdParty();
		achPage.clickAttachmentBtn();
		newAttachmentPage.navigateTopage();
		newAttachmentPage.addAttachments();
		Thread.sleep(1000);
		achPage.clickSubmitBtn();
		processFormcheckPage.navigateTopage();
	}

	public void CreateDistRecordTypeC(String Amount, String AttestorName, String ThirdParty)
			throws InterruptedException {
		achPage.selectACHInstructions();
		achPage.selectIRARecordTypeC();
		Thread.sleep(2000);
		achPage.enterAmount(Amount);
		achPage.selectTransferinOutOfBaird();
		achPage.selectAttestationChkbox();
		achPage.enterAttestorName(AttestorName);
		achPage.selectDistRecord();
		achPage.enterThirdPartyName(ThirdParty);
		achPage.selectYesRadioBtnThirdParty();
		achPage.clickAttachmentBtn();
		newAttachmentPage.navigateTopage();
		newAttachmentPage.addAttachments();
		Thread.sleep(1000);
		achPage.clickSubmitBtn();
		processFormcheckPage.navigateTopage();
	}

	public void CreateDistRecordTypeD(String Amount, String AttestorName, String ThirdParty)
			throws InterruptedException {
		achPage.selectACHInstructions();
		achPage.selectIRARecordTypeD();
		Thread.sleep(2000);
		achPage.enterAmount(Amount);
		achPage.selectTransferinOutOfBaird();
		achPage.selectAttestationChkbox();
		achPage.enterAttestorName(AttestorName);
		achPage.selectDistRecord();
		achPage.enterThirdPartyName(ThirdParty);
		achPage.selectYesRadioBtnThirdParty();
		achPage.clickAttachmentBtn();
		newAttachmentPage.navigateTopage();
		newAttachmentPage.addAttachments();
		Thread.sleep(1000);
		achPage.clickSubmitBtn();
		processFormcheckPage.navigateTopage();
	}

	public void CreateDistRecordTypeE(String Amount, String AttestorName, String ThirdParty)
			throws InterruptedException {
		achPage.selectACHInstructions();
		achPage.selectIRARecordTypeE();
		Thread.sleep(2000);
		achPage.enterAmount(Amount);
		achPage.selectTransferinOutOfBaird();
		achPage.selectAttestationChkbox();
		achPage.enterAttestorName(AttestorName);
		achPage.selectDistRecord();
		achPage.enterThirdPartyName(ThirdParty);
		achPage.selectYesRadioBtnThirdParty();
		achPage.clickAttachmentBtn();
		newAttachmentPage.navigateTopage();
		newAttachmentPage.addAttachments();
		Thread.sleep(1000);
		achPage.clickSubmitBtn();
		processFormcheckPage.navigateTopage();
	}

	public void CreateDistRecordTypeF(String Amount, String AttestorName, String ThirdParty)
			throws InterruptedException {
		achPage.selectACHInstructions();
		achPage.selectIRARecordTypeF();
		Thread.sleep(2000);
		achPage.enterAmount(Amount);
		achPage.selectTransferinOutOfBaird();
		achPage.selectAttestationChkbox();
		achPage.enterAttestorName(AttestorName);
		achPage.selectDistRecord();
		achPage.enterThirdPartyName(ThirdParty);
		achPage.selectYesRadioBtnThirdParty();
		achPage.clickAttachmentBtn();
		newAttachmentPage.navigateTopage();
		newAttachmentPage.addAttachments();
		Thread.sleep(1000);
		achPage.clickSubmitBtn();
		processFormcheckPage.navigateTopage();
	}

	public void CreateDistRecordTypeG(String Amount, String AttestorName, String ThirdParty)
			throws InterruptedException {
		achPage.selectACHInstructions();
		achPage.selectIRARecordTypeG();
		Thread.sleep(2000);
		achPage.enterAmount(Amount);
		achPage.selectTransferinOutOfBaird();
		achPage.selectAttestationChkbox();
		achPage.enterAttestorName(AttestorName);
		achPage.selectDistRecord();
		achPage.clickAttachmentBtn();
		newAttachmentPage.navigateTopage();
		newAttachmentPage.addAttachments();
		Thread.sleep(1000);
		achPage.clickSubmitBtn();
		processFormcheckPage.navigateTopage();
	}

	public void CreateDistRecordTypeBwithTax(String Amount, String AttestorName, String ThirdParty)
			throws InterruptedException {
		achPage.selectACHInstructions();
		achPage.selectIRARecordTypeB();
		Thread.sleep(2000);
		achPage.enterAmount(Amount);
		achPage.selectTransferinOutOfBaird();
		achPage.selectAttestationChkbox();
		achPage.enterAttestorName(AttestorName);
		achPage.selectDistRecord();
		achPage.enterThirdPartyName(ThirdParty);
		achPage.selectYesRadioBtnThirdParty();
		achPage.selectNoRadioBtnAdvisoryAcc();
		Thread.sleep(1000);
		achPage.clickSubmitBtn();
		processFormcheckPage.navigateTopage();
	}

	public void CreateDistRecordTypeAwithTax(String Amount, String AttestorName) throws InterruptedException {
		achPage.selectACHInstructions();
		achPage.selectIRARecordTypeA();
		Thread.sleep(2000);
		achPage.enterAmount(Amount);
		achPage.selectTransferinOutOfBaird();
		achPage.selectAttestationChkbox();
		achPage.enterAttestorName(AttestorName);
		achPage.selectDistRecordTypeAwithTax();
		achPage.selectNoRadioBtnAdvisoryAcc();
		achPage.clickSubmitBtn();
		processFormcheckPage.navigateTopage();
	}

	public void ApproveClientServicesACHqueueProcess() throws InterruptedException {
		achPage.clickWorkQueuesTab();
		achPage.clickClientServicesACH();
		achPage.sortReceivedColoumn();
		achPage.openLatestACHprocess();
		processFormcheckPage.navigateTopage();
		achPage.closeDialbox();
		achPage.clickGoBtn();
		processFormcheckPage.navigateTopage();
		SendACHRequest();
		processFormcheckPage.navigateTopage();
		achPage.clickGoBtn();
	}

	public void SendToNextApprovalqueueProcess(String SendToNextApproval) throws InterruptedException {
		achPage.clickWorkQueuesTab();
		achPage.clickBPMnpaContriWithdrawal();
		achPage.sortReceivedColoumn();
		achPage.openLatestACHprocess();
		processFormcheckPage.navigateTopage();
		achPage.selectSendToNextApproval(SendToNextApproval);
		achPage.clickGoBtn();
		processFormcheckPage.navigateTopage();
		SendACHRequest();
	}

	public void ApproveClientServicesACHqueueWithMMFProcess(String Fund) throws InterruptedException {
		achPage.clickWorkQueuesTab();
		achPage.clickClientServicesACH();
		achPage.sortReceivedColoumn();
		achPage.openLatestACHprocess();
		processFormcheckPage.navigateTopage();
		Thread.sleep(1000);
		achPage.selectCashorMMF(Fund);
		achPage.clickGoBtn();
		processFormcheckPage.navigateTopage();
		SendACHRequest();
	}

	public void RejectClientServicesACHqueueProcess(String Reject) throws Exception {
		achPage.clickWorkQueuesTab();
		achPage.clickClientServicesACH();
		achPage.sortReceivedColoumn();
		achPage.openLatestACHprocess();
		processFormcheckPage.navigateTopage();
		Thread.sleep(4000);
		achPage.closeDialbox();
		Thread.sleep(2000);
		achPage.selectSendToNextApproval(Reject);
		achPage.clickGoBtn();
		processFormcheckPage.navigateTopage();
		achPage.selectRejectreason();
		achPage.clickAddBtn();
		achPage.clickContinueBtn();
		NavigatetoWorkQueueACH("SignIn");
		achPage.clickInboxTab();
		achPage.openLatestRejectedProcess();
		processFormcheckPage.navigateTopage();
	}

	public boolean VerifyReqAmountRejectedProcess() throws InterruptedException {
		if (achPage.checkReqAmount("1.47")) {
			return true;
		} else
			return false;
	}

	public void SendToDelayqueueProcess() throws InterruptedException {
		achPage.clickWorkQueuesTab();
		achPage.clickBPMnpaContriWithdrawal();
		achPage.sortReceivedColoumn();
		achPage.openLatestACHprocess();
		processFormcheckPage.navigateTopage();
		// achPage.selectSendToNextApproval(SendToNextApproval);
		achPage.clickGoBtn();
		processFormcheckPage.navigateTopage();
		// SendACHRequest();
	}

}
