package baird.LiquidOffice.Automation.Models;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import baird.core.Automation.WebDrivers.Browser;
import baird.core.Automation.WebDrivers.Elements.HtmlElementImpl;

/**
 * @author AmitaKumari
 */

public class NewAttachmentModel extends BaseModel {

	public NewAttachmentModel(Browser obj) {
		super(obj);
	}

	@FindBy(id = "btnAdd")
	WebElement btn_add;

	@FindBy(id = "btnFinish")
	WebElement btn_finish;

	public HtmlElementImpl getBtn_add() {
		return new HtmlElementImpl(btn_add);
	}

	public HtmlElementImpl getBtn_finish() {
		return new HtmlElementImpl(btn_finish);
	}
}
