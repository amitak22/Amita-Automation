package baird.LiquidOffice.Automation.BusinessLayer;

import baird.LiquidOffice.Automation.Resources.TestSettings;
import baird.core.Automation.CommonAPI.ICommonAPI;
import baird.core.Automation.WebDrivers.Browser;

/**
 * @author AmitaKumari
 */

public abstract class BaseTestLogic {
	public ICommonAPI CommonApi = null;
	Browser _browser = null;
	public TestSettings testSettings = null;

	public BaseTestLogic(ICommonAPI commonApi, TestSettings Settings) {
		CommonApi = commonApi;
		testSettings = Settings;
		_browser = CommonApi.getBrowser();
	}

}
