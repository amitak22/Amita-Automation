package baird.LiquidOffice.Automation.BusinessLayer;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.openqa.selenium.Alert;
import org.openqa.selenium.NoAlertPresentException;

import baird.LiquidOffice.Automation.Pages.CTAPage;
import baird.LiquidOffice.Automation.Pages.CheckFormPage;
import baird.LiquidOffice.Automation.Pages.ClientServicesPage;
import baird.LiquidOffice.Automation.Pages.HomePage;
import baird.LiquidOffice.Automation.Pages.NewAttachmentPage;
import baird.LiquidOffice.Automation.Pages.ProcessFormCheckPage;
import baird.LiquidOffice.Automation.Pages.SignInPage;
import baird.LiquidOffice.Automation.Resources.TestSettings;
import baird.core.Automation.CommonAPI.ICommonAPI;

/**
 * @author AmitaKumari
 */

public class CTAcheckFormTestLogic extends BaseTestLogic {

	SignInPage signinPage = null;
	HomePage homePage = null;
	ClientServicesPage clientServices = null;
	CTAPage ctaPage = null;
	CheckFormPage checkPage = null;
	ProcessFormCheckPage processFormcheckPage = null;
	NewAttachmentPage newAttachmentPage = null;

	public CTAcheckFormTestLogic(ICommonAPI commonApi, TestSettings Settings) {
		super(commonApi, Settings);

		signinPage = new SignInPage(commonApi, Settings);
		homePage = new HomePage(commonApi, Settings);
		clientServices = new ClientServicesPage(commonApi, Settings);
		ctaPage = new CTAPage(commonApi, Settings);
		checkPage = new CheckFormPage(commonApi, Settings);
		processFormcheckPage = new ProcessFormCheckPage(commonApi, Settings);
		newAttachmentPage = new NewAttachmentPage(commonApi, Settings);
	}

	public void NavigateToSignInPage() {
		signinPage.navigateTopage();
	}

	// Action method for login using Logo or SignIn
	public void LoginToHomePage(String LoginMethod) throws Exception {
		if (LoginMethod.contains("Logo")) {
			signinPage.signInClickLogo();
		} else if (LoginMethod.contains("SignIn")) {
			signinPage.signInClick();
		} else {
			throw new Exception("Invalid Login Method");
		}
	}

	public void LoadHomePage() {
		homePage.navigateTopage();
	}

	public void LoadClientServices() {
		clientServices.navigateTopage();
	}

	// Action method for opening CTA form (TestCase:1)
	public void OpenCTApage(String LoginMethod) throws Exception {
		NavigateToSignInPage();
		LoginToHomePage(LoginMethod);
		LoadHomePage();
		homePage.clientServicesClick();
		LoadClientServices();
		clientServices.ctaClick();
		ctaPage.navigateTopage();
	}

	// Action method for opening CTA form in SIT
	public void OpenCTApageSIT(String LoginMethod) throws Exception {
		NavigateToSignInPage();
		LoginToHomePage(LoginMethod);
		LoadHomePage();
		homePage.clientServicesClickSIT();
		LoadClientServices();
		clientServices.ctaClickSIT();
		ctaPage.navigateTopage();
	}

	// Action method to get Client Info
	public void GetClientInfo(String AccountNo, String Type) throws InterruptedException {
		ctaPage.enterAccNumber(AccountNo);
		if (Type != null && Type.contains("Check Request")) {
			Thread.sleep(2000);
			ctaPage.selectCHKradiobtn();
		}
	}

	// Action method to click on Continue button on Client Info
	public void ClickContinueOnClientInfo() throws InterruptedException {
		ctaPage.clickContinueBtn();
		checkPage.navigateTopage();
	}

	public boolean VerifyErrorMessageWithNoAccount(String errorText) {
		if (ctaPage.getUtaErrorMessage().contains(errorText)) {
			return true;
		} else
			return false;
	}

	public boolean VerifyErrorMessageWithInvalidAccount(String errorText) {
		if (ctaPage.getInvalidCharErrorMessage().contains(errorText)) {
			return true;
		} else
			return false;
	}

	public boolean VerifyErrorMessageWithNoType(String errorText) {
		if (ctaPage.getErrorPopUp().contains(errorText)) {
			return true;
		} else
			return false;
	}

	public boolean VerifySignInSuccess() {
		if (ctaPage.getClientInfotext().toLowerCase().contains("client information")) {
			return true;
		} else
			return false;
	}

	public boolean VerifyAccountRegistration() {
		if (ctaPage.checkClientName("BERNIE BREWER") && (ctaPage.checkClientAddress("777 E WISCONSIN AVE"))) {
			return true;
		} else
			return false;
	}

	public boolean VerifyRetrievedClientTitle() {
		if (checkPage.getRetrievedClientTitle().toLowerCase().contains("retrieved client information")) {
			return true;
		} else
			return false;
	}

	public void VerifyInvalidAmount(String Amount) {
		checkPage.enterAmount(Amount);
		checkPage.selectAccTypeCash();
	}

	public boolean VerifyErrorMessageWithInvalidAmount(String errorText) {
		if (checkPage.getInvalidFormatErrorMessage().contains(errorText)) {
			return true;
		} else
			return false;
	}

	public boolean VerifyCashAmount() {
		if (checkPage.getCashorMMF().toLowerCase().contains("cash")) {
			return true;
		} else
			return false;
	}

	public boolean VerifyCashAutoPopulatesForMargin() {
		_browser._browserDriver.switchTo().alert().accept();
		if (checkPage.getCashorMMF().toLowerCase().contains("cash")) {
			return true;
		} else
			return false;
	}

	public void SelectCashorIDPfund(String Fund) {
		checkPage.clickCashorMMFDrpdwn(Fund);
	}

	public boolean VerifyWarningPopUpforMargin(String Fund, String errorText) throws InterruptedException {
		checkPage.clickCashorMMFDrpdwn(Fund);
		checkPage.selectAccTypeMargin();
		if (checkPage.getErrorPopUp().contains(errorText)) {
			return true;
		} else
			return false;
	}

	public void SelectDeliveryMethod(String DeliveryMethod) {
		checkPage.selectDeliveryMethodDrpdwn(DeliveryMethod);
	}

	public boolean VerifyDeliveryMethod() {
		checkPage.selectPrintLocMilwaukee();
		checkPage.getDeliveryMethod();
		return true;
	}

	public boolean VerifyPrintLocBranch(String PrintLoc) {
		checkPage.selectPrintLocBranch();
		checkPage.selectPrintChkbox();
		checkPage.getPrintChkboxTxt();
		checkPage.enterPrintChkbox(PrintLoc);
		return true;
	}

	public boolean VerifyPayeeInformation() throws InterruptedException {
		checkPage.clickBtnSameasAccReg();
		if (checkPage.checkPayeeName("BERNIE BREWER") && checkPage.checkPayeeCity("MILWAUKEE")
				&& checkPage.checktPayeeAddress("777 E WISCONSIN AVE") && checkPage.checkPayeeState("WI")
				&& checkPage.selectPayeeZip("53202")) {
			return true;
		} else
			return false;
	}

	public boolean VerifyClearPayeeInformation() throws InterruptedException {
		checkPage.clickBtnSameasAccReg();
		checkPage.clickBtnClearPayeeInfo();
		return checkPage.getPayeeInfoField();
	}

	public void EnterPayeeInformation(String PayeeName, String PayeeAddressLine1, String PayeeAddressLine2,
			String PayeeCity, String PayeeState, String PayeeZip) throws InterruptedException {
		checkPage.enterPayeeName(PayeeName);
		checkPage.enterPayeeAddress(PayeeAddressLine1, PayeeAddressLine2);
		checkPage.enterPayeeCity(PayeeCity);
		checkPage.enterPayeeState(PayeeState);
		checkPage.enterPayeeZip(PayeeZip);
	}

	public void SendCheckRequest() throws InterruptedException {
		Thread.sleep(3000);
		processFormcheckPage.clickSendBtn();
	}

	public void VerifyBackBtnOnCheckProcess() {
		processFormcheckPage.clickBackBtn();
	}

	public void VerifyCancelBtnOnCheckProcess() {
		processFormcheckPage.clickCancelBtn();
	}

	/* Action method to verify the duplicate record pop up */

	public boolean VerifyErrorMessageForDuplicateRecord() {
		try {
			Alert a = _browser._browserDriver.switchTo().alert();
			if (a != null) {
				a.accept();
				checkPage.selectNoDuplicateChkbox();
				checkPage.clickSubmitBtn();
				processFormcheckPage.navigateTopage();
				return true;
			} else
				return false;
		} catch (NoAlertPresentException e) {
			return false;
		}
	}

	public boolean VerifyCheckIssueDateForCurrentDate() {
		return checkPage.getIssueDate().equals(FetchCurrentDate());
	}

	public String FetchCurrentDate() {
		DateFormat dateFormat = new SimpleDateFormat("M/d/yyyy");
		Date date = new Date();
		String currentDate = dateFormat.format(date);
		return currentDate;
	}

	public boolean VerifyCheckIssueDateForFutureDate(String FutureDate) {
		checkPage.clickIssueDate(FutureDate);
		return true;
	}

	public boolean VerifyWarningPopUpforCheckIssueDate(String errorText) throws InterruptedException {
		checkPage.selectAccTypeCash();
		if (checkPage.getErrorPopUp().contains(errorText)) {
			return true;
		} else
			return false;
	}

	public void EnterAdditionalMemoLines(String MemoLines) {
		checkPage.enterMemoLines(MemoLines);
	}

	public void CreateCheckReqWithPayeeInstruction(String Amount, String Fund, String CheckPurpose, String AttestorName)
			throws InterruptedException {
		Thread.sleep(2000);
		checkPage.enterAmount(Amount);
		checkPage.selectAccTypeCash();
		checkPage.clickCashorMMFDrpdwn(Fund);
		checkPage.selectPrintLocMilwaukee();
		checkPage.clickCheckPurposeDrpdwn(CheckPurpose);
		checkPage.clickBtnSelectPayeeInstruction();
		Thread.sleep(1000);
		checkPage.selectThirdPartyInfoNo();
		checkPage.selectAdvisoryAccWithdrawalInfoNo();
		checkPage.selectAttestationChkbox();
		checkPage.enterAttestorName(AttestorName);
		checkPage.clickAttachmentBtn();
		newAttachmentPage.navigateTopage();
		newAttachmentPage.addAttachments();
		checkPage.clickAttachmentBtn();
		newAttachmentPage.navigateTopage();
		newAttachmentPage.addAttachments();
		checkPage.clickSubmitBtn();
		processFormcheckPage.navigateTopage();
	}

	public void CreateCheckRequestTypeA(String Amount, String Fund, String CheckPurpose, String AttestorName) {
		checkPage.enterAmount(Amount);
		checkPage.selectAccTypeCash();
		checkPage.clickCashorMMFDrpdwn(Fund);
		checkPage.selectPrintLocMilwaukee();
		checkPage.clickCheckPurposeDrpdwn(CheckPurpose);
		checkPage.clickBtnSameasAccReg();
		checkPage.selectAdvisoryAccWithdrawalInfoNo();
		checkPage.selectAttestationChkbox();
		checkPage.enterAttestorName(AttestorName);
		checkPage.clickSubmitBtn();
		processFormcheckPage.navigateTopage();
	}

	public void VerifyErrorPopUpforTypeD(String Amount, String Fund, String CheckPurpose, String AttestorName,
			String TypeofPayee) throws InterruptedException {
		checkPage.enterAmount(Amount);
		checkPage.selectAccTypeCash();
		checkPage.clickCashorMMFDrpdwn(Fund);
		checkPage.selectPrintLocMilwaukee();
		checkPage.clickCheckPurposeDrpdwn(CheckPurpose);
		checkPage.clickBtnSameasAccReg();
		checkPage.selectTypeofPayee(TypeofPayee);
		checkPage.selectThirdPartyInfoYes();
		checkPage.selectAdvisoryAccWithdrawalInfoNo();
		checkPage.selectAttestationChkbox();
		checkPage.enterAttestorName(AttestorName);
		checkPage.clickSubmitBtn();
	}

	public void VerifyErrorPopUpforTypeC(String Amount, String Fund, String CheckPurpose, String AttestorName,
			String TypeofPayee) throws InterruptedException {
		checkPage.enterAmount(Amount);
		checkPage.selectAccTypeCash();
		checkPage.clickCashorMMFDrpdwn(Fund);
		checkPage.selectPrintLocMilwaukee();
		checkPage.clickCheckPurposeDrpdwn(CheckPurpose);
		checkPage.clickBtnSameasAccReg();
		checkPage.selectTypeofPayee(TypeofPayee);
		checkPage.selectThirdPartyInfoYes();
		checkPage.selectAdvisoryAccWithdrawalInfoNo();
		checkPage.selectAttestationChkbox();
		checkPage.enterAttestorName(AttestorName);
		checkPage.clickSubmitBtn();
	}

	public void CreateCheckRequestTypeF3(String Amount, String Fund, String DeliveryMethod, String CheckPurpose,
			String TypeofPayee, String AttestorName) {
		checkPage.enterAmount(Amount);
		checkPage.selectAccTypeCash();
		checkPage.clickCashorMMFDrpdwn(Fund);
		checkPage.selectPrintLocBranch();
		checkPage.selectDeliveryMethodDrpdwn(DeliveryMethod);
		checkPage.clickCheckPurposeDrpdwn(CheckPurpose);
		checkPage.clickBtnSameasAccReg();
		checkPage.selectTypeofPayee(TypeofPayee);
		checkPage.selectAdvisoryAccWithdrawalInfoNo();
		checkPage.selectAttestationChkbox();
		checkPage.enterAttestorName(AttestorName);
		checkPage.clickSubmitBtn();
		processFormcheckPage.navigateTopage();
	}

	public void CreateCheckRequestTypeF2(String Amount, String Fund, String DeliveryMethod, String CheckPurpose,
			String TypeofPayee, String AttestorName) throws InterruptedException {
		checkPage.enterAmount(Amount);
		checkPage.selectAccTypeCash();
		checkPage.clickCashorMMFDrpdwn(Fund);
		checkPage.selectPrintLocBranch();
		checkPage.selectDeliveryMethodDrpdwn(DeliveryMethod);
		checkPage.clickCheckPurposeDrpdwn(CheckPurpose);
		checkPage.clickBtnSameasAccReg();
		checkPage.selectTypeofPayee(TypeofPayee);
		checkPage.selectThirdPartyInfoYes();
		checkPage.selectAdvisoryAccWithdrawalInfoNo();
		checkPage.selectAttestationChkbox();
		checkPage.enterAttestorName(AttestorName);
		checkPage.clickAttachmentBtn();
		newAttachmentPage.navigateTopage();
		newAttachmentPage.addAttachments();
		checkPage.clickSubmitBtn();
		processFormcheckPage.navigateTopage();
		Thread.sleep(1000);
	}

	public void CreateCheckRequestTypeB_C_D_E_F1(String Amount, String Fund, String CheckPurpose, String AttestorName,
			String TypeofPayee) throws InterruptedException {
		checkPage.enterAmount(Amount);
		checkPage.selectAccTypeCash();
		checkPage.clickCashorMMFDrpdwn(Fund);
		checkPage.selectPrintLocMilwaukee();
		checkPage.clickCheckPurposeDrpdwn(CheckPurpose);
		checkPage.clickBtnSameasAccReg();
		checkPage.selectTypeofPayee(TypeofPayee);
		checkPage.selectThirdPartyInfoYes();
		checkPage.selectAdvisoryAccWithdrawalInfoNo();
		checkPage.selectAttestationChkbox();
		checkPage.enterAttestorName(AttestorName);
		checkPage.clickAttachmentBtn();
		newAttachmentPage.navigateTopage();
		newAttachmentPage.addAttachments();
		checkPage.clickSubmitBtn();
		processFormcheckPage.navigateTopage();
		Thread.sleep(2000);
	}

	public void CreateCheckRequestTypeF1(String Amount, String Fund, String CheckPurpose, String AttestorName,
			String TypeofPayee) throws InterruptedException {
		checkPage.enterAmount(Amount);
		checkPage.selectAccTypeCash();
		checkPage.clickCashorMMFDrpdwn(Fund);
		checkPage.selectPrintLocMilwaukee();
		checkPage.clickCheckPurposeDrpdwn(CheckPurpose);
		checkPage.selectTypeofPayee(TypeofPayee);
		checkPage.selectThirdPartyInfoYes();
		checkPage.selectAdvisoryAccWithdrawalInfoNo();
		checkPage.selectAttestationChkbox();
		checkPage.enterAttestorName(AttestorName);
		checkPage.clickAttachmentBtn();
		newAttachmentPage.navigateTopage();
		newAttachmentPage.addAttachments();
		checkPage.clickSubmitBtn();
		processFormcheckPage.navigateTopage();
	}

	public void VerifyErrorPopUpWithoutAttestation(String Amount, String Fund, String CheckPurpose, String TypeofPayee)
			throws InterruptedException {
		checkPage.enterAmount(Amount);
		checkPage.selectAccTypeCash();
		checkPage.clickCashorMMFDrpdwn(Fund);
		checkPage.selectPrintLocMilwaukee();
		checkPage.clickCheckPurposeDrpdwn(CheckPurpose);
		checkPage.clickBtnSameasAccReg();
		checkPage.selectTypeofPayee(TypeofPayee);
		checkPage.selectAdvisoryAccWithdrawalInfoNo();
		checkPage.clickSubmitBtn();
	}

	public boolean VerifyPayeeTypeF2(String Fund, String TypeofPayee) throws InterruptedException {
		checkPage.clickCashorMMFDrpdwn(Fund);
		checkPage.selectPrintLocMilwaukee();
		checkPage.clickBtnSameasAccReg();
		checkPage.selectTypeofPayee(TypeofPayee);
		if (checkPage.getTypeofPayee("F1")) {
			return true;
		} else
			return false;
	}

	public boolean VerifyErrorMessage(String errorText) {
		if (checkPage.getInvalidFormatErrorMessage().contains(errorText)) {
			return true;
		} else
			return false;
	}

	public boolean VerifyErrorMessageforYesAdvisoryAccount(String errorText) {
		checkPage.selectAdvisoryAccWithdrawalInfoYes();
		if (checkPage.getInvalidFormatErrorMessage().contains(errorText)) {
			return true;
		} else
			return false;
	}

	public void SelectSLOA(String SLOA) {
		checkPage.selectStandingInstruction(SLOA);
	}

	public void VerifyBackButton() {
		checkPage.clickBackButton();
	}

	public boolean VerifyPayeeInformationBlankFields() throws InterruptedException {
		checkPage.clickBtnSameasAccReg();
		checkPage.clickResetButton();
		return checkPage.getPayeeInfoField();
	}

	public boolean VerifySaveFunctionality() throws InterruptedException {
		checkPage.clickBtnSameasAccReg();
		checkPage.clickSaveButton();
		checkPage.clickCloseButton();
		return true;
	}

	// Checks IRA Methods

	public boolean VerifyIRAWithholdingTitleTest() {
		if (checkPage.getIRAWithholdingTitle("IRA Distribution/Withholding Information")) {
			return true;
		} else
			return false;
	}

	public void CreateIRACheckRequestOneTimeAdvisoryAccTypeA(String Amount, String CheckPurpose, String FederalTax,
			String StateTax, String DistributionType, String PayeeName, String PayeeAddressLine1,
			String PayeeAddressLine2, String PayeeCity, String PayeeState, String PayeeZip, String TypeofPayee,
			String AttestorName) throws InterruptedException {
		checkPage.enterAmount(Amount);
		checkPage.clickCashorMMFDrpdwn("ID3");
		checkPage.selectPrintLocMilwaukee();
		checkPage.clickCheckPurposeDrpdwn(CheckPurpose);
		checkPage.selectOneTime();
		Thread.sleep(2000);
		checkPage.enterFederalTax(FederalTax);
		checkPage.enterStateTax(StateTax);
		checkPage.clickDistributionTypeDrpdwn(DistributionType);
		EnterPayeeInformation(PayeeName, PayeeAddressLine1, PayeeAddressLine2, PayeeCity, PayeeState, PayeeZip);
		checkPage.selectTypeofPayee(TypeofPayee);
		checkPage.selectAdvisoryAccWithdrawalInfoYes();
		_browser._browserDriver.switchTo().alert().accept();
		checkPage.selectAttestationChkbox();
		Thread.sleep(2000);
		checkPage.enterAttestorName(AttestorName);
		AddtwoAttachment();
		checkPage.clickSubmitBtn();
		processFormcheckPage.navigateTopage();
	}

	public void CreateIRACheckRequestOneTimeAdvisoryAccTypeB(String Amount, String CheckPurpose, String FederalTax,
			String StateTax, String DistributionType, String PayeeName, String PayeeAddressLine1,
			String PayeeAddressLine2, String PayeeCity, String PayeeState, String PayeeZip, String TypeofPayee,
			String AttestorName) throws InterruptedException {
		checkPage.enterAmount(Amount);
		checkPage.clickCashorMMFDrpdwn("ID3");
		checkPage.selectPrintLocMilwaukee();
		checkPage.clickCheckPurposeDrpdwn(CheckPurpose);
		checkPage.selectOneTime();
		Thread.sleep(2000);
		checkPage.enterFederalTax(FederalTax);
		checkPage.enterStateTax(StateTax);
		checkPage.clickDistributionTypeDrpdwn(DistributionType);
		EnterPayeeInformation(PayeeName, PayeeAddressLine1, PayeeAddressLine2, PayeeCity, PayeeState, PayeeZip);
		checkPage.selectTypeofPayee(TypeofPayee);
		checkPage.selectThirdPartyInfoNoForCheckIRA();
		checkPage.selectAdvisoryAccWithdrawalInfoYes();
		_browser._browserDriver.switchTo().alert().accept();
		checkPage.selectAttestationChkbox();
		Thread.sleep(2000);
		checkPage.enterAttestorName(AttestorName);
		AddtwoAttachment();
		checkPage.clickSubmitBtn();
		processFormcheckPage.navigateTopage();
	}

	public void CreateIRACheckRequestOneTimeTypeBCDEF(String Amount, String CheckPurpose, String FederalTax,
			String StateTax, String DistributionType, String PayeeName, String PayeeAddressLine1,
			String PayeeAddressLine2, String PayeeCity, String PayeeState, String PayeeZip, String TypeofPayee,
			String AttestorName) throws InterruptedException {
		checkPage.enterAmount(Amount);
		checkPage.selectPrintLocMilwaukee();
		checkPage.clickCheckPurposeDrpdwn(CheckPurpose);
		checkPage.selectOneTime();
		checkPage.enterFederalTax(FederalTax);
		checkPage.enterStateTax(StateTax);
		checkPage.clickDistributionTypeDrpdwn(DistributionType);
		EnterPayeeInformation(PayeeName, PayeeAddressLine1, PayeeAddressLine2, PayeeCity, PayeeState, PayeeZip);
		checkPage.selectTypeofPayee(TypeofPayee);
		checkPage.selectThirdPartyInfoNoForCheckIRA();
		checkPage.selectAttestationChkbox();
		Thread.sleep(2000);
		checkPage.enterAttestorName(AttestorName);
		AddtwoAttachment();
		checkPage.clickSubmitBtn();
		processFormcheckPage.navigateTopage();
	}

	public boolean VerifyWarningPopUpWithoutDistRecord(String Amount, String Error) throws InterruptedException {
		checkPage.enterAmount(Amount);
		checkPage.selectOnDemand();
		checkPage.clickDistRecord();
		return VerifyErrorMessage(Error);
	}

	public void CreateIRACheckRequestOnDemandTypeA(String Amount, String CheckPurpose, String FederalTax,
			String StateTax, String AttestorName) throws InterruptedException {
		checkPage.enterAmount(Amount);
		checkPage.selectPrintLocMilwaukee();
		checkPage.clickCheckPurposeDrpdwn(CheckPurpose);
		checkPage.selectOnDemand();
		checkPage.clickDistRecord();
		processFormcheckPage.navigateTopage();
		Thread.sleep(2000);
		checkPage.selectDistRecordTypeA();
		checkPage.enterFederalTax(FederalTax);
		checkPage.enterStateTax(StateTax);
		checkPage.selectAttestationChkbox();
		Thread.sleep(2000);
		checkPage.enterAttestorName(AttestorName);
		checkPage.clickSubmitBtn();
		processFormcheckPage.navigateTopage();
	}

	public void CreateIRACheckRequestOnDemandTypeB(String Amount, String CheckPurpose, String FederalTax,
			String StateTax, String PayeeName, String PayeeAddressLine1, String PayeeAddressLine2, String PayeeCity,
			String PayeeState, String PayeeZip, String AttestorName) throws InterruptedException {
		checkPage.enterAmount(Amount);
		checkPage.selectPrintLocMilwaukee();
		checkPage.clickCheckPurposeDrpdwn(CheckPurpose);
		checkPage.selectOnDemand();
		checkPage.clickDistRecord();
		processFormcheckPage.navigateTopage();
		Thread.sleep(2000);
		checkPage.selectDistRecordTypeB();
		checkPage.enterFederalTax(FederalTax);
		checkPage.enterStateTax(StateTax);
		EnterPayeeInformation(PayeeName, PayeeAddressLine1, PayeeAddressLine2, PayeeCity, PayeeState, PayeeZip);
		checkPage.selectThirdPartyInfoNoForCheckIRA();
		checkPage.selectAttestationChkbox();
		Thread.sleep(2000);
		checkPage.enterAttestorName(AttestorName);
		AddtwoAttachment();
		checkPage.clickSubmitBtn();
		processFormcheckPage.navigateTopage();
	}

	public void CreateIRACheckRequestOnDemandTypeC(String Amount, String CheckPurpose, String FederalTax,
			String StateTax, String PayeeName, String PayeeAddressLine1, String PayeeAddressLine2, String PayeeCity,
			String PayeeState, String PayeeZip, String AttestorName) throws InterruptedException {
		checkPage.enterAmount(Amount);
		checkPage.selectPrintLocMilwaukee();
		checkPage.clickCheckPurposeDrpdwn(CheckPurpose);
		checkPage.selectOnDemand();
		checkPage.clickDistRecord();
		processFormcheckPage.navigateTopage();
		Thread.sleep(2000);
		checkPage.selectDistRecordTypeC();
		checkPage.enterFederalTax(FederalTax);
		checkPage.enterStateTax(StateTax);
		EnterPayeeInformation(PayeeName, PayeeAddressLine1, PayeeAddressLine2, PayeeCity, PayeeState, PayeeZip);
		checkPage.selectThirdPartyInfoNoForCheckIRA();
		checkPage.selectAttestationChkbox();
		Thread.sleep(2000);
		checkPage.enterAttestorName(AttestorName);
		checkPage.clickAttachmentBtn();
		newAttachmentPage.navigateTopage();
		newAttachmentPage.addAttachments();
		checkPage.clickSubmitBtn();
		processFormcheckPage.navigateTopage();
	}

	public void CreateIRACheckRequestOnDemandTypeD(String Amount, String CheckPurpose, String FederalTax,
			String StateTax, String PayeeName, String PayeeAddressLine1, String PayeeAddressLine2, String PayeeCity,
			String PayeeState, String PayeeZip, String AttestorName) throws InterruptedException {
		checkPage.enterAmount(Amount);
		checkPage.selectPrintLocMilwaukee();
		checkPage.clickCheckPurposeDrpdwn(CheckPurpose);
		checkPage.selectOnDemand();
		checkPage.clickDistRecord();
		processFormcheckPage.navigateTopage();
		Thread.sleep(2000);
		checkPage.selectDistRecordTypeD();
		checkPage.enterFederalTax(FederalTax);
		checkPage.enterStateTax(StateTax);
		EnterPayeeInformation(PayeeName, PayeeAddressLine1, PayeeAddressLine2, PayeeCity, PayeeState, PayeeZip);
		checkPage.selectThirdPartyInfoNoForCheckIRA();
		checkPage.selectAttestationChkbox();
		Thread.sleep(2000);
		checkPage.enterAttestorName(AttestorName);
		checkPage.clickAttachmentBtn();
		newAttachmentPage.navigateTopage();
		newAttachmentPage.addAttachments();
		checkPage.clickSubmitBtn();
		processFormcheckPage.navigateTopage();
	}

	public void CreateIRACheckRequestOnDemandTypeE(String Amount, String CheckPurpose, String FederalTax,
			String StateTax, String PayeeName, String PayeeAddressLine1, String PayeeAddressLine2, String PayeeCity,
			String PayeeState, String PayeeZip, String AttestorName) throws InterruptedException {
		checkPage.enterAmount(Amount);
		checkPage.selectPrintLocMilwaukee();
		checkPage.clickCheckPurposeDrpdwn(CheckPurpose);
		checkPage.selectOnDemand();
		checkPage.clickDistRecord();
		processFormcheckPage.navigateTopage();
		Thread.sleep(2000);
		checkPage.selectDistRecordTypeE();
		checkPage.enterFederalTax(FederalTax);
		checkPage.enterStateTax(StateTax);
		EnterPayeeInformation(PayeeName, PayeeAddressLine1, PayeeAddressLine2, PayeeCity, PayeeState, PayeeZip);
		checkPage.selectThirdPartyInfoNoForCheckIRA();
		checkPage.selectAttestationChkbox();
		Thread.sleep(2000);
		checkPage.enterAttestorName(AttestorName);
		checkPage.clickAttachmentBtn();
		newAttachmentPage.navigateTopage();
		newAttachmentPage.addAttachments();
		checkPage.clickSubmitBtn();
		processFormcheckPage.navigateTopage();
	}

	public void CreateIRACheckRequestOnDemandTypeF1(String Amount, String CheckPurpose, String FederalTax,
			String StateTax, String PayeeName, String PayeeAddressLine1, String PayeeAddressLine2, String PayeeCity,
			String PayeeState, String PayeeZip, String AttestorName) throws InterruptedException {
		checkPage.enterAmount(Amount);
		checkPage.selectPrintLocMilwaukee();
		checkPage.clickCheckPurposeDrpdwn(CheckPurpose);
		checkPage.selectOnDemand();
		checkPage.clickDistRecord();
		processFormcheckPage.navigateTopage();
		Thread.sleep(2000);
		checkPage.selectDistRecordTypeF1();
		checkPage.enterFederalTax(FederalTax);
		checkPage.enterStateTax(StateTax);
		EnterPayeeInformation(PayeeName, PayeeAddressLine1, PayeeAddressLine2, PayeeCity, PayeeState, PayeeZip);
		checkPage.selectThirdPartyInfoNoForCheckIRA();
		checkPage.selectAttestationChkbox();
		Thread.sleep(2000);
		checkPage.enterAttestorName(AttestorName);
		checkPage.clickAttachmentBtn();
		newAttachmentPage.navigateTopage();
		newAttachmentPage.addAttachments();
		checkPage.clickSubmitBtn();
		processFormcheckPage.navigateTopage();
	}

	public boolean VerifyWarningPopUpDistRecordNotSelected(String Amount, String CheckPurpose, String DistributionType,
			String FederalTax, String StateTax, String PayeeName, String PayeeAddressLine1, String PayeeAddressLine2,
			String PayeeCity, String PayeeState, String PayeeZip, String TypeofPayee, String AttestorName, String Error)
			throws InterruptedException {
		checkPage.enterAmount(Amount);
		checkPage.selectPrintLocMilwaukee();
		checkPage.clickCheckPurposeDrpdwn(CheckPurpose);
		checkPage.selectOnDemand();
		checkPage.clickDistributionTypeDrpdwn(DistributionType);
		checkPage.enterFederalTax(FederalTax);
		checkPage.enterStateTax(StateTax);
		EnterPayeeInformation(PayeeName, PayeeAddressLine1, PayeeAddressLine2, PayeeCity, PayeeState, PayeeZip);
		checkPage.selectTypeofPayee(TypeofPayee);
		checkPage.selectAttestationChkbox();
		Thread.sleep(2000);
		checkPage.enterAttestorName(AttestorName);
		checkPage.clickSubmitBtn();
		return VerifyErrorMessage(Error);
	}

	public void CreateIRACheckRequestQCDTypeD(String Amount, String CheckPurpose, String FederalTax, String StateTax,
			String DistributionType, String TypeofPayee, String AttestorName) {
		checkPage.enterAmount(Amount);
		checkPage.selectPrintLocMilwaukee();
		checkPage.clickCheckPurposeDrpdwn(CheckPurpose);
		checkPage.selectQCD();
		_browser._browserDriver.switchTo().alert().accept();
		_browser._browserDriver.switchTo().alert().accept();
		checkPage.enterFederalTax(FederalTax);
		checkPage.enterStateTax(StateTax);
		checkPage.clickDistributionTypeDrpdwn(DistributionType);
		checkPage.clickBtnSameasAccReg();
		checkPage.selectTypeofPayee(TypeofPayee);
		checkPage.selectThirdPartyInfoNo();
		checkPage.selectAttestationChkbox();
		checkPage.enterAttestorName(AttestorName);
		AddtwoAttachment();
		checkPage.clickSubmitBtn();
		processFormcheckPage.navigateTopage();
	}

	public void CreateIRACheckRequestOneTimeTypeA(String Amount, String CheckPurpose, String FederalTax,
			String StateTax, String DistributionType, String AttestorName) throws InterruptedException {
		checkPage.enterAmount(Amount);
		checkPage.selectPrintLocMilwaukee();
		checkPage.clickCheckPurposeDrpdwn(CheckPurpose);
		checkPage.selectOneTime();
		checkPage.clickBtnSameasAccReg();
		checkPage.clickBtnSameasAccReg();
		Thread.sleep(2000);
		checkPage.enterFederalTax(FederalTax);
		checkPage.enterStateTax(StateTax);
		checkPage.clickDistributionTypeDrpdwn(DistributionType);
		checkPage.selectAttestationChkbox();
		Thread.sleep(2000);
		checkPage.enterAttestorName(AttestorName);
		checkPage.clickSubmitBtn();
		processFormcheckPage.navigateTopage();
	}

	void AddtwoAttachment() {
		checkPage.clickAttachmentBtn();
		newAttachmentPage.navigateTopage();
		newAttachmentPage.addAttachments();
		checkPage.clickAttachmentBtn();
		newAttachmentPage.navigateTopage();
		newAttachmentPage.addAttachments();
	}

	public void CreateIRACheckRequestTypeB(String Amount, String CheckPurpose, String FederalTax, String StateTax,
			String DistributionType, String TypeofPayee, String AttestorName) {
		checkPage.enterAmount(Amount);
		checkPage.selectPrintLocMilwaukee();
		checkPage.clickCheckPurposeDrpdwn(CheckPurpose);
		checkPage.enterFederalTax(FederalTax);
		checkPage.enterStateTax(StateTax);
		checkPage.clickDistributionTypeDrpdwn(DistributionType);
		checkPage.selectAttachedDistributionForm();
		checkPage.clickBtnSameasAccReg();
		checkPage.selectTypeofPayee(TypeofPayee);
		checkPage.selectThirdPartyInfoYes();
		checkPage.selectAttestationChkbox();
		checkPage.enterAttestorName(AttestorName);
		AddtwoAttachment();
		checkPage.clickSubmitBtn();
		processFormcheckPage.navigateTopage();
	}

	public boolean VerifyWarningMessageforQCDdist(String errorText) throws InterruptedException {
		checkPage.enterAmount("2");
		checkPage.selectQCD();
		if (checkPage.getErrorPopUp().contains(errorText)) {
			return true;
		} else
			return false;
	}

	public boolean VerifysecondWarningMessageforQCDdist(String errorText) throws InterruptedException {
		checkPage.enterAmount("2");
		checkPage.selectQCD();
		_browser._browserDriver.switchTo().alert().accept();
		if (checkPage.getErrorPopUp().contains(errorText)) {
			return true;
		} else
			return false;
	}

	public boolean VerifyforQCDTypeOfPayeeD() throws InterruptedException {
		checkPage.enterAmount("2");
		checkPage.selectQCD();
		_browser._browserDriver.switchTo().alert().accept();
		_browser._browserDriver.switchTo().alert().accept();
		if (checkPage.getTypeofPayee("D")) {
			return true;
		} else
			return false;
	}

	public boolean VerifyErrorPopUpFederalTax(String FederalTax, String errorText) throws InterruptedException {
		checkPage.enterAmount("2");
		checkPage.selectOneTime();
		checkPage.enterFederalTax(FederalTax);
		checkPage.selectPrintLocMilwaukee();
		if (checkPage.getErrorPopUp().contains(errorText)) {
			return true;
		} else
			return false;
	}

	public boolean VerifyFinalAmountWithStateTax() throws InterruptedException {
		checkPage.enterAmount("4");
		checkPage.selectOneTime();
		checkPage.enterStateTax("7");
		checkPage.selectPrintLocMilwaukee();
		if (checkPage.checkFinalAmount("3.72")) {
			return true;
		} else
			return false;
	}

	public boolean VerifyFinalAmountWithStateandFederalTax() throws InterruptedException {
		checkPage.enterAmount("5");
		checkPage.selectOneTime();
		checkPage.enterFederalTax("10");
		checkPage.enterStateTax("7");
		checkPage.selectPrintLocMilwaukee();
		if (checkPage.checkFinalAmount("4.15")) {
			return true;
		} else
			return false;
	}

	public boolean VerifyFedWithholding() throws InterruptedException {
		checkPage.enterAmount("10");
		checkPage.selectOneTime();
		checkPage.enterFederalTax("10");
		checkPage.selectPrintLocMilwaukee();
		if (checkPage.checkFedWithholding("1")) {
			return true;
		} else
			return false;
	}

	public boolean VerifyStateWithholding() throws InterruptedException {
		checkPage.enterAmount("10");
		checkPage.selectOneTime();
		checkPage.enterStateTax("10");
		checkPage.selectPrintLocMilwaukee();
		if (checkPage.checkStateWithholding("1")) {
			return true;
		} else
			return false;
	}

	public boolean VerifyRequestedAmount() throws InterruptedException {
		checkPage.enterAmount("10");
		checkPage.selectOneTime();
		if (checkPage.checkRequestedAmount("10")) {
			return true;
		} else
			return false;
	}

	public boolean SelectPayeeInstructionForAddressLine2() throws InterruptedException {
		Thread.sleep(2000);
		checkPage.selectPayeeInstruction2();
		Thread.sleep(2000);
		if (checkPage.checktPayeeAddressLine2("BAIRD")) {
			return true;
		} else
			return false;
	}

	public void ClickQuestionMark() throws InterruptedException {
		Thread.sleep(2000);
		checkPage.clickIconQuestion();
	}
}
