package baird.LiquidOffice.Automation.Pages;

import org.openqa.selenium.Keys;

import baird.LiquidOffice.Automation.Models.DomesticWireModel;
import baird.LiquidOffice.Automation.Resources.TestSettings;
import baird.core.Automation.CommonAPI.ICommonAPI;

/**
 * @author AmitaKumari
 */

public class DomesticWirePage extends BasePage<DomesticWireModel> {

	public DomesticWirePage(ICommonAPI commonApi, TestSettings Settings) {
			super(commonApi, Settings);
			PageElements = new DomesticWireModel(_browser);
		}

	@Override
	public void navigateTopage() {
		SwitchToPopupWindow();
		try {
			Thread.sleep(1000);

		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		PageElements.init();
	}

	public void enterTransferToAcc(String AccountNo) {
		PageElements.getTxt_transfertoacc().sendKeys(AccountNo);
	}

	public void selectCashorMMF(String Fund) {
		PageElements.getTxt_cashorMMF().sendKeys(Fund);
	}
	
	public void clickTransferDate(String TransferFutureDate) {
		PageElements.getTxt_transferdate().click();
	}

	public void enterTransferDate() {
		PageElements.getTxt_transferdate().click();
		PageElements.getTxt_transferdate().clear();
	}

	public String getTransferDate() {
		PageElements.getTxt_transferdate().click();
		return PageElements.getTxt_transferdate().getText();
	}
	
	public boolean checkWireInformationTitle(String WireInfo) {
		return PageElements.getTxt_wireinfo().getAttribute("value").contains(WireInfo);
	}
	
	public boolean checkNewWireInstructionTitle(String WireInstruction) {
		return PageElements.getTxt_wireinstruction().getAttribute("value").contains(WireInstruction);
	}
	
	public boolean getAccountNumber(String AccNumber) {
		return PageElements.getTxt_accnumber().getAttribute("value").contains(AccNumber);
	}
	
	public boolean getAccountNo2(String AccNumber) {
		return PageElements.getTxt_accnumber2().getAttribute("value").contains(AccNumber);
	}
	
	public void selectWireInstructions() {
		PageElements.getBtn_wireinstruction().click();
	}
	
	public void selectRecordTypeA() {
		PageElements.getBtn_selectrecordtypeA().click();
	}
	
	public boolean checkNameOfAccount(String BankCustomerName) {
		return PageElements.getTxt_nameOfAccount().getAttribute("value").contains(BankCustomerName);
	}

	public boolean checkBankName(String BankName) {
		return PageElements.getTxt_bankname().getAttribute("value").contains(BankName);
	}

	public boolean checkBankABA(String BankABA) {
		return PageElements.getTxt_bankaba().getAttribute("value").contains(BankABA);
	}

	public boolean checkBankAccNumber(String BankAccNumber) {
		return PageElements.getTxt_bankaccnumber().getAttribute("value").contains(BankAccNumber);
	}
	
	public boolean checkCity(String City) {
		return PageElements.getTxt_city().getAttribute("value").contains(City);
	}
	
	public boolean checkState(String State) {
		return PageElements.getTxt_state().getAttribute("value").contains(State);
	}
	
	public void selectFAradioBtn() {
		PageElements.getRadiobtn_fa().click();
	}
	
	public void selectClientradioBtn() {
		PageElements.getRadiobtn_client().click();
	}
	
	public void selectYesFAradioBtn() {
		PageElements.getRadiobtn_yesfa().click();
	}
	
	public void selectYesFAradioBtnMMF() {
		PageElements.getRadiobtn_yesfammf().click();
	}
	
	public void selectBusinessPhoneNo() {
		PageElements.getRadiobtn_businessphone().click();
	}
	
	public boolean getHomePhoneNo(String HomePhone) {
		return PageElements.getTxt_homephone().getAttribute("value").contains(HomePhone);
	}
	
	public boolean getTextChargeWireFeeClient(String WireFeeClientText) {
		return PageElements.getTxt_WireFeeClient().getAttribute("value").contains(WireFeeClientText);
	}
	
	public String getInvalidCharErrorMessage() {
		return _browser._browserDriver.switchTo().alert().getText();
	}
	
	public void enterAmount(String Amount) {
		PageElements.getTxt_amount().click();
		PageElements.getTxt_amount().sendKeys(Keys.BACK_SPACE);
		PageElements.getTxt_amount().sendKeys(Keys.BACK_SPACE);
		PageElements.getTxt_amount().sendKeys(Keys.BACK_SPACE);
		PageElements.getTxt_amount().sendKeys(Keys.BACK_SPACE);
		PageElements.getTxt_amount().sendKeys(Keys.BACK_SPACE);
		PageElements.getTxt_amount().sendKeys(Amount);
	}
	
	public String getIssueDate() {
		PageElements.getTxt_issuedate().click();
		return PageElements.getTxt_issuedate().getText();
	}
	
	public void clickIssueDate(String FutureDate) {
		PageElements.getTxt_issuedate().click();
		PageElements.getTxt_issuedate().clear();
		PageElements.getTxt_issuedate().click();
		PageElements.getTxt_issuedate().sendKeys(FutureDate);
	}
	
	public void selectAccTypeCash() {
		PageElements.getRadiobtn_cash().click();
	}
	
	public void selectAccTypeMargin() {
		PageElements.getRadiobtn_margin().click();
	}
	
	public void enterBankInformation(String BankCustomerName, String BankName, String BankABA, String BankAccNumber, String City, String State) {
		PageElements.getTxt_nameOfAccount().sendKeys(BankCustomerName);
		PageElements.getTxt_bankname().sendKeys(BankName);
		PageElements.getTxt_bankaba().sendKeys(BankABA);
		PageElements.getTxt_bankaccnumber().sendKeys(BankAccNumber);
		PageElements.getTxt_city().sendKeys(City);
		PageElements.getTxt_state().sendKeys(State);
	}
	
	public void enterFinalBeneficiaryAccNoandName(String FinalAccNo, String FinalName) {
		PageElements.getTxt_finalaccnumber().sendKeys(FinalAccNo);
		PageElements.getTxt_finalname().sendKeys(FinalName);
	}
	
	public boolean getFinalAccountNo2(String FinalAccNumber2) {
		return PageElements.getTxt_finalaccnumber2().getAttribute("value").contains(FinalAccNumber2);
	}
	
	public boolean getFinalName2(String FinalName2) {
		return PageElements.getTxt_finalname2().getAttribute("value").contains(FinalName2);
	}
	
	public void enterBankAccNo(String BankAccNumber) {
		PageElements.getTxt_bankaccnumber().sendKeys(BankAccNumber);
	}
	
	public void enterBankABA(String BankABA) {
		PageElements.getTxt_bankaba().sendKeys(BankABA);
	}
	
	public void selectStandingInstruction(String SLOA) {
		PageElements.getDrpdwn_standinginst().sendKeys(SLOA);
	}
	
	public void selectBeneficiaryType(String BeneficiaryType) {
		PageElements.getDrpdwn_beneficiarytype().sendKeys(BeneficiaryType);
	}
	
	public void clickAttachmentBtn() {
		PageElements.getBtn_attachment().click();
	}
	
	public void clickContinueBtn() {
		PageElements.getBtn_continue().click();
	}
	
	public void enterThirdParty(String ThirdPArty) {
		PageElements.getTxt_thirdparty().click();
		PageElements.getTxt_thirdparty().sendKeys(ThirdPArty);
	}
	
	public void selectAccountLength2() {
		PageElements.getBtn_acclength2().click();
	}
	
	public void selectAccountLength1() {
		PageElements.getBtn_acclength1().click();
	}
	
	public void selectAttestationChkbox() {
		PageElements.getChkbox_attestation().click();
	}

	public void enterAttestorName(String AttestorName) {
		PageElements.getTxt_attestorname().sendKeys(AttestorName);
	}
	
	public void selectNoAdvisoryRadioBtn() {
		PageElements.getRadiobtn_noadvisory().click();
	}
	
	public void selectYesAdvisoryRadioBtn() {
		PageElements.getRadiobtn_yesadvisory().click();
	}
	
	public void clickSubmitBtn() {
		PageElements.getBtn_submit().click();
	}
	
	public void clickSendBtn() {
		PageElements.getBtn_send().click();
	}
	
	public void selectNoDuplicateChkbox() throws InterruptedException {
		Thread.sleep(1000);
		PageElements.getChkbox_noduplicateconfirm().click();
		Thread.sleep(2000);
	}
	
	public void clickResetButton() throws InterruptedException {
		PageElements.getBtn_reset().click();
		Thread.sleep(2000);
	}
	
	public void clickSaveButton() {
		PageElements.getBtn_save().click();
	}

	public void clickBackButton() {
		PageElements.getBtn_back().click();
	}
}
