package baird.LiquidOffice.Automation.Models;

import baird.core.Automation.WebDrivers.Browser;

/**
 * @author AmitaKumari
 */

public class BaseModel {

	protected Browser browserobj = null;

	public BaseModel(Browser obj) {
		browserobj = obj;
	}

	public void init() {
		browserobj.LoadElements(this);
	}

}