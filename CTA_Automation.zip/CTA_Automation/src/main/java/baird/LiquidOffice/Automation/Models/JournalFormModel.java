package baird.LiquidOffice.Automation.Models;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import baird.core.Automation.WebDrivers.Browser;
import baird.core.Automation.WebDrivers.Elements.HtmlElementImpl;

/**
 * @author AmitaKumari
 */

public class JournalFormModel extends BaseModel {

	public JournalFormModel(Browser obj) {
		super(obj);
	}

	@FindBy(id = "TO_ACCOUNT")
	WebElement txt_accountno;

	@FindBy(id = "TRANSFER_DATE")
	WebElement txt_transferdate;

	@FindBy(id = "beneType")
	WebElement drpdwn_typeofpayee;

	@FindBy(id = "TransferType_RadioButton2")
	WebElement fullradiobtn_transfertype;

	@FindBy(id = "TransferType_RadioButton3")
	WebElement partialradiobtn_transfertype;

	@FindBy(id = "gift_RadioButton2_1")
	WebElement yesradiobtn_giftfortax;

	@FindBy(id = "DTB__CASH_TBL_0_TransferPartFull_Cash_RadioButton5_1")
	WebElement partialradiobtn_quantity;

	@FindBy(id = "DTB__CASH_TBL_1_TransferPartFull_Cash_RadioButton5_1")
	WebElement mmfpartialradiobtn_quantity;

	@FindBy(id = "DTB__CASH_TBL_1_TransferPartFull_Cash_RadioButton6")
	WebElement mmfnoneradiobtn_quantity;

	@FindBy(id = "DTB__CASH_TBL_0_TransferPartFull_Cash_RadioButton4_1")
	WebElement allradiobtn_quantity;

	@FindBy(id = "DTB__CASH_TBL_0_TransferPartFull_Cash_RadioButton6")
	WebElement noneradiobtn_quantity;

	@FindBy(id = "StandingLOA")
	WebElement drpdwn_standinginst;

	@FindBy(id = "DTB__CASH_TBL_0_TransferAmount_Valuation")
	WebElement txt_transfervalue;

	@FindBy(id = "DTB__CASH_TBL_1_TransferAmount_Valuation")
	WebElement txt_transfervaluemmf;

	@FindBy(id = "CASH_WITHDRAWAL")
	WebElement txt_cashwithdrawalamount;

	@FindBy(id = "VALUATION_TOTAL")
	WebElement txt_totalfromvaluations;

	@FindBy(id = "TOTAL_JOURNAL")
	WebElement txt_totalfromallselections;

	@FindBy(id = "POSITION_TOTAL")
	WebElement txt_totalfrompositions;

	@FindBy(id = "transferDesc")
	WebElement txt_transferdesc;
	
	@FindBy(id = "toAccountRegistration")
	WebElement txt_transfertoaccdesc;
	
	@FindBy(id = "DTB__CASH_TBL_0_VALUE_TYPE")
	WebElement txt_cashinfotype;

	@FindBy(id = "DTB__CASH_TBL_1_VALUE_TYPE")
	WebElement txt_mmfinfotype;

	@FindBy(id = "DTB__CASH_TBL_1_VALUE_VALUE")
	WebElement txt_mmfvalue;

	@FindBy(id = "pageInfo")
	WebElement txt_pageno;

	@FindBy(id = "DTB__CASH_TBL_0_VALUE_VALUE")
	WebElement txt_value;

	@FindBy(id = "btnCharitableGift")
	WebElement icon_question;

	@FindBy(id = "DFS__ctrlPgFlipTop")
	WebElement txt_confirmation;

	@FindBy(id = "btnAttachments")
	WebElement btn_attachment;

	@FindBy(id = "btnBack")
	WebElement btn_back;

	@FindBy(id = "btnSave")
	WebElement btn_save;

	@FindBy(id = "btnPreviousPage")
	WebElement btn_previous;

	@FindBy(id = "btnNextPage")
	WebElement btn_next;

	@FindBy(id = "btnSave_1")
	WebElement btn_saveforlater;

	@FindBy(id = "Journal_Information")
	WebElement txt_journalinfotitle;

	@FindBy(id = "Advisory_Acct_Withdraw_Info")
	WebElement txt_advisoryacctitle;

	@FindBy(id = "DTB__tblAdvisoryAcctWithdrawalInfo_0_SourceAccountModelChange_RadioButton10_5")
	WebElement radiobtn_yesadvisoryaccount;

	@FindBy(id = "DTB__tblAdvisoryAcctWithdrawalInfo_0_SourceAccountModelChange_RadioButton11_5")
	WebElement radiobtn_noadvisoryaccount;
	
	@FindBy(id = "DTB__tblAdvisoryAcctWithdrawalInfo_0_radioCashDepositIntoSourceAcct_RadioButton14")
	WebElement radiobtn_yessecuritiesout;

	@FindBy(id = "DFS__ctrlPgFlipBot")
	WebElement drpdwn_journal;

	@FindBy(id = "btnContinue_3")
	WebElement btn_continue;
	
	@FindBy(id = "btnContinue_2")
	WebElement btn_continueIRA;
	
	@FindBy(id = "DTB__ASSET_TBL_0_TransferPartFull_Position_RadioButton7")
	WebElement partialradiobtn_securities;

	@FindBy(id = "DTB__ASSET_TBL_1_TransferPartFull_Position_RadioButton7")
	WebElement partialradiobtn_securities2;

	@FindBy(id = "DTB__ASSET_TBL_0_TransferPartFull_Position_RadioButton4")
	WebElement allradiobtn_securities;

	@FindBy(id = "DTB__ASSET_TBL_0_TransferAmount")
	WebElement txt_shareno;

	@FindBy(id = "DTB__ASSET_TBL_1_TransferAmount")
	WebElement txt_shareno2;

	@FindBy(id = "DTB__ASSET_TBL_0_taxLotSelection")
	WebElement btn_taxlot;

	@FindBy(id = "DTB__ASSET_TBL_0_Value")
	WebElement txt_valuesecurity;

	@FindBy(id = "DTB__ASSET_TBL_0_TransferValue_Position")
	WebElement txt_transfervaluesecurity;
	
	@FindBy(id = "IRA_Contr_Info")
	WebElement txt_iracontributiontitle;
	
	@FindBy(id = "ACCOUNT_TYPE")
	WebElement txt_acctypeto;
	
	@FindBy(id = "ACCOUNT_TYPE_4")
	WebElement txt_acctypetoiratoretail;
	
	@FindBy(id = "ACCOUNT_TYPE_2")
	WebElement txt_acctypefrom;
	
	@FindBy(id = "ACCOUNT_NUMBER_7")
	WebElement txt_accno;
	
	@FindBy(id = "ACCOUNT_NUMBER_6")
	WebElement txt_transferfromaccno;
	
	@FindBy(id = "ACCOUNT_NUMBER_8")
	WebElement txt_transfertoaccno;
	
	@FindBy(id = "DTB__tblContributionType_0_pecoIn")
	WebElement drpdwn_depositcode;
	
	@FindBy(id = "distCodes")
	WebElement drpdwn_withdrawalcode;
	
	@FindBy(id = "DIST_FORM_RadioButton19")
	WebElement onfileradiobtn_distributionform;
	
	@FindBy(id = "DIST_FORM_Radio16_1")
	WebElement attachedradiobtn_distributionform;
	
	@FindBy(id = "FED_WITHHOLDING")
	WebElement txt_federaltax;
	
	@FindBy(id = "STATE_WITHHOLDING")
	WebElement txt_statetax;
	
	@FindBy(id = "Fed_Withholding_Amount")
	WebElement txt_fedwithholding;
	
	@FindBy(id = "State_Withholding_Amount")
	WebElement txt_statewithholding;
	
	@FindBy(id = "FINAL_AMT")
	WebElement txt_finalamount;
	
	public HtmlElementImpl getTxt_transfertoacc() {
		return new HtmlElementImpl(txt_accountno);
	}

	public HtmlElementImpl getTxt_transferdate() {
		return new HtmlElementImpl(txt_transferdate);
	}

	public HtmlElementImpl getDrpdwn_typeofpayee() {
		return new HtmlElementImpl(drpdwn_typeofpayee);
	}

	public HtmlElementImpl getRadiobtnFull_transfertype() {
		return new HtmlElementImpl(fullradiobtn_transfertype);
	}

	public HtmlElementImpl getRadiobtnPartial_transfertype() {
		return new HtmlElementImpl(partialradiobtn_transfertype);
	}

	public HtmlElementImpl getRadiobtnYes_giftfortax() {
		return new HtmlElementImpl(yesradiobtn_giftfortax);
	}

	public HtmlElementImpl getRadiobtnPartial_quantity() {
		return new HtmlElementImpl(partialradiobtn_quantity);
	}

	public HtmlElementImpl getRadiobtnPartialmmf_quantity() {
		return new HtmlElementImpl(mmfpartialradiobtn_quantity);
	}

	public HtmlElementImpl getRadiobtnNonemmf_quantity() {
		return new HtmlElementImpl(mmfnoneradiobtn_quantity);
	}

	public HtmlElementImpl getRadiobtnAll_quantity() {
		return new HtmlElementImpl(allradiobtn_quantity);
	}

	public HtmlElementImpl getRadiobtnNone_quantity() {
		return new HtmlElementImpl(noneradiobtn_quantity);
	}

	public HtmlElementImpl getDrpdwn_standinginst() {
		return new HtmlElementImpl(drpdwn_standinginst);
	}

	public HtmlElementImpl getTxt_transfervalue() {
		return new HtmlElementImpl(txt_transfervalue);
	}

	public HtmlElementImpl getTxt_transfervaluemmf() {
		return new HtmlElementImpl(txt_transfervaluemmf);
	}

	public HtmlElementImpl getTxt_cashwithdrawalamount() {
		return new HtmlElementImpl(txt_cashwithdrawalamount);
	}

	public HtmlElementImpl getTxt_totalfromvaluations() {
		return new HtmlElementImpl(txt_totalfromvaluations);
	}

	public HtmlElementImpl getTxt_totalfromallselections() {
		return new HtmlElementImpl(txt_totalfromallselections);
	}

	public HtmlElementImpl getTxt_totalfrompositions() {
		return new HtmlElementImpl(txt_totalfrompositions);
	}

	public HtmlElementImpl getTxt_transferdesc() {
		return new HtmlElementImpl(txt_transferdesc);
	}
	
	public HtmlElementImpl getTxt_transfertoaccdesc() {
		return new HtmlElementImpl(txt_transfertoaccdesc);
	}
	
	public HtmlElementImpl getTxt_cashinfotype() {
		return new HtmlElementImpl(txt_cashinfotype);
	}

	public HtmlElementImpl getTxt_mmfinfotype() {
		return new HtmlElementImpl(txt_mmfinfotype);
	}

	public HtmlElementImpl getTxt_mmfvalue() {
		return new HtmlElementImpl(txt_mmfvalue);
	}

	public HtmlElementImpl getTxt_pageno() {
		return new HtmlElementImpl(txt_pageno);
	}

	public HtmlElementImpl getTxt_value() {
		return new HtmlElementImpl(txt_value);
	}

	public HtmlElementImpl getIcon_question() {
		return new HtmlElementImpl(icon_question);
	}

	public HtmlElementImpl getTxt_confirmation() {
		return new HtmlElementImpl(txt_confirmation);
	}

	public HtmlElementImpl getBtn_attachment() {
		return new HtmlElementImpl(btn_attachment);
	}

	public HtmlElementImpl getBtn_back() {
		return new HtmlElementImpl(btn_back);
	}

	public HtmlElementImpl getBtn_save() {
		return new HtmlElementImpl(btn_save);
	}

	public HtmlElementImpl getBtn_next() {
		return new HtmlElementImpl(btn_next);
	}

	public HtmlElementImpl getBtn_previous() {
		return new HtmlElementImpl(btn_previous);
	}

	public HtmlElementImpl getBtn_saveforlater() {
		return new HtmlElementImpl(btn_saveforlater);
	}

	public HtmlElementImpl getTxt_journalinfotitle() {
		return new HtmlElementImpl(txt_journalinfotitle);
	}

	public HtmlElementImpl getTxt_advisoryacctitle() {
		return new HtmlElementImpl(txt_advisoryacctitle);
	}

	public HtmlElementImpl getRadiobtn_yesadvisoryaccount() {
		return new HtmlElementImpl(radiobtn_yesadvisoryaccount);
	}

	public HtmlElementImpl getRadiobtn_noadvisoryaccount() {
		return new HtmlElementImpl(radiobtn_noadvisoryaccount);
	}
	
	public HtmlElementImpl getRadiobtn_yessecuritiesout() {
		return new HtmlElementImpl(radiobtn_yessecuritiesout);
	}

	public HtmlElementImpl getDrpdwn_journal() {
		return new HtmlElementImpl(drpdwn_journal);
	}

	public HtmlElementImpl getBtn_continue() {
		return new HtmlElementImpl(btn_continue);
	}

	public HtmlElementImpl getRadiobtnPartial_securities() {
		return new HtmlElementImpl(partialradiobtn_securities);
	}

	public HtmlElementImpl getRadiobtnPartial_securities2() {
		return new HtmlElementImpl(partialradiobtn_securities2);
	}

	public HtmlElementImpl getRadiobtnAll_securities() {
		return new HtmlElementImpl(allradiobtn_securities);
	}

	public HtmlElementImpl getTxt_shareno() {
		return new HtmlElementImpl(txt_shareno);
	}

	public HtmlElementImpl getTxt_shareno2() {
		return new HtmlElementImpl(txt_shareno2);
	}

	public HtmlElementImpl getBtn_taxlot() {
		return new HtmlElementImpl(btn_taxlot);
	}

	public HtmlElementImpl getTxt_valuesecurity() {
		return new HtmlElementImpl(txt_valuesecurity);
	}

	public HtmlElementImpl getTxt_transfervaluesecurity() {
		return new HtmlElementImpl(txt_transfervaluesecurity);
	}

	public HtmlElementImpl getTxt_iracontributiontitle() {
		return new HtmlElementImpl(txt_iracontributiontitle);
	}
	
	public HtmlElementImpl getTxt_acctypeto() {
		return new HtmlElementImpl(txt_acctypeto);
	}
	
	public HtmlElementImpl getTxt_acctypetoiratoretail() {
		return new HtmlElementImpl(txt_acctypetoiratoretail);
	}
	
	public HtmlElementImpl getTxt_acctypefrom() {
		return new HtmlElementImpl(txt_acctypefrom);
	}
	
	public HtmlElementImpl getTxt_accno() {
		return new HtmlElementImpl(txt_accno);
	}
	
	public HtmlElementImpl getTxt_transferfromaccno() {
		return new HtmlElementImpl(txt_transferfromaccno);
	}
	
	public HtmlElementImpl getTxt_transfertoaccno() {
		return new HtmlElementImpl(txt_transfertoaccno);
	}
	
	public HtmlElementImpl getDrpdwn_depositcode() {
		return new HtmlElementImpl(drpdwn_depositcode);
	}

	public HtmlElementImpl getDrpdwn_withdrawalcode() {
		return new HtmlElementImpl(drpdwn_withdrawalcode);
	}
	
	public HtmlElementImpl getBtn_distributionformonfile() {
		return new HtmlElementImpl(onfileradiobtn_distributionform);
	}
	
	public HtmlElementImpl getBtn_distributionformattached() {
		return new HtmlElementImpl(attachedradiobtn_distributionform);
	}
	
	public HtmlElementImpl getBtn_continueIRA() {
		return new HtmlElementImpl(btn_continueIRA);
	}
	
	public HtmlElementImpl getTxt_federaltax() {
		return new HtmlElementImpl(txt_federaltax);
	}
	
	public HtmlElementImpl getTxt_statetax() {
		return new HtmlElementImpl(txt_statetax);
	}
	
	public HtmlElementImpl getTxt_fedwithholding() {
		return new HtmlElementImpl(txt_fedwithholding);
	}
	
	public HtmlElementImpl getTxt_statewithholding() {
		return new HtmlElementImpl(txt_statewithholding);
	}
	
	public HtmlElementImpl getTxt_finalamount() {
		return new HtmlElementImpl(txt_finalamount);
	}
}
