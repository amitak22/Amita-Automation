package baird.LiquidOffice.Automation.Pages;

import org.openqa.selenium.support.ui.ExpectedConditions;

import baird.LiquidOffice.Automation.Models.SignInPageModel;
import baird.LiquidOffice.Automation.Resources.TestSettings;
import baird.core.Automation.CommonAPI.ICommonAPI;

/**
 * @author AmitaKumari
 */

public class SignInPage extends BasePage<SignInPageModel> {
	public SignInPage(ICommonAPI commonApi, TestSettings Settings) {
		super(commonApi, Settings);
		PageElements = new SignInPageModel(_browser);
	}

	@Override
	public void navigateTopage() {

		_browser.navigateToUrl(_Settings.Url + "/lfserver?DFS__Action=FoldersGetFolder&DFS__Client=JSP");
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		PageElements.init();
	}

	public void signInClickLogo() {
		_explicitwait.until(ExpectedConditions.visibilityOf(PageElements.getLnk_homelogo()));
		PageElements.getLnk_homelogo().click();
	}

	public void signInClick() {
		_explicitwait.until(ExpectedConditions.elementToBeClickable(PageElements.getLnk_signIn()));
		PageElements.getLnk_signIn().click();
	}
}
