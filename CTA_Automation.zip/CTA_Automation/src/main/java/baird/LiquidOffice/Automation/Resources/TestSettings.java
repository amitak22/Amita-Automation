/**
 * 
 */
package baird.LiquidOffice.Automation.Resources;

import baird.core.Automation.CommonAPI.ApiSettings;
import baird.core.Automation.WebDrivers.BrowserType;

/**
 * @author AmitaKumari
 */

public class TestSettings {
	public String Url;
	public BrowserType Browser;

	public ApiSettings CoreSettings;
	public String ReportFilePrefix;
}