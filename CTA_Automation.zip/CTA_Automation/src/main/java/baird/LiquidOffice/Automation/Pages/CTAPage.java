package baird.LiquidOffice.Automation.Pages;

import org.openqa.selenium.WebDriver;

import baird.LiquidOffice.Automation.Models.CTAModel;
import baird.LiquidOffice.Automation.Resources.TestSettings;
import baird.core.Automation.CommonAPI.ICommonAPI;
import io.appium.java_client.functions.ExpectedCondition;

/**
 * @author AmitaKumari
 */

public class CTAPage extends BasePage<CTAModel> {

	public CTAPage(ICommonAPI commonApi, TestSettings Settings) {
		super(commonApi, Settings);
		PageElements = new CTAModel(_browser);
	}

	@Override
	public void navigateTopage() {
		SwitchToPopupWindow();
		PageElements.init();
	}

	public void enterAccNumber(String AccNumber) {
		PageElements.getTxt_accnumber().sendKeys(AccNumber);
	}

	public void selectCHKradiobtn() {
		PageElements.getradiobtn_check().click();
	}

	public void selectACHradiobtn() {
		PageElements.getradiobtn_ach().click();
	}
	
	public void selectJournalradiobtn() {
		PageElements.getradiobtn_journal().click();
	}
	
	public void selectDomesticWireradiobtn() {
		PageElements.getradiobtn_domesticwire().click();
	}
	
	public String getClientInfotext() {
		return PageElements.getTxt_ClientinfoTitle().getText();
	}

	public void clickContinueBtn() {
		PageElements.getBtn_Continue().click();
	}
	
	public String getUtaErrorMessage() {
		return _browser._browserDriver.switchTo().alert().getText();
	}

	public String getInvalidCharErrorMessage() {
		return _browser._browserDriver.switchTo().alert().getText();
	}

	public String getErrorPopUp() {
		return _browser._browserDriver.switchTo().alert().getText();
	}

	public Boolean checkClientName(String ClientName) {
		_explicitwait.until(new ExpectedCondition<Boolean>() {
			public Boolean apply(WebDriver d) {
				return PageElements.getTxt_ClientName().getAttribute("value").length() != 0;
			}
		});
		return PageElements.getTxt_ClientName().getAttribute("value").contains(ClientName);
	}

	public Boolean checkClientAddress(String ClientAddress) {
		return PageElements.getTxt_ClientAddress().getAttribute("value").contains(ClientAddress);
	}

}
