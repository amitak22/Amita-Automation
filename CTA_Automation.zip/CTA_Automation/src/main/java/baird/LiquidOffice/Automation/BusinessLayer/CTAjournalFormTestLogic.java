package baird.LiquidOffice.Automation.BusinessLayer;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import baird.LiquidOffice.Automation.Pages.AchFormPage;
import baird.LiquidOffice.Automation.Pages.CTAPage;
import baird.LiquidOffice.Automation.Pages.CheckFormPage;
import baird.LiquidOffice.Automation.Pages.ClientServicesPage;
import baird.LiquidOffice.Automation.Pages.HomePage;
import baird.LiquidOffice.Automation.Pages.JournalFormPage;
import baird.LiquidOffice.Automation.Pages.NewAttachmentPage;
import baird.LiquidOffice.Automation.Pages.ProcessFormCheckPage;
import baird.LiquidOffice.Automation.Pages.SignInPage;
import baird.LiquidOffice.Automation.Resources.TestSettings;
import baird.core.Automation.CommonAPI.ICommonAPI;

/**
 * @author AmitaKumari
 */

public class CTAjournalFormTestLogic extends BaseTestLogic {

	SignInPage signinPage = null;
	HomePage homePage = null;
	ClientServicesPage clientServices = null;
	CTAPage ctaPage = null;
	CheckFormPage checkPage = null;
	ProcessFormCheckPage processFormcheckPage = null;
	AchFormPage achPage = null;
	JournalFormPage journalPage = null;
	NewAttachmentPage newAttachmentPage = null;

	public CTAjournalFormTestLogic(ICommonAPI commonApi, TestSettings Settings) {
		super(commonApi, Settings);

		signinPage = new SignInPage(commonApi, Settings);
		homePage = new HomePage(commonApi, Settings);
		clientServices = new ClientServicesPage(commonApi, Settings);
		ctaPage = new CTAPage(commonApi, Settings);
		checkPage = new CheckFormPage(commonApi, Settings);
		processFormcheckPage = new ProcessFormCheckPage(commonApi, Settings);
		newAttachmentPage = new NewAttachmentPage(commonApi, Settings);
		achPage = new AchFormPage(commonApi, Settings);
		journalPage = new JournalFormPage(commonApi, Settings);
	}

	public void NavigateToSignInPage() {
		signinPage.navigateTopage();
	}

	// Action method for login using Logo or SignIn
	public void LoginToHomePage(String LoginMethod) throws Exception {
		if (LoginMethod.contains("Logo")) {
			signinPage.signInClickLogo();
		} else if (LoginMethod.contains("SignIn")) {
			signinPage.signInClick();
		} else {
			throw new Exception("Invalid Login Method");
		}
	}

	public void LoadHomePage() {
		homePage.navigateTopage();
	}

	public void LoadClientServices() {
		clientServices.navigateTopage();
	}

	// Action method for opening CTA form in UAT
	public void OpenCTApage(String LoginMethod) throws Exception {
		NavigateToSignInPage();
		LoginToHomePage(LoginMethod);
		LoadHomePage();
		homePage.clientServicesClick();
		LoadClientServices();
		clientServices.ctaClick();
		ctaPage.navigateTopage();
	}

	// Action method for opening CTA form in SIT
	public void OpenCTApageSIT(String LoginMethod) throws Exception {
		NavigateToSignInPage();
		LoginToHomePage(LoginMethod);
		LoadHomePage();
		homePage.clientServicesClickSIT();
		LoadClientServices();
		clientServices.ctaClickSIT();
		ctaPage.navigateTopage();
	}

	// Action method to get Client Info
	public void GetClientInfo(String AccountNo, String Type) throws InterruptedException {
		ctaPage.enterAccNumber(AccountNo);
		Thread.sleep(2000);
		ctaPage.selectJournalradiobtn();
	}

	// Action method to click on Continue button on Client Info
	public void ClickContinueOnClientInfo() throws InterruptedException {
		ctaPage.clickContinueBtn();
		journalPage.navigateTopage();
	}

	public void SendJournalRequest() throws InterruptedException {
		processFormcheckPage.clickSendBtn();
	}

	public void SubmitJournalRequest() throws InterruptedException {
		processFormcheckPage.clickSubmitBtn();
	}

	public boolean VerifyJournalInfoTitle() {
		if (journalPage.checkJournalInformationTitle("Journal Information")) {
			return true;
		} else
			return false;
	}

	public boolean VerifyWarningPopUpInvalidAcc(String AccountNo, String errorText) throws InterruptedException {
		journalPage.enterTransferToAcc(AccountNo);
		journalPage.clickTransferDate("");
		if (achPage.getInvalidCharErrorMessage().contains(errorText)) {
			return true;
		} else
			return false;
	}

	public boolean VerifyTransferCurrentDate() {
		journalPage.getTransferDate().equals(FetchCurrentDate());
		return true;
	}

	public String FetchCurrentDate() {
		DateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		Date date = new Date();
		String currentDate = dateFormat.format(date);
		return currentDate;
	}

	public boolean VerifyWarningPopUpForTypeA(String AccountNo, String TypeofPayee, String errorText)
			throws InterruptedException {
		journalPage.enterTransferToAcc(AccountNo);
		journalPage.clickTransferDate("");
		Thread.sleep(1000);
		journalPage.selectTypeofPayee(TypeofPayee);
		if (achPage.getInvalidCharErrorMessage().contains(errorText)) {
			return true;
		} else
			return false;
	}

	public boolean VerifyTotalfromValuations(String AccountNo, String TypeofPayee, String TransferValue)
			throws InterruptedException {
		journalPage.enterTransferToAcc(AccountNo);
		journalPage.clickTransferDate("");
		Thread.sleep(1000);
		journalPage.selectTypeofPayee(TypeofPayee);
		journalPage.selectTransferTypePartial();
		journalPage.selectQuantityPartial();
		Thread.sleep(2000);
		journalPage.enterTransferValue(TransferValue);
		journalPage.selectGiftforTaxYes();
		Thread.sleep(1000);
		if (journalPage.checkTotalfromValuations("2.00")) {
			return true;
		} else
			return false;
	}

	public boolean VerifyWarningPopUpForQuestionMark(String AccountNo, String TypeofPayee, String errorText)
			throws InterruptedException {
		journalPage.enterTransferToAcc(AccountNo);
		journalPage.clickTransferDate("");
		Thread.sleep(1000);
		journalPage.selectTypeofPayee(TypeofPayee);
		journalPage.clickIconQuestion();
		if (achPage.getInvalidCharErrorMessage().contains(errorText)) {
			return true;
		} else
			return false;
	}

	public boolean VerifyTransferDateForFutureDate(String errorText) throws InterruptedException {
		journalPage.enterTransferDate();
		if (checkPage.getErrorPopUp().contains(errorText)) {
			return true;
		} else
			return false;
	}

	public boolean VerifySummaryOfJournalTitle(String AccountNo, String TypeofPayee, String TransferValue)
			throws InterruptedException {
		journalPage.enterTransferToAcc(AccountNo);
		journalPage.clickTransferDate("");
		Thread.sleep(1000);
		journalPage.selectTypeofPayee(TypeofPayee);
		journalPage.selectTransferTypePartial();
		journalPage.selectGiftforTaxYes();
		journalPage.selectQuantityPartial();
		Thread.sleep(1000);
		journalPage.enterTransferValue(TransferValue);
		journalPage.clickTransferDate("");
		Thread.sleep(1000);
		ctaPage.clickContinueBtn();
		processFormcheckPage.navigateTopage();
		if (processFormcheckPage.getSummaryOfJournalTitle().contains("Summary of Journal Request")) {
			return true;
		} else
			return false;
	}

	public void VerifyJournalFormSubmitTypeB_C_D_E(String AccountNo, String TypeofPayee, String TransferValue)
			throws InterruptedException {
		journalPage.enterTransferToAcc(AccountNo);
		journalPage.clickTransferDate("");
		Thread.sleep(1000);
		journalPage.selectTypeofPayee(TypeofPayee);
		journalPage.selectTransferTypePartial();
		journalPage.selectGiftforTaxYes();
		journalPage.selectQuantityPartial();
		Thread.sleep(1000);
		journalPage.enterTransferValue(TransferValue);
		journalPage.clickTransferDate("");
		Thread.sleep(1000);
		journalPage.clickAttachmentBtn();
		newAttachmentPage.navigateTopage();
		newAttachmentPage.addAttachments();
		Thread.sleep(1000);
		ctaPage.clickContinueBtn();
		processFormcheckPage.navigateTopage();
		SubmitJournalRequest();
		processFormcheckPage.navigateTopage();
		SendJournalRequest();
	}

	public boolean VerifyBackButton() {
		journalPage.clickBackButton();
		if (ctaPage.getClientInfotext().toLowerCase().contains("client information")) {
			return true;
		} else
			return false;
	}

	public boolean VerifySaveFunctionality() throws InterruptedException {
		journalPage.clickSaveButton();
		return true;
	}

	public boolean VerifyTotalfromAllSelections(String AccountNo, String TypeofPayee, String TransferValue)
			throws InterruptedException {
		journalPage.enterTransferToAcc(AccountNo);
		journalPage.clickTransferDate("");
		Thread.sleep(1000);
		journalPage.selectTypeofPayee(TypeofPayee);
		journalPage.selectTransferTypePartial();
		journalPage.selectQuantityPartial();
		Thread.sleep(1000);
		journalPage.enterTransferValue(TransferValue);
		journalPage.clickTransferDate("");
		Thread.sleep(1000);
		if (journalPage.checkTotalfromAllSelections("2.00")) {
			return true;
		} else
			return false;
	}

	public boolean VerifyTotalfromPositions(String AccountNo, String TypeofPayee, String TransferValue)
			throws InterruptedException {
		journalPage.enterTransferToAcc(AccountNo);
		journalPage.clickTransferDate("");
		Thread.sleep(1000);
		journalPage.selectTypeofPayee(TypeofPayee);
		journalPage.selectTransferTypePartial();
		journalPage.selectQuantityPartial();
		Thread.sleep(1000);
		journalPage.enterTransferValue(TransferValue);
		journalPage.clickTransferDate("");
		Thread.sleep(1000);
		if (journalPage.checkTotalfromPositions("0.00")) {
			return true;
		} else
			return false;
	}

	public boolean VerifyTransferDesc(String AccountNo) throws InterruptedException {
		journalPage.enterTransferToAcc(AccountNo);
		journalPage.clickTransferDate("");
		Thread.sleep(1000);
		if (journalPage.checkTransferDesc("Retail to Retail") && journalPage.checkCashInfoType("Cash (Type 1)")
				&& journalPage.checkPageNo("Page 1 of 1")) {
			return true;
		} else
			return false;
	}

	public void VerifyJournalFormSubmitTypeA(String AccountNo, String TransferValue) throws InterruptedException {
		journalPage.enterTransferToAcc(AccountNo);
		journalPage.clickTransferDate("");
		Thread.sleep(1000);
		journalPage.selectTransferTypePartial();
		journalPage.selectQuantityPartial();
		Thread.sleep(1000);
		journalPage.enterTransferValue(TransferValue);
		journalPage.clickTransferDate("");
		Thread.sleep(1000);
		journalPage.clickAttachmentBtn();
		newAttachmentPage.navigateTopage();
		newAttachmentPage.addAttachments();
		Thread.sleep(1000);
		ctaPage.clickContinueBtn();
		processFormcheckPage.navigateTopage();
		SubmitJournalRequest();
		processFormcheckPage.navigateTopage();
		SendJournalRequest();
	}

	public boolean VerifyTotalValueWithTransferValue(String AccountNo) throws InterruptedException {
		journalPage.enterTransferToAcc(AccountNo);
		journalPage.clickTransferDate("");
		Thread.sleep(1000);
		journalPage.selectTransferTypeFull();
		return journalPage.getValue().equals(GetTransferValue());
	}

	public String GetTransferValue() {
		return journalPage.getTransferValue();
	}

	public boolean VerifyTotalValueWithNoneBtn(String AccountNo) throws InterruptedException {
		journalPage.enterTransferToAcc(AccountNo);
		journalPage.clickTransferDate("");
		Thread.sleep(1000);
		journalPage.selectTransferTypePartial();
		journalPage.selectQuantityNone();
		if (journalPage.checkTransferValue("0.00")) {
			return true;
		} else
			return false;
	}

	public boolean VerifyTypeandValueForMMF() throws InterruptedException {
		if (journalPage.checkMMFInfoType("ID3") && (journalPage.checkMMFValue("100.00"))) {
			return true;
		} else
			return false;
	}

	public boolean VerifyPreviousBtn(String AccountNo, String TypeofPayee, String TransferValue)
			throws InterruptedException {
		journalPage.enterTransferToAcc(AccountNo);
		journalPage.clickTransferDate("");
		Thread.sleep(1000);
		journalPage.selectTypeofPayee(TypeofPayee);
		journalPage.selectTransferTypePartial();
		journalPage.selectGiftforTaxYes();
		journalPage.selectQuantityPartial();
		Thread.sleep(1000);
		journalPage.enterTransferValue(TransferValue);
		journalPage.clickTransferDate("");
		Thread.sleep(1000);
		ctaPage.clickContinueBtn();
		processFormcheckPage.navigateTopage();
		processFormcheckPage.clickPreviousBtn();
		if (journalPage.checkJournalInformationTitle("Journal Information")) {
			return true;
		} else
			return false;
	}

	public boolean VerifySaveforLater(String AccountNo, String TypeofPayee, String TransferValue)
			throws InterruptedException {
		journalPage.enterTransferToAcc(AccountNo);
		journalPage.clickTransferDate("");
		Thread.sleep(1000);
		journalPage.selectTypeofPayee(TypeofPayee);
		journalPage.selectTransferTypePartial();
		journalPage.selectGiftforTaxYes();
		journalPage.selectQuantityPartial();
		Thread.sleep(1000);
		journalPage.enterTransferValue(TransferValue);
		journalPage.clickTransferDate("");
		Thread.sleep(2000);
		ctaPage.clickContinueBtn();
		processFormcheckPage.navigateTopage();
		Thread.sleep(1000);
		journalPage.clickSaveforLaterButton();
		return true;
	}

	public boolean VerifyTransferDescMMF(String AccountNo) throws InterruptedException {
		journalPage.enterTransferToAcc(AccountNo);
		journalPage.checkTotalfromPositions("0.00");
		Thread.sleep(2000);
		if (journalPage.checkTransferDesc("SPS004 to Retail")) {
			return true;
		} else
			return false;
	}

	public boolean VerifyTotalfromAllSelectionsMMF(String AccountNo, String TypeofPayee, String CashWithdrawal)
			throws InterruptedException {
		journalPage.enterTransferToAcc(AccountNo);
		journalPage.checkTotalfromPositions("0.00");
		Thread.sleep(1000);
		journalPage.selectTypeofPayee(TypeofPayee);
		journalPage.enterTotalAmountCashWithdrawal(CashWithdrawal);
		journalPage.checkTotalfromPositions("0.00");
		Thread.sleep(1000);
		if (journalPage.checkTotalfromAllSelections("4.00")) {
			return true;
		} else
			return false;
	}

	public boolean VerifyAdvisoryAccWithdrawalTitle(String AccountNo, String TypeofPayee, String CashWithdrawal)
			throws InterruptedException {
		journalPage.enterTransferToAcc(AccountNo);
		journalPage.checkTotalfromPositions("0.00");
		Thread.sleep(1000);
		journalPage.selectTypeofPayee(TypeofPayee);
		journalPage.selectGiftforTaxYes();
		journalPage.enterTotalAmountCashWithdrawal(CashWithdrawal);
		journalPage.checkTotalfromPositions("0.00");
		ctaPage.clickContinueBtn();
		processFormcheckPage.navigateTopage();
		if (journalPage.checkAdvisoryAccTitle("Advisory Account Withdrawal Information")) {
			return true;
		} else
			return false;
	}

	public boolean VerifyWarningPopUpforYesRadionBtnAdvisoryAccount(String AccountNo, String TypeofPayee,
			String CashWithdrawal, String errorText) throws InterruptedException {
		journalPage.enterTransferToAcc(AccountNo);
		journalPage.checkTotalfromPositions("0.00");
		Thread.sleep(1000);
		journalPage.selectTypeofPayee(TypeofPayee);
		journalPage.selectGiftforTaxYes();
		journalPage.enterTotalAmountCashWithdrawal(CashWithdrawal);
		journalPage.checkTotalfromPositions("0.00");
		ctaPage.clickContinueBtn();
		processFormcheckPage.navigateTopage();
		journalPage.selectYesRadioBtnAdvisoryAcc();
		if (achPage.getInvalidCharErrorMessage().contains(errorText)) {
			return true;
		} else
			return false;
	}

	public boolean VerifyJournalDropdown(String AccountNo, String TypeofPayee, String CashWithdrawal, String Journal)
			throws InterruptedException {
		journalPage.enterTransferToAcc(AccountNo);
		journalPage.checkTotalfromPositions("0.00");
		Thread.sleep(1000);
		journalPage.selectTypeofPayee(TypeofPayee);
		journalPage.selectGiftforTaxYes();
		journalPage.enterTotalAmountCashWithdrawal(CashWithdrawal);
		journalPage.checkTotalfromPositions("0.00");
		ctaPage.clickContinueBtn();
		processFormcheckPage.navigateTopage();
		journalPage.selectJournalfromDropdown("Journal");
		if (journalPage.checkJournalInformationTitle("Journal Information")) {
			return true;
		} else
			return false;
	}

	public boolean VerifyJournalWarningPopUpNoBeneficiaryTypeAccount(String AccountNo, String TypeofPayee,
			String CashWithdrawal, String errorText) throws InterruptedException {
		journalPage.enterTransferToAcc(AccountNo);
		journalPage.checkTotalfromPositions("0.00");
		Thread.sleep(1000);
		journalPage.selectTypeofPayee(TypeofPayee);
		journalPage.enterTotalAmountCashWithdrawal(CashWithdrawal);
		journalPage.checkTotalfromPositions("0.00");
		ctaPage.clickContinueBtn();
		if (achPage.getInvalidCharErrorMessage().contains(errorText)) {
			return true;
		} else
			return false;
	}

	public boolean VerifyJournalWarningPopUpNoGiftforTax(String AccountNo, String TypeofPayee, String CashWithdrawal,
			String errorText) throws InterruptedException {
		journalPage.enterTransferToAcc(AccountNo);
		journalPage.checkTotalfromPositions("0.00");
		Thread.sleep(1000);
		journalPage.selectTypeofPayee(TypeofPayee);
		journalPage.enterTotalAmountCashWithdrawal(CashWithdrawal);
		journalPage.checkTotalfromPositions("0.00");
		ctaPage.clickContinueBtn();
		if (achPage.getInvalidCharErrorMessage().contains(errorText)) {
			return true;
		} else
			return false;
	}

	public boolean VerifyJournalWarningPopUpNoJournal(String AccountNo, String TypeofPayee, String CashWithdrawal,
			String errorText) throws InterruptedException {
		journalPage.enterTransferToAcc(AccountNo);
		journalPage.checkTotalfromPositions("0.00");
		Thread.sleep(1000);
		journalPage.selectTypeofPayee(TypeofPayee);
		journalPage.selectGiftforTaxYes();
		journalPage.enterTotalAmountCashWithdrawal(CashWithdrawal);
		journalPage.checkTotalfromPositions("0.00");
		ctaPage.clickContinueBtn();
		if (achPage.getInvalidCharErrorMessage().contains(errorText)) {
			return true;
		} else
			return false;
	}

	public boolean VerifyJournalWarningPopWhenNoAttachmentTypeB(String AccountNo, String TypeofPayee,
			String TransferValue, String errorText) throws InterruptedException {
		journalPage.enterTransferToAcc(AccountNo);
		journalPage.clickTransferDate("");
		Thread.sleep(1000);
		journalPage.selectTypeofPayee(TypeofPayee);
		journalPage.selectTransferTypePartial();
		journalPage.selectGiftforTaxYes();
		journalPage.selectQuantityPartial();
		Thread.sleep(1000);
		journalPage.enterTransferValue(TransferValue);
		journalPage.clickTransferDate("");
		Thread.sleep(1000);
		ctaPage.clickContinueBtn();
		processFormcheckPage.navigateTopage();
		Thread.sleep(1000);
		SubmitJournalRequest();
		if (achPage.getInvalidCharErrorMessage().contains(errorText)) {
			return true;
		} else
			return false;
	}

	public void VerifyJournalFormSubmitMMFAdvisory(String AccountNo, String TypeofPayee, String CashWithdrawal)
			throws InterruptedException {
		journalPage.enterTransferToAcc(AccountNo);
		journalPage.checkTotalfromPositions("0.00");
		Thread.sleep(1000);
		journalPage.selectTypeofPayee(TypeofPayee);
		journalPage.selectGiftforTaxYes();
		Thread.sleep(1000);
		journalPage.enterTotalAmountCashWithdrawal(CashWithdrawal);
		journalPage.checkTotalfromPositions("0.00");
		journalPage.clickAttachmentBtn();
		newAttachmentPage.navigateTopage();
		newAttachmentPage.addAttachments();
		Thread.sleep(1000);
		ctaPage.clickContinueBtn();
		processFormcheckPage.navigateTopage();
		journalPage.selectYesRadioBtnAdvisoryAcc();
		_browser._browserDriver.switchTo().alert().accept();
		journalPage.clickContinueBtn();
		processFormcheckPage.navigateTopage();
		SubmitJournalRequest();
		processFormcheckPage.navigateTopage();
		SendJournalRequest();
	}

	public void VerifyJournalFormSubmitMMFNonAdvisory(String AccountNo, String TypeofPayee, String CashWithdrawal)
			throws InterruptedException {
		journalPage.enterTransferToAcc(AccountNo);
		journalPage.checkTotalfromPositions("0.00");
		Thread.sleep(1000);
		journalPage.selectTypeofPayee(TypeofPayee);
		journalPage.selectQuantityPartialMMF();
		journalPage.selectGiftforTaxYes();
		Thread.sleep(1000);
		journalPage.enterTotalAmountCashWithdrawal(CashWithdrawal);
		journalPage.checkTotalfromPositions("0.00");
		Thread.sleep(1000);
		journalPage.clickAttachmentBtn();
		newAttachmentPage.navigateTopage();
		newAttachmentPage.addAttachments();
		Thread.sleep(1000);
		ctaPage.clickContinueBtn();
		processFormcheckPage.navigateTopage();
		journalPage.selectYesRadioBtnAdvisoryAcc();
		_browser._browserDriver.switchTo().alert().accept();
		journalPage.clickContinueBtn();
		processFormcheckPage.navigateTopage();
		SubmitJournalRequest();
		processFormcheckPage.navigateTopage();
		SendJournalRequest();
	}

	public boolean VerifyTotalValueWithNoneBtnMMF(String AccountNo) throws InterruptedException {
		journalPage.enterTransferToAcc(AccountNo);
		journalPage.clickTransferDate("");
		Thread.sleep(1000);
		journalPage.selectTransferTypePartial();
		journalPage.selectQuantityNone();
		if (journalPage.checkTransferValue("0.00")) {
			return true;
		} else
			return false;
	}

	public void VerifyJournalFormSubmitSLOATypeD(String AccountNo, String TypeofPayee, String SLOA,
			String TransferValue) throws InterruptedException {
		journalPage.enterTransferToAcc(AccountNo);
		journalPage.clickTransferDate("");
		Thread.sleep(1000);
		journalPage.selectTypeofPayee(TypeofPayee);
		journalPage.selectStandingInstruction(SLOA);
		journalPage.selectTransferTypePartial();
		journalPage.selectGiftforTaxYes();
		journalPage.selectQuantityPartial();
		Thread.sleep(1000);
		journalPage.enterTransferValue(TransferValue);
		journalPage.clickTransferDate("");
		Thread.sleep(1000);
		journalPage.clickAttachmentBtn();
		newAttachmentPage.navigateTopage();
		newAttachmentPage.addAttachments();
		Thread.sleep(1000);
		ctaPage.clickContinueBtn();
		processFormcheckPage.navigateTopage();
		SubmitJournalRequest();
		processFormcheckPage.navigateTopage();
		SendJournalRequest();
	}

	public boolean VerifyJournalWarningPopUpWhenNoneRadioBtnSelected(String AccountNo, String TypeofPayee,
			String errorText) throws InterruptedException {
		journalPage.enterTransferToAcc(AccountNo);
		journalPage.clickTransferDate("");
		Thread.sleep(1000);
		journalPage.selectTypeofPayee(TypeofPayee);
		journalPage.selectTransferTypePartial();
		journalPage.selectGiftforTaxYes();
		journalPage.selectQuantityNone();
		Thread.sleep(1000);
		ctaPage.clickContinueBtn();
		if (achPage.getInvalidCharErrorMessage().contains(errorText)) {
			return true;
		} else
			return false;
	}

	public void VerifyJournalFormSubmitQuantityAll(String AccountNo, String TransferValue) throws InterruptedException {
		journalPage.enterTransferToAcc(AccountNo);
		journalPage.clickTransferDate("");
		Thread.sleep(1000);
		journalPage.selectTransferTypeFull();
		Thread.sleep(1000);
		journalPage.enterTransferValue(TransferValue);
		journalPage.clickTransferDate("");
		Thread.sleep(1000);
		ctaPage.clickContinueBtn();
		processFormcheckPage.navigateTopage();
		SubmitJournalRequest();
		processFormcheckPage.navigateTopage();
		SendJournalRequest();
	}

	public boolean TransferToAccDescription(String AccountNo) throws InterruptedException {
		journalPage.enterTransferToAcc(AccountNo);
		journalPage.clickTransferDate("");
		Thread.sleep(1000);
		if (journalPage.checkTransferToAccDescription("AUTO M TESTER 777 E WISCONIN AVE")) {
			return true;
		} else
			return false;
	}

	public boolean VerifyTotalfromValuationsTransferTypeFull(String AccountNo) throws InterruptedException {
		journalPage.enterTransferToAcc(AccountNo);
		journalPage.checkTotalfromPositions("0.00");
		Thread.sleep(1000);
		journalPage.selectTransferTypeFull();
		Thread.sleep(2000);
		return journalPage.getValue().equals(GetTotalfromValuations());
	}

	public String GetTotalfromValuations() {
		return journalPage.getTotalfromValuations();
	}

	public boolean VerifyNextandPreviousPage() {
		journalPage.clickNextButton();
		processFormcheckPage.navigateTopage();
		journalPage.clickPreviousButton();
		if (journalPage.checkJournalInformationTitle("Journal Information")) {
			return true;
		} else
			return false;
	}

	public boolean VerifyJournalWarningPopForTaxLot(String AccountNo, String TypeofPayee, String ShareNo,
			String errorText) throws InterruptedException {
		journalPage.enterTransferToAcc(AccountNo);
		journalPage.checkTotalfromPositions("0.00");
		Thread.sleep(1000);
		journalPage.selectTypeofPayee(TypeofPayee);
		journalPage.selectGiftforTaxYes();
		Thread.sleep(1000);
		journalPage.selectSecuritiesPartialQuantity();
		Thread.sleep(1000);
		journalPage.enterNoOfShares(ShareNo);
		journalPage.clickTaxLots();
		if (achPage.getInvalidCharErrorMessage().contains(errorText)) {
			return true;
		} else
			return false;
	}

	public void VerifyJournalFormSubmitSecurities(String AccountNo, String TypeofPayee, String ShareNo)
			throws InterruptedException {
		journalPage.enterTransferToAcc(AccountNo);
		journalPage.checkTotalfromPositions("0.00");
		Thread.sleep(1000);
		journalPage.selectTypeofPayee(TypeofPayee);
		journalPage.selectGiftforTaxYes();
		Thread.sleep(1000);
		journalPage.selectSecuritiesPartialQuantity();
		Thread.sleep(1000);
		journalPage.enterNoOfShares(ShareNo);
		Thread.sleep(1000);
		journalPage.clickAttachmentBtn();
		newAttachmentPage.navigateTopage();
		newAttachmentPage.addAttachments();
		Thread.sleep(1000);
		ctaPage.clickContinueBtn();
		processFormcheckPage.navigateTopage();
		journalPage.selectYesRadioBtnAdvisoryAcc();
		_browser._browserDriver.switchTo().alert().accept();
		journalPage.selectYesRadioBtnSecuritiesOut();
		journalPage.clickContinueBtn();
		processFormcheckPage.navigateTopage();
		SubmitJournalRequest();
		processFormcheckPage.navigateTopage();
		SendJournalRequest();
	}

	public void VerifyJournalFormSubmitAllSecurities(String AccountNo, String TypeofPayee, String ShareNo)
			throws InterruptedException {
		journalPage.enterTransferToAcc(AccountNo);
		journalPage.checkTotalfromPositions("0.00");
		Thread.sleep(1000);
		journalPage.selectTypeofPayee(TypeofPayee);
		journalPage.selectGiftforTaxYes();
		Thread.sleep(1000);
		journalPage.selectSecuritiesPartialQuantity();
		journalPage.selectSecuritiesAllQuantity();
		Thread.sleep(1000);
		journalPage.enterNoOfShares(ShareNo);
		Thread.sleep(1000);
		journalPage.clickAttachmentBtn();
		newAttachmentPage.navigateTopage();
		newAttachmentPage.addAttachments();
		Thread.sleep(1000);
		ctaPage.clickContinueBtn();
		processFormcheckPage.navigateTopage();
		journalPage.selectYesRadioBtnAdvisoryAcc();
		_browser._browserDriver.switchTo().alert().accept();
		journalPage.selectYesRadioBtnSecuritiesOut();
		journalPage.clickContinueBtn();
		processFormcheckPage.navigateTopage();
		SubmitJournalRequest();
		processFormcheckPage.navigateTopage();
		SendJournalRequest();
	}

	public void VerifyJournalFormSubmitSecurityandCash(String AccountNo, String TypeofPayee, String CashWithdrawal,
			String ShareNo) throws InterruptedException {
		journalPage.enterTransferToAcc(AccountNo);
		journalPage.checkTotalfromPositions("0.00");
		Thread.sleep(1000);
		journalPage.selectTypeofPayee(TypeofPayee);
		journalPage.selectGiftforTaxYes();
		journalPage.enterTotalAmountCashWithdrawal(CashWithdrawal);
		journalPage.checkTotalfromPositions("0.00");
		Thread.sleep(1000);
		journalPage.selectSecuritiesPartialQuantity();
		Thread.sleep(1000);
		journalPage.enterNoOfShares(ShareNo);
		Thread.sleep(1000);
		journalPage.clickAttachmentBtn();
		newAttachmentPage.navigateTopage();
		newAttachmentPage.addAttachments();
		Thread.sleep(1000);
		ctaPage.clickContinueBtn();
		processFormcheckPage.navigateTopage();
		journalPage.selectYesRadioBtnAdvisoryAcc();
		_browser._browserDriver.switchTo().alert().accept();
		journalPage.selectYesRadioBtnSecuritiesOut();
		journalPage.clickContinueBtn();
		processFormcheckPage.navigateTopage();
		SubmitJournalRequest();
		processFormcheckPage.navigateTopage();
		SendJournalRequest();
	}

	public void VerifyJournalFormSubmitTypeAWithSecurityandCash(String AccountNo, String TransferValue, String ShareNo)
			throws InterruptedException {
		journalPage.enterTransferToAcc(AccountNo);
		journalPage.clickTransferDate("");
		Thread.sleep(1000);
		journalPage.selectTransferTypePartial();
		journalPage.selectQuantityPartial();
		Thread.sleep(1000);
		journalPage.enterTransferValue(TransferValue);
		journalPage.clickTransferDate("");
		journalPage.selectSecuritiesPartialQuantity();
		Thread.sleep(1000);
		journalPage.enterNoOfShares(ShareNo);
		Thread.sleep(1000);
		ctaPage.clickContinueBtn();
		processFormcheckPage.navigateTopage();
		SubmitJournalRequest();
		processFormcheckPage.navigateTopage();
		SendJournalRequest();
	}

	public void VerifyJournalFormSubmitTypeDMMFandSecurity(String AccountNo, String TypeofPayee, String CashWithdrawal,
			String ShareNo2ndRow) throws InterruptedException {
		journalPage.enterTransferToAcc(AccountNo);
		journalPage.checkTotalfromPositions("0.00");
		Thread.sleep(1000);
		journalPage.selectTypeofPayee(TypeofPayee);
		journalPage.selectQuantityPartialMMF();
		journalPage.selectGiftforTaxYes();
		Thread.sleep(1000);
		journalPage.enterTotalAmountCashWithdrawal(CashWithdrawal);
		journalPage.checkTotalfromPositions("0.00");
		Thread.sleep(1000);
		journalPage.selectSecuritiesPartialQuantity2();
		Thread.sleep(1000);
		journalPage.enterNoOfShares2ndRow(ShareNo2ndRow);
		Thread.sleep(1000);
		journalPage.clickAttachmentBtn();
		newAttachmentPage.navigateTopage();
		newAttachmentPage.addAttachments();
		Thread.sleep(1000);
		ctaPage.clickContinueBtn();
		processFormcheckPage.navigateTopage();
		journalPage.selectYesRadioBtnAdvisoryAcc();
		_browser._browserDriver.switchTo().alert().accept();
		journalPage.selectYesRadioBtnSecuritiesOut();
		journalPage.clickContinueBtn();
		processFormcheckPage.navigateTopage();
		SubmitJournalRequest();
		_browser._browserDriver.switchTo().alert().accept();
		processFormcheckPage.navigateTopage();
		SendJournalRequest();
	}

	public boolean VerifyTotalValueWithTransferValueSecurity(String AccountNo, String ShareNo)
			throws InterruptedException {
		journalPage.enterTransferToAcc(AccountNo);
		journalPage.clickTransferDate("");
		Thread.sleep(1000);
		journalPage.selectTransferTypePartial();
		journalPage.selectSecuritiesAllQuantity();
		Thread.sleep(1000);
		journalPage.enterNoOfShares(ShareNo);
		return journalPage.getValueSecurity().equals(GetTransferValueSecurity());
	}

	public String GetTransferValueSecurity() {
		return journalPage.getTransferValueSecurity();
	}

	public boolean VerifyTransferDescIRA(String AccountNo) throws InterruptedException {
		journalPage.enterTransferToAcc(AccountNo);
		journalPage.checkTotalfromPositions("0.00");
		Thread.sleep(2000);
		if (journalPage.checkTransferDesc("IRA(BPM) to IRA")) {
			return true;
		} else
			return false;
	}

	public boolean VerifyTransferDescIRAtoIRA(String AccountNo) throws InterruptedException {
		journalPage.enterTransferToAcc(AccountNo);
		journalPage.checkTotalfromPositions("0.00");
		Thread.sleep(2000);
		if (journalPage.checkTransferDesc("IRA to IRA")) {
			return true;
		} else
			return false;
	}

	public boolean VerifyTransferDescIRACommingle(String AccountNo) throws InterruptedException {
		journalPage.enterTransferToAcc(AccountNo);
		journalPage.checkTotalfromPositions("0.00");
		Thread.sleep(2000);
		if (journalPage.checkTransferDesc("IRA Commingle")) {
			return true;
		} else
			return false;
	}

	public boolean VerifyIRAaccInfoTitle(String AccountNo, String TypeofPayee, String CashWithdrawal)
			throws InterruptedException {
		journalPage.enterTransferToAcc(AccountNo);
		journalPage.checkTotalfromPositions("0.00");
		Thread.sleep(1000);
		journalPage.selectTypeofPayee(TypeofPayee);
		journalPage.selectTransferTypePartial();
		journalPage.enterTotalAmountCashWithdrawal(CashWithdrawal);
		journalPage.checkTotalfromPositions("0.00");
		Thread.sleep(1000);
		ctaPage.clickContinueBtn();
		processFormcheckPage.navigateTopage();
		if (journalPage.getIRAContributionInfoTitle("IRA Contribution Information")) {
			return true;
		} else
			return false;
	}

	public boolean VerifyIRATypeField(String AccountNo, String TypeofPayee, String CashWithdrawal)
			throws InterruptedException {
		journalPage.enterTransferToAcc(AccountNo);
		journalPage.checkTotalfromPositions("0.00");
		Thread.sleep(1000);
		journalPage.selectTypeofPayee(TypeofPayee);
		journalPage.selectTransferTypePartial();
		journalPage.enterTotalAmountCashWithdrawal(CashWithdrawal);
		journalPage.checkTotalfromPositions("0.00");
		Thread.sleep(1000);
		ctaPage.clickContinueBtn();
		processFormcheckPage.navigateTopage();
		if (journalPage.getAccTypeTo("IRA")) {
			return true;
		} else
			return false;
	}

	public boolean VerifyIRADepositWithdrawalCodeWarningPopUp(String AccountNo, String TypeofPayee,
			String CashWithdrawal, String WithdrawalCode, String DepositCode, String errorText)
			throws InterruptedException {
		journalPage.enterTransferToAcc(AccountNo);
		journalPage.checkTotalfromPositions("0.00");
		Thread.sleep(1000);
		journalPage.selectTypeofPayee(TypeofPayee);
		journalPage.selectTransferTypePartial();
		journalPage.enterTotalAmountCashWithdrawal(CashWithdrawal);
		journalPage.checkTotalfromPositions("0.00");
		Thread.sleep(1000);
		ctaPage.clickContinueBtn();
		processFormcheckPage.navigateTopage();
		journalPage.selectOnFileDistributionForm();
		journalPage.clickWithdrawalCodeDrpdwn(WithdrawalCode);
		journalPage.clickDepositCodeDrpdwn(DepositCode);
		journalPage.clickContinueBtnIRA();
		if (achPage.getInvalidCharErrorMessage().contains(errorText)) {
			return true;
		} else
			return false;
	}

	public boolean VerifyIRADistributionFormWarningPopUp(String AccountNo, String TypeofPayee, String CashWithdrawal,
			String WithdrawalCode, String DepositCode, String errorText) throws InterruptedException {
		journalPage.enterTransferToAcc(AccountNo);
		journalPage.checkTotalfromPositions("0.00");
		Thread.sleep(1000);
		journalPage.selectTypeofPayee(TypeofPayee);
		journalPage.selectTransferTypePartial();
		journalPage.enterTotalAmountCashWithdrawal(CashWithdrawal);
		journalPage.checkTotalfromPositions("0.00");
		Thread.sleep(1000);
		ctaPage.clickContinueBtn();
		processFormcheckPage.navigateTopage();
		journalPage.clickWithdrawalCodeDrpdwn(WithdrawalCode);
		journalPage.clickDepositCodeDrpdwn(DepositCode);
		journalPage.clickContinueBtnIRA();
		if (achPage.getInvalidCharErrorMessage().contains(errorText)) {
			return true;
		} else
			return false;
	}

	public boolean VerifyAccNoOnIRAAccInfoPage(String AccountNo, String TypeofPayee, String CashWithdrawal)
			throws InterruptedException {
		journalPage.enterTransferToAcc(AccountNo);
		journalPage.checkTotalfromPositions("0.00");
		Thread.sleep(1000);
		journalPage.selectTypeofPayee(TypeofPayee);
		journalPage.selectTransferTypePartial();
		journalPage.enterTotalAmountCashWithdrawal(CashWithdrawal);
		journalPage.checkTotalfromPositions("0.00");
		Thread.sleep(1000);
		ctaPage.clickContinueBtn();
		processFormcheckPage.navigateTopage();
		if (journalPage.getAccNumber("48616390")) {
			return true;
		} else
			return false;
	}

	public void VerifyJournalFormSubmitIRATypeB_C_D_E(String AccountNo, String TypeofPayee, String CashWithdrawal,
			String WithdrawalCode, String DepositCode) throws InterruptedException {
		journalPage.enterTransferToAcc(AccountNo);
		journalPage.checkTotalfromPositions("0.00");
		Thread.sleep(1000);
		journalPage.selectTypeofPayee(TypeofPayee);
		journalPage.selectTransferTypePartial();
		journalPage.enterTotalAmountCashWithdrawal(CashWithdrawal);
		journalPage.checkTotalfromPositions("0.00");
		Thread.sleep(1000);
		journalPage.clickAttachmentBtn();
		newAttachmentPage.navigateTopage();
		newAttachmentPage.addAttachments();
		Thread.sleep(1000);
		ctaPage.clickContinueBtn();
		processFormcheckPage.navigateTopage();
		journalPage.clickWithdrawalCodeDrpdwn(WithdrawalCode);
		journalPage.selectOnFileDistributionForm();
		journalPage.clickDepositCodeDrpdwn(DepositCode);
		journalPage.clickContinueBtnIRA();
		journalPage.selectYesRadioBtnAdvisoryAcc();
		_browser._browserDriver.switchTo().alert().accept();
		journalPage.clickContinueBtn();
		processFormcheckPage.navigateTopage();
		SubmitJournalRequest();
		processFormcheckPage.navigateTopage();
		SendJournalRequest();
	}

	public void VerifyJournalFormSubmitWithSLOA(String AccountNo, String TypeofPayee, String SLOA,
			String CashWithdrawal, String WithdrawalCode, String DepositCode) throws InterruptedException {
		journalPage.enterTransferToAcc(AccountNo);
		journalPage.checkTotalfromPositions("0.00");
		Thread.sleep(1000);
		journalPage.selectTypeofPayee(TypeofPayee);
		journalPage.selectStandingInstruction(SLOA);
		journalPage.enterTotalAmountCashWithdrawal(CashWithdrawal);
		journalPage.checkTotalfromPositions("0.00");
		Thread.sleep(1000);
		journalPage.clickAttachmentBtn();
		newAttachmentPage.navigateTopage();
		newAttachmentPage.addAttachments();
		Thread.sleep(1000);
		ctaPage.clickContinueBtn();
		processFormcheckPage.navigateTopage();
		journalPage.clickWithdrawalCodeDrpdwn(WithdrawalCode);
		journalPage.selectOnFileDistributionForm();
		journalPage.clickDepositCodeDrpdwn(DepositCode);
		journalPage.clickContinueBtnIRA();
		journalPage.selectYesRadioBtnAdvisoryAcc();
		_browser._browserDriver.switchTo().alert().accept();
		journalPage.clickContinueBtn();
		processFormcheckPage.navigateTopage();
		SubmitJournalRequest();
		processFormcheckPage.navigateTopage();
		SendJournalRequest();
	}

	public void VerifyJournalFormSubmitTypeBSecurities(String AccountNo, String TypeofPayee, String ShareNo,
			String WithdrawalCode, String DepositCode) throws InterruptedException {
		journalPage.enterTransferToAcc(AccountNo);
		journalPage.clickTransferDate("");
		Thread.sleep(1000);
		journalPage.selectTransferTypePartial();
		journalPage.selectTypeofPayee(TypeofPayee);
		Thread.sleep(1000);
		journalPage.selectSecuritiesPartialQuantity();
		Thread.sleep(1000);
		journalPage.enterNoOfShares(ShareNo);
		Thread.sleep(1000);
		journalPage.clickAttachmentBtn();
		newAttachmentPage.navigateTopage();
		newAttachmentPage.addAttachments();
		Thread.sleep(1000);
		ctaPage.clickContinueBtn();
		processFormcheckPage.navigateTopage();
		journalPage.clickWithdrawalCodeDrpdwn(WithdrawalCode);
		journalPage.selectOnFileDistributionForm();
		journalPage.clickDepositCodeDrpdwn(DepositCode);
		journalPage.clickContinueBtnIRA();
		processFormcheckPage.navigateTopage();
		SubmitJournalRequest();
		processFormcheckPage.navigateTopage();
		SendJournalRequest();
	}

	public void VerifyJournalFormSubmitTypeDSecurities(String AccountNo, String TypeofPayee, String WithdrawalCode,
			String DepositCode) throws InterruptedException {
		journalPage.enterTransferToAcc(AccountNo);
		journalPage.clickTransferDate("");
		Thread.sleep(1000);
		journalPage.selectTransferTypePartial();
		journalPage.selectTypeofPayee(TypeofPayee);
		Thread.sleep(1000);
		journalPage.selectSecuritiesAllQuantity();
		Thread.sleep(1000);
		journalPage.clickAttachmentBtn();
		newAttachmentPage.navigateTopage();
		newAttachmentPage.addAttachments();
		Thread.sleep(1000);
		ctaPage.clickContinueBtn();
		processFormcheckPage.navigateTopage();
		journalPage.clickWithdrawalCodeDrpdwn(WithdrawalCode);
		journalPage.selectOnFileDistributionForm();
		journalPage.clickDepositCodeDrpdwn(DepositCode);
		journalPage.clickContinueBtnIRA();
		processFormcheckPage.navigateTopage();
		SubmitJournalRequest();
		processFormcheckPage.navigateTopage();
		SendJournalRequest();
	}

	public boolean VerifyJournalWarningPopWhenNoAttachmentIRA(String AccountNo, String TypeofPayee,
			String CashWithdrawal, String WithdrawalCode, String DepositCode, String errorText)
			throws InterruptedException {
		journalPage.enterTransferToAcc(AccountNo);
		journalPage.checkTotalfromPositions("0.00");
		Thread.sleep(1000);
		journalPage.selectTypeofPayee(TypeofPayee);
		Thread.sleep(1000);
		journalPage.enterTotalAmountCashWithdrawal(CashWithdrawal);
		journalPage.checkTotalfromPositions("0.00");
		Thread.sleep(1000);
		ctaPage.clickContinueBtn();
		processFormcheckPage.navigateTopage();
		journalPage.clickWithdrawalCodeDrpdwn(WithdrawalCode);
		journalPage.selectOnFileDistributionForm();
		journalPage.clickDepositCodeDrpdwn(DepositCode);
		journalPage.clickContinueBtnIRA();
		processFormcheckPage.navigateTopage();
		journalPage.selectYesRadioBtnAdvisoryAcc();
		_browser._browserDriver.switchTo().alert().accept();
		journalPage.clickContinueBtn();
		processFormcheckPage.navigateTopage();
		SubmitJournalRequest();
		if (achPage.getInvalidCharErrorMessage().contains(errorText)) {
			return true;
		} else
			return false;
	}

	public boolean VerifyJournalFormSubmitNoAdvisoryIRA(String AccountNo, String TypeofPayee, String CashWithdrawal,
			String WithdrawalCode, String DepositCode) throws InterruptedException {
		journalPage.enterTransferToAcc(AccountNo);
		journalPage.checkTotalfromPositions("0.00");
		Thread.sleep(1000);
		journalPage.selectTypeofPayee(TypeofPayee);
		Thread.sleep(1000);
		journalPage.enterTotalAmountCashWithdrawal(CashWithdrawal);
		journalPage.checkTotalfromPositions("0.00");
		Thread.sleep(1000);
		journalPage.clickAttachmentBtn();
		newAttachmentPage.navigateTopage();
		newAttachmentPage.addAttachments();
		Thread.sleep(1000);
		ctaPage.clickContinueBtn();
		processFormcheckPage.navigateTopage();
		journalPage.clickWithdrawalCodeDrpdwn(WithdrawalCode);
		journalPage.selectOnFileDistributionForm();
		journalPage.clickDepositCodeDrpdwn(DepositCode);
		journalPage.clickContinueBtnIRA();
		processFormcheckPage.navigateTopage();
		journalPage.selectNoRadioBtnAdvisoryAcc();
		journalPage.clickContinueBtn();
		processFormcheckPage.navigateTopage();
		SubmitJournalRequest();
		processFormcheckPage.navigateTopage();
		SendJournalRequest();
		return true;
	}

	public boolean VerifyTotalValueWhenCashWithdrawalGreater(String AccountNo, String TypeofPayee,
			String CashWithdrawal) throws InterruptedException {
		journalPage.enterTransferToAcc(AccountNo);
		journalPage.checkTotalfromPositions("0.00");
		Thread.sleep(1000);
		journalPage.selectTypeofPayee(TypeofPayee);
		Thread.sleep(1000);
		journalPage.enterTotalAmountCashWithdrawal(CashWithdrawal);
		journalPage.checkTotalfromPositions("0.00");
		return journalPage.getMMFValue().equals(GetTransferValueMMF());
	}

	public String GetTransferValueMMF() {
		return journalPage.getTransferValueMMF();
	}

	public boolean VerifyTransferFromAccNoOnAdvisoryAccInfoPage(String AccountNo, String TypeofPayee,
			String CashWithdrawal, String WithdrawalCode, String DepositCode) throws InterruptedException {
		journalPage.enterTransferToAcc(AccountNo);
		journalPage.checkTotalfromPositions("0.00");
		Thread.sleep(1000);
		journalPage.selectTypeofPayee(TypeofPayee);
		journalPage.selectTransferTypePartial();
		journalPage.enterTotalAmountCashWithdrawal(CashWithdrawal);
		journalPage.checkTotalfromPositions("0.00");
		Thread.sleep(1000);
		ctaPage.clickContinueBtn();
		processFormcheckPage.navigateTopage();
		journalPage.clickWithdrawalCodeDrpdwn(WithdrawalCode);
		journalPage.selectOnFileDistributionForm();
		journalPage.clickDepositCodeDrpdwn(DepositCode);
		journalPage.clickContinueBtnIRA();
		processFormcheckPage.navigateTopage();
		if (journalPage.getTransferFromAccNumber("16869265")) {
			return true;
		} else
			return false;
	}

	public boolean VerifyTransferToAccNoOnAdvisoryAccInfoPage(String AccountNo, String TypeofPayee,
			String CashWithdrawal, String WithdrawalCode, String DepositCode) throws InterruptedException {
		journalPage.enterTransferToAcc(AccountNo);
		journalPage.checkTotalfromPositions("0.00");
		Thread.sleep(1000);
		journalPage.selectTypeofPayee(TypeofPayee);
		journalPage.selectTransferTypePartial();
		journalPage.enterTotalAmountCashWithdrawal(CashWithdrawal);
		journalPage.checkTotalfromPositions("0.00");
		Thread.sleep(1000);
		ctaPage.clickContinueBtn();
		processFormcheckPage.navigateTopage();
		journalPage.clickWithdrawalCodeDrpdwn(WithdrawalCode);
		journalPage.selectOnFileDistributionForm();
		journalPage.clickDepositCodeDrpdwn(DepositCode);
		journalPage.clickContinueBtnIRA();
		processFormcheckPage.navigateTopage();
		if (journalPage.getTransferToAccNumber("74116970")) {
			return true;
		} else
			return false;
	}

	public void VerifyJournalFormSubmitTypeBFull(String AccountNo, String TypeofPayee, String WithdrawalCode,
			String DepositCode) throws InterruptedException {
		journalPage.enterTransferToAcc(AccountNo);
		journalPage.clickTransferDate("");
		Thread.sleep(1000);
		journalPage.selectTypeofPayee(TypeofPayee);
		journalPage.selectTransferTypeFull();
		Thread.sleep(1000);
		journalPage.clickAttachmentBtn();
		newAttachmentPage.navigateTopage();
		newAttachmentPage.addAttachments();
		Thread.sleep(1000);
		ctaPage.clickContinueBtn();
		processFormcheckPage.navigateTopage();
		journalPage.clickWithdrawalCodeDrpdwn(WithdrawalCode);
		journalPage.selectOnFileDistributionForm();
		journalPage.clickDepositCodeDrpdwn(DepositCode);
		journalPage.clickContinueBtnIRA();
		processFormcheckPage.navigateTopage();
		SubmitJournalRequest();
		processFormcheckPage.navigateTopage();
		SendJournalRequest();
	}

	public boolean VerifyTransferDescRetailtoIRA(String AccountNo) throws InterruptedException {
		journalPage.enterTransferToAcc(AccountNo);
		journalPage.clickTransferDate("");
		Thread.sleep(1000);
		if (journalPage.checkTransferDesc("Retail to IRA")
				&& journalPage.checkTransferToAccDescription("ROBERT W BAIRD & CO INC TTEE FBO BABS BREWER IRA")) {
			return true;
		} else
			return false;
	}

	public boolean VerifyIRAAccInfoFields(String AccountNo, String TypeofPayee, String TransferValue)
			throws InterruptedException {
		journalPage.enterTransferToAcc(AccountNo);
		journalPage.clickTransferDate("");
		Thread.sleep(1000);
		journalPage.selectTypeofPayee(TypeofPayee);
		journalPage.selectTransferTypePartial();
		journalPage.selectQuantityPartial();
		Thread.sleep(1000);
		journalPage.enterTransferValue(TransferValue);
		journalPage.clickTransferDate("");
		Thread.sleep(1000);
		ctaPage.clickContinueBtn();
		processFormcheckPage.navigateTopage();
		if (journalPage.getAccTypeFrom("Non-IRA") && journalPage.getAccTypeTo("IRA")) {
			return true;
		} else
			return false;
	}

	public boolean VerifyRetailToIRAJournalFormSubmit(String AccountNo, String TypeofPayee, String SLOA,
			String TransferValue, String DepositCode) throws InterruptedException {
		journalPage.enterTransferToAcc(AccountNo);
		journalPage.clickTransferDate("");
		Thread.sleep(1000);
		journalPage.selectTypeofPayee(TypeofPayee);
		journalPage.selectStandingInstruction(SLOA);
		journalPage.selectTransferTypePartial();
		journalPage.selectQuantityPartial();
		Thread.sleep(1000);
		journalPage.enterTransferValue(TransferValue);
		journalPage.clickTransferDate("");
		Thread.sleep(1000);
		journalPage.clickAttachmentBtn();
		newAttachmentPage.navigateTopage();
		newAttachmentPage.addAttachments();
		Thread.sleep(1000);
		ctaPage.clickContinueBtn();
		processFormcheckPage.navigateTopage();
		journalPage.clickDepositCodeDrpdwn(DepositCode);
		journalPage.clickContinueBtnIRA();
		processFormcheckPage.navigateTopage();
		SubmitJournalRequest();
		processFormcheckPage.navigateTopage();
		SendJournalRequest();
		return true;
	}

	public boolean VerifyRetailToIRAJournalFormSubmitA(String AccountNo, String CashWithdrawal, String DepositCode)
			throws InterruptedException {
		journalPage.enterTransferToAcc(AccountNo);
		journalPage.checkTotalfromPositions("0.00");
		Thread.sleep(1000);
		journalPage.enterTotalAmountCashWithdrawal(CashWithdrawal);
		journalPage.checkTotalfromPositions("0.00");
		Thread.sleep(1000);
		journalPage.clickAttachmentBtn();
		newAttachmentPage.navigateTopage();
		newAttachmentPage.addAttachments();
		Thread.sleep(1000);
		ctaPage.clickContinueBtn();
		processFormcheckPage.navigateTopage();
		journalPage.clickDepositCodeDrpdwn(DepositCode);
		journalPage.clickContinueBtnIRA();
		journalPage.selectYesRadioBtnAdvisoryAcc();
		_browser._browserDriver.switchTo().alert().accept();
		journalPage.clickContinueBtn();
		processFormcheckPage.navigateTopage();
		SubmitJournalRequest();
		processFormcheckPage.navigateTopage();
		SendJournalRequest();
		return true;
	}

	public boolean VerifyTransferDescRetailToIRA(String AccountNo) throws InterruptedException {
		journalPage.enterTransferToAcc(AccountNo);
		journalPage.checkTotalfromPositions("0.00");
		Thread.sleep(1000);
		if (journalPage.checkTransferDesc("SPS004 to IRA")) {
			return true;
		} else
			return false;
	}

	public boolean VerifyRetailToIRAJournalFormSubmitFull(String AccountNo, String TypeofPayee, String DepositCode)
			throws InterruptedException {
		journalPage.enterTransferToAcc(AccountNo);
		journalPage.clickTransferDate("");
		Thread.sleep(1000);
		journalPage.selectTypeofPayee(TypeofPayee);
		journalPage.selectTransferTypeFull();
		_browser._browserDriver.switchTo().alert().accept();
		Thread.sleep(1000);
		journalPage.clickAttachmentBtn();
		newAttachmentPage.navigateTopage();
		newAttachmentPage.addAttachments();
		Thread.sleep(1000);
		ctaPage.clickContinueBtn();
		processFormcheckPage.navigateTopage();
		journalPage.clickDepositCodeDrpdwn(DepositCode);
		journalPage.clickContinueBtnIRA();
		processFormcheckPage.navigateTopage();
		SubmitJournalRequest();
		processFormcheckPage.navigateTopage();
		SendJournalRequest();
		return true;
	}

	public boolean VerifyJournalWarningPopWhenNoAttachment(String AccountNo, String TypeofPayee, String TransferValue,
			String DepositCode, String errorText) throws InterruptedException {
		journalPage.enterTransferToAcc(AccountNo);
		journalPage.clickTransferDate("");
		Thread.sleep(1000);
		journalPage.selectTypeofPayee(TypeofPayee);
		journalPage.selectTransferTypePartial();
		journalPage.selectQuantityPartial();
		Thread.sleep(1000);
		journalPage.enterTransferValue(TransferValue);
		journalPage.clickTransferDate("");
		Thread.sleep(1000);
		ctaPage.clickContinueBtn();
		processFormcheckPage.navigateTopage();
		journalPage.clickDepositCodeDrpdwn(DepositCode);
		journalPage.clickContinueBtnIRA();
		processFormcheckPage.navigateTopage();
		SubmitJournalRequest();
		if (achPage.getInvalidCharErrorMessage().contains(errorText)) {
			return true;
		} else
			return false;
	}

	public boolean VerifyTransferDescIRAtoRetail(String AccountNo) throws InterruptedException {
		journalPage.enterTransferToAcc(AccountNo);
		journalPage.checkTotalfromPositions("0.00");
		Thread.sleep(1000);
		if (journalPage.checkTransferDesc("IRA(BPM) to Retail")) {
			return true;
		} else
			return false;
	}

	public boolean VerifyIRAAccInfoFieldsForIRAtoRetail(String AccountNo, String TypeofPayee, String CashWithdrawal)
			throws InterruptedException {
		journalPage.enterTransferToAcc(AccountNo);
		journalPage.checkTotalfromPositions("0.00");
		Thread.sleep(1000);
		journalPage.selectTypeofPayee(TypeofPayee);
		journalPage.enterTotalAmountCashWithdrawal(CashWithdrawal);
		journalPage.checkTotalfromPositions("0.00");
		Thread.sleep(1000);
		ctaPage.clickContinueBtn();
		processFormcheckPage.navigateTopage();
		if (journalPage.getAccTypeFrom("IRA") && journalPage.getAccTypeToIRAtoRetail("Non-IRA")
				&& journalPage.getAccNumber("19401744")) {
			return true;
		} else
			return false;
	}

	public boolean VerifyIRAtoRetailJournalFormSubmit(String AccountNo, String TypeofPayee, String SLOA,
			String CashWithdrawal, String WithdrawalCode, String FederalTax, String StateTax)
			throws InterruptedException {
		journalPage.enterTransferToAcc(AccountNo);
		journalPage.checkTotalfromPositions("0.00");
		Thread.sleep(1000);
		journalPage.selectTypeofPayee(TypeofPayee);
		journalPage.selectStandingInstruction(SLOA);
		journalPage.enterTotalAmountCashWithdrawal(CashWithdrawal);
		journalPage.checkTotalfromPositions("0.00");
		Thread.sleep(1000);
		journalPage.clickAttachmentBtn();
		newAttachmentPage.navigateTopage();
		newAttachmentPage.addAttachments();
		Thread.sleep(1000);
		ctaPage.clickContinueBtn();
		processFormcheckPage.navigateTopage();
		journalPage.clickWithdrawalCodeDrpdwn(WithdrawalCode);
		journalPage.selectOnFileDistributionForm();
		journalPage.enterFederalTax(FederalTax);
		journalPage.enterStateTax(StateTax);
		journalPage.clickContinueBtnIRA();
		processFormcheckPage.navigateTopage();
		journalPage.selectYesRadioBtnAdvisoryAcc();
		_browser._browserDriver.switchTo().alert().accept();
		journalPage.clickContinueBtn();
		SubmitJournalRequest();
		processFormcheckPage.navigateTopage();
		SendJournalRequest();
		return true;
	}

	public boolean VerifyWithholdingFieldsWithFederalTax(String AccountNo, String TypeofPayee, String SLOA,
			String CashWithdrawal, String WithdrawalCode, String FederalTax, String StateTax)
			throws InterruptedException {
		journalPage.enterTransferToAcc(AccountNo);
		journalPage.checkTotalfromPositions("0.00");
		Thread.sleep(1000);
		journalPage.selectTypeofPayee(TypeofPayee);
		journalPage.selectStandingInstruction(SLOA);
		journalPage.enterTotalAmountCashWithdrawal(CashWithdrawal);
		journalPage.checkTotalfromPositions("0.00");
		Thread.sleep(1000);
		journalPage.clickAttachmentBtn();
		newAttachmentPage.navigateTopage();
		newAttachmentPage.addAttachments();
		Thread.sleep(1000);
		ctaPage.clickContinueBtn();
		processFormcheckPage.navigateTopage();
		journalPage.clickWithdrawalCodeDrpdwn(WithdrawalCode);
		journalPage.enterFederalTax(FederalTax);
		journalPage.selectOnFileDistributionForm();
		journalPage.enterStateTax(StateTax);
		if (journalPage.checkFinalAmount("$1.80") && journalPage.getFedWithholding("$0.20")
				&& journalPage.getStateWithholding("$0.00")) {
			return true;
		} else
			return false;
	}
	
	public boolean VerifyWithholdingFieldsWithStateTax(String AccountNo, String TypeofPayee, String SLOA,
			String CashWithdrawal, String WithdrawalCode, String FederalTax, String StateTax)
			throws InterruptedException {
		journalPage.enterTransferToAcc(AccountNo);
		journalPage.checkTotalfromPositions("0.00");
		Thread.sleep(1000);
		journalPage.selectTypeofPayee(TypeofPayee);
		journalPage.selectStandingInstruction(SLOA);
		journalPage.enterTotalAmountCashWithdrawal(CashWithdrawal);
		journalPage.checkTotalfromPositions("0.00");
		Thread.sleep(1000);
		journalPage.clickAttachmentBtn();
		newAttachmentPage.navigateTopage();
		newAttachmentPage.addAttachments();
		Thread.sleep(2000);
		ctaPage.clickContinueBtn();
		processFormcheckPage.navigateTopage();
		journalPage.clickWithdrawalCodeDrpdwn(WithdrawalCode);		
		journalPage.enterFederalTax(FederalTax);
		journalPage.enterStateTax(StateTax);
		journalPage.selectOnFileDistributionForm();
		if (journalPage.checkFinalAmount("$1.80") && journalPage.getFedWithholding("$0.00")
				&& journalPage.getStateWithholding("$0.20")) {
			return true;
		} else
			return false;
	}
	
	public boolean VerifyWarningPopUpForInvalidStateTax(String AccountNo, String TypeofPayee, String SLOA,
			String CashWithdrawal, String WithdrawalCode, String FederalTax, String StateTax, String errorText)
			throws InterruptedException {
		journalPage.enterTransferToAcc(AccountNo);
		journalPage.checkTotalfromPositions("0.00");
		Thread.sleep(1000);
		journalPage.selectTypeofPayee(TypeofPayee);
		journalPage.selectStandingInstruction(SLOA);
		journalPage.enterTotalAmountCashWithdrawal(CashWithdrawal);
		journalPage.checkTotalfromPositions("0.00");
		Thread.sleep(1000);
		journalPage.clickAttachmentBtn();
		newAttachmentPage.navigateTopage();
		newAttachmentPage.addAttachments();
		Thread.sleep(2000);
		ctaPage.clickContinueBtn();
		processFormcheckPage.navigateTopage();
		journalPage.clickWithdrawalCodeDrpdwn(WithdrawalCode);		
		journalPage.enterFederalTax(FederalTax);
		journalPage.enterStateTax(StateTax);
		journalPage.selectOnFileDistributionForm();
		if (ctaPage.getInvalidCharErrorMessage().contains(errorText)) {
			return true;
		} else
			return false;
	}
	
	public boolean VerifyWarningPopUpForInvalidFederalTax(String AccountNo, String TypeofPayee, String SLOA,
			String CashWithdrawal, String WithdrawalCode,  String StateTax, String FederalTax, String errorText)
			throws InterruptedException {
		journalPage.enterTransferToAcc(AccountNo);
		journalPage.checkTotalfromPositions("0.00");
		Thread.sleep(1000);
		journalPage.selectTypeofPayee(TypeofPayee);
		journalPage.selectStandingInstruction(SLOA);
		journalPage.enterTotalAmountCashWithdrawal(CashWithdrawal);
		journalPage.checkTotalfromPositions("0.00");
		Thread.sleep(1000);
		journalPage.clickAttachmentBtn();
		newAttachmentPage.navigateTopage();
		newAttachmentPage.addAttachments();
		Thread.sleep(2000);
		ctaPage.clickContinueBtn();
		processFormcheckPage.navigateTopage();
		journalPage.clickWithdrawalCodeDrpdwn(WithdrawalCode);		
		journalPage.enterStateTax(StateTax);
		journalPage.enterFederalTax(FederalTax);		
		journalPage.selectOnFileDistributionForm();
		if (ctaPage.getInvalidCharErrorMessage().contains(errorText)) {
			return true;
		} else
			return false;
	}
	
	public boolean VerifyIRAtoRetailJournalFormSubmitNoAdvisory(String AccountNo, String TypeofPayee, String SLOA,
			String CashWithdrawal, String WithdrawalCode, String FederalTax, String StateTax)
			throws InterruptedException {
		journalPage.enterTransferToAcc(AccountNo);
		journalPage.checkTotalfromPositions("0.00");
		Thread.sleep(1000);
		journalPage.selectTypeofPayee(TypeofPayee);
		journalPage.selectStandingInstruction(SLOA);
		journalPage.enterTotalAmountCashWithdrawal(CashWithdrawal);
		journalPage.checkTotalfromPositions("0.00");
		Thread.sleep(1000);
		journalPage.clickAttachmentBtn();
		newAttachmentPage.navigateTopage();
		newAttachmentPage.addAttachments();
		Thread.sleep(1000);
		ctaPage.clickContinueBtn();
		processFormcheckPage.navigateTopage();
		journalPage.clickWithdrawalCodeDrpdwn(WithdrawalCode);
		journalPage.selectOnFileDistributionForm();
		journalPage.enterFederalTax(FederalTax);
		journalPage.enterStateTax(StateTax);
		journalPage.clickContinueBtnIRA();
		processFormcheckPage.navigateTopage();
		journalPage.selectNoRadioBtnAdvisoryAcc();
		journalPage.clickContinueBtn();
		SubmitJournalRequest();
		processFormcheckPage.navigateTopage();
		SendJournalRequest();
		return true;
	}
	
	public boolean VerifyIRAtoRetailJournalFormSubmitCash(String AccountNo, String TypeofPayee,
			String TransferValue, String WithdrawalCode, String FederalTax, String StateTax)
			throws InterruptedException {
		journalPage.enterTransferToAcc(AccountNo);
		journalPage.clickTransferDate("");
		Thread.sleep(1000);
		journalPage.selectTypeofPayee(TypeofPayee);
		journalPage.selectTransferTypePartial();
		journalPage.selectQuantityPartial();
		Thread.sleep(1000);
		journalPage.enterTransferValue(TransferValue);
		journalPage.clickTransferDate("");
		Thread.sleep(1000);
		journalPage.clickAttachmentBtn();
		newAttachmentPage.navigateTopage();
		newAttachmentPage.addAttachments();
		Thread.sleep(1000);
		ctaPage.clickContinueBtn();
		processFormcheckPage.navigateTopage();
		journalPage.clickWithdrawalCodeDrpdwn(WithdrawalCode);
		journalPage.selectOnFileDistributionForm();
		journalPage.enterFederalTax(FederalTax);
		journalPage.enterStateTax(StateTax);
		journalPage.clickContinueBtnIRA();
		processFormcheckPage.navigateTopage();
		SubmitJournalRequest();
		processFormcheckPage.navigateTopage();
		SendJournalRequest();
		return true;
	}
	
	public boolean VerifyTransDescIRAtoRetail(String AccountNo) throws InterruptedException {
		journalPage.enterTransferToAcc(AccountNo);
		journalPage.clickTransferDate("");
		Thread.sleep(1000);
		if (journalPage.checkTransferDesc("IRA to Retail")) {
			return true;
		} else
			return false;
	}
	
	public boolean VerifyIRAtoRetailJournalFormSubmitFullTransfer(String AccountNo, String TypeofPayee,
			String TransferValue, String WithdrawalCode, String FederalTax, String StateTax)
			throws InterruptedException {
		journalPage.enterTransferToAcc(AccountNo);
		journalPage.clickTransferDate("");
		Thread.sleep(1000);
		journalPage.selectTypeofPayee(TypeofPayee);
		journalPage.selectTransferTypeFull();		
		Thread.sleep(1000);
		journalPage.clickAttachmentBtn();
		newAttachmentPage.navigateTopage();
		newAttachmentPage.addAttachments();
		Thread.sleep(1000);
		ctaPage.clickContinueBtn();
		processFormcheckPage.navigateTopage();
		journalPage.clickWithdrawalCodeDrpdwn(WithdrawalCode);
		journalPage.selectOnFileDistributionForm();
		journalPage.enterFederalTax(FederalTax);
		journalPage.enterStateTax(StateTax);
		journalPage.clickContinueBtnIRA();
		processFormcheckPage.navigateTopage();
		SubmitJournalRequest();
		processFormcheckPage.navigateTopage();
		SendJournalRequest();
		return true;
	}
}