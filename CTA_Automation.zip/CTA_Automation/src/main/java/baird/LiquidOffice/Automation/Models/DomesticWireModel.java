package baird.LiquidOffice.Automation.Models;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import baird.core.Automation.WebDrivers.Browser;
import baird.core.Automation.WebDrivers.Elements.HtmlElementImpl;

/**
 * @author AmitaKumari
 */

public class DomesticWireModel extends BaseModel {

	public DomesticWireModel(Browser obj) {
		super(obj);
	}

	@FindBy(id = "TO_ACCOUNT")
	WebElement txt_accountno;

	@FindBy(id = "TRANSFER_DATE")
	WebElement txt_transferdate;

	@FindBy(id = "Wire_Information")
	WebElement txt_wireinfo;
	
	@FindBy(id = "WINS_NO")
	WebElement txt_wireinstruction;
	
	@FindBy(id = "ACCOUNT_NUMBER")
	WebElement txt_accnumber;
	
	@FindBy(id = "ACCOUNT_NUMBER_2")
	WebElement txt_accnumber2;
	
	@FindBy(id = "mmfChoicesDom")
	WebElement txt_cashormmf;
	
	@FindBy(id = "btnExisting")
	WebElement btn_wireinstruction;
	
	@FindBy(id = "DTB__WINS_TBL_0_btnSelect")
	WebElement btn_selectRecordTypeA;
	
	@FindBy(id = "bankName")
	WebElement txt_bankname;

	@FindBy(id = "accountName")
	WebElement txt_nameofacc;

	@FindBy(id = "ABA")
	WebElement txt_bankaba;

	@FindBy(id = "BANK_ACCOUNT")
	WebElement txt_bankaccnumber;
	
	@FindBy(id = "bankCity")
	WebElement txt_city;
	
	@FindBy(id = "BANK_STATE")
	WebElement txt_state;
	
	@FindBy(id = "beneAcctDom")
	WebElement txt_finalaccnumber;
	
	@FindBy(id = "beneNameDom")
	WebElement txt_finalname;
	
	@FindBy(id = "beneAcctNon")
	WebElement txt_finalaccnumber2;
	
	@FindBy(id = "beneNameNon")
	WebElement txt_finalname2;
	
	@FindBy(id = "feeDom_RadioButton16")
	WebElement radiobtn_fa;
	
	@FindBy(id = "feeDom_Radio4_1")
	WebElement radiobtn_client;
	
	@FindBy(id = "OFAC_RadioButton32")
	WebElement radiobtn_yesfa;
	
	@FindBy(id = "feeDom_RadioButton16")
	WebElement radiobtn_yesfammf;
	
	@FindBy(id = "selectPhone_RadioButton39_1")
	WebElement radiobtn_businessphone;
	
	@FindBy(id = "HOME_PHONE")
	WebElement txt_homephone;
	
	@FindBy(id = "Entry47")
	WebElement txt_wirefeeclient;
	
	@FindBy(id = "AmountDom")
	WebElement txt_amount;
	
	@FindBy(id = "FUTURE_DATE")
	WebElement txt_date;
	
	@FindBy(id = "cashMarginDom_Radio3_1")
	WebElement radiobtn_cash;
	
	@FindBy(id = "cashMarginDom_RadioButton15")
	WebElement radiobtn_margin;
	
	@FindBy(id = "StandingLOADom")
	WebElement drpdwn_standinginst;
	
	@FindBy(id = "tobDom")
	WebElement drpdwn_beneficiarytype;
	
	@FindBy(id = "ATTACHMENTS_3")
	WebElement btn_attachment;
	
	@FindBy(id = "btnContinue")
	WebElement btn_continue;
	
	@FindBy(id = "addInfoNon1")
	WebElement txt_thirdparty;
	
	@FindBy(id = "AccountOpenLengthNon_RadioButton34")
	WebElement radiobtn_acclength2;
	
	@FindBy(id = "AccountOpenLengthNon_RadioButton35")
	WebElement radiobtn_acclength1;
	
	@FindBy(id = "chkVerbalConfirmNon")
	WebElement chkbox_attestation;

	@FindBy(id = "Attest")
	WebElement txt_attestorname;
	
	@FindBy(id = "DTB__tblAdvisoryAcctWithdrawalInfo_0_SourceAccountModelChange_RadioButton11_5")
	WebElement radiobtn_noadvisory;
	
	@FindBy(id = "DTB__tblAdvisoryAcctWithdrawalInfo_0_SourceAccountModelChange_RadioButton10_5")
	WebElement radiobtn_yesadvisory;
	
	@FindBy(id = "btnSubmit")
	WebElement btn_submit;
	
	@FindBy(id = "btnSend")
	WebElement btn_send;
	
	@FindBy(id = "ATTEST_NO_DUPE")
	WebElement chkbox_noduplicateconfirm;
	
	@FindBy(id = "btnReset")
	WebElement btn_reset;

	@FindBy(id = "btnSave")
	WebElement btn_save;

	@FindBy(id = "btnBack")
	WebElement btn_back;
	
	public HtmlElementImpl getTxt_transfertoacc() {
		return new HtmlElementImpl(txt_accountno);
	}
	
	public HtmlElementImpl getTxt_cashorMMF() {
		return new HtmlElementImpl(txt_cashormmf);
	}
	
	public HtmlElementImpl getTxt_transferdate() {
		return new HtmlElementImpl(txt_transferdate);
	}
	
	public HtmlElementImpl getTxt_wireinfo() {
		return new HtmlElementImpl(txt_wireinfo);
	}
	
	public HtmlElementImpl getTxt_wireinstruction() {
		return new HtmlElementImpl(txt_wireinstruction);
	}
	
	public HtmlElementImpl getBtn_wireinstruction() {
		return new HtmlElementImpl(btn_wireinstruction);
	}
	
	public HtmlElementImpl getBtn_selectrecordtypeA() {
		return new HtmlElementImpl(btn_selectRecordTypeA);
	}
	
	public HtmlElementImpl getTxt_accnumber() {
		return new HtmlElementImpl(txt_accnumber);
	}
	
	public HtmlElementImpl getTxt_accnumber2() {
		return new HtmlElementImpl(txt_accnumber2);
	}
	
	public HtmlElementImpl getTxt_bankname() {
		return new HtmlElementImpl(txt_bankname);
	}

	public HtmlElementImpl getTxt_nameOfAccount() {
		return new HtmlElementImpl(txt_nameofacc);
	}

	public HtmlElementImpl getTxt_bankaba() {
		return new HtmlElementImpl(txt_bankaba);
	}

	public HtmlElementImpl getTxt_bankaccnumber() {
		return new HtmlElementImpl(txt_bankaccnumber);
	}
	
	public HtmlElementImpl getTxt_city() {
		return new HtmlElementImpl(txt_city);
	}
	
	public HtmlElementImpl getTxt_state() {
		return new HtmlElementImpl(txt_state);
	}
	
	public HtmlElementImpl getTxt_finalaccnumber() {
		return new HtmlElementImpl(txt_finalaccnumber);
	}
	
	public HtmlElementImpl getTxt_finalname() {
		return new HtmlElementImpl(txt_finalname);
	}
	
	public HtmlElementImpl getTxt_finalaccnumber2() {
		return new HtmlElementImpl(txt_finalaccnumber2);
	}
	
	public HtmlElementImpl getTxt_finalname2() {
		return new HtmlElementImpl(txt_finalname2);
	}
	
	public HtmlElementImpl getRadiobtn_fa() {
		return new HtmlElementImpl(radiobtn_fa);
	}
	
	public HtmlElementImpl getRadiobtn_client() {
		return new HtmlElementImpl(radiobtn_client);
	}
	
	public HtmlElementImpl getRadiobtn_yesfa() {
		return new HtmlElementImpl(radiobtn_yesfa);
	}
	
	public HtmlElementImpl getRadiobtn_yesfammf() {
		return new HtmlElementImpl(radiobtn_yesfammf);
	}
	
	public HtmlElementImpl getRadiobtn_businessphone() {
		return new HtmlElementImpl(radiobtn_businessphone);
	}
	
	public HtmlElementImpl getTxt_homephone() {
		return new HtmlElementImpl(txt_homephone);
	}
	
	public HtmlElementImpl getTxt_WireFeeClient() {
		return new HtmlElementImpl(txt_wirefeeclient);
	}
	
	public HtmlElementImpl getTxt_amount() {
		return new HtmlElementImpl(txt_amount);
	}
	
	public HtmlElementImpl getTxt_issuedate() {
		return new HtmlElementImpl(txt_date);
	}
	
	public HtmlElementImpl getRadiobtn_cash() {
		return new HtmlElementImpl(radiobtn_cash);
	}
	
	public HtmlElementImpl getRadiobtn_margin() {
		return new HtmlElementImpl(radiobtn_margin);
	}
	
	public HtmlElementImpl getDrpdwn_standinginst() {
		return new HtmlElementImpl(drpdwn_standinginst);
	}
	
	public HtmlElementImpl getDrpdwn_beneficiarytype() {
		return new HtmlElementImpl(drpdwn_beneficiarytype);
	}
	
	public HtmlElementImpl getBtn_attachment() {
		return new HtmlElementImpl(btn_attachment);
	}
	
	public HtmlElementImpl getBtn_continue() {
		return new HtmlElementImpl(btn_continue);
	}
	
	public HtmlElementImpl getTxt_thirdparty() {
		return new HtmlElementImpl(txt_thirdparty);
	}
	
	public HtmlElementImpl getBtn_acclength2() {
		return new HtmlElementImpl(radiobtn_acclength2);
	}
	
	public HtmlElementImpl getBtn_acclength1() {
		return new HtmlElementImpl(radiobtn_acclength1);
	}
	
	public HtmlElementImpl getChkbox_attestation() {
		return new HtmlElementImpl(chkbox_attestation);
	}

	public HtmlElementImpl getTxt_attestorname() {
		return new HtmlElementImpl(txt_attestorname);
	}
	
	public HtmlElementImpl getRadiobtn_noadvisory() {
		return new HtmlElementImpl(radiobtn_noadvisory);
	}
		
	public HtmlElementImpl getRadiobtn_yesadvisory() {
		return new HtmlElementImpl(radiobtn_yesadvisory);
	}
	
	public HtmlElementImpl getBtn_submit() {
		return new HtmlElementImpl(btn_submit);
	}
	
	public HtmlElementImpl getBtn_send() {
		return new HtmlElementImpl(btn_send);
	}
	
	public HtmlElementImpl getChkbox_noduplicateconfirm() {
		return new HtmlElementImpl(chkbox_noduplicateconfirm);
	}
	
	public HtmlElementImpl getBtn_reset() {
		return new HtmlElementImpl(btn_reset);
	}
	

	public HtmlElementImpl getBtn_save() {
		return new HtmlElementImpl(btn_save);
	}

	public HtmlElementImpl getBtn_back() {
		return new HtmlElementImpl(btn_back);
	}
}
