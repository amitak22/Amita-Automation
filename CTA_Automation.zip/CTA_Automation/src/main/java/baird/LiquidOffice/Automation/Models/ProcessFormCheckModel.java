package baird.LiquidOffice.Automation.Models;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import baird.core.Automation.WebDrivers.Browser;
import baird.core.Automation.WebDrivers.Elements.HtmlElementImpl;

/**
 * @author AmitaKumari
 */

public class ProcessFormCheckModel extends BaseModel {

	public ProcessFormCheckModel(Browser obj) {
		super(obj);
	}

	@FindBy(id = "btnSend")
	WebElement btn_send;

	@FindBy(id = "btnBack")
	WebElement btn_back;

	@FindBy(id = "btnCancel")
	WebElement btn_cancel;

	@FindBy(id = "btnSubmit")
	WebElement btn_submit;
	
	@FindBy(id = "Text5_5")
	WebElement txt_summaryofjournal;
	
	@FindBy(id = "btnPrevious_3")
	WebElement btn_previous;
	
	public HtmlElementImpl getBtn_send() {
		return new HtmlElementImpl(btn_send);
	}

	public HtmlElementImpl getBtn_back() {
		return new HtmlElementImpl(btn_back);
	}

	public HtmlElementImpl getBtn_cancel() {
		return new HtmlElementImpl(btn_cancel);
	}
	
	public HtmlElementImpl getBtn_submit() {
		return new HtmlElementImpl(btn_submit);
	}
	
	public HtmlElementImpl getTxt_summaryofjournaltitle() {
		return new HtmlElementImpl(txt_summaryofjournal);
	}
	
	public HtmlElementImpl getBtn_Previous() {
		return new HtmlElementImpl(btn_previous);
	}
}
