package baird.LiquidOffice.Automation.Models;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import baird.core.Automation.WebDrivers.Browser;
import baird.core.Automation.WebDrivers.Elements.HtmlElementImpl;

/**
 * @author AmitaKumari
 */

public class CTAModel extends BaseModel {

	public CTAModel(Browser obj) {
		super(obj);
	}

	@FindBy(id = "ACCOUNT_NUMBER")
	WebElement txt_accnumber;

	@FindBy(id = "processType_RadioButton13")
	WebElement radiobtn_check;
	
	@FindBy(id = "processType_Check1")
	WebElement radiobtn_ach;
	
	@FindBy(id = "processType_RadioButton5")
	WebElement radiobtn_journal;
	
	@FindBy(id = "processType_RadioButton14")
	WebElement radiobtn_domesticwire;
	
	@FindBy(id = "Text1_1")
	WebElement txt_clientinfotitle;

	@FindBy(id = "btnContinue")
	WebElement btn_continue;

	@FindBy(id = "NALine1")
	WebElement txt_clientname;

	@FindBy(id = "NALine2")
	WebElement txt_clientaddress;

	public HtmlElementImpl getTxt_accnumber() {
		return new HtmlElementImpl(txt_accnumber);
	}

	public HtmlElementImpl getradiobtn_check() {
		return new HtmlElementImpl(radiobtn_check);
	}

	public HtmlElementImpl getTxt_ClientinfoTitle() {
		return new HtmlElementImpl(txt_clientinfotitle);
	}

	public HtmlElementImpl getBtn_Continue() {
		return new HtmlElementImpl(btn_continue);
	}

	public HtmlElementImpl getTxt_ClientName() {
		return new HtmlElementImpl(txt_clientname);
	}

	public HtmlElementImpl getTxt_ClientAddress() {
		return new HtmlElementImpl(txt_clientaddress);
	}
	
	public HtmlElementImpl getradiobtn_ach() {
		return new HtmlElementImpl(radiobtn_ach);
	}
	
	public HtmlElementImpl getradiobtn_journal() {
		return new HtmlElementImpl(radiobtn_journal);
	}
	
	public HtmlElementImpl getradiobtn_domesticwire() {
		return new HtmlElementImpl(radiobtn_domesticwire);
	}
}
