package baird.LiquidOffice.Automation.Pages;

import org.openqa.selenium.WebDriver;

import baird.LiquidOffice.Automation.Models.CheckFormModel;
import baird.LiquidOffice.Automation.Resources.TestSettings;
import baird.core.Automation.CommonAPI.ICommonAPI;
import io.appium.java_client.functions.ExpectedCondition;

/**
 * @author AmitaKumari
 */

public class CheckFormPage extends BasePage<CheckFormModel> {

	public CheckFormPage(ICommonAPI commonApi, TestSettings Settings) {
		super(commonApi, Settings);
		PageElements = new CheckFormModel(_browser);
	}

	@Override
	public void navigateTopage() {
		SwitchToPopupWindow();
		try {
			Thread.sleep(1000);

		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		PageElements.init();
	}

	public String getRetrievedClientTitle() {
		return PageElements.getTxt_retrievedclienttitle().getText();
	}

	public void enterAmount(String Amount) {
		PageElements.getTxt_amount().sendKeys(Amount);
	}

	public String getInvalidFormatErrorMessage() {
		return _browser._browserDriver.switchTo().alert().getText();
	}

	public String getErrorPopUp() {
		return _browser._browserDriver.switchTo().alert().getText();
	}

	public void selectAccTypeCash() {
		PageElements.getRadiobtn_cash().click();
	}

	public void selectAccTypeMargin() {
		PageElements.getRadiobtn_margin().click();
	}

	public String getCashorMMF() {
		PageElements.getTxt_cashorMMF().click();
		return PageElements.getTxt_cashorMMF().getText();
	}

	public void clickCashorMMFDrpdwn(String IDPfund) {
		PageElements.getTxt_cashorMMF().sendKeys(IDPfund);
	}

	public void selectDatefromCalendar() {
		PageElements.getIcon_calendar().click();
	}

	public String getIssueDate() {
		PageElements.getTxt_issuedate().click();
		return PageElements.getTxt_issuedate().getAttribute("value");
	}

	public void clickIssueDate(String FutureDate) {
		PageElements.getTxt_issuedate().click();
		PageElements.getTxt_issuedate().clear();
		PageElements.getTxt_issuedate().click();
		PageElements.getTxt_issuedate().sendKeys(FutureDate);
	}

	public void selectPrintLocMilwaukee() {
		PageElements.getRadiobtn_mkeaccount().click();
	}

	public void selectPrintLocBranch() {
		PageElements.getRadiobtn_branch().click();
	}

	public void selectDeliveryMethodDrpdwn(String DeliveryMethod) {
		PageElements.getDrpdwn_deliverymethod().sendKeys(DeliveryMethod);
	}

	public void getDeliveryMethod() {
		PageElements.getDrpdwn_deliverymethod().getText();
	}

	public void clickCheckPurposeDrpdwn(String CheckPurpose) {
		PageElements.getDrpdwn_checkpurpose().sendKeys(CheckPurpose);
	}
	
	public void selectOneTime() {
		PageElements.getRadiobtn_onetime().click();
	}
	
	public void selectOnDemand() {
		PageElements.getRadiobtn_ondemand().click();
	}
	
	public void clickDistRecord() {
		PageElements.getBtn_distrecord().click();
	}
	
	public void selectQCD() {
		PageElements.getRadiobtn_qcd().click();
	}
	
	public void selectPrintChkbox() {
		PageElements.getChkbox_printlocation().click();
	}

	public void getPrintChkboxTxt() {
		PageElements.getTxt_printlocationChkbox().getText();
	}

	public void enterPrintChkbox(String PrintLoc) {
		PageElements.getTxtbox_printlocation().sendKeys(PrintLoc);
	}

	public void clickBtnSameasAccReg() {
		PageElements.getBtn_sameaccountreg().click();
	}

	public void clickBtnClearPayeeInfo() {
		PageElements.getBtn_clearpayeeinfo().click();
	}

	public void clickBtnSelectPayeeInstruction() {
		PageElements.getBtn_payeeinstruction().click();
		PageElements.getBtn_payeeinstructionrecord().click();
	}
	
	public void selectDistRecordTypeA() {
		PageElements.getBtn_typeA().click();
	}
	
	public void selectDistRecordTypeB() {
		PageElements.getBtn_typeB().click();
	}
	
	public void selectDistRecordTypeC() {
		PageElements.getBtn_typeC().click();
	}
	
	public void selectDistRecordTypeD() {
		PageElements.getBtn_typeD().click();
	}
	
	public void selectDistRecordTypeE() {
		PageElements.getBtn_typeE().click();
	}
	
	public void selectDistRecordTypeF1() {
		PageElements.getBtn_typeF1().click();
	}
	
	public void selectPayeeInstruction2() {
		PageElements.getBtn_payeeinstruction().click();
		PageElements.getBtn_payeeinstructionrecord2().click();
	}

	public void enterMemoLines(String MemoLines) {
		PageElements.getTxtbox_memolines().sendKeys(MemoLines);
	}

	public void enterPayeeName(String PayeeName) {
		PageElements.getTxt_payeename().sendKeys(PayeeName);
	}

	public boolean getPayeeInfoField() {
		PageElements.getTxt_payeename().getAttribute("value").isEmpty();
		PageElements.getTxt_payeeaddress().getAttribute("value").isEmpty();
		PageElements.getTxt_payeecity().getAttribute("value").isEmpty();
		PageElements.getTxt_payeestate().getAttribute("value").isEmpty();
		PageElements.getTxt_payeezip().getAttribute("value").isEmpty();
		return true;
	}

	public boolean checkPayeeName(String PayeeName) {
		_explicitwait.until(new ExpectedCondition<Boolean>() {
			public Boolean apply(WebDriver d) {
				return PageElements.getTxt_payeename().getAttribute("value").length() != 0;
			}
		});
		return PageElements.getTxt_payeename().getAttribute("value").contains(PayeeName);
	}

	public void enterPayeeAddress(String PayeeAddressLine1, String PayeeAddressLine2) {
		PageElements.getTxt_payeeaddress().sendKeys(PayeeAddressLine1);
		PageElements.getTxt_payeeaddressline2().sendKeys(PayeeAddressLine2);
	}

	public boolean checktPayeeAddress(String PayeeAddressLine1) {
		return PageElements.getTxt_payeeaddress().getAttribute("value").contains(PayeeAddressLine1);
	}

	public boolean checktPayeeAddressLine2(String PayeeAddressLine2) {
		return PageElements.getTxt_payeeaddressline2().getAttribute("value").contains(PayeeAddressLine2);
	}

	public boolean checkPayeeCity(String PayeeCity) {
		return PageElements.getTxt_payeecity().getAttribute("value").contains(PayeeCity);
	}

	public void enterPayeeCity(String PayeeCity) {
		PageElements.getTxt_payeecity().sendKeys(PayeeCity);
	}

	public boolean checkPayeeState(String PayeeState) {
		return PageElements.getTxt_payeestate().getAttribute("value").contains(PayeeState);
	}

	public void enterPayeeState(String PayeeState) {
		PageElements.getTxt_payeestate().sendKeys(PayeeState);
	}

	public boolean selectPayeeZip(String PayeeZip) {
		return PageElements.getTxt_payeezip().getAttribute("value").contains(PayeeZip);
	}

	public void enterPayeeZip(String PayeeZip) {
		PageElements.getTxt_payeezip().sendKeys(PayeeZip);
	}

	public void selectTypeofPayee(String TypeofPayee) {
		PageElements.getDrpdwn_typeofpayee().sendKeys(TypeofPayee);
	}

	public boolean getTypeofPayee(String TypeofPayee) {
		return PageElements.getDrpdwn_typeofpayee().getAttribute("value").contains(TypeofPayee);
	}

	public void selectStandingInstruction(String SLOA) {
		PageElements.getDrpdwn_standinginst().sendKeys(SLOA);
	}

	public void selectThirdPartyInfoYes() {
		PageElements.getRadiobtnYes_thirdpartyinfo().click();
	}

	public void selectThirdPartyInfoNo() {
		PageElements.getRadiobtnNo_thirdpartyinfo().click();
	}

	public void selectAdvisoryAccWithdrawalInfoNo() {
		PageElements.getRadiobtnNo_advisoryacc().click();
	}

	public void selectAdvisoryAccWithdrawalInfoYes() {
		PageElements.getRadiobtnYes_advisoryacc().click();
	}

	public void selectAttestationChkbox() {
		PageElements.getChkbox_attestation().click();
	}

	public void enterAttestorName(String AttestorName) {
		PageElements.getTxt_attestorname().sendKeys(AttestorName);
	}

	public void clickAttachmentBtn() {
		PageElements.getBtn_attachment().click();
	}

	public void clickSubmitBtn() {
		PageElements.getBtn_submit().click();
	}

	public String getDuplicateErrorMessage() {
		return _browser._browserDriver.switchTo().alert().getText();
	}

	public void selectNoDuplicateChkbox() {
		PageElements.getChkbox_noduplicateconfirm().click();
	}

	public String getErrorPopUpforNoThirdParty() {
		return _browser._browserDriver.switchTo().alert().getText();
	}

	public void clickBackButton() {
		PageElements.getBtn_back().click();
	}

	public void clickResetButton() {
		PageElements.getBtn_reset().click();
	}

	public void clickSaveButton() {
		PageElements.getBtn_save().click();
	}

	public void clickCloseButton() {
		PageElements.getBtn_close().click();
	}

	// Checks IRA functions

	public boolean getIRAWithholdingTitle(String IRADist) {
		return PageElements.getTxt_irawithholdingtitle().getAttribute("value").contains(IRADist);
	}

	public void clickDistributionTypeDrpdwn(String DistributionType) {
		PageElements.getDrpdwn_distributiontype().sendKeys(DistributionType);
	}

	public void selectOnFileDistributionForm() {
		PageElements.getRadiobtn_onfile().click();
	}

	public void selectAttachedDistributionForm() {
		PageElements.getRadiobtn_attached().click();
	}

	public void selectQCDDistributionForm() {
		PageElements.getRadiobtn_qcd().click();
	}

	public void enterFederalTax(String FederalTax) {
		PageElements.getTxt_federaltax().click();
		PageElements.getTxt_federaltax().sendKeys(FederalTax);
	}

	public void enterStateTax(String StateTax) {
		PageElements.getTxt_statetax().click();
		PageElements.getTxt_statetax().sendKeys(StateTax);
	}

	public boolean checkRequestedAmount(String RquestedAmount) {
		return PageElements.getTxt_requestedamount().getAttribute("value").contains(RquestedAmount);
	}

	public boolean checkFedWithholding(String FedWithholding) {
		return PageElements.getTxt_federaltax().getAttribute("value").contains(FedWithholding);
	}

	public boolean checkStateWithholding(String StateWithholding) {
		return PageElements.getTxt_statetax().getAttribute("value").contains(StateWithholding);
	}

	public boolean checkFinalAmount(String FinalAmount) {
		return PageElements.getTxt_finalamount().getAttribute("value").contains(FinalAmount);
	}

	public void selectThirdPartyInfoNoForCheckIRA() {
		PageElements.getRadiobtn_Nothirdpartyinfo().click();
	}

	public void selectThirdPartyInfoYesForCheckIRA() {
		PageElements.getRadiobtn_Yesthirdpartyinfo().click();
	}

	public void clickIconQuestion() {
		PageElements.getIcon_question().click();
	}
}
