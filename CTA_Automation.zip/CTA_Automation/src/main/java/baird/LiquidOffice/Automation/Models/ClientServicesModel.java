package baird.LiquidOffice.Automation.Models;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import baird.core.Automation.WebDrivers.Browser;
import baird.core.Automation.WebDrivers.Elements.HtmlElementImpl;

/**
 * @author AmitaKumari
 */

public class ClientServicesModel extends BaseModel {

	public ClientServicesModel(Browser obj) {
		super(obj);
	}

	@FindBy(xpath = "(//table[@id='Folder_FieldsPanel']//tr[@id='46289f3dz142b3e31392zx35dcgsxaxbooxgbu']//a[@class='record_cell_fields'])[2]")
	WebElement lnk_cta;

	public HtmlElementImpl getLnk_cta() {
		return new HtmlElementImpl(lnk_cta);
	}
	
	@FindBy(xpath = "(//table[@id='Folder_FieldsPanel']//tr[@id='5b761424z16665729213z7be5gsxaxboux44']//a[@class='record_cell_fields'])[2]")
	WebElement lnk_sitcta;
	
	public HtmlElementImpl getLnk_sitcta() {
		return new HtmlElementImpl(lnk_sitcta);
	}
}
