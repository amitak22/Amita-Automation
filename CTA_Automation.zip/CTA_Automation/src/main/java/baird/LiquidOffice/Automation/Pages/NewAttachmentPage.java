package baird.LiquidOffice.Automation.Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import baird.LiquidOffice.Automation.Models.NewAttachmentModel;
import baird.LiquidOffice.Automation.Resources.TestSettings;
import baird.core.Automation.CommonAPI.ICommonAPI;

/**
 * @author AmitaKumari
 */

public class NewAttachmentPage extends BasePage<NewAttachmentModel> {

	public NewAttachmentPage(ICommonAPI commonApi, TestSettings Settings) {
		super(commonApi, Settings);
		PageElements = new NewAttachmentModel(_browser);
	}

	@Override
	public void navigateTopage() {
		SwitchToPopupWindow();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		PageElements.init();
	}

	public void addAttachments() {
		String attLocation = System.getProperty("attachmentPath") != null ? System.getProperty("attachmentPath") : "C:\\Shared\\AutomationAttachment.pdf";
		WebElement fileInput = _browser._browserDriver.findElement((By.name("DFS__File")));
		fileInput.sendKeys(attLocation);
		PageElements.getBtn_add().click();
		PageElements.getBtn_finish().click();
	}

}
