package baird.core.Automation.Helpers;

/**
 * @author AmitaKumari
 */

public interface IHelpers {
	FileValidationHelpers getFileValidationHelper();
}
