package baird.core.Automation.Helpers;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author AmitaKumari
 */

public class FileValidationHelpers {

	// private constructor restricted object creation
	// using new keyword
	private FileValidationHelpers() {

	}

	// static variable of FileValidationHelpers in order to share with all process
	private static FileValidationHelpers single_instance = null;

	// static method to create instance of Singleton class
	public static FileValidationHelpers getInstance() {
		if (single_instance == null) {
			single_instance = new FileValidationHelpers();
		}

		return single_instance;
	}

	public boolean validateFileExtn(String FilePath, String ExtensionToValidate) {
		// extension validation expression
		Pattern fileExtnPtrn = Pattern.compile("([^\\s]+(\\.(?i)(" + ExtensionToValidate + "))$)");

		Matcher mtch = fileExtnPtrn.matcher(FilePath);
		if (mtch.matches()) {
			return true;
		}
		return false;
	}
}
