package baird.core.Automation.Helpers;

/**
 * this class get instance of underlying Helper classes
 * @author AmitaKumari
 */
public class FactoryHelpers implements IHelpers {

	// private constructor restricted object creation
	private FactoryHelpers() {

	}

	// static variable single_instance of type Singleton
	private static FactoryHelpers single_instance = null;

	// static method to create instance of Singleton class
	public static FactoryHelpers getInstance() {
		if (single_instance == null)
			single_instance = new FactoryHelpers();

		return single_instance;
	}

	/**
	 * Function to get File validation helpers
	 */
	public FileValidationHelpers getFileValidationHelper() {
		// calling singleton method of FileValidationHelpers
		return FileValidationHelpers.getInstance();
	}

}
