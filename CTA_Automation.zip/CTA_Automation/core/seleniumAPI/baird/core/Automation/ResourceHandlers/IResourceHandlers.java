package baird.core.Automation.ResourceHandlers;

/**
 * @author AmitaKumari
 */

public interface IResourceHandlers {
  
	PropertyFileHandler getPropertyFileHandler();
}
