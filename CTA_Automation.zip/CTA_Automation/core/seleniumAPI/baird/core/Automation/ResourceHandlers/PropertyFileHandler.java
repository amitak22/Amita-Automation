package baird.core.Automation.ResourceHandlers;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import baird.core.Automation.Helpers.IHelpers;
import baird.core.Automation.Loggers.Logger;

/**
 * constructor
 * 
 * @param : ILogger
 */
/**
 * @author AmitaKumari
 */

public class PropertyFileHandler {

	Logger _logger = null;
	IHelpers _helpers = null;

	// static variable of PropertyFileHandler in order to share with all process
	private static PropertyFileHandler single_instance = null;

	// static method to create instance of Singleton class
	public static PropertyFileHandler getInstance(Logger logger, IHelpers helpers) {
		if (single_instance == null) {
			single_instance = new PropertyFileHandler(logger, helpers);
		}

		return single_instance;
	}

	/**
	 * Constructor
	 * 
	 * @param logger
	 * @param helpers
	 */
	private PropertyFileHandler(Logger logger, IHelpers helpers) {
		_logger = logger;
		_helpers = helpers;
	}

	/**
	 * Read a Property file (.properties)
	 * 
	 * @param FilePath
	 * @return
	 */
	public Properties ReadAll(String FilePath) {

		if (_helpers.getFileValidationHelper().validateFileExtn(FilePath, "properties")) {
			Properties prop = new Properties();

			try {
				InputStream input = new FileInputStream(FilePath);
				// load a properties file
				prop.load(input);
				input.close();

			} catch (IOException ex) {
				ex.printStackTrace();
			}
			return prop;
		} else
			return null;
	}

}
