package baird.core.Automation.ResourceHandlers;

import baird.core.Automation.Helpers.FactoryHelpers;
import baird.core.Automation.Loggers.LogManager;

/**
 * @author AmitaKumari
 */

public class ResourceHandler implements IResourceHandlers {

	public PropertyFileHandler getPropertyFileHandler() {

		return PropertyFileHandler.getInstance(LogManager.getActiveLogger(), FactoryHelpers.getInstance());
	}
}
