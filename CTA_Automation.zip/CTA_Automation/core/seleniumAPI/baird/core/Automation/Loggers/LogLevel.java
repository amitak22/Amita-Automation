package baird.core.Automation.Loggers;

/**
 * @author AmitaKumari
 */

public enum LogLevel {
	INFO, DEBUG, WARNING, ERROR
}
