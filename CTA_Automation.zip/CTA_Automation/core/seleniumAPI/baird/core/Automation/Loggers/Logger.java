package baird.core.Automation.Loggers;

/**
 * Base class of all logger implementations
 * @author AmitaKumari
 */
public abstract class Logger {

	protected LoggerType type = LoggerType.CONSOLE;	

	public abstract void Log(String Message, LogLevel Level);

	public abstract void Log(LogEntity logEntry, LogLevel Level);

	public abstract void LogDebug(String Message);

	public abstract void LogWarning(String Message);

}
