package baird.core.Automation.Loggers.LogTypes;

import baird.core.Automation.Loggers.LogEntity;
import baird.core.Automation.Loggers.LogLevel;
import baird.core.Automation.Loggers.Logger;
import baird.core.Automation.Loggers.LoggerType;

/**
 * @author AmitaKumari
 */

public class ConsoleLogger extends Logger {

	public ConsoleLogger() {
		this.type = LoggerType.CONSOLE;
	}

	public void Log(String Message, LogLevel Level) {
		System.out.println(Level.toString() + " :" + Message);
	}

	public void Log(LogEntity logEntry, LogLevel Level) {
		System.out.println(
				Level.toString() + " :" + logEntry.Message + " | " + logEntry.TimeStamp + " | " + logEntry.SourceName);
	}

	public void LogDebug(String Message) {
		System.out.println("DEBUG :" + Message);
	}

	public void LogWarning(String Message) {
		System.out.println("WARNING!! :" + Message);
	}

}
