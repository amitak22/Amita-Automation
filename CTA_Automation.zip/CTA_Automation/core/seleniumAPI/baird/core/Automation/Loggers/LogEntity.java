package baird.core.Automation.Loggers;

/**
 * Log entity class for complex logging
 * @author AmitaKumari
 */
public class LogEntity {

	public String Message;
	public String TimeStamp;
	public String SourceName;

}
