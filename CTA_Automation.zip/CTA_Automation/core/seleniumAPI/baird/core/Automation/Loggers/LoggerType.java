package baird.core.Automation.Loggers;

/**
 * @author AmitaKumari
 */

public enum LoggerType {
	CONSOLE, FILE
}
