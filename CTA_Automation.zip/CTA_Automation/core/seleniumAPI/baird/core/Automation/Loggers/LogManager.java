package baird.core.Automation.Loggers;

import baird.core.Automation.Loggers.LogTypes.ConsoleLogger;

/**
 * @author AmitaKumari
 */

public class LogManager {

	private LogManager() {

	}

	private static Logger log_obj = null;

	public static Logger getLogger(LoggerType logType) {
		if (log_obj == null) {
			if (logType == LoggerType.CONSOLE) {
				log_obj = new ConsoleLogger();
			}
		}

		return log_obj;
	}

	public static Logger getActiveLogger() {
		if (log_obj == null) {
			System.out.println("Active logger is null!! Switching to console Logging");
			return new ConsoleLogger();
		}
		return log_obj;
	}

}
