package baird.core.Automation.WebServiceUtilities;

/**
 * @author AmitaKumari
 */

public interface IWebServiceUtility {

	void getWebServiceUtility();
}
