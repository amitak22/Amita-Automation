package baird.core.Automation.WebServiceUtilities;

/**
 * @author AmitaKumari
 */

public class WebServiceUtlity implements IWebServiceUtility {

	public void getWebServiceUtility() {
		System.out.println("Executing WebServiceUtility");

	}
}
