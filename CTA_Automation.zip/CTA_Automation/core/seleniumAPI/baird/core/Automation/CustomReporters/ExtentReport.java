package baird.core.Automation.CustomReporters;

import java.text.SimpleDateFormat;
import java.util.Calendar;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.ChartLocation;
import com.aventstack.extentreports.reporter.configuration.Theme;

/**
 * @author AmitaKumari
 */

public class ExtentReport implements ICustomReporter {

	String _relativeReportPath = "TestReport.html";

	// private constructor restricted object creation
	// using new keyword
	private ExtentReport(String relativeReportPath) {
		_relativeReportPath = relativeReportPath;
	}

	// static variable of ExtentReport in order to share with all process
	private static ExtentReport single_instance = null;

	// static method to create instance of Singleton class
	public static ExtentReport getInstance(String relativeReportPath) {
		if (single_instance == null) {
			single_instance = new ExtentReport(relativeReportPath);
		}

		return single_instance;
	}

	// builds a new report using the html template
	ExtentHtmlReporter htmlReporter;

	ExtentReports extent;
	// helps to generate the logs in test report.
	ExtentTest test;

	public void startReport(String OS, String browser) {
		
		Calendar now = Calendar.getInstance();
		SimpleDateFormat sdf = new SimpleDateFormat( "yyyy-MM-dd-HHmmss");
		
		String date = sdf.format( now.getTimeInMillis() );
		// initialize the HtmlReporter
		htmlReporter = new ExtentHtmlReporter(System.getProperty("user.dir") + "\\" + date + "_" + _relativeReportPath);

		// initialize ExtentReports and attach the HtmlReporter
		extent = new ExtentReports();
		extent.attachReporter(htmlReporter);

		// To add system or environment info by using the setSystemInfo method.
		extent.setSystemInfo("OS", OS);
		extent.setSystemInfo("Browser", browser);

		// configuration items to change the look and feel
		// add content, manage tests etc
		htmlReporter.config().setChartVisibilityOnOpen(true);
		htmlReporter.config().setDocumentTitle("CTA Automation");
		htmlReporter.config().setReportName("CTA Automation Report");
		htmlReporter.config().setTestViewChartLocation(ChartLocation.TOP);
		htmlReporter.config().setTheme(Theme.STANDARD);
	}

	public void flush() {
		extent.flush();
	}

	public void LogSuccess(String TestName, String Message) {
		test = extent.createTest(TestName, Message);
		test.log(Status.PASS, MarkupHelper.createLabel(TestName + " PASSED ", ExtentColor.GREEN));
	}

	public void LogFail(String TestName, String Message) {
		test = extent.createTest(TestName, Message);
		test.log(Status.FAIL, MarkupHelper.createLabel(TestName + " Failed ", ExtentColor.RED));
	}
}
