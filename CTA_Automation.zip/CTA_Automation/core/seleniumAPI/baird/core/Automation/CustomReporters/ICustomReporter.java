package baird.core.Automation.CustomReporters;

/**
 * @author AmitaKumari
 */

public interface ICustomReporter {

	void startReport(String OS, String browser);

	void flush();

	void LogSuccess(String TestName, String Message);
	
	void LogFail(String TestName, String Message);

}
