package baird.core.Automation.WebDrivers;

/**
 * @author AmitaKumari
 */

public enum BrowserType {
	NONE, CHROME, FIREFOX, IE

}
