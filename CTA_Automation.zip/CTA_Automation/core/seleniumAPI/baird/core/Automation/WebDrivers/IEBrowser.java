package baird.core.Automation.WebDrivers;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.ie.InternetExplorerDriver;

/**
 * @author AmitaKumari
 */

public class IEBrowser extends Browser {

	private IEBrowser() {
		super(BrowserType.IE);
		this._browserDriver = new InternetExplorerDriver();
		this._browserDriver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	private static IEBrowser _instance = null;

	public static IEBrowser getInstance() {
		if (_instance == null) {
			_instance = new IEBrowser();
		}

		return _instance;
	}
	
	@Override
	public void Close() {
		super.Close();
		_instance = null;
	}
}
