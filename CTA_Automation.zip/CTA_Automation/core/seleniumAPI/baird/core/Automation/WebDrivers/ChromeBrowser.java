package baird.core.Automation.WebDrivers;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.chrome.ChromeDriver;

/**
 * @author AmitaKumari
 */

public class ChromeBrowser extends Browser {

	private ChromeBrowser() {
		super(BrowserType.CHROME);
		this._browserDriver = new ChromeDriver();
		this._browserDriver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	private static ChromeBrowser _instance = null;

	public static ChromeBrowser getInstance() {
		if (_instance == null) {
			_instance = new ChromeBrowser();
		}

		return _instance;
	}
	
	@Override
	public void Close() {
		super.Close();
		_instance = null;
	}
}