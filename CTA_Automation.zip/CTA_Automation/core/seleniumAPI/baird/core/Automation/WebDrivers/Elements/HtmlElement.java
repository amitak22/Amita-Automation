package baird.core.Automation.WebDrivers.Elements;

import org.openqa.selenium.WebElement;

/**
 * @author AmitaKumari
 */

public interface HtmlElement extends WebElement {

}