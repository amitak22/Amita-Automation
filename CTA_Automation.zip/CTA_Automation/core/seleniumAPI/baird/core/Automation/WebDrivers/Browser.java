package baird.core.Automation.WebDrivers;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import baird.core.Automation.WebDrivers.Elements.HtmlElementImpl;
import io.github.bonigarcia.wdm.WebDriverManager;

/**
 * @author AmitaKumari
 */

public abstract class Browser {

	public WebDriver _browserDriver = null;
	BrowserType _type = BrowserType.NONE;

	protected Browser(BrowserType type) {
		setupBrowserEnv(type);
		_type = type;
	}

	private void setupBrowserEnv(BrowserType type) {
		switch (type) {
		case CHROME:
			WebDriverManager.chromedriver().setup();
			break;
		case FIREFOX:
			WebDriverManager.firefoxdriver().setup();
			break;
		case IE:
			WebDriverManager.iedriver().setup();
			break;
		default:
			break;
		}
	}

	public void navigateToUrl(String url) {
		_browserDriver.navigate().to(url);
	}

	public void Close() {
		if (_browserDriver != null) {
			_browserDriver.quit();			
		}
	}

	public void LoadElements(Object page) {
		PageFactory.initElements(_browserDriver, page);
	}

	public HtmlElementImpl findElement(By by) {
		WebElement elem = _browserDriver.findElement(by);
		return new HtmlElementImpl(elem);
	}
}