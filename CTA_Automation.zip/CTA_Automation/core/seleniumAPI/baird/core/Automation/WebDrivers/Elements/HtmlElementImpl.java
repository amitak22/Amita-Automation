package baird.core.Automation.WebDrivers.Elements;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.Point;
import org.openqa.selenium.Rectangle;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;

/**
 * @author AmitaKumari
 */

public class HtmlElementImpl implements HtmlElement {

	private final WebElement element;

	public HtmlElementImpl(final WebElement element) {
		this.element = element;
	}

	public void click() {
		element.click();
	}

	public void submit() {
		element.submit();
	}

	public void sendKeys(CharSequence... keysToSend) {
		element.sendKeys(keysToSend);
	}

	public void clear() {
		element.clear();
	}

	public String getTagName() {
		return element.getTagName();
	}

	public String getAttribute(String name) {
		return element.getAttribute(name);
	}

	public boolean isSelected() {
		return element.isSelected();
	}

	public boolean isEnabled() {
		return element.isEnabled();
	}

	public String getText() {
		return element.getText();
	}

	public List<WebElement> findElements(By by) {
		return element.findElements(by);
	}

	public WebElement findElement(By by) {
		return element.findElement(by);
	}

	public boolean isDisplayed() {
		return element.isDisplayed();
	}

	public Point getLocation() {
		return element.getLocation();
	}

	public Dimension getSize() {
		return element.getSize();
	}

	public Rectangle getRect() {
		return element.getRect();
	}

	public String getCssValue(String propertyName) {
		return element.getCssValue(propertyName);
	}

	public <X> X getScreenshotAs(OutputType<X> target) throws WebDriverException {
		return element.getScreenshotAs(target);
	}
}