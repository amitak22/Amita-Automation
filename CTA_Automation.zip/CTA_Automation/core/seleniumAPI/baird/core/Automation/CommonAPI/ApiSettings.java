package baird.core.Automation.CommonAPI;

import baird.core.Automation.Loggers.LoggerType;
import baird.core.Automation.WebDrivers.BrowserType;

/**
 * @author AmitaKumari
 */

public class ApiSettings {
	
	public LoggerType LogType;
	
	public BrowserType Browsertype;
	
	public String RelativeReportPath;

}
