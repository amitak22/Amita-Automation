package baird.core.Automation.CommonAPI;

import baird.core.Automation.CustomReporters.ICustomReporter;
import baird.core.Automation.Helpers.IHelpers;
import baird.core.Automation.Loggers.Logger;
import baird.core.Automation.WebDrivers.Browser;

/**
 * Based on the singleton pattern, only one object will be created in the memory
 * @author AmitaKumari
 */

public interface ICommonAPI {

	IHelpers getHelpers();

	Logger getLogger();

	Browser getBrowser();

	ICustomReporter getReporter();

}
