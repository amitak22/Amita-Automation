package baird.core.Automation.CommonAPI;

import baird.core.Automation.CustomReporters.ExtentReport;
import baird.core.Automation.CustomReporters.ICustomReporter;
import baird.core.Automation.Helpers.FactoryHelpers;
import baird.core.Automation.Helpers.IHelpers;
import baird.core.Automation.Loggers.LogManager;
import baird.core.Automation.Loggers.Logger;
import baird.core.Automation.WebDrivers.Browser;
import baird.core.Automation.WebDrivers.ChromeBrowser;
import baird.core.Automation.WebDrivers.IEBrowser;

/**
 * Solid implementation of Common API Layer this layer give core services to top layer
 * @author AmitaKumari
 */
public class CommonAPI implements ICommonAPI {

	ApiSettings _settings = null;

	public CommonAPI(ApiSettings Settings) {
		_settings = Settings;
	}

	public IHelpers getHelpers() {
		return FactoryHelpers.getInstance();
	}

	public Logger getLogger() {
		return LogManager.getLogger(_settings.LogType);
	}

	public Browser getBrowser() {
		Browser browser = null;
		switch (_settings.Browsertype) {
		case CHROME:
			browser = ChromeBrowser.getInstance();
			break;
		case IE:
			browser = IEBrowser.getInstance();
			break;
		default:
			break;
		}

		return browser;
	}

	public ICustomReporter getReporter() {
		return ExtentReport.getInstance(_settings.RelativeReportPath);
	}

}
