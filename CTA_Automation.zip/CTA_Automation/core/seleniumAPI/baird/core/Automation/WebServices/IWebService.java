package baird.core.Automation.WebServices;

/**
 * @author AmitaKumari
 */

public interface IWebService {
	
	void getWebservice();

}
