package baird.core.Automation.WebServices;

/**
 * @author AmitaKumari
 */

public class WebService implements IWebService{

	public void getWebservice() {
		System.out.println("Executing Webservice");
		
	}

}
