package com.baird.testawa;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class TestKillSubsessionPage {
	
private static WebElement element = null;
	
	public static WebElement txtarea_AccountNum (WebDriver driver) {
		
	 //   element = driver.findElement(By.cssSelector("textarea[id=accountNumbers]"));
		element = driver.findElement(By.xpath("//textarea[@id='accountNumbers']"));
				
	//	element = driver.findElement(By.xpath("/html/body/div/form[1]/div/div/textarea[1]"));
		//element = driver.findElement(By.xpath("//td[contains(text(), userid)]//preceding-sibling::td//a[contains(text(),'" + finalAcct + "')]"))
	//	element = driver.findElement((By.cssSelector("input[id=CLIEN_ACCOUNT]")));
		//driver.findElement(By.cssSelector("div[class='txtblock']"));
		
		
		return element;
		
	}

   public static WebElement btn_Find (WebDriver driver) {
		
	    element = driver.findElement((By.cssSelector("button[id=btnFind]")));
		//element = driver.findElement((By.cssSelector("input[id=CLIEN_ACCOUNT]")));
		
		return element;
		
	}
   
   public static WebElement btn_Kill (WebDriver driver) {
		
	    element = driver.findElement((By.cssSelector("button[id=btnKill]")));
		//element = driver.findElement((By.cssSelector("input[id=CLIEN_ACCOUNT]")));
		
		return element;
		
	}

	
}
