package com.baird.testawa;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import java.util.concurrent.TimeUnit;
import java.io.File;
import java.util.Set;
import org.openqa.selenium.Alert;
import org.openqa.selenium.chrome.ChromeOptions;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import java.util.List;
import java.util.ArrayList;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import java.util.Calendar;



public class TestCalendar  {

	Boolean suitabilityReview;
	//WebDriver driver = new ChromeDriver();
	static ChromeOptions chromeOptions = new ChromeOptions();
 	static WebDriver driver;
 	static WebElement element;
 	static ExtentTest test;
	static ExtentReports report;
 	static LocalDate date = LocalDate.now();
	
	
	//public void approveFBAA (String account, ExtentTest testRun, ExtentReports reportRun) {
 	public static void main (String args[]) {
 	 
	
		//System.setProperty("webdriver.chrome.driver", System.getProperty("user.home")+"\\chromedriver.exe");
		//System.setProperty("webdriver.chrome.driver","WebDriver/chromedriver.exe");
		System.setProperty("webdriver.chrome.driver","src" + File.separator + "main" + File.separator + "resources" + File.separator + "WebDriver" +File.separator+ "chromedriver.exe");
		chromeOptions.setHeadless(true);
		driver = new ChromeDriver(chromeOptions);
		
		driver.get("http://uatworkflow");
		driver.manage().window().maximize();
		//suitabilityReview = suitability;
	
		
	//	this.driver = driver;
		
		 		  		
	
	//String accountFAApprove = account;
		String accountFAApprove = "1605-9956";
		
		/*
		 * char [] charAcct = new char [4];
		 * 
		 * for (int i=0; i<4; i++) { charAcct[i] = accountFAApprove.charAt(i);
		 * 
		 * }
		 * 
		 * String leftaccount = new String (charAcct); System.out.println(leftaccount);
		 * 
		 * 
		 * for (int i=4; i<8; i++) { charAcct[i-4] = accountFAApprove.charAt(i);
		 * 
		 * }
		 * 
		 * String rightaccount = new String (charAcct);
		 * System.out.println(rightaccount); String finalAcct =
		 * leftaccount+"-"+rightaccount; System.out.println(finalAcct);
		 */
	
	
	//driver.get("http://uatworkflow");
	driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
	driver.findElement(By.linkText("Work Queues")).click();
	driver.findElement(By.linkText("FBAA_WORKABLE")).click();
	driver.findElement(By.linkText("Work Queues")).click();
	driver.findElement(By.linkText("FBAA_WORKABLE")).click();
	driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	String userid = driver.findElement(By.xpath("//td[@class='user_id_hmenu']")).getText();
	System.out.println("Value of user id "+userid);
	driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	List<WebElement> approveItems = new ArrayList<WebElement>();
	approveItems = driver.findElements(By.xpath("//td[contains(text(), userid)]//following::td//a[contains(text(),'" + accountFAApprove + "')]"));
	 
	WebElement lastElement = approveItems.get(approveItems.size()-1);
	String ItemforApproval = lastElement.getText();
	  lastElement.click();
	
	//String approveItem = driver.findElement(By.xpath("//td[contains(text(), userid)]//preceding-sibling::td//a[contains(text(),'" + finalAcct + "')]")).getText();
	 // System.out.println("Item found "+finalAcct+ approveItem);
	  //driver.findElement(By.linkText(approveItem)).click();
	  driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	  driver.manage().window().maximize();
	  String faaID = driver.getWindowHandle();
	  findWindow("FBAA Review Form");
	  String fbaareviewID = driver.getWindowHandle();
	  
	  
	   
	     
	   driver.switchTo().window(fbaareviewID);
	   
		
		  WebElement txtFirstBillDate =  driver.findElement(By.cssSelector("input[id=FIRST_BILL_DATE]"));
		  WebElement txtCSI =  driver.findElement(By.cssSelector("input[id=ACCOUNT_CSI]"));
		  
		//  txtFirstBillDate.click();
		  String inputFirstBillDate = txtFirstBillDate.getAttribute("value");
		  String inputCSI = txtCSI.getAttribute("value");
		  System.out.println("First Bill Date "+inputFirstBillDate);
		  System.out.println("CSI "+inputCSI);
		  
		  if (inputFirstBillDate.equals("")) {

		  System.out.println("First Bill Date is blank!"); 
		  String formattedDate = date.format(DateTimeFormatter.ofLocalizedDate(FormatStyle.SHORT));
		  System.out.println("setting First Bill date to "+formattedDate);
		  
		  try {
		  
		  WebDriverWait wait = new WebDriverWait (driver, 20);
		  
				
				 // wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("input[id=FIRST_BILL_DATE]"))).click();
				  //wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("input[id=FIRST_BILL_DATE]"))).clear();
				 // wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("input[id=FIRST_BILL_DATE]"))).sendKeys(formattedDate);
				  
		         txtFirstBillDate.sendKeys(formattedDate);
	//	  wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("img[id=HTobj__CalLaunch_FIRST_BILL_DATE]"))).click(); //
		  
	
		  System.out.println("Inside null logic, First Bill Date was blank, setting to today's date");
		  
		  } catch (Exception e) { test.log(LogStatus.PASS, e.toString());
		  System.out.println(e.toString()); }
		  
		  
		  
		  
		  }
		  
		  
		  
		 	   
	   
	
	   System.out.println("Processing general logic");
	   
		/*
		 * WebElement btnFBAA =
		 * driver.findElement(By.cssSelector("button[id=DFS__GO]")); btnFBAA.click();
		 * 
		 * WebElement btnFBAANewSend =
		 * driver.findElement(By.cssSelector("input[id=btnSend]"));
		 * btnFBAANewSend.click();
		 * 
		 * WebElement btnFBAANewServiceGo =
		 * driver.findElement(By.cssSelector("button[id=DFS__GO]"));
		 * btnFBAANewServiceGo.click();
		 * 
		 * WebElement btnFBAAApproveClose =
		 * driver.findElement(By.cssSelector("input[id=button_CloseWindow]"));
		 * btnFBAAApproveClose.click();
		 */
	   
	   System.out.println("Item queue id "+faaID);
		  // System.out.println("existing handle"+driver.getWindowHandle());
		   

		   
		   
		   
		   // WebElement FBAAApproveClose = driver.findElement(By.cssSelector("input[id=button_CloseWindow]"));
		 //   FBAAApproveClose.click();
		   
		 
	   
	 
	 
	    
      //  return faaID;
	 	
	}
	
	//public void findWindow (String window) {
 	public static void findWindow (String window) {
		
		 Set <String> WinHandles = driver.getWindowHandles();
		  
		  while (!driver.getTitle().contains(window)) {
		        for (String handle: WinHandles) {
		       
		            System.out.println(handle);
		            System.out.println(WinHandles);
		        	System.out.println(driver.getTitle());
		    	  	driver.switchTo().window(handle);
		    	  	System.out.println(driver.getTitle());
		    	  	
	  
		        }
		    }

		
	    }
	
	  public WebElement findElement (Integer account) {
		  
	  	    String userid = driver.findElement(By.xpath("//td[@class='user_id_hmenu']")).getText();
			System.out.println("Value of user id "+userid);
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		//	String approveItem = driver.findElement(By.xpath("//td[contains(text(), userid)]//preceding-sibling::td//a[contains(text(),'" + finalAcct + "')]")).getText();
		//	System.out.println("Item found "+finalAcct+ approveItem);

		  
		return element;  
	  }
		
	
	}


  


