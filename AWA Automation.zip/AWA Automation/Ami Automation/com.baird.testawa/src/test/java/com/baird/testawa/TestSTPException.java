package com.baird.testawa;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import java.util.concurrent.TimeUnit;
import java.util.Set;
import java.util.List;
import java.io.File;
import java.util.ArrayList;

public class TestSTPException {
	
	WebDriver driver = new ChromeDriver();
	
	public void approveSTP (String accountNumber) {
		
		String accountNum = accountNumber;
		//this.driver = driver;
		//System.setProperty("webdriver.chrome.driver", "C:\\Users\\mllesol\\chromedriver.exe");
		System.setProperty("webdriver.chrome.driver","src" + File.separator + "main" + File.separator + "resources" + File.separator + "WebDriver" +File.separator+ "chromedriver.exe");
		//WebDriver driver = new ChromeDriver();
		driver.get("http://uatworkflow");
		
		driver.manage().timeouts().implicitlyWait(200, TimeUnit.SECONDS);
		driver.findElement(By.linkText("Work Queues")).click();
		driver.findElement(By.linkText("Advisory_Ops_STP_Exception_Queue")).click();
		driver.manage().timeouts().implicitlyWait(200, TimeUnit.SECONDS);
		driver.findElement(By.linkText("Work Queues")).click();
		driver.findElement(By.linkText("Advisory_Ops_STP_Exception_Queue")).click();
		driver.manage().timeouts().implicitlyWait(200, TimeUnit.SECONDS);
		driver.findElement(By.linkText("Work Queues")).click();
		driver.findElement(By.linkText("Advisory_Ops_STP_Exception_Queue")).click();
		
		String processAcct = convertAccount (accountNum);
		
		String userid = driver.findElement(By.xpath("//td[@class='user_id_hmenu']")).getText();
		System.out.println("Value of user id in PWM"+userid);
		//String approveItem = driver.findElement(By.xpath("//td[contains(text(), userid)]//preceding-sibling::td//a[contains(text(),'" + processAcct + "')]")).getText();
		 //driver.findElement(By.linkText(approveItem)).click();
		List<WebElement> approveItems = new ArrayList<WebElement>();
		approveItems = driver.findElements(By.xpath("//td[contains(text(), userid)]//following::td//a[contains(text(),'" + processAcct + "')]"));
		 
		WebElement lastElement = approveItems.get(approveItems.size()-1);
	     lastElement.click();
		
		  driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		  driver.manage().window().maximize();
		  
		//  String faaID = driver.getWindowHandle();
		  findWindow("FBAA Review Form");
		//  String webrespID = driver.getWindowHandle();
		  
		 WebElement btnFAGo = driver.findElement(By.cssSelector("button[id=DFS__GO]"));
		   btnFAGo.click();
		 
		   WebElement FAApproveClose = driver.findElement(By.cssSelector("input[id=button_CloseWindow]"));
		   FAApproveClose.click();
		//   return faaID;
		
		
		
	}
	
	public String convertAccount (String account) {
		String accountConvert = account;
		
		char [] charAcct = new char [4];
		
		for (int i=0; i<4; i++) {
			charAcct[i] = accountConvert.charAt(i);
			
		}
		
		String leftaccount = new String (charAcct);
		System.out.println(leftaccount);
		
		
		for (int i=4; i<8; i++) {
			charAcct[i-4] = accountConvert.charAt(i);
			
		}
		
		String rightaccount = new String (charAcct);
		System.out.println(rightaccount);
		String finalAcct = leftaccount+"-"+rightaccount;
		System.out.println(finalAcct);

		return finalAcct;
		
	}
	
	public void findWindow (String window) {
		
		 Set <String> WinHandles = driver.getWindowHandles();
		  
		  while (!driver.getTitle().contains(window)) {
		        for (String handle: WinHandles) {
		       
		            System.out.println(handle);
		            System.out.println(WinHandles);
		        	System.out.println(driver.getTitle());
		    	  	driver.switchTo().window(handle);
		    	  	System.out.println(driver.getTitle());
		    	  	
	  
		        }
		    }

		
	    }

	

}
