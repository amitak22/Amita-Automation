package com.baird.testawa;

import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import javafx.collections.ObservableList;
import autolayer.testawa.baird.*;
import guilayer.testawa.baird.TestJSONReader;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import pagelayer.testawa.baird.*;

public class TestKillSubsession {
	
	static ExtentTest test;
	static ExtentReports report;
	TestJSONReader tstJSONReader;
	static WebDriver driver; 
	
	//public void killSubsession (String account, WebDriver driver ) {
	 public static void main (String args[]) {
		driver = new ChromeDriver();
		String accountRun = "41535357";
		//this.driver = driver;
		
		
		System.setProperty("webdriver.chrome.driver","WebDriver/chromedriver.exe");
		driver.get("http://uatworkflow");
		driver.findElement(By.linkText("Fee Based")).click();
	 	driver.findElement(By.linkText("Kill AWA Subprocesses By Account Number")).click();
		
   	   // driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	 	findWindow ("Kill AWA Subprocesses By Account Number");
	 	WebDriverWait wait = new WebDriverWait (driver, 20);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='accountNumbers']"))).click();
	 //	wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("accountNumbers"))).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='accountNumbers']"))).sendKeys(accountRun);
	 	//wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("/html/body/div/form[1]/div/div/textarea[1]"))).click();
		 TestKillSubsessionPage.btn_Find(driver).click();
		  driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		  TestKillSubsessionPage.btn_Kill(driver).click();
		  
		  Alert alert = driver.switchTo().alert(); alert.accept();
		
		 
		
		
	}
	 
		public static void findWindow (String window) {
			
			 Set <String> WinHandles = driver.getWindowHandles();
			  
			  while (!driver.getTitle().contains(window)) {
			        for (String handle: WinHandles) {
			       
			          
			    	  	driver.switchTo().window(handle);
			    	  	
			    	  	
		  
			        }
			    }

			
		    }

}
