//'****************************************************************************
//' Description  : This module handles Envestnet for Fee Change processes
//' Author       : Mel Llesol
//' Created      : 01/6/2020
//' Last Update  : 04/20/2020
//'****************************************************************************


package com.baird.testawa;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import pagelayer.testawa.baird.*;
import guilayer.testawa.baird.*;
import org.openqa.selenium.Alert;



public class TestFeeChange02 extends TestProcessor {
	
	WebElement testelement;
	WebDriver driver;
	static ExtentTest test;
	static ExtentReports report;
	Alert alert;
	Boolean approvalRun;
	
	
	//runs the Envestnet process, reads JSON data and executes web elements 
	public void runFlow(String account,  String program, String flow, String wrap, String type, String stub, WebDriver driver, ExtentTest testRun, ExtentReports reportRun) {	
		
		this.driver = driver;
		test = testRun;
		report = reportRun;
		String accountRun = account;
		String flowRun = flow;
		String stubRun = stub;
		String wrapRun = wrap;
		String typeRun = type;
		
		
	
	    String envestURL = "http://uatworkflow/lfserver/awa?ENV_ID="+stubRun;
	  
	  try {			
		driver.get(envestURL);
		driver.manage().window().maximize();
		test.log(LogStatus.PASS, "**Fee Schedule Change - Envestnet workflow** "+envestURL);
		
		
		String originalWindow = driver.getWindowHandle();
				

		driver.manage().window().maximize();
		test.log(LogStatus.PASS, "Window maximized");
		

		TestAddSchedule.button_NextHousehold(driver).click();
		test.log(LogStatus.PASS, "NextHousehold button clicked");


		TestOtherInfo.otherinfoFinish(driver).click();
		test.log(LogStatus.PASS, "Finish button clicked");

		TestSubmission.button_SubmitAccount(driver).click();
		test.log(LogStatus.PASS, "Finish button clicked");
		
					
		if (isDialogPresent(driver)) {
			alert = driver.switchTo().alert();
			String alertMessage = alert.getText();
			test.log(LogStatus.WARNING,"There is no fee schedule and an alert has been flagged. Skipping approval process. Alert message>> "+alertMessage);
			alert.accept();
			approvalRun=false;
			
		} else {
			test.log(LogStatus.PASS,"No alert found for missing fee schedule");
			approvalRun=true;
		}

	if (approvalRun.equals(true)) {
		TestFAApproval tstFAApproval = new TestFAApproval();
		//tstFAApproval.approveFA(accountRun, originalWindow, flowRun, false, driver, test, report, wrapRun, typeRun);
		test.log(LogStatus.PASS, "FA Approval done");
	
		TestFeeChangeApproval tstFeeChangeApproval = new TestFeeChangeApproval ();
		tstFeeChangeApproval.approveFeeChange(accountRun, originalWindow, driver);
		test.log(LogStatus.PASS, "Fee Change Approval done");
	}
	        } catch (Exception e) {
	        	test.log(LogStatus.FAIL, e.toString());
	        }
					
		  }
	
	private static boolean isDialogPresent(WebDriver driver) {
		try {
	          
	        	driver.switchTo().alert();
	            return true;
	        } catch (Exception e) {
	            
	            return false;
	        }
    }
	
	
}
