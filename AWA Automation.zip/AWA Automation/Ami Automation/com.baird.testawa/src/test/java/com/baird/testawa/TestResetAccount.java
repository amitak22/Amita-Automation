//'****************************************************************************
//' Description : Resets account via Swagger UAT website 
//' Author      : Mel Llesol
//' Created     : 03/05/2020
//' Last Update : 03/20/2020
//'****************************************************************************


package com.baird.testawa;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class TestResetAccount  {
	
	static WebDriver driver;
	
	public static void main (String args[]) {
    driver= new ChromeDriver();
	String accountRun = "44814081";
	
	//WebDriverWait wait = new WebDriverWait (driver, 10).until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(By.xpath("//*[@id='BetaTestData_BetaTestData_SetBetaInformationFromWarehouse_content']/form/table/tbody/tr/td[2]/input")));
	//WebDriverWait wait = new WebDriverWait (driver, 10).until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(By.xpath("//*[@id='BetaTestData_BetaTestData_SetBetaInformationFromWarehouse_content']/form/table/tbody/tr/td[2]/input")));
	driver.get("http://uatadvisoryprogram.rwbaird.com/TestData/swagger/ui/index#!/BetaTestData/BetaTestData_SetBetaInformationFromWarehouse");
	driver.manage().window().maximize();
	WebDriverWait wait = new WebDriverWait (driver, 20);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='BetaTestData_BetaTestData_SetBetaInformationFromWarehouse_content']/form/table/tbody/tr/td[2]/input"))).sendKeys(accountRun);
	wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='BetaTestData_BetaTestData_SetBetaInformationFromWarehouse_content']/form/div[2]/input"))).click();
	String element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='BetaTestData_BetaTestData_SetBetaInformationFromWarehouse_content']/div[2]/div[3]/pre"))).getAttribute("textContent");
	if (element.equals ("200")) {
		System.out.println("Response OK");
	} else {
		System.out.println("Response not OK");
	}
	
	//driver.findElement(By.xpath("//*[@id='BetaTestData_BetaTestData_SetBetaInformationFromWarehouse_content']/form/table/tbody/tr/td[2]/input")).click();
	//driver.findElement(By.xpath("//*[@id='BetaTestData_BetaTestData_SetBetaInformationFromWarehouse_content']/form/table/tbody/tr/td[2]/input")).sendKeys(accountRun);
	
	
 }
}