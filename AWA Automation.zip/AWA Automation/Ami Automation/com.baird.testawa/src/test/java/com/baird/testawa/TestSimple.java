package com.baird.testawa;
import java.io.File;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import java.util.List;
import java.util.ArrayList;

public class TestSimple {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriver driver = new ChromeDriver();
		//System.setProperty("webdriver.chrome.driver", "C:\\Users\\mllesol\\Selenium\\chromedriver_win32_new\\chromedriver.exe");
		System.setProperty("webdriver.chrome.driver","src" + File.separator + "main" + File.separator + "resources" + File.separator + "WebDriver" +File.separator+ "chromedriver.exe");
		driver.get("http://uatworkflow");
		driver.findElement(By.linkText("Work Queues")).click();
		driver.findElement(By.linkText("FBAA_WORKABLE")).click();
		driver.findElement(By.linkText("Work Queues")).click();
		driver.findElement(By.linkText("FBAA_WORKABLE")).click();
		
      String finalAcct = "6634-9867";
	  String userid = driver.findElement(By.xpath("//td[@class='user_id_hmenu']")).getText();
	  System.out.println("Value of user id "+userid);
	  driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	 // String approveItem = driver.findElement(By.xpath("//td[contains(text(), userid)]//preceding-sibling::td//a[contains(text(),'" + finalAcct + "']).getText();"
	 // String approveItem = driver.findElement(By.xpath("//td[contains(text(), userid)]//preceding-sibling::td//a[contains(text(),'" + finalAcct + "')]//ancestor::td/id[contains(text(), 'WorkQueue_Selector')]")).getText();
	//  System.out.println("Item found "+finalAcct+ approveItem);
	  
	  List<WebElement> elements = new ArrayList<WebElement>();
	  
	 // elements = driver.findElements(By.xpath("//td[contains(text(), userid)]//preceding-sibling::td//*[starts-with(@id,'WorkQueue_Selector')]"));
	   elements = driver.findElements(By.xpath("//td[contains(text(), userid)]//following::td//a[contains(text(),'" + finalAcct + "')]"));
	  //WebElement recentitem = elements.get(elements.size()-1);
	  WebElement recentitem = elements.get(elements.size()-1);
	  String recentitemapprove = recentitem.toString();
	  System.out.println("Queue size"+elements.size());
	  System.out.println("RecentItem "+recentitemapprove);
	  recentitem.click();
	 // driver.findElement(By.xpath("//*[@id='"+recentitem+"']//following::td//a[contains(text(),'3744-5497')]")).click();;
	  


	}

}
