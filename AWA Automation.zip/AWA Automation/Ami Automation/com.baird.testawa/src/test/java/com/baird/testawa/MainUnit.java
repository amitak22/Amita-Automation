package com.baird.testawa;

import static org.junit.Assert.*;
import static org.junit.Before.*;
import static org.junit.After.*;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import org.junit.Test;

public class MainUnit {
	WebDriver driver = new ChromeDriver();
	
	
	
	@Test
	public void test() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\mllesol\\chromedriver.exe");
		driver.get("http://uatworkflow");
		String url = driver.getCurrentUrl();
		assertEquals(url, "http://uatworkflow/lfserver?DFS__Action=FoldersGetFolder&DFS__Client=JSP");
		
		//driver.findElement(By.linkText("Fee Based")).click();
		
		
		
	}

}
