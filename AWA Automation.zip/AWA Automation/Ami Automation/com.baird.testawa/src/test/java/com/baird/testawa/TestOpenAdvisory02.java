//'****************************************************************************
//' Description  : This module handles Envestnet for Open Advisory processes
//' Author       : Mel Llesol
//' Created      : 01/6/2020
//' Last Update  : 04/20/2020
//'****************************************************************************


package com.baird.testawa;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import pagelayer.testawa.baird.*;
import guilayer.testawa.baird.*;
import org.openqa.selenium.Alert;




public class TestOpenAdvisory02 extends TestProcessor {
	
	WebElement testelement;
	WebDriver driver;
	static ExtentTest test;
	static ExtentReports report;
	Alert alert;
	Boolean approvalRun;
	
	//runs the Envestnet process, reads JSON data and executes web elements 
	public void runFlow(String account, String program, String flow, String wrap, String type, String stub, WebDriver driver, ExtentTest testRun, ExtentReports reportRun, Boolean stage) {	
		
		
		this.driver = driver;
		test = testRun;
		report = reportRun;
		String accountRun = account;
		String flowRun = flow;
		String stubRun = stub;
		String typeRun = type;
	    String envestURL = "http://uatworkflow/lfserver/awa?ENV_ID="+stubRun;
	    String wrapRun = wrap;
	    
	   
	try {	
		driver.get(envestURL);
		test.log(LogStatus.PASS, "**Open Advisory - Envestnet workflow ** "+envestURL);
		driver.manage().window().maximize();
		
		String originalWindow = driver.getWindowHandle();
				
	
		TestCompliance.radio_CompYes(driver).click();
		test.log(LogStatus.PASS, "Compliance yes button selected");
	
	
		TestCompliance.check_SuitComp(driver).click();
		test.log(LogStatus.PASS, "Compliance radiobox selected");
			
		TestCompliance.button_Continue(driver).click();
		test.log(LogStatus.PASS, "Continue button selected");
	
	
		driver.manage().window().maximize();
		test.log(LogStatus.PASS, "Window maximized");
	
		TestAddSchedule.button_NextHousehold(driver).click();
		test.log(LogStatus.PASS, "NextHousehold button clicked");
	
		TestOtherInfo.proxyConfirm(driver).click();
		test.log(LogStatus.PASS, "Proxy Confirm clicked");
	
		TestOtherInfo.otherinfoFinish(driver).click();
		test.log(LogStatus.PASS, "Finish button clicked");
		
    	TestSubmission.button_UpdateHousehold(driver).click();
		test.log(LogStatus.PASS, "Update Household button clicked");
		

		TestSubmission.checkbox_AddHousehold(driver).click();
		test.log(LogStatus.PASS, "Add Billing Household account checkbox clicked");
	
		TestSubmission.button_SaveMaintenance(driver).click();
		test.log(LogStatus.PASS, "Save Maintenance button clicked");

		TestSubmission.button_SubmitAccount(driver).click();
		test.log(LogStatus.PASS, "Submit account button clicked");
		
				
		if (isDialogPresent(driver)) {
			alert = driver.switchTo().alert();
			String alertMessage = alert.getText();
			test.log(LogStatus.WARNING,"There is no fee schedule and an alert has been flagged. Skipping approval process. Alert message>> "+alertMessage);
			alert.accept();
			approvalRun=false;
			
		} else {
			test.log(LogStatus.PASS,"No alert found for missing fee schedule");
			approvalRun=true;
		}
		
	
		driver.switchTo().window(originalWindow);
	    
		if (approvalRun.equals(true)) {
		   
		TestFAApproval tstFAApproval = new TestFAApproval();
		//tstFAApproval.approveFA(accountRun, originalWindow, flowRun, true, driver, test, report, wrapRun, typeRun);
		test.log(LogStatus.PASS, "FA Approval done");

		TestPWMApproval tstPWMApproval = new TestPWMApproval ();
		tstPWMApproval.PWMApprove(accountRun, flowRun, true, driver);
		test.log(LogStatus.PASS, "PWM Approval done");

		
		
		if (!typeRun.equals("STP")) {

		TestAdvisoryOpsNewAccount tstAdvisoryOpsNewAccount = new TestAdvisoryOpsNewAccount();
		tstAdvisoryOpsNewAccount.AdvisoryOpsNewAcctApprove(accountRun, driver, typeRun);
		test.log(LogStatus.PASS, "Advisory Ops Approval done");
	
				
		  }
		}
	} catch (Exception e) {
		test.log(LogStatus.FAIL, e.toString());
	}
	
	}
	
	 private static boolean isDialogPresent(WebDriver driver) {
		 try {
	           
	        	driver.switchTo().alert();
	            return true;
	        } catch (Exception e) {
	            
	            return false;
	        }
	    }
}
