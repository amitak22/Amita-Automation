//'****************************************************************************
//' Description      : handles page object model for Fee Change Approval queue
//' Author           : Mel Llesol
//' Created          : 11/5/2019
//' Last Updated     : 03/23/2020
//'****************************************************************************

package pagelayer.testawa.baird;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.Select;
import java.util.concurrent.TimeUnit;
import java.util.Set;
import java.util.List;
import java.util.ArrayList;

//main logic to check web elements for Fee Change approval
public class TestFeeChangeApproval {
	
	ChromeOptions chromeOptions = new ChromeOptions();
	WebDriver driver;
	WebElement element;
	
	public void approveFeeChange (String account, String origWindow, WebDriver driver) {
	
	this.driver = driver;
		

	try {
   		driver.get("http://uatworkflow");
		driver.manage().window().maximize();
		
		String accountFAApprove = account;
		
		char [] charAcct = new char [4];
		
		for (int i=0; i<4; i++) {
			charAcct[i] = accountFAApprove.charAt(i);
			
		}
		
		String leftaccount = new String (charAcct);
		
		
		
		for (int i=4; i<8; i++) {
			charAcct[i-4] = accountFAApprove.charAt(i);
			
		}
		
		String rightaccount = new String (charAcct);
	
		String finalAcct = leftaccount+"-"+rightaccount;
		
		
		
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		driver.findElement(By.linkText("Work Queues")).click();
		driver.findElement(By.linkText("FBAA_FEE_SCHEDULE_CHANGE")).click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		String userid = driver.findElement(By.xpath("//td[@class='user_id_hmenu']")).getText();
		
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		List<WebElement> approveItems = new ArrayList<WebElement>();
		approveItems = driver.findElements(By.xpath("//td[contains(text(), '"+userid+"')]//following::td//a[contains(text(),'" + finalAcct + "')]"));
		 
		WebElement lastElement = approveItems.get(approveItems.size()-1);
		
		
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		lastElement.click();
		String faaID = driver.getWindowHandle();
		findWindow("FBAA Review Form");
		String fbaareviewID = driver.getWindowHandle();
		driver.manage().window().maximize();
		  
		driver.switchTo().window(fbaareviewID);
		driver.manage().window().maximize(); 
		  
		Select dropCoding= new Select (driver.findElement(By.cssSelector("select[id=DFS__ActionList]")));
		dropCoding.selectByVisibleText("Approve, Code Account");
		WebElement btnFinalFAApprove = driver.findElement(By.cssSelector("button[id=DFS__GO]"));
		btnFinalFAApprove.click();
		   
		WebElement btnSend = driver.findElement(By.cssSelector("input[id=btnSend]"));
		btnSend.click();
		   
		     
			   
		WebElement btnWebResGo = driver.findElement(By.cssSelector("button[id=DFS__GO]"));
		btnWebResGo.click();
		   
			   
		WebElement FAApproveClose = driver.findElement(By.cssSelector("input[id=button_CloseWindow]"));
		FAApproveClose.click();
		    
		driver.switchTo().window(faaID);
	//	driver.close();
		 
	} catch (Exception e) {
		e.printStackTrace();
	}
		    

		 	
		}
		
		public void findWindow (String window) {
			
			 Set <String> WinHandles = driver.getWindowHandles();
			  
			  while (!driver.getTitle().contains(window)) {
			        for (String handle: WinHandles) {
			       
			           	driver.switchTo().window(handle);
			    	  	
			    	  	
		  
			        }
			    }

			
		    }
		

		
	}


