//'****************************************************************************
//' Description      : handles page object model for Advisory Operations queue
//' Author           : Mel Llesol
//' Created          : 11/5/2019
//' Last Updated     : 03/23/2020
//'****************************************************************************



package pagelayer.testawa.baird;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeOptions;
import java.util.concurrent.TimeUnit;
import java.util.Set;
import java.util.ArrayList;
import java.util.List;
import org.openqa.selenium.support.ui.Select;

public class TestAdvisoryOpsNewAccount {
	

Boolean check;
ChromeOptions chromeOptions = new ChromeOptions();
WebDriver driver;
	

    //main logic to check web elements for Advisory Operations New account
	public void AdvisoryOpsNewAcctApprove (String accountNumber, WebDriver driver, String type) {
		String accountNum = accountNumber;
		String typeRun=type;
		
		this.driver=driver;

	try {	
		driver.get("http://uatworkflow");
		driver.manage().window().maximize();
		
		for (int i=0; i<2; i++) {
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.linkText("Work Queues")).click();
		driver.findElement(By.linkText("Advisory_Ops_New_Accounts")).click();
		}
		
		String processAcct = convertAccount (accountNum);
		String userid = driver.findElement(By.xpath("//td[@class='user_id_hmenu']")).getText();
		
		
		
		List<WebElement> approveItems = new ArrayList<WebElement>();
		approveItems = driver.findElements(By.xpath("//td[contains(text(), '"+userid+"')]//following::td//a[contains(text(),'" + processAcct + "')]"));
		 
		WebElement lastElement = approveItems.get(approveItems.size()-1);
		
        
		   
		 lastElement.click(); 
		 
		  driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		  driver.manage().window().maximize();
		  
		  String faaID = driver.getWindowHandle();
		  findWindow("FBAA Review Form");
		
		   if (typeRun.equals("Reject")) {
			   WebElement approvalAction = driver.findElement(By.cssSelector("select[id=DFS__ActionList"));
			   Select dropApproval = new Select (approvalAction);
			   dropApproval.selectByVisibleText("Reject");
		   } 
		   
		   WebElement btnAdvisoryOpsNewApprove = driver.findElement(By.cssSelector("button[id=DFS__GO]"));
		   btnAdvisoryOpsNewApprove.click();

		  
		   WebElement btnAdvOpsNewSend = driver.findElement(By.cssSelector("input[id=btnSend]"));
		   btnAdvOpsNewSend.click();
		   
		   WebElement btnAdvOpsNewServiceGo = driver.findElement(By.cssSelector("button[id=DFS__GO]"));
		   btnAdvOpsNewServiceGo.click();
		   		 
		   WebElement btnAdvisoryApproveClose = driver.findElement(By.cssSelector("input[id=button_CloseWindow]"));
		   btnAdvisoryApproveClose.click();
		   
		   
		    driver.switchTo().window(faaID);
		
		   
	} catch (Exception e) {
		e.printStackTrace();
	}
	}
	
	//converts account to - separated
	public String convertAccount (String account) {
		String accountConvert = account;
		
		char [] charAcct = new char [4];
		
		for (int i=0; i<4; i++) {
			charAcct[i] = accountConvert.charAt(i);
			
		}
		
		String leftaccount = new String (charAcct);
		
		
		
		for (int i=4; i<8; i++) {
			charAcct[i-4] = accountConvert.charAt(i);
			
		}
		
		String rightaccount = new String (charAcct);
		
		String finalAcct = leftaccount+"-"+rightaccount;
		

		return finalAcct;
		
	}
	
	//finds the relevant window given parameter
	public void findWindow (String window) {
		
		 Set <String> WinHandles = driver.getWindowHandles();
		  
		  while (!driver.getTitle().contains(window)) {
		        for (String handle: WinHandles) {
		       		        	
		    	  	driver.switchTo().window(handle);
		    	  
		    	  	
	  
		        }
		    }

		
	    }


}
