//'****************************************************************************
//' Description      : handles page object model for Workable approval  
//' Author           : Mel Llesol
//' Created          : 11/5/2019
//' Last Updated     : 04/20/2020
//'****************************************************************************



package pagelayer.testawa.baird;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import java.util.concurrent.TimeUnit;
import java.util.Set;
import org.openqa.selenium.chrome.ChromeOptions;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import java.util.List;
import java.util.ArrayList;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;



//main logic to check web elements for Workable approval
public class TestWorkable  {

	Boolean suitabilityReview;
	ChromeOptions chromeOptions = new ChromeOptions();
 	WebDriver driver;
 	WebElement element;
 	static ExtentTest test;
	static ExtentReports report;
 	LocalDate date = LocalDate.now();
	
	
	public void approveFBAA (String account, ExtentTest testRun, ExtentReports reportRun, WebDriver driver) {
 	 
		test = testRun;
		report = reportRun;
	
		this.driver = driver;
	
	try {	
		driver.get("http://uatworkflow");
		driver.manage().window().maximize();
		
		
		 		  		
	
	String accountFAApprove = account;
	
		
	char [] charAcct = new char [4];
	
	for (int i=0; i<4; i++) {
		charAcct[i] = accountFAApprove.charAt(i);
		
	}
	
	String leftaccount = new String (charAcct);
	
	
	
	for (int i=4; i<8; i++) {
		charAcct[i-4] = accountFAApprove.charAt(i);
		
	}
	
	String rightaccount = new String (charAcct);
	
	String finalAcct = leftaccount+"-"+rightaccount;
	
	
	
	
	driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
	driver.findElement(By.linkText("Work Queues")).click();
	driver.findElement(By.linkText("FBAA_WORKABLE")).click();
	driver.findElement(By.linkText("Work Queues")).click();
	driver.findElement(By.linkText("FBAA_WORKABLE")).click();
	driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	String userid = driver.findElement(By.xpath("//td[@class='user_id_hmenu']")).getText();
	
	driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	List<WebElement> approveItems = new ArrayList<WebElement>();
	approveItems = driver.findElements(By.xpath("//td[contains(text(), '"+userid+"')]//following::td//a[contains(text(),'" + finalAcct + "')]"));
	 
	WebElement lastElement = approveItems.get(approveItems.size()-1);
	
	  lastElement.click();
	
	
	  driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	  driver.manage().window().maximize();
	  String faaID = driver.getWindowHandle();
	  findWindow("FBAA Review Form");
	  String fbaareviewID = driver.getWindowHandle();
	  
	  
	   
	     
	   driver.switchTo().window(fbaareviewID);
	   driver.manage().window().maximize();
	   
	   WebElement txtFirstBillDate =  driver.findElement(By.cssSelector("input[id=FIRST_BILL_DATE]"));
	
	 
	   String inputFirstBillDate = txtFirstBillDate.getAttribute("value");
	  
		  
		  if (inputFirstBillDate.equals("")) {

		  
		  String formattedDate = date.format(DateTimeFormatter.ofLocalizedDate(FormatStyle.SHORT));
		  
		  
		      try {
		  
		      
		    	  txtFirstBillDate.click();
		    	  txtFirstBillDate.sendKeys(formattedDate);
		    	  txtFirstBillDate.sendKeys(Keys.TAB);
		    	  
		    	  test.log(LogStatus.PASS, "First Bill Date was blank, setting to today's date");
		       
		      
		      
		  
		  } catch (Exception e) { 
			test.log(LogStatus.FAIL, e.toString());
		
		  }
		  
		  
		  
		  
		  }
		  
	  
	   
	   WebElement btnFBAA = driver.findElement(By.cssSelector("button[id=DFS__GO]"));
	   btnFBAA.click();
	   
	   WebElement btnFBAANewSend = driver.findElement(By.cssSelector("input[id=btnSend]"));
	   btnFBAANewSend.click();
	   
	   WebElement btnFBAANewServiceGo = driver.findElement(By.cssSelector("button[id=DFS__GO]"));
	   btnFBAANewServiceGo.click();
	   		 
	   WebElement btnFBAAApproveClose = driver.findElement(By.cssSelector("input[id=button_CloseWindow]"));
	   btnFBAAApproveClose.click();
	   
	 
		   
		   
		 
	   driver.switchTo().window(faaID);
	//    driver.close();
	 
	 
	} catch (Exception e) {
		test.log(LogStatus.WARNING, e.toString());
	}
  
	 	
	}
	
	public void findWindow (String window) {
 	
		
		 Set <String> WinHandles = driver.getWindowHandles();
		  
		  while (!driver.getTitle().contains(window)) {
		        for (String handle: WinHandles) {
		       
		          
		    	  	driver.switchTo().window(handle);
		    	  
		    	  	
	  
		        }
		    }

		
	    }
	
	
		
	
	}


  


