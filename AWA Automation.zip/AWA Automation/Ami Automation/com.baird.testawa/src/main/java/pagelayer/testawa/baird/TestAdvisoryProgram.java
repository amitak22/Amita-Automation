//'****************************************************************************
//' Description      : handles page object model for Open advisory account
//' Author           : Mel Llesol
//' Created          : 11/5/2019
//' Last Updated     : 03/23/2020
//'****************************************************************************


package pagelayer.testawa.baird;

import org.openqa.selenium.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class TestAdvisoryProgram {
	
	private static WebElement element = null;
	
	//each method returns a web element to be processed by auto layer 
	public static WebElement drop_Program (WebDriver driver) {
		
		element = driver.findElement(By.cssSelector("select[id=ADVISORY_SOLUTION]"));
		
		return element;
		
	}
	
	public static WebElement drop_ImpMethod (WebDriver driver) {
		
		element = driver.findElement(By.cssSelector("select[id=SOLUTION_IMPLEMENTATION_METHOD]"));
		
		return element;
		
	}
	
	public static WebElement drop_Solution (WebDriver driver) {
		element = driver.findElement(By.cssSelector("select[id=SOLUTION_MANAGER]"));
		
		return element;
		
	}
	
	public static WebElement drop_Model (WebDriver driver) {
		element = driver.findElement(By.cssSelector("select[id=SOLUTION_MANAGER_STYLE]"));
		
		return element;
		
	}
	
	public static WebElement drop_RebalancingOption (WebDriver driver) {
		element = driver.findElement(By.cssSelector("select[id=SOLUTION_REBALANCING_OPTION]"));
		
		return element;
		
	}
	
	public static WebElement drop_AllocationPortfolio (WebDriver driver) {
		element = driver.findElement(By.cssSelector("select[id=SOLUTION_ALLOCATION_PORTFOLIO]"));
		
		return element;
		
	}
	
	public static WebElement drop_FixedIncome (WebDriver driver) {
		element = driver.findElement(By.cssSelector("select[id=SOLUTION_FIXED_INCOME_OPTION]"));
		
		return element;
		
	}
	
	public static WebElement drop_AlignModel (WebDriver driver) {
		element = driver.findElement(By.cssSelector("select[id=SOLUTION_ALIGN_MODEL]"));
		
		return element;
		
	}
	
	public static WebElement drop_BIMShell (WebDriver driver) {
		element = driver.findElement(By.cssSelector("select[id=BIM_SHELL]"));
		
		return element;
		
	}
	
	
	public static WebElement radio_Invest (WebDriver driver) {
		element = driver.findElement(By.cssSelector("input[id=INVESTMENT_OPTIONS_RadioButton1_4]"));
		
		return element;
		
	}
	
	public static WebElement button_Continue (WebDriver driver) {
		
	    element = driver.findElement(By.cssSelector("button[name=btnContinue_2]"));
	    
	    return element;
	    
	}
	
	

}
