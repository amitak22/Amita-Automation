//'****************************************************************************
//' Description      : handles page object model for FA approval queue
//' Author           : Mel Llesol
//' Created          : 11/5/2019
//' Last Updated     : 04/20/2020
//'****************************************************************************



package pagelayer.testawa.baird;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import java.util.concurrent.TimeUnit;
import java.util.Set;
import java.util.List;
import java.util.ArrayList;
import org.openqa.selenium.Alert;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import guilayer.testawa.baird.TestProcessor;


//main logic to check web elements for FA approval
public class TestFAApproval extends TestProcessor {
	

	Boolean suitabilityReview;
	//ChromeOptions chromeOptions = new ChromeOptions();
 	WebDriver driver;
 	WebElement testelement;
	static ExtentTest test;
	static ExtentReports report;
	String ItemforApproval;

	
	
	
	public void approveFA (String account, String accountTo, String origWindow, String flow, Boolean suitability, WebDriver driver, ExtentTest testRun, ExtentReports reportRun, String wrap, String type, List<Integer> programReasonRun, String program) {
	    this.driver = driver;
	    test = testRun;
		report = reportRun;
		String wrapRun = wrap;
		String typeRun = type;
		String programRun = program;
		List<Integer>programReasonList=new ArrayList<Integer>();
		
		programReasonList = programReasonRun;
	
		
		
	
	try {	
		driver.get("http://uatworkflow");
		driver.manage().window().maximize();
		suitabilityReview = suitability;
		String flowRun = flow;
	
			
  	    String accountFAApprove = account;
  	    String accountToApprove = accountTo;
	
		
   	    char [] charAcct = new char [4];
	
	    for (int i=0; i<4; i++) {
		  charAcct[i] = accountFAApprove.charAt(i);
		
	    }
	
	    String leftaccount = new String (charAcct);
	
	
	
	    for (int i=4; i<8; i++) {
		   charAcct[i-4] = accountFAApprove.charAt(i);
		
      	}
	
     	String rightaccount = new String (charAcct);
	
	    String finalAcct = leftaccount+"-"+rightaccount;
	
	
	driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
	for (int i=0; i<9; i++) {
	driver.findElement(By.linkText("Work Queues")).click();
	driver.findElement(By.linkText("FA_TEST_QUEUE")).click();
	}
	driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	String userid = driver.findElement(By.xpath("//td[@class='user_id_hmenu']")).getText();
	
	driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	
	
	List<WebElement> approveItems = new ArrayList<WebElement>();
	approveItems = driver.findElements(By.xpath("//td[contains(text(), '"+userid+"')]//following::td//a[contains(text(),'" + finalAcct + "')]"));
	
	
	WebElement lastElement = approveItems.get(approveItems.size()-1);
	ItemforApproval = lastElement.getText();
	lastElement.click();
	driver.manage().window().maximize(); 
	
	
	
		  driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		  driver.manage().window().maximize(); 
		  String faaID = driver.getWindowHandle();
		  findWindow("Account Attestation Form");
		  String attestationID =  driver.getWindowHandle(); 
		  driver.manage().window().maximize(); 
		  
		  if (suitabilityReview.equals(true)) { 
		  WebElement btnReviewDoc = driver.findElement(By.cssSelector("button[id=suitabilityReviewButton]"));
		  btnReviewDoc.click();
		  driver.manage().window().maximize(); 
		 
		  if (flowRun.equals("Open Advisory Account") || flowRun.equals("Registration Change")) {
			
			if (flowRun.equals("Open Advisory Account")) {
			String suitabilityAccountNumber = driver.findElement(By.cssSelector("input[id=DTB__tblOpenAndRegChgAccountInfo_0_openAndRegChgAccountNumber]")).getAttribute("value");
			String suitabilityProgramNameOpen = driver.findElement(By.cssSelector("input[id=DTB__tblOpenAndRegChgAccountInfo_0_openAndRegChgSolutionName]")).getAttribute("value");
		    System.out.println("Suitability Account Number"+suitabilityAccountNumber);
		    System.out.println("FA acct num"+accountFAApprove);
		    System.out.println("Suitability Program Name"+suitabilityProgramNameOpen);
		    System.out.println("Flow Program Name"+programRun);
		    
			
			if (suitabilityAccountNumber.equals(accountFAApprove)) {
				test.log(LogStatus.PASS, "Account number at FA suitability header field is correct");
			} else {
				test.log(LogStatus.FAIL, "Account number at FA suitability header field is incorrect"+suitabilityAccountNumber);
			}
			
			if (suitabilityProgramNameOpen.equals(programRun)) {
				test.log(LogStatus.PASS, "Program name at FA suitability header field is correct");
			} else {
				test.log(LogStatus.FAIL, "Program name at FA suitability header field is incorrect-->"+programRun);
			}
			
			} else if (flowRun.equals("Registration Change")) {
				String suitabilityFromAccountNumber = driver.findElement(By.cssSelector("input[id=DTB__tblOpenAndRegChgAccountInfo_0_openAndRegChgAccountNumber]")).getAttribute("value");
				String suitabilityToAccountNumber = driver.findElement(By.cssSelector("input[id=DTB__tblOpenAndRegChgAccountInfo_0_openAndRegChgAccountNumber2]")).getAttribute("value");
				System.out.println("Suit Account Number"+suitabilityToAccountNumber);
				System.out.println("json Account Number"+accountToApprove);
				String suitabilityRegProgramName = driver.findElement(By.cssSelector("input[id=DTB__tblOpenAndRegChgAccountInfo_0_openAndRegChgSolutionName2]")).getAttribute("value");
				
				if (suitabilityFromAccountNumber.equals(accountFAApprove)) {
					test.log(LogStatus.PASS, "From Account number at FA suitability header field is correct");
				} else {
					test.log(LogStatus.FAIL, "From Account number at FA suitability header field is incorrect-->"+suitabilityFromAccountNumber);
				}
				
				
				if (suitabilityToAccountNumber.equals(accountToApprove)) {
					test.log(LogStatus.PASS, "To Account number at FA suitability header field is correct");
				} else {
					test.log(LogStatus.FAIL, "To Account number at FA suitability header field is incorrect-->"+suitabilityToAccountNumber);
				}
				
				System.out.println("Suit To Prog"+suitabilityRegProgramName);
				System.out.println("Json To Prog"+programRun);
				
				if (suitabilityRegProgramName.equals(programRun)) {
					test.log(LogStatus.PASS, "Program name at FA suitability header field is correct");
				} else {
					test.log(LogStatus.WARNING, "Program name at FA suitability header field is incorrect-->"+suitabilityRegProgramName);
				}
			}
			  
		    if (TestSuitability.check_OpenRegPlatformSuit1(driver).isSelected()) {
		    	 test.log(LogStatus.PASS, "Platform suitability radio button 1 is checked per AWA input");
		    } else {
		    	test.log(LogStatus.FAIL, "Platform suitability radio button 1 is not checked per AWA input");
		    }
		    
		    if (TestSuitability.check_OpenRegPlatformSuit2(driver).isSelected()) {
		    	 test.log(LogStatus.PASS, "Platform suitability radio button 2 is checked per AWA input");
		    } else {
		    	test.log(LogStatus.FAIL, "Platform suitability radio button 2 is not checked per AWA input");
		    }
		    
		    
		    if (TestSuitability.check_OpenRegPlatformSuit3(driver).isSelected()) {
		    	 test.log(LogStatus.PASS, "Platform suitability radio button 3 is checked per AWA input");
		    } else {
		    	test.log(LogStatus.FAIL, "Platform suitability radio button 3 is not checked per AWA input");
		    }
		    
		    if (TestSuitability.check_OpenRegPlatformSuit4(driver).isSelected()) {
		    	 test.log(LogStatus.PASS, "Platform suitability radio button 4 is checked per AWA input");
		    } else {
		    	test.log(LogStatus.FAIL, "Platform suitability radio button 4 is not checked per AWA input");
		    }
		    
		    if (TestSuitability.check_OpenRegPlatformSuit5(driver).isSelected()) {
		    	 test.log(LogStatus.PASS, "Platform suitability radio button 5 is checked per AWA input");
		    } else {
		    	test.log(LogStatus.FAIL, "Platform suitability radio button 5 is not checked per AWA input");
		    }
		    
		    if (TestSuitability.check_OpenRegPlatformSuit6(driver).isSelected()) {
		    	 test.log(LogStatus.PASS, "Platform suitability radio button 6 is checked per AWA input");
		    } else {
		    	test.log(LogStatus.FAIL, "Platform suitability radio button 6 is not checked per AWA input");
		    }
		    
		    if (TestSuitability.check_OpenRegProgramAttest(driver).isSelected()) {
		    	 test.log(LogStatus.PASS, "Program attestation is checked per AWA input");
		    } else {
		    	test.log(LogStatus.FAIL, "Program attestation is not checked per AWA input");
		    }
		    
				    
		    for(Integer count:programReasonList){  
		        System.out.println("FA"+count);  
						

		        if (count.equals(1) ) {
		        	if (TestSuitability.check_OpenRegProgramSuit1(driver).isSelected()) {
		        		test.log(LogStatus.PASS, "Program suitability radio button 1 is checked per AWA input");
		        	} else {
		        		test.log(LogStatus.FAIL, "Program suitability radio button 1 is not checked per AWA input"); 
		                	}
		        		
		        } else if (count.equals(2)) {
		        	if (TestSuitability.check_OpenRegProgramSuit2(driver).isSelected()) {
		        		test.log(LogStatus.PASS, "Program suitability radio button 2 is checked per AWA input");
		        	} else {
		        		test.log(LogStatus.FAIL, "Program suitability radio button 2 is not checked per AWA input"); 
		                	}
		        } else if (count.equals(3)) {
		        	if (TestSuitability.check_OpenRegProgramSuit3(driver).isSelected()) {
		        		test.log(LogStatus.PASS, "Program suitability radio button 3 is checked per AWA input");
		        	} else {
		        		test.log(LogStatus.FAIL, "Program suitability radio button 3 is not checked per AWA input"); 
		                	}
		        } else if (count.equals(4)) {
		        	if (TestSuitability.check_OpenRegProgramSuit4(driver).isSelected()) {
		        		test.log(LogStatus.PASS, "Program suitability radio button 4 is checked per AWA input");
		        	} else {
		        		test.log(LogStatus.FAIL, "Program suitability radio button 4 is not checked per AWA input"); 
		                	}
		        	
		        } else if (count.equals(5)) {
		        	if (TestSuitability.check_OpenRegProgramSuit5(driver).isSelected()) {
		        		test.log(LogStatus.PASS, "Program suitability radio button 5 is checked per AWA input");
		        	} else {
		        		test.log(LogStatus.FAIL, "Program suitability radio button 5 is not checked per AWA input"); 
		                	}
		        }
		    }
		    
		  
		
		    WebElement btnBackOpenRegFAApprove = driver.findElement(By.cssSelector("button[id=BACK_BUTTON_1]"));
		    btnBackOpenRegFAApprove.click(); 
		    
 		  } else if (flowRun.equals("Program/Manager/Model/Allocation Change")) {
 			  
 			String suitabilityAccountNumber = driver.findElement(By.cssSelector("input[id=DTB__tblPmmaAccountInfo_0_pmmaAccountNumber]")).getAttribute("value");
 			System.out.println("suit account number"+suitabilityAccountNumber);
 			System.out.println("json account number"+accountFAApprove);
 			String suitabilityProgramName = driver.findElement(By.cssSelector("input[id=DTB__tblPmmaAccountInfo_0_pmmaSolutionName]")).getAttribute("value");
 			System.out.println("suit prog name"+suitabilityProgramName);
 			System.out.println("json prog name"+programRun);
 			
 			if (suitabilityAccountNumber.equals(accountFAApprove)) {
 				test.log(LogStatus.PASS, "Account number at suitability header field is correct");
 			} else {
 				test.log(LogStatus.FAIL, "Account number at suitability header field is incorrect-->"+suitabilityAccountNumber);
 			}
 			
 			if (suitabilityProgramName.equals(programRun)) {
				test.log(LogStatus.PASS, "Program name at FA suitability header field is correct");
			} else {
				test.log(LogStatus.FAIL, "Program name at FA suitability header field is incorrect-->"+suitabilityProgramName);
			}
 			  
 			
 			  for(Integer count:programReasonList){  
 			        System.out.println(count);  
 			 
 			   
 			  if (count.equals(1) ) {
		        	
 				    if (TestSuitability.check_PMMAProgramSuit1(driver).isSelected()) { 
		        		test.log(LogStatus.PASS, "Program suitability radio button 1 is checked per AWA input");
		        	} else {
		        		test.log(LogStatus.FAIL, "Program suitability radio button 1 is not checked per AWA input"); 
		                	}
		        		
		        } else if (count.equals(2)) {
		        	
		    	    if (TestSuitability.check_PMMAProgramSuit2(driver).isSelected()) { 
		        		test.log(LogStatus.PASS, "Program suitability radio button 2 is checked per AWA input");
		        	} else {
		        		test.log(LogStatus.FAIL, "Program suitability radio button 2 is not checked per AWA input"); 
		                	}
		        } else if (count.equals(3)) {
		        	
		    	    if (TestSuitability.check_PMMAProgramSuit3(driver).isSelected()) { 
		        		test.log(LogStatus.PASS, "Program suitability radio button 3 is checked per AWA input");
		        	} else {
		        		test.log(LogStatus.FAIL, "Program suitability radio button 3 is not checked per AWA input"); 
		                	}
		        } else if (count.equals(4)) {
		        	
		    	    if (TestSuitability.check_PMMAProgramSuit4(driver).isSelected()) { 
		        		test.log(LogStatus.PASS, "Program suitability radio button 4 is checked per AWA input");
		        	} else {
		        		test.log(LogStatus.FAIL, "Program suitability radio button 4 is not checked per AWA input"); 
		                	}
		        	
		        } else if (count.equals(5)) {
		        	
		    	    if (TestSuitability.check_PMMAProgramSuit5(driver).isSelected()) { 
		        		test.log(LogStatus.PASS, "Program suitability radio button 5 is checked per AWA input");
		        	} else {
		        		test.log(LogStatus.FAIL, "Program suitability radio button 5 is not checked per AWA input"); 
		                	}
		        }
		    }
 			  
					
 			
 			 			
 			WebElement btnBackPmmaFAApprove = driver.findElement(By.cssSelector("button[id=BACK_BUTTON_2]"));
 			btnBackPmmaFAApprove.click(); 
 			
 		  } else if (flowRun.equals("Terminate Advisory Account")) {
 			 String suitabilityAccountNumber = driver.findElement(By.cssSelector("input[id=DTB__tblTermAccountInfo_0_termAccountNumber]")).getAttribute("value");
  			
  			 if (suitabilityAccountNumber.equals(accountFAApprove)) {
  				test.log(LogStatus.PASS, "Account number at suitability header field is correct");
  		 	 } else {
  				test.log(LogStatus.FAIL, "Account number at suitability header field is incorrect");
  			 }
 			  
 			  if (TestSuitability.check_TermPlatformSuit1(driver).isSelected()) {
 				 test.log(LogStatus.PASS, "Suitability check box 1 clicked");
 			  } else {
 				 test.log(LogStatus.FAIL, "Suitability check box 1 is not clicked per AWA");
 			  }
 			  
 			 if (TestSuitability.check_TermPlatformSuit2(driver).isSelected()) {
 				 test.log(LogStatus.PASS, "Suitability check box 2 clicked");
 			  } else {
 				 test.log(LogStatus.FAIL, "Suitability check box 2 is not clicked per AWA");
 			  }
 			 
 			if (TestSuitability.check_TermPlatformSuit3(driver).isSelected()) {
				 test.log(LogStatus.PASS, "Suitability check box 3 clicked");
			  } else {
				 test.log(LogStatus.FAIL, "Suitability check box 3 is not clicked per AWA");
			  }
 			
 			if (TestSuitability.check_TermPlatformSuit4(driver).isSelected()) {
				 test.log(LogStatus.PASS, "Suitability check box 4 clicked");
			  } else {
				 test.log(LogStatus.FAIL, "Suitability check box 4 is not clicked per AWA");
			  }
 			
 			if (TestSuitability.check_TermPlatformSuit5(driver).isSelected()) {
				 test.log(LogStatus.PASS, "Suitability check box 5 clicked");
			  } else {
				 test.log(LogStatus.FAIL, "Suitability check box 5 is not clicked per AWA");
			  }
 			
 			if (TestSuitability.check_TermPlatformSuit6(driver).isSelected()) {
				 test.log(LogStatus.PASS, "Suitability check box 6 clicked");
			  } else {
				 test.log(LogStatus.FAIL, "Suitability check box 6 is not clicked per AWA");
			  }
 			
 			if (TestSuitability.check_TermPlatformSuit7(driver).isSelected()) {
				 test.log(LogStatus.PASS, "Suitability check box 7 clicked");
			  } else {
				 test.log(LogStatus.FAIL, "Suitability check box 7 is not clicked per AWA");
			  }
 			
 			if (TestSuitability.check_TermPlatformSuit8(driver).isSelected()) {
				 test.log(LogStatus.PASS, "Suitability check box 8 clicked");
			  } else {
				 test.log(LogStatus.FAIL, "Suitability check box 8 is not clicked per AWA");
			  }
 			
 			if (TestSuitability.check_TermPlatformSuit9(driver).isSelected()) {
				 test.log(LogStatus.PASS, "Suitability check box 9 clicked");
			  } else {
				 test.log(LogStatus.FAIL, "Suitability check box 9 is not clicked per AWA");
			  }
 			  
 			WebElement btnBackTermFAApprove = driver.findElement(By.cssSelector("button[id=BACK_BUTTON_3]"));
 			btnBackTermFAApprove.click();  
 			  
 		  }
		  
	  }
		  
	
	   if (!flowRun.equals("Terminate Advisory Account") && !wrapRun.equals("NGA") && !typeRun.equals("ManualFee"))	  {
		  String advisorRate1 = driver.findElement(By.cssSelector("input[id=DTB__FEE_SCHEDULE_0_ADVISOR_RATE_TIER_0]")).getAttribute("value");
		  String advisorRate2 = driver.findElement(By.cssSelector("input[id=DTB__FEE_SCHEDULE_1_ADVISOR_RATE_TIER_0]")).getAttribute("value");
		  String advisorRate3 = driver.findElement(By.cssSelector("input[id=DTB__FEE_SCHEDULE_2_ADVISOR_RATE_TIER_0]")).getAttribute("value");
		  String advisorRate4 = driver.findElement(By.cssSelector("input[id=DTB__FEE_SCHEDULE_3_ADVISOR_RATE_TIER_0]")).getAttribute("value");
		  String advisorRate5 = driver.findElement(By.cssSelector("input[id=DTB__FEE_SCHEDULE_4_ADVISOR_RATE_TIER_0]")).getAttribute("value");
		  String advisorRate6 = driver.findElement(By.cssSelector("input[id=DTB__FEE_SCHEDULE_5_ADVISOR_RATE_TIER_0]")).getAttribute("value");
		  String clientRate1 = driver.findElement(By.cssSelector("input[id=DTB__FEE_SCHEDULE_0_CLIENT_RATE_TIER_0]")).getAttribute("value");
		  String clientRate2 = driver.findElement(By.cssSelector("input[id=DTB__FEE_SCHEDULE_1_CLIENT_RATE_TIER_0]")).getAttribute("value");
		  String clientRate3 = driver.findElement(By.cssSelector("input[id=DTB__FEE_SCHEDULE_2_CLIENT_RATE_TIER_0]")).getAttribute("value");	
		  String clientRate4 = driver.findElement(By.cssSelector("input[id=DTB__FEE_SCHEDULE_3_CLIENT_RATE_TIER_0]")).getAttribute("value");
		  String clientRate5 = driver.findElement(By.cssSelector("input[id=DTB__FEE_SCHEDULE_4_CLIENT_RATE_TIER_0]")).getAttribute("value");
		  String clientRate6 = driver.findElement(By.cssSelector("input[id=DTB__FEE_SCHEDULE_5_CLIENT_RATE_TIER_0]")).getAttribute("value");
		  
		 
		  if (advisorRate1.equals("")) {
			  test.log(LogStatus.FAIL, "FA Approval - Advisor Rate 1 is blank");
		  } else if (advisorRate1.equals("0.000")) {
			  test.log(LogStatus.FAIL, "FA Approval - Advisor Rate 1 is "+advisorRate1);
		  } else {
			  test.log(LogStatus.PASS, "FA Approval - Advisor Rate 1: "+advisorRate1);
		  }
		  
		  if (advisorRate2.equals("")) {
			  test.log(LogStatus.FAIL, "FA Approval - Advisor Rate 2 is blank");
		  } else if (advisorRate2.equals("0.000")) {
			  test.log(LogStatus.FAIL, "FA Approval - Advisor Rate 2 is "+advisorRate2);
		  } else {
			  test.log(LogStatus.PASS, "FA Approval - Advisor Rate 2: "+advisorRate2);
		  }
		  
		  if (advisorRate3.equals("")) {
			  test.log(LogStatus.FAIL, "FA Approval - Advisor Rate 3 is blank");
		  } else if (advisorRate3.equals("0.000")) {
			  test.log(LogStatus.FAIL, "FA Approval - Advisor Rate 3 is "+advisorRate3);
		  } else {
			  test.log(LogStatus.PASS, "FA Approval - Advisor Rate 3: "+advisorRate3);
		  }
		  
		  if (advisorRate4.equals("")) {
			  test.log(LogStatus.FAIL, "FA Approval - Advisor Rate 4 is blank");
		  } else if (advisorRate4.equals("0.000")) {
			  test.log(LogStatus.FAIL, "FA Approval - Advisor Rate 4 is "+advisorRate4);
		  } else {
			  test.log(LogStatus.PASS, "FA Approval - Advisor Rate 4: "+advisorRate4);
		  }
		  
		  if (advisorRate5.equals("")) {
			  test.log(LogStatus.FAIL, "FA Approval - Advisor Rate 5 is blank");
		  } else if (advisorRate5.equals("0.000")) {
			  test.log(LogStatus.FAIL, "FA Approval - Advisor Rate 5 is "+advisorRate5);
		  } else {
			  test.log(LogStatus.PASS, "FA Approval - Advisor Rate 5: "+advisorRate5);
		  }
		  
		  if (advisorRate6.equals("")) {
			  test.log(LogStatus.FAIL, "FA Approval - Advisor Rate 6 is blank");
		  } else if (advisorRate6.equals("0.000")) {
			  test.log(LogStatus.FAIL, "FA Approval - Advisor Rate 6 is "+advisorRate6);
		  } else {
			  test.log(LogStatus.PASS, "FA Approval - Advisor Rate 6: "+advisorRate6);
		  }
		 
		  if (clientRate1.equals("")) {
			  test.log(LogStatus.FAIL, "FA Approval - Client Rate 1 is blank");
		  } else if (clientRate1.equals("0.000")) {
			  test.log(LogStatus.FAIL, "FA Approval - Client Rate 1 is "+clientRate1);
		  } else {
			  test.log(LogStatus.PASS, "FA Approval - Client Rate 1: "+clientRate1);
		  }
		  
		  if (clientRate2.equals("")) {
			  test.log(LogStatus.FAIL, "FA Approval - Client Rate 2 is blank");
		  } else if (clientRate2.equals("0.000")) {
			  test.log(LogStatus.FAIL, "FA Approval - Client Rate 2 is "+clientRate2);
		  } else {
			  test.log(LogStatus.PASS, "FA Approval - Client Rate 2: "+clientRate2);
		  }
		  
		  
		  if (clientRate3.equals("")) {
			  test.log(LogStatus.FAIL, "FA Approval - Client Rate 3 is blank");
		  } else if (clientRate3.equals("0.000")) {
			  test.log(LogStatus.FAIL, "FA Approval - Client Rate 3 is "+clientRate3);
		  } else {
			  test.log(LogStatus.PASS, "FA Approval - Client Rate 3: "+clientRate3);
		  }
		  
		  if (clientRate4.equals("")) {
			  test.log(LogStatus.FAIL, "FA Approval - Client Rate 4 is blank");
		  } else if (clientRate4.equals("0.000")) {
			  test.log(LogStatus.FAIL, "FA Approval - Client Rate 4 is "+clientRate4);
		  } else {
			  test.log(LogStatus.PASS, "FA Approval - Client Rate 4: "+clientRate4);
		  }
		  
		  if (clientRate5.equals("")) {
			  test.log(LogStatus.FAIL, "FA Approval - Client Rate 5 is blank");
		  } else if (clientRate5.equals("0.000")) {
			  test.log(LogStatus.FAIL, "FA Approval - Client Rate 5 is "+clientRate5);
		  } else {
			  test.log(LogStatus.PASS, "FA Approval - Client Rate 5: "+clientRate5);
		  }
		  
		  if (clientRate6.equals("")) {
			  test.log(LogStatus.FAIL, "FA Approval - Client Rate 6 is blank");
		  } else if (clientRate5.equals("0.000")) {
			  test.log(LogStatus.FAIL, "FA Approval - Client Rate 6 is "+clientRate6);
		  } else {
			  test.log(LogStatus.PASS, "FA Approval - Client Rate 6: "+clientRate6);
		  }
		  
		
	 }
	   
		  
		  WebElement btnFinalFAApprove = driver.findElement(By.cssSelector("button[id=SIG__FA_APPROVAL]"));
		  btnFinalFAApprove.click();
		  
		  Alert alert = driver.switchTo().alert(); 
		  alert.accept();
		  
		  if (flowRun.equals("Fee Schedule Change Only")) { 
			  Alert alert2 = driver.switchTo().alert(); 
			  alert2.accept();
		  
		  }
		  
		  
		  
		  
		  driver.switchTo().window(attestationID);
		  
		  
		  WebElement btnFAGo = driver.findElement(By.cssSelector("button[id=DFS__GO]")); btnFAGo.click();
		  
		  
		  WebElement FAApproveClose = driver.findElement(By.cssSelector("input[id=button_CloseWindow]"));
		  FAApproveClose.click();
		  
		  driver.switchTo().window(faaID); 
		  // driver.close();
		 	  
	} catch (Exception e) {
		test.log(LogStatus.FAIL, e.toString());
	}
	  
	  }
	 
	
	public void findWindow (String window) {
		
		 Set <String> WinHandles = driver.getWindowHandles();
		  
		  while (!driver.getTitle().contains(window)) {
		        for (String handle: WinHandles) {
		       
		          
		    	  	driver.switchTo().window(handle);
		    	  	
		    	  	
	  
		        }
		    }

		
	    }
	
	
	}
