//'****************************************************************************
//' Description      : handles page object model for Proxy/Confirm info
//' Author           : Mel Llesol
//' Created          : 11/5/2019
//' Last Updated     : 03/23/2020
//'****************************************************************************



package pagelayer.testawa.baird;

import org.openqa.selenium.*;

//each method returns a web element to be processed by auto layer 
public class TestOtherInfo {
	
	private static WebElement element = null;
	
    public static WebElement proxyConfirm (WebDriver driver) {
		
		//element = driver.findElement(By.cssSelector("input[id=DTB__tblProxyConfirm_0_PROXY_QUESTION]"));
    	  element = driver.findElement(By.cssSelector("input[id=DTB__tblProxyConfirm_0_PROXY_QUESTION]"));
		
		return element;
		
	}
    
    
 public static WebElement CUSIPSecurities_RadioYes (WebDriver driver) {
		
		element = driver.findElement(By.cssSelector("input[id=DTB__tblSyndicates_0_Syndicates_RadioButton19]"));
		
		return element;
		
	}
 
 public static WebElement CUSIPSecurities_RadioNo (WebDriver driver) {
		
		element = driver.findElement(By.cssSelector("input[id=DTB__tblSyndicates_0_Syndicates_RadioButton20]"));
		
		return element;
		
	}
    
 public static WebElement CUSIPMutualFunds_RadioYes (WebDriver driver) {
		
		element = driver.findElement(By.cssSelector("input[id=DTB__tblSyndicates_0_FrontLoadMutualFunds_RadioButton21]"));
		
		return element;
		
	}
 
 public static WebElement CUSIPMutualFunds_RadioNo (WebDriver driver) {
		
		element = driver.findElement(By.cssSelector("input[id=DTB__tblSyndicates_0_FrontLoadMutualFunds_RadioButton22]"));
		
		return element;
		
	}
 
 public static WebElement CUSIPSymbol (WebDriver driver) {
		
		element = driver.findElement(By.cssSelector("input[id=DTB__tblSymbolCusip_0_Symbol0]"));
		
		return element;
		
	}
 
 public static WebElement CUSIPDate (WebDriver driver) {
		
		element = driver.findElement(By.cssSelector("input[id=DTB__tblSymbolCusip_0_Date0]"));
		
		return element;
		
	}
 
 public static WebElement CUSIPSecurity (WebDriver driver) {
		
		element = driver.findElement(By.cssSelector("input[id=DTB__tblSymbolCusip_0_Security0]"));
		
		return element;
		
	}

 
    
    public static WebElement otherinfoFinish (WebDriver driver) {
		
		element = driver.findElement(By.cssSelector("button[id=btnContinue_3]"));
		
		return element;
		
	}
    
    

}
