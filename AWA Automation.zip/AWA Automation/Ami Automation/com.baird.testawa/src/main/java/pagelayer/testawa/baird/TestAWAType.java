//'****************************************************************************
//' Description      : handles page object model for account input 
//' Author           : Mel Llesol
//' Created          : 11/5/2019
//' Last Updated     : 03/23/2020
//'****************************************************************************


package pagelayer.testawa.baird;

import org.openqa.selenium.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class TestAWAType {
	
	private static WebElement element = null;
	
	//each method returns a web element to be processed by auto layer 
	public static WebElement txtbox_AccountNum (WebDriver driver) {
		
	    element = driver.findElement((By.cssSelector("input[id=CLIENT_ACCOUNT]")));
	
		
		return element;
		
	}
	
    public static WebElement txtbox_RegAccount (WebDriver driver) {
		
	    element = driver.findElement((By.cssSelector("input[id=REGISTRATION_TO_ACCOUNT]")));
		
		
		return element;
		
	}
	
	public static WebElement form_Type (WebDriver driver) {
		
		element = driver.findElement((By.cssSelector("div[id=Rectangle1_17]")));
			
		return element;
		
			
	}
	
	
	public static WebElement drop_Solution (WebDriver driver) {
		element = driver.findElement(By.cssSelector("select[id=REGISTRATION_SOLUTION_CHANGE]"));
		
		return element;
		
	}
	
	public static WebElement button_ContinueType (WebDriver driver) {
		
		element = driver.findElement(By.cssSelector("button[id=btnContinue]"));
		
		return element;
		
	}

}
