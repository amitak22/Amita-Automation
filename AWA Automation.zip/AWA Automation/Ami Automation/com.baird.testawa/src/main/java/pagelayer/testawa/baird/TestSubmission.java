//'****************************************************************************
//' Description      : handles page object model for submitting transaction
//' Author           : Mel Llesol
//' Created          : 11/5/2019
//' Last Updated     : 03/23/2020
//'****************************************************************************


package pagelayer.testawa.baird;

import org.openqa.selenium.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

//each method returns a web element to be processed by auto layer 
public class TestSubmission {
	
	private static WebElement element = null;
	
	public static WebElement button_UpdateHousehold (WebDriver driver) {
		
		element = driver.findElement(By.cssSelector("button[id=performHM]"));
		
		return element;
		
	}
	
	public static WebElement checkbox_AddHousehold (WebDriver driver) {
		
		element = driver.findElement(By.cssSelector("input[id=DTB__householdAccounts_0_ADD_TO_HOUSEHOLD]"));
		
		return element;
		
	}
	
    public static WebElement checkbox_AddHousehold2 (WebDriver driver) {
		
		element = driver.findElement(By.cssSelector("input[id=DTB__householdAccounts_1_ADD_TO_HOUSEHOLD]"));
		
		return element;
		
	}
	
	public static WebElement button_SaveMaintenance (WebDriver driver) {
		
		element = driver.findElement(By.cssSelector("button[id=saveMaintenance]"));
		
		return element;
		
	}
	
	public static WebElement button_SubmitAccount (WebDriver driver) {
	   element = driver.findElement(By.cssSelector("button[id=submitSession]"));
	   
	   return element;
	   
		
	}
	
	public static WebElement button_BuildDocPacket (WebDriver driver) {
		   element = driver.findElement(By.cssSelector("button[id=buildPacket]"));
		   
		   return element;
		   
			
		}
	
	

}
