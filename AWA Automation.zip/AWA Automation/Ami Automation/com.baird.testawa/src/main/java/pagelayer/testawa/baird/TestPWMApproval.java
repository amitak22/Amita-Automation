//'****************************************************************************
//' Description      : handles page object model for Holding Queue approval  
//' Author           : Mel Llesol
//' Created          : 11/5/2019
//' Last Updated     : 03/23/2020
//'****************************************************************************


package pagelayer.testawa.baird;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import java.util.concurrent.TimeUnit;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;


//main logic to check web elements for Supervisor approval
public class TestPWMApproval {
	

 	WebDriver driver;
	
	public void PWMApprove (String accountNumber, String flow, Boolean suitability, WebDriver driver) {
		String accountNum = accountNumber;
		Boolean suitabilityReview = suitability;
		String flowRun = flow;
		

		System.setProperty("webdriver.chrome.driver","src" + File.separator + "main" + File.separator + "resources" + File.separator + "WebDriver" +File.separator+ "chromedriver.exe");
		this.driver = driver;
	
		
	 try {
		driver.get("http://uatworkflow");
		driver.manage().window().maximize();
		
		for (int i=0; i<5; i++) {
		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
		driver.findElement(By.linkText("Work Queues")).click();
		driver.findElement(By.linkText("Advisory_Workflow_PWM_Approval_Queue")).click();
		}
		
		
		String processAcct = convertAccount (accountNum);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		String userid = driver.findElement(By.xpath("//td[@class='user_id_hmenu']")).getText();
		
		List<WebElement> approveItems = new ArrayList<WebElement>();
		approveItems = driver.findElements(By.xpath("//td[contains(text(), '"+userid+"')]//following::td//a[contains(text(),'" + processAcct + "')]"));
		 
		WebElement lastElement = approveItems.get(approveItems.size()-1);
		
		lastElement.click();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	    driver.manage().window().maximize();
		  
		  String faaID = driver.getWindowHandle();
		  findWindow("Account Attestation Form");
		  String attestationID = driver.getWindowHandle();
		  
		  driver.manage().window().maximize();
		  
		   if (suitabilityReview.equals(true)) {
		   WebElement btnReviewDoc = driver.findElement(By.cssSelector("button[id=suitabilityReviewButton]"));
		   btnReviewDoc.click();
		   
		   WebElement btnBackFAApprove = driver.findElement(By.cssSelector("button[id=BACK_BUTTON]"));
		   btnBackFAApprove.click();
		   }
		   
		   WebElement btnFinalFAApprove = driver.findElement(By.cssSelector("button[id=SIG__SUPERVISION_APPROVAL]"));
		   btnFinalFAApprove.click();
		   
		   Alert alert = driver.switchTo().alert();
		   alert.accept();
		   
		   if (flowRun.equals("Fee Schedule Change Only")) {
			   Alert alert2 = driver.switchTo().alert();
			   alert2.accept();
			      
		   }
		   
		   
		   
		     
		   driver.switchTo().window(attestationID);
		   
		   
		   WebElement btnFAGo = driver.findElement(By.cssSelector("button[id=DFS__GO]"));
		   btnFAGo.click();
		 
		   WebElement FAApproveClose = driver.findElement(By.cssSelector("input[id=button_CloseWindow]"));
		   FAApproveClose.click();
		   

		   
		    driver.switchTo().window(faaID);
		  //  driver.close();
	   } catch (Exception e) {
		   e.printStackTrace();
	   }
	
	}
	
	
	public String convertAccount (String account) {
		String accountConvert = account;
		
		char [] charAcct = new char [4];
		
		for (int i=0; i<4; i++) {
			charAcct[i] = accountConvert.charAt(i);
			
		}
		
		String leftaccount = new String (charAcct);
		
		
		
		for (int i=4; i<8; i++) {
			charAcct[i-4] = accountConvert.charAt(i);
			
		}
		
		String rightaccount = new String (charAcct);
		
		String finalAcct = leftaccount+"-"+rightaccount;
		

		return finalAcct;
		
	}
	
	public void findWindow (String window) {
		
		 Set <String> WinHandles = driver.getWindowHandles();
		  
		  while (!driver.getTitle().contains(window)) {
		        for (String handle: WinHandles) {
		       
		           	driver.switchTo().window(handle);
		    	  
		    	  	
	  
		        }
		    }

		
	    }


}