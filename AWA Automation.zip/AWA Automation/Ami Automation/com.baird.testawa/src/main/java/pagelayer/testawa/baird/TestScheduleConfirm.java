//'****************************************************************************
//' Description      : handles page object model for confirming fee schedule
//' Author           : Mel Llesol
//' Created          : 11/5/2019
//' Last Updated     : 03/23/2020
//'****************************************************************************



package pagelayer.testawa.baird;

import org.openqa.selenium.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

//each method returns a web element to be processed by auto layer 
public class TestScheduleConfirm {
    
	private static WebElement element = null;
	
	public static WebElement button_ConfirmSchedule (WebDriver driver) {
		
		element = driver.findElement(By.cssSelector("button[name=btnContinue_3]"));
		
		return element;
				
	}
	
		
	
}
