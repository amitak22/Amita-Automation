package pagelayer.testawa.baird;

import org.openqa.selenium.*;

public class TestSuitability {
	
private static WebElement element = null;
	
	public static WebElement check_OpenRegPlatformSuit1 (WebDriver driver) {
		
		element = driver.findElement(By.cssSelector("input[id=openRegChgAdvPlatformReason_1]"));
		
		return element;
		
	}
	
    public static WebElement check_OpenRegPlatformSuit2 (WebDriver driver) {
		
		element = driver.findElement(By.cssSelector("input[id=openRegChgAdvPlatformReason_2]"));
		
		return element;
		
	}
    
    public static WebElement check_OpenRegPlatformSuit3 (WebDriver driver) {
		
		element = driver.findElement(By.cssSelector("input[id=openRegChgAdvPlatformReason_3]"));
		
		return element;
		
	}
    
    public static WebElement check_OpenRegPlatformSuit4 (WebDriver driver) {
		
		element = driver.findElement(By.cssSelector("input[id=openRegChgAdvPlatformReason_4]"));
		
		return element;
		
	}
    
   public static WebElement check_OpenRegPlatformSuit5 (WebDriver driver) {
		
		element = driver.findElement(By.cssSelector("input[id=openRegChgAdvPlatformReason_5]"));
		
		return element;
		
	}
   
   public static WebElement check_OpenRegPlatformSuit6 (WebDriver driver) {
		
		element = driver.findElement(By.cssSelector("input[id=openRegChgAdvPlatformReason_6]"));
		
		return element;
		
	}
   
   public static WebElement check_OpenRegProgramAttest (WebDriver driver) {
		
		element = driver.findElement(By.cssSelector("input[id=openRegChgAdvProgramAttest_1]"));
		
		return element;
		
	}
   
   public static WebElement check_OpenRegProgramSuit1 (WebDriver driver) {
		
		element = driver.findElement(By.cssSelector("input[id=openRegChgAdvProgramReason_1]"));
		
		return element;
		
	}
   
   
   public static WebElement check_OpenRegProgramSuit2 (WebDriver driver) {
		
		element = driver.findElement(By.cssSelector("input[id=openRegChgAdvProgramReason_2]"));
		
		return element;
		
	}
   
   public static WebElement check_OpenRegProgramSuit3 (WebDriver driver) {
		
		element = driver.findElement(By.cssSelector("input[id=openRegChgAdvProgramReason_3]"));
		
		return element;
		
	}
   
   public static WebElement check_OpenRegProgramSuit4 (WebDriver driver) {
		
		element = driver.findElement(By.cssSelector("input[id=openRegChgAdvProgramReason_4]"));
		
		return element;
		
	}
   
   public static WebElement check_OpenRegProgramSuit5 (WebDriver driver) {
		
		element = driver.findElement(By.cssSelector("input[id=openRegChgAdvProgramReason_5]"));
		
		return element;
		
	}
   
   public static WebElement check_PMMAProgramAttest (WebDriver driver) {
		
		element = driver.findElement(By.cssSelector("input[id=pmmaAdvProgramAttest_1]"));
		
		return element;
		
	}
   
   public static WebElement check_PMMAProgramSuit1 (WebDriver driver) {
		
		element = driver.findElement(By.cssSelector("input[id=pmmaAdvProgramReason_1]"));
		
		return element;
		
	}
   
   public static WebElement check_PMMAProgramSuit2 (WebDriver driver) {
		
		element = driver.findElement(By.cssSelector("input[id=pmmaAdvProgramReason_2]"));
		
		return element;
		
	}
   
   public static WebElement check_PMMAProgramSuit3 (WebDriver driver) {
		
		element = driver.findElement(By.cssSelector("input[id=pmmaAdvProgramReason_3]"));
		
		return element;
		
	}
   
   public static WebElement check_PMMAProgramSuit4 (WebDriver driver) {
		
		element = driver.findElement(By.cssSelector("input[id=pmmaAdvProgramReason_4]"));
		
		return element;
		
	}
   
   public static WebElement check_PMMAProgramSuit5 (WebDriver driver) {
		
		element = driver.findElement(By.cssSelector("input[id=pmmaAdvProgramReason_5]"));
		
		return element;
		
	}
   
   
   public static WebElement button_OpenRegNext (WebDriver driver) {
		
		element = driver.findElement(By.cssSelector("button[id=btnContinue_10]"));
		
		return element;
		
	}
   
   public static WebElement button_OpenRegBack (WebDriver driver) {
		
		element = driver.findElement(By.cssSelector("button[id=btnBack_10]"));
		
		return element;
		
	}
   
   
   
   public static WebElement button_PmmaNext (WebDriver driver) {
		
		element = driver.findElement(By.cssSelector("button[id=btnContinue_11]"));
		
		return element;
		
	}
   
   public static WebElement check_TermPlatformSuit1 (WebDriver driver) {
		
		element = driver.findElement(By.cssSelector("input[id=termAdvToBrokerageReason_1]"));
		
		return element;
		
	}
   
   public static WebElement check_TermPlatformSuit2 (WebDriver driver) {
		
		element = driver.findElement(By.cssSelector("input[id=termAdvToBrokerageReason_2]"));
		
		return element;
		
	}
   
   public static WebElement check_TermPlatformSuit3 (WebDriver driver) {
		
		element = driver.findElement(By.cssSelector("input[id=termAdvToBrokerageReason_3]"));
		
		return element;
		
	}
   
   public static WebElement check_TermPlatformSuit4 (WebDriver driver) {
		
		element = driver.findElement(By.cssSelector("input[id=termAdvToBrokerageReason_4]"));
		
		return element;
		
	}
   
   public static WebElement check_TermPlatformSuit5 (WebDriver driver) {
		
		element = driver.findElement(By.cssSelector("input[id=termAdvToBrokerageReason_5]"));
		
		return element;
		
	}
   
   public static WebElement check_TermPlatformSuit6 (WebDriver driver) {
		
		element = driver.findElement(By.cssSelector("input[id=termAdvToBrokerageReason_6]"));
		
		return element;
		
	}
   
   public static WebElement check_TermPlatformSuit7 (WebDriver driver) {
		
		element = driver.findElement(By.cssSelector("input[id=termAdvToBrokerageReason_7]"));
		
		return element;
		
	}
   
   public static WebElement check_TermPlatformSuit8 (WebDriver driver) {
		
		element = driver.findElement(By.cssSelector("input[id=termAdvToBrokerageReason_8]"));
		
		return element;
		
	}
   
   public static WebElement check_TermPlatformSuit9 (WebDriver driver) {
		
		element = driver.findElement(By.cssSelector("input[id=termAdvToBrokerageReason_9]"));
		
		return element;
		
	}
   
   public static WebElement button_TermNext (WebDriver driver) {
		
		element = driver.findElement(By.cssSelector("button[id=btnContinue_12]"));
		
		return element;
		
	}
  
   
   
   
   

}
