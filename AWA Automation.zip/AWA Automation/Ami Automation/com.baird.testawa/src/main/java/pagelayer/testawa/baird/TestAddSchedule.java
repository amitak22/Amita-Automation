//'****************************************************************************
//' Description      : handles page object model for adding schedule
//' Author           : Mel Llesol
//' Created          : 11/5/2019
//' Last Updated     : 03/23/2020
//'****************************************************************************


package pagelayer.testawa.baird;

import org.openqa.selenium.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class TestAddSchedule {

	private static WebElement element = null;
	
	
	//each method returns a web element to be processed by auto layer 
	public static WebElement button_AddNewSchedule (WebDriver driver) {
	
		element = driver.findElement(By.cssSelector("button[id=btnAddFeeSchedule]"));
		
		return element;
		
		
	}
	
	public static WebElement drop_TypeSchedule (WebDriver driver) {
		element = driver.findElement(By.cssSelector("select[id=DTB__tblHouseHold_0_feeScheduleHH]"));
		
		return element;
		
		
	}
	
	public static WebElement text_HouseholdTier1 (WebDriver driver) {
		element = driver.findElement(By.cssSelector("input[id=DTB__tblHouseHold_0_tier1"));
		
		return element;
		
	}
	
	public static WebElement text_HouseholdTier2 (WebDriver driver) {
		element = driver.findElement(By.cssSelector("input[id=DTB__tblHouseHold_0_tier2"));
		
		return element;
		
	}
	
	public static WebElement text_HouseholdTier3 (WebDriver driver) {
		element= driver.findElement(By.cssSelector("input[id=DTB__tblHouseHold_0_tier3"));
		
		return element;
		
				
	}
	
	public static WebElement text_HouseholdTier4 (WebDriver driver) {
		
		element = driver.findElement(By.cssSelector("input[name=DTB__tblHouseHold_0_tier4"));
		
		return element;
		
		
	}
	
	public static WebElement text_HouseholdTier5 (WebDriver driver) {
		element = driver.findElement(By.cssSelector("input[name=DTB__tblHouseHold_0_tier5"));
		
		return element;
		
		
	}
	
	public static WebElement text_HouseholdTier6 (WebDriver driver) {
		element = driver.findElement(By.cssSelector("input[id=DTB__tblHouseHold_0_tier6"));
		
		return element;
	}
	
	public static WebElement drop_ApplySchedule (WebDriver driver) {
		element = driver.findElement(By.cssSelector("select[id=DTB__tblRepricing_0_feeScheduleName]"));
		
		return element;
		
		
	}
	
	
	public static WebElement drop_ApplySchedule2 (WebDriver driver) {
		element = driver.findElement(By.cssSelector("select[id=DTB__tblRepricing_1_feeScheduleName]"));
		
		return element;
		
		
	}
	
	public static WebElement button_NextHousehold (WebDriver driver) {
		element = driver.findElement(By.cssSelector("button[name=btnRepricingNext]"));
		
		return element;
		
	}
	
	public static WebElement drop_Attachment (WebDriver driver) {
		element = driver.findElement(By.cssSelector("select[id=DTB__tblHouseHold_0_feeScheduleHH]"));
		
		return element;
		
	}
	
	public static WebElement check_ManualFee (WebDriver driver) {
		element = driver.findElement(By.cssSelector("input[name=feeScheduleManualAttach]"));
		
		return element;
		
	}
	
	public static WebElement drop_ApplyScheduleNGF (WebDriver driver) {
		element = driver.findElement(By.cssSelector("select[id=FEE_SCHEDULE_DROPDOWN]"));
		
		return element;
	}
	
	
	
	public static WebElement text_Advisor0 (WebDriver driver) {
		element = driver.findElement(By.cssSelector("input[id=DTB__tblFeeSchedule_0_Advisor0]"));
		
		return element;
	}
	
	public static WebElement text_Advisor1 (WebDriver driver) {
		element = driver.findElement(By.cssSelector("input[id=DTB__tblFeeSchedule_0_Advisor1]"));
		
		return element;
	}

	public static WebElement text_Advisor2 (WebDriver driver) {
		element = driver.findElement(By.cssSelector("input[id=DTB__tblFeeSchedule_0_Advisor2]"));
		
		return element;
	}
	
	public static WebElement text_Advisor3 (WebDriver driver) {
		element = driver.findElement(By.cssSelector("input[id=DTB__tblFeeSchedule_0_Advisor3]"));
		
		return element;
	}
	
	public static WebElement text_Advisor4 (WebDriver driver) {
		element = driver.findElement(By.cssSelector("input[id=DTB__tblFeeSchedule_0_Advisor4]"));
		
		return element;
	}
	
	public static WebElement text_Advisor5 (WebDriver driver) {
		element = driver.findElement(By.cssSelector("input[id=DTB__tblFeeSchedule_0_Advisor5]"));
		
		return element;
	}
	


}
