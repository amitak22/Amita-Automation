//'****************************************************************************
//' Description      : handles page object model for Holding Queue approval  
//' Author           : Mel Llesol
//' Created          : 11/5/2019
//' Last Updated     : 03/23/2020
//'****************************************************************************

package pagelayer.testawa.baird;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import java.util.concurrent.TimeUnit;
import java.util.Set;
import java.util.ArrayList;
import java.util.List;

//main logic to check web elements for Holding Queue approval
public class TestHoldingQueue {

	Boolean suitabilityReview;
	
 	WebDriver driver;
	
	
	public void approveHold (String account, WebDriver driver) {
	     
		this.driver = driver;
	
		
	try {
		driver.get("http://uatworkflow");
		driver.manage().window().maximize();
	
	
		
	
		
		 		  		
	
	String accountFAApprove = account;
		
	char [] charAcct = new char [4];
	
	for (int i=0; i<4; i++) {
		charAcct[i] = accountFAApprove.charAt(i);
		
	}
	
	String leftaccount = new String (charAcct);
	
	
	
	for (int i=4; i<8; i++) {
		charAcct[i-4] = accountFAApprove.charAt(i);
		
	}
	
	String rightaccount = new String (charAcct);
	
	String finalAcct = leftaccount+"-"+rightaccount;
	
	
	
	
	driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
	driver.findElement(By.linkText("Work Queues")).click();
	driver.findElement(By.linkText("FBAA_HOLDING_QUEUE")).click();
	driver.findElement(By.linkText("Work Queues")).click();
	driver.findElement(By.linkText("FBAA_HOLDING_QUEUE")).click();
	driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	String userid = driver.findElement(By.xpath("//td[@class='user_id_hmenu']")).getText();
	
	driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	List<WebElement> approveItems = new ArrayList<WebElement>();
	approveItems = driver.findElements(By.xpath("//td[contains(text(), '"+userid+"')]//following::td//a[contains(text(),'" + finalAcct + "')]"));
	 
	WebElement lastElement = approveItems.get(approveItems.size()-1);
	
	
	
	lastElement.click();
	driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	driver.manage().window().maximize();
	String faaID = driver.getWindowHandle();
	findWindow("FBAA Review Form");
	String fbaareviewID = driver.getWindowHandle();
	  
	  
	   
	     
	   driver.switchTo().window(fbaareviewID);
	   
	   driver.manage().window().maximize();
	   
	   
	   WebElement btnHoldQueueGo = driver.findElement(By.cssSelector("button[id=DFS__GO]"));
	   btnHoldQueueGo.click();
	   
	  	   		 
	   WebElement btnHoldQueueClose = driver.findElement(By.cssSelector("input[id=button_CloseWindow]"));
	   btnHoldQueueClose.click();
	   
	 
	    driver.switchTo().window(faaID);
	  //  driver.close();
	    
	} catch (Exception e) {
		e.printStackTrace();
	}
	    
     
	 	
	}
	
	
	//finds a window given a parameter
	public void findWindow (String window) {
		
		 Set <String> WinHandles = driver.getWindowHandles();
		  
		  while (!driver.getTitle().contains(window)) {
		        for (String handle: WinHandles) {
		       
		    	  	driver.switchTo().window(handle);
		    	  	
		    	  	
	  
		        }
		    }

		
	    }
	}

	



	
	

