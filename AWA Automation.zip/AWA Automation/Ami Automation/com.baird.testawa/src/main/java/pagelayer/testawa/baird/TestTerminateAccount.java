//'****************************************************************************
//' Description      : handles page object model for termination choices
//' Author           : Mel Llesol
//' Created          : 01/6/2020
//' Last Updated     : 03/23/2020
//'****************************************************************************



package pagelayer.testawa.baird;

import org.openqa.selenium.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

//each method returns a web element to be processed by auto layer 
public class TestTerminateAccount {
	
	private static WebElement element = null;
	
	public static WebElement button_DoNotLiquidate (WebDriver driver) {
		
	    element = driver.findElement((By.cssSelector("input[id=DISPOSITION_OF_ASSETS_RadioButton2]")));
		
		
		return element;
		
	}
	
    public static WebElement button_Finish (WebDriver driver) {
		
	    element = driver.findElement((By.cssSelector("button[id=btnContinue_4]")));
		
		
		return element;
		
	}
	
	
	
    
}
