package pagelayer.testawa.baird;

import org.openqa.selenium.*;


public class TestBairdNext {
	
private static WebElement element = null;
	
	public static WebElement txtbox_ClientName (WebDriver driver) {
		element = driver.findElement(By.cssSelector("input[id=txtClientName]"));
		
		return element;
		
	}
	
	public static WebElement txtbox_BirthDate (WebDriver driver) {
		element = driver.findElement(By.cssSelector("input[id=txtDateOfBirth]"));
		
		return element;
		
	}
	
	public static WebElement txtbox_ServiceDate (WebDriver driver) {
		element = driver.findElement(By.cssSelector("input[id=DTB__tblAdvicePricing_0_txtServiceStartDate]"));
		
		return element;
		
	}
	
	public static WebElement txtbox_AnnualFee (WebDriver driver) {
		element = driver.findElement(By.cssSelector("input[id=DTB__tblAdvicePricing_0_txtAnnualFee]"));
		
		return element;
		
	}
	
	
	public static WebElement checkBox_LimitedSalaryGrowth (WebDriver driver) {
		element = driver.findElement(By.cssSelector("input[id=chkLimitedSalaryGrowth]"));
		
		return element;
		
	}
	
	
	public static WebElement checkBox_StrongCareerGrowth (WebDriver driver) {
		element = driver.findElement(By.cssSelector("input[id=chkStrongCareerGrowth]"));
		
		return element;
		
	}
	
	public static WebElement checkBox_ProfessionalSalaryGrowth (WebDriver driver) {
		element = driver.findElement(By.cssSelector("input[id=chkProfessionalSalaryGrowth]"));
		
		return element;
		
	}
	
	public static WebElement checkBox_NoNetworkOfSecurity (WebDriver driver) {
		element = driver.findElement(By.cssSelector("input[id=chkNoNetworkOfSecurity]"));
		
		return element;
		
	}
	
	public static WebElement checkBox_AumOpportunities (WebDriver driver) {
		element = driver.findElement(By.cssSelector("input[id=chkAumOpportunities]"));
		
		return element;
		
	}
	
	public static WebElement checkBox_NetworkOfAumClients (WebDriver driver) {
		element = driver.findElement(By.cssSelector("input[id=chkNetworkOfAumClients]"));
		
		return element;
		
	}
	
	public static WebElement txtArea_BairdNextConsiderations (WebDriver driver) {
		element = driver.findElement(By.cssSelector("textarea[id=txtBairdNextConsiderations]"));
		
		return element;
		
	}
	
	public static WebElement checkbox_ExistingClientHeir (WebDriver driver) {
		element = driver.findElement(By.cssSelector("input[id=chkExistingClientHeir]"));
		
		return element;
		
	}
	
	public static WebElement txtbox_StatementHHAccount (WebDriver driver) {
		element = driver.findElement(By.cssSelector("input[id=txtStatementHHAccount]"));
		
		return element;
		
	}
	
	public static WebElement txtArea_OtherMeetClient (WebDriver driver) {
		element = driver.findElement(By.cssSelector("textarea[id=txtOtherMeetClient]"));
		
		return element;
		
	}
	
	public static WebElement button_Next (WebDriver driver) {
		element = driver.findElement(By.cssSelector("button[id=btnNextNext]"));
		
		return element;
		
	}
	
	
    
}
