//'****************************************************************************
//' Description      : handles page object model for compliance items
//' Author           : Mel Llesol
//' Created          : 11/5/2019
//' Last Updated     : 03/23/2020
//'****************************************************************************


package pagelayer.testawa.baird;

import org.openqa.selenium.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

//each method returns a web element to be processed by auto layer 
public class TestCompliance {
	
	private static WebElement element = null;
	
	public static WebElement radio_CompYes (WebDriver driver) {
		
		element = driver.findElement(By.cssSelector("input[id=ADVISORY_VS_BROKERAGE_RadioButton15]"));
		
		return element;
		
	}
	
	public static WebElement check_SuitComp (WebDriver driver) {
		
		element = driver.findElement(By.cssSelector("input[name=SUITABILITY_1]"));
		
		return element;
		
	}
	
	public static WebElement button_Continue (WebDriver driver) {
		
		element = driver.findElement(By.cssSelector("button[name=btnContinue_5]"));
		
		return element;
				
	}
	

}
