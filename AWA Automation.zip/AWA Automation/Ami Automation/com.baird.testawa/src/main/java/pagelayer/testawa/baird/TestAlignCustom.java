//'****************************************************************************
//' Description      : handles page object model for Align Custom accounts
//' Author           : Mel Llesol
//' Created          : 11/5/2019
//' Last Updated     : 03/23/2020
//'****************************************************************************


package pagelayer.testawa.baird;

import org.openqa.selenium.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class TestAlignCustom {

private static WebElement element = null;
	
    //each method returns a web element to be processed by auto layer 
	public static WebElement drop_AssetClass (WebDriver driver) {
		
	    element = driver.findElement((By.cssSelector("select[id=assetClass]")));
		
		
		return element;
		
	}
	
    public static WebElement drop_InvestmentSelection (WebDriver driver) {
		
	    element = driver.findElement((By.cssSelector("select[id=investmentSelection]")));
		
		
		return element;
		
	}
    
    public static WebElement button_AddClass (WebDriver driver) {
    	
    	element = driver.findElement((By.cssSelector("button[id=btnSelect]")));
    	
    	return element;
    }
    
   public static WebElement text_AssetAllocation1 (WebDriver driver) {
		
	    element = driver.findElement((By.cssSelector("input[id=DTB__tblCustom_0_alignAllocation]")));
		
		
		return element;
		
	}
   
   
   public static WebElement text_AssetAllocation2 (WebDriver driver) {
		
	    element = driver.findElement((By.cssSelector("input[id=DTB__tblCustom_1_alignAllocation]")));
		
		
		return element;
		
	}
   
   public static WebElement button_AlignCustomNext (WebDriver driver) {
		
	    element = driver.findElement((By.cssSelector("button[id=btnNext]")));
		
		
		return element;
		
	}
	

}
