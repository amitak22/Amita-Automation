//'****************************************************************************
//' Description  : This module handles non-Envestnet for Fee Change processes
//' Author       : Mel Llesol
//' Created      : 11/5/2019
//' Last Update  : 04/20/2020
//'****************************************************************************

package autolayer.testawa.baird;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import pagelayer.testawa.baird.*;
import guilayer.testawa.baird.*;
import org.openqa.selenium.Alert;


public class TestFeeChange extends TestProcessor {
	
	WebElement testelement;
	WebDriver driver;
	static ExtentTest test;
	static ExtentReports report;
	Alert alert;
	Boolean approvalRun;
	String originalWindow;
	List<Integer>programReasonList=new ArrayList<Integer>();
	
	//runs the non-Envestnet process, reads JSON data and executes web elements 
	public void runFlow(String account, String program, String flow, String wrap, String type, String stub, WebDriver driver, ExtentTest testRun, ExtentReports reportRun) {	
		this.driver = driver;
		test = testRun;
		report = reportRun;
		String accountRun = account;
		String regacctRun = null;
		String flowRun = flow;
		String stubRun = stub;
		String wrapRun = wrap;
		String typeRun = type;
		
		String envestURL = "http://uatworkflow/lfserver/awa?ENV_ID="+stubRun;
		
		
		  //accesses UAT environment and verifies web elements
	try {
		
		if (!wrapRun.equals("CSM")) {
		  driver.manage().window().maximize(); 
		  driver.get("http://uatworkflow");
		  test.log(LogStatus.PASS, "http://uatworkflow accessed");
			
		  driver.findElement(By.linkText("Fee Based")).click();
		  test.log(LogStatus.PASS, "Fee Based link clicked");
		  		
		  originalWindow = driver.getWindowHandle();
		  
		  driver.manage().window().maximize(); 		
	      driver.findElement(By.linkText("Advisory Workflow Application (AWA)")).click();
	      driver.manage().window().maximize();
	      
	      driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	      
			
		  Set <String> WinHandles = driver.getWindowHandles();
		   
		    while (!driver.getTitle().contains("AWA Start Form")) {
		        for (String handle: WinHandles) {
		       
		    	  	driver.switchTo().window(handle);
		    	
		    	  		    
		        }
		    }

		    
	   	    WebElement create = driver.findElement(By.cssSelector("button[name=btnStart]"));
		    create.click();	
		

			testelement = TestAWAType.txtbox_AccountNum(driver);
			TestAWAType.txtbox_AccountNum(driver).sendKeys(accountRun);
			test.log(LogStatus.PASS, "**Fee Schedule Change Workflow **");
			test.log(LogStatus.PASS, "Account number found "+accountRun);
			test.log(LogStatus.PASS, "Program: "+programRun);
			test.log(LogStatus.PASS, "Wrap code: "+wrapRun);	
			
	
	
		    TestAWAType.form_Type(driver).click();
		    test.log(LogStatus.PASS, "Checkpoint: Frame clicked");
		    
	
			Select dropSol= new Select (TestAWAType.drop_Solution(driver));
			dropSol.selectByVisibleText(flowRun);
			test.log(LogStatus.PASS, flowRun+" selected");

	
			TestAWAType.button_ContinueType(driver).click();
			test.log(LogStatus.PASS, "Continue button clicked");
			
		
		
	
	
	
	if (!wrapRun.equals("NGF")) {
		  
	
			TestAddSchedule.button_AddNewSchedule(driver).click();
			test.log(LogStatus.PASS, "Add New Schedule button clicked");
	
	
			Select dropTypeSched = new Select (TestAddSchedule.drop_TypeSchedule(driver));
			dropTypeSched.selectByVisibleText("Breakpoint");
			test.log(LogStatus.PASS, "Breakpoint selected");
		
			driver.manage().window().maximize();
			TestAddSchedule.text_HouseholdTier1(driver).sendKeys("1.00");
			TestAddSchedule.text_HouseholdTier2(driver).sendKeys("1.00");
			TestAddSchedule.text_HouseholdTier3(driver).sendKeys("1.00");
			TestAddSchedule.text_HouseholdTier4(driver).sendKeys("1.00");
			TestAddSchedule.text_HouseholdTier5(driver).sendKeys("1.00");
			TestAddSchedule.text_HouseholdTier6(driver).sendKeys("1.00");
			test.log(LogStatus.PASS, "Household Tier added");
	
	
			Select dropApplySched = new Select (TestAddSchedule.drop_ApplySchedule(driver));
			dropApplySched.selectByVisibleText("New Schedule 1");
			test.log(LogStatus.PASS, "New Schedule selected");

		
			TestAddSchedule.button_NextHousehold(driver).click();
			test.log(LogStatus.PASS, "NextHousehold button clicked");

		
	                                        }
	
	else if (wrapRun.equals("NGF")) {
	
		  Select dropTypeSched2 = new Select (TestAddSchedule.drop_ApplyScheduleNGF(driver));
		  dropTypeSched2.selectByVisibleText("Breakpoint Pricing");
		  test.log(LogStatus.PASS, "Breakpoint Pricing clicked");
	
	
			  TestAddSchedule.text_Advisor0(driver).sendKeys("1.00");
			  TestAddSchedule.text_Advisor1(driver).sendKeys("1.00");
			  TestAddSchedule.text_Advisor2(driver).sendKeys("1.00");
			  TestAddSchedule.text_Advisor3(driver).sendKeys("1.00");
			  TestAddSchedule.text_Advisor4(driver).sendKeys("1.00");
			  TestAddSchedule.text_Advisor5(driver).sendKeys("1.00");
			  test.log(LogStatus.PASS, "Advisor rate added");

	  
	  }
		
	
		TestScheduleConfirm.button_ConfirmSchedule(driver).click();
		test.log(LogStatus.PASS, "Confirm Schedule button clicked");
	} else {
		
		driver.get(envestURL);
		driver.manage().window().maximize();
		test.log(LogStatus.PASS, "**Fee Schedule Change - Envestnet workflow** "+envestURL);
		
		
		originalWindow = driver.getWindowHandle();
				

		driver.manage().window().maximize();
		test.log(LogStatus.PASS, "Window maximized");
		

		TestAddSchedule.button_NextHousehold(driver).click();
		test.log(LogStatus.PASS, "NextHousehold button clicked");


		TestOtherInfo.otherinfoFinish(driver).click();
		test.log(LogStatus.PASS, "Finish button clicked");
		
	}
	
		TestSubmission.button_SubmitAccount(driver).click();
		test.log(LogStatus.PASS, "Submit Account button clicked");
		
			

		if (isDialogPresent(driver)) {
			alert = driver.switchTo().alert();
			String alertMessage = alert.getText();
			test.log(LogStatus.WARNING,"There is no fee schedule and an alert has been flagged. Skipping approval process. Alert message>> "+alertMessage);
			alert.accept();
			approvalRun=false;
			
		} else {
			test.log(LogStatus.PASS,"No alert found for missing fee schedule");
			approvalRun=true;
		}
	
	if (approvalRun.equals(true)) {
		if (!wrapRun.equals("CSM")) {
		TestClosePage.button_CloseWindow(driver).click();
		test.log(LogStatus.PASS, "Close Window button clicked");
		}
		
		driver.switchTo().window(originalWindow);

	
		TestFAApproval tstFAApproval = new TestFAApproval();
		tstFAApproval.approveFA(accountRun, regacctRun, originalWindow, flowRun, false, driver, test, report, wrapRun, typeRun, programReasonList, programRun);
		test.log(LogStatus.PASS, "FA Approval done");

		TestFeeChangeApproval tstFeeChangeApproval = new TestFeeChangeApproval ();
		tstFeeChangeApproval.approveFeeChange(accountRun, originalWindow, driver);
		test.log(LogStatus.PASS, "Fee Change Approval done");
	}	

	} catch (Exception e) {
		test.log(LogStatus.FAIL, e.toString());
	  }
		
	}
	
	
	private static boolean isDialogPresent(WebDriver driver) {
		try {
	           
	        	driver.switchTo().alert();
	            return true;
	        } catch (Exception e) {
	          
	            return false;
	        }
    }
	
	
	

}
