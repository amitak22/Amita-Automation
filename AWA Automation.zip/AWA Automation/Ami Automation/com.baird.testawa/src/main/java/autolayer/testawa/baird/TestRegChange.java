//'*************************************************************************************************
//' Description  : This module handles non-Envestnet and Envestnet for Registration Change processes
//' Author       : Mel Llesol
//' Created      : 01/6/2020
//' Last Update  : 04/20/2020
//'**************************************************************************************************


package autolayer.testawa.baird;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import pagelayer.testawa.baird.*;
import guilayer.testawa.baird.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import org.openqa.selenium.Alert;


public class TestRegChange extends TestProcessor {
	WebElement testelement;
	WebDriver driver;
	static ExtentTest test;
	static ExtentReports report;
	Alert alert;
	Boolean approvalRun;
	String currentWindow;
	
	
		
	//runs both non-Envestnet and Envestnet processes, reads JSON data and executes web elements 
	public void runFlow(String account, String regaccount, String program, String flow, String wrap, String type, WebDriver driver, ExtentTest testRun, ExtentReports reportRun) {	
		
		this.driver = driver;
		test = testRun;
		report = reportRun;
		String accountRun = account;
		String regacctRun = regaccount;
		String programRun = program;
		String flowRun = flow;
		String wrapRun = wrap;
		String typeRun = type;
		List<Integer>programReasonList=new ArrayList<Integer>();
		List<Integer>platformReasonList=new ArrayList<Integer>();
		
			
		
	 try {	
		
		TestCommon tstCommon = new TestCommon();
		 
		driver.manage().window().maximize(); 
		driver.get("http://uatworkflow");
		test.log(LogStatus.PASS, "http://uatworkflow accessed");
			
		driver.findElement(By.linkText("Fee Based")).click();
		test.log(LogStatus.PASS, "Fee Based link clicked");
			  
						  
		String originalWindow = driver.getWindowHandle();
	
		
		driver.findElement(By.linkText("Advisory Workflow Application (AWA)")).click();
   	    driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
   	  	driver.manage().window().maximize();
	
	
		
		 Set <String> WinHandles = driver.getWindowHandles();
		   
		    while (!driver.getTitle().contains("AWA Start Form")) {
		        for (String handle: WinHandles) {
		       
		    	  	driver.switchTo().window(handle);
		    	  	    
		        }
		    }

		    driver.manage().window().maximize();
		    WebElement create = driver.findElement(By.cssSelector("button[name=btnStart]"));
		    create.click();	

		
		testelement = TestAWAType.txtbox_AccountNum(driver);
		TestAWAType.txtbox_AccountNum(driver).sendKeys(accountRun);
		test.log(LogStatus.PASS, "**Registration Change Workflow selected **");
		test.log(LogStatus.PASS, "From Account number found "+accountRun);	
		test.log(LogStatus.PASS, "Program: "+programRun);	
			
		
		TestAWAType.form_Type(driver).click();
		test.log(LogStatus.PASS, "Checkpoint: Frame clicked");
		    
		
		
	
		Select dropSol= new Select (TestAWAType.drop_Solution(driver));
		dropSol.selectByVisibleText(flowRun);
		test.log(LogStatus.PASS, flowRun+" selected");
	
		
		TestAWAType.txtbox_RegAccount(driver).sendKeys(regacctRun);
		test.log(LogStatus.PASS, "To Account number found "+regacctRun);	
			
			
		TestAWAType.button_ContinueType(driver).click();
		test.log(LogStatus.PASS, "Continue button clicked");
		
			
		driver.manage().window().maximize();
		
		for (int p=1; p<7; p++) { 
			 
			  if (p==1) {
			  TestSuitability.check_OpenRegPlatformSuit1(driver).click();
			  platformReasonList.add(Integer.valueOf(p));
			  test.log(LogStatus.PASS, "Platform suitability check box 1 is clicked");
			  } else if (p==2) {
			  TestSuitability.check_OpenRegPlatformSuit2(driver).click();
			  platformReasonList.add(Integer.valueOf(p));
			  test.log(LogStatus.PASS, "Platform suitability check box 2 is clicked");
			  } else if (p==3) {
			  TestSuitability.check_OpenRegPlatformSuit3(driver).click();
			  platformReasonList.add(Integer.valueOf(p));
			  test.log(LogStatus.PASS, "Platform suitability check box 3 is clicked");
			  } else if (p==4) {
			  TestSuitability.check_OpenRegPlatformSuit4(driver).click();
			  platformReasonList.add(Integer.valueOf(p));
			  test.log(LogStatus.PASS, "Platform suitability check box 4 is clicked");
			  } else if (p==5) {
			  TestSuitability.check_OpenRegPlatformSuit5(driver).click();
			  platformReasonList.add(Integer.valueOf(p));
			  test.log(LogStatus.PASS, "Platform suitability check box 5 is clicked");
			  } else if (p==6) {
			  TestSuitability.check_OpenRegPlatformSuit6(driver).click();
			  platformReasonList.add(Integer.valueOf(p));
			  test.log(LogStatus.PASS, "Platform suitability check box 6 is clicked");
			  } 
			 } 
			 
			 System.out.println("Traversing List...");  
			    for(Integer count:platformReasonList){  
			        System.out.println(count);  
			    }  	   
		
		
		
		TestSuitability.check_OpenRegProgramAttest(driver).click();
		test.log(LogStatus.PASS, "Program attestation is clicked");
		
		
		 
		  
		 for (int i=1; i<6; i++ ) {
				
			  if (i==1) {
				  TestSuitability.check_OpenRegProgramSuit1(driver).click();
				  System.out.println("Program suit 1 clicked");
				  test.log(LogStatus.PASS, "Program suitability reason 1 clicked");
			
				
				  if (tstCommon.checkProgramReason(i, wrapRun, driver, test, report) == true) {
					  
					 
					  programReasonList.add(Integer.valueOf(i));
					  
				  }
				  
			
				  
			  }else if (i==2) {
				  TestSuitability.check_OpenRegProgramSuit2(driver).click();
				  System.out.println("Program suit 2 clicked");
				  test.log(LogStatus.PASS, "Program suitability reason 2 clicked");
				 
				  if (tstCommon.checkProgramReason(i, wrapRun, driver, test, report) == true) {
					  programReasonList.add(Integer.valueOf(i));
				  }
				  
			  
			  } else if (i==3) {
				  TestSuitability.check_OpenRegProgramSuit3(driver).click();
				  System.out.println("Program suit 3 clicked");
				  test.log(LogStatus.PASS, "Program suitability reason 3 clicked");
				
				  if (tstCommon.checkProgramReason(i, wrapRun, driver, test, report) == true) {
					  programReasonList.add(Integer.valueOf(i));
				  }
			  } else if (i==4) {
				  TestSuitability.check_OpenRegProgramSuit4(driver).click();
				  System.out.println("Program suit 4 clicked");
				  test.log(LogStatus.PASS, "Program suitability reason 4 clicked");
				 
				  if (tstCommon.checkProgramReason(i, wrapRun, driver, test, report) == true) {
					  programReasonList.add(Integer.valueOf(i));
				  }
			  } else if (i==5) {
				  TestSuitability.check_OpenRegProgramSuit5(driver).click();
				  System.out.println("Program suit 5 clicked");
				  test.log(LogStatus.PASS, "Program suitability reason 5 clicked");
				 
				  if (tstCommon.checkProgramReason(i, wrapRun, driver, test, report) == true) {
					  programReasonList.add(Integer.valueOf(i));
				  }	
				
		   }
			  
			  System.out.println("Traversing List...");  
			    for(Integer count:programReasonList){  
			        System.out.println(count);  
			    }  
		  }
		
		driver.manage().window().maximize();
		test.log(LogStatus.PASS, "Window maximized");
			
		TestSuitability.button_OpenRegNext(driver).click();
		test.log(LogStatus.PASS, "AWA suitability next button is clicked");
			
		TestOtherInfo.proxyConfirm(driver).click();
		test.log(LogStatus.PASS, "Proxy confirm clicked");
		
	
		TestOtherInfo.otherinfoFinish(driver).click();
		test.log(LogStatus.PASS, "Finish button clicked");
	
		tstCommon.cleanupPDF();
		
		
		TestSubmission.button_BuildDocPacket(driver).click();
		test.log(LogStatus.PASS, "Build Document Packet clicked");
	
		
		Set <String> WinHandles2 = driver.getWindowHandles();
		        for (String handle: WinHandles2) {
		        	String winTitle = driver.getTitle();
		       		System.out.println("before submission windows"+winTitle+""+handle);   
	
	   if (driver.getTitle().contains("Session Summary Page")) {
		       	    	currentWindow = handle;
		       		    System.out.println("currentwindow"+currentWindow);
		       	     	
		    	  	
		       		}
		       		
		    	  	    
		        }
	
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.switchTo().window(currentWindow);
	
		TestSubmission.button_UpdateHousehold(driver).click();
		test.log(LogStatus.PASS, "Update Household button clicked");
    
		
		
		TestSubmission.checkbox_AddHousehold(driver).click();
		test.log(LogStatus.PASS, "Add Billing Household account checkbox clicked");
	
		
		TestSubmission.button_SaveMaintenance(driver).click();
		test.log(LogStatus.PASS, "Save Maintenance button clicked");
	
		
		
		TestSubmission.button_SubmitAccount(driver).click();
		test.log(LogStatus.PASS, "Submit button clicked");
    
			
		
		if (isDialogPresent(driver)) {
			alert = driver.switchTo().alert();
			String alertMessage = alert.getText();
			test.log(LogStatus.WARNING,"There is no fee schedule and an alert has been flagged. Skipping approval process. Alert message>> "+alertMessage);
			alert.accept();
			approvalRun=false;
			
		} else {
			test.log(LogStatus.PASS,"No alert found for missing fee schedule");
			approvalRun=true;
		}
		
	if (approvalRun.equals(true)) {	
		TestClosePage.button_CloseWindow(driver).click();
		test.log(LogStatus.PASS, "Close Window button clicked");
    
		
		
		driver.switchTo().window(originalWindow);
		
	
		TestFAApproval tstFAApproval = new TestFAApproval();
		tstFAApproval.approveFA(accountRun, regacctRun, originalWindow, flowRun, true, driver, test, report, wrapRun, typeRun, programReasonList, programRun);
		test.log(LogStatus.PASS, "FA Approval done");
	
	
		TestWorkable tstworkable = new TestWorkable();
		tstworkable.approveFBAA(accountRun, test, report, driver);
		test.log(LogStatus.PASS, "Workable Approval Day 1 done");
			
		TestHoldingQueue tstholdingqueue = new TestHoldingQueue();
		tstholdingqueue.approveHold(accountRun, driver); 
		test.log(LogStatus.PASS, "Holding Queue Approval Day 1 done");
					
		tstworkable.approveFBAA(accountRun, test, report, driver);
		test.log(LogStatus.PASS, "Workable Approval Day 2 done");
				
		tstholdingqueue.approveHold(accountRun, driver); 
		test.log(LogStatus.PASS, "Holding Queue Approval Day 2 done");
				
		tstworkable.approveFBAA(accountRun, test, report, driver);
	    test.log(LogStatus.PASS, "Workable Approval Day 3 done");
	    
	    
		 for(Integer count:platformReasonList){ 
			  System.out.println("PlatformReasonList>>"+count);
			  
		      Boolean verifyPDFReply = tstCommon.checkPlatformOpenReg (count, flowRun);
		     
		      	      
		      if (verifyPDFReply == true) {
	           System.out.println("client playback present for platform reason"+count);
	           test.log(LogStatus.PASS, "Client playback is present in build doc packet for platform reason "+count);
		      } else {
		    	  System.out.println("client playback not present"+count);
		          test.log(LogStatus.FAIL, "Client playback is not present in build doc packet for platform reason "+count); 
		      }
		   }
		   
		   tstCommon.cleanupPDF();
    	}
	
	

	   
	 } catch (Exception e) {
		 test.log(LogStatus.FAIL, e.toString());
	 }
				
	  }
	
	private static boolean isDialogPresent(WebDriver driver) {
		try {
	           
	        	driver.switchTo().alert();
	            return true;
	        } catch (Exception e) {
	           
	            return false;
	        }
    }
	
}
