//'****************************************************************************
//' Description  : This module handles non-Envestnet for Termination process
//' Author       : Mel Llesol
//' Created      : 01/6/2020
//' Last Update  : 04/20/2020
//'****************************************************************************


package autolayer.testawa.baird;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.Select;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import pagelayer.testawa.baird.*;
import guilayer.testawa.baird.*;

import org.apache.pdfbox.cos.COSDocument;
import org.apache.pdfbox.pdfparser.PDFParser;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.util.PDFTextStripper;
import org.openqa.selenium.Alert;



public class TestTerm extends TestProcessor {
	
	WebElement testelement;
	WebDriver driver;
	static ExtentTest test;
	static ExtentReports report;
	Alert alert;
	Boolean approvalRun;
	String originalWindow;
	String currentWindow;
	List<Integer>programReasonList=new ArrayList<Integer>();
	List<Integer>platformReasonList=new ArrayList<Integer>();

	
	
	//runs the non-Envestnet process, reads JSON data and executes web elements 
	public void runFlow(String account, String program, String flow, String wrap, String type, String stub, WebDriver driver, ExtentTest testRun, ExtentReports reportRun) {	
		this.driver = driver;
		test = testRun;
		report = reportRun;
		String accountRun = account;
		String flowRun = flow;
		String programRun = program;
		String stubRun = stub;
		String wrapRun = wrap;
		String typeRun = type;
		String envestURL = "http://uatworkflow/lfserver/awa?ENV_ID="+stubRun;
		String regacctRun = null;
		String pdfWindow;
		String pdfURL;
		
		
		
		
	try {
		
		TestCommon tstCommon = new TestCommon();
			
	if (!wrapRun.equals("CSM"))	{
		driver.manage().window().maximize(); 
		driver.get("http://uatworkflow");
		test.log(LogStatus.PASS, "http://uatworkflow accessed");
			  
		driver.findElement(By.linkText("Fee Based")).click();
		test.log(LogStatus.PASS, "Fee Based link clicked");
			  
		originalWindow = driver.getWindowHandle();
		
		driver.findElement(By.linkText("Advisory Workflow Application (AWA)")).click();
   	    driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
   	 	driver.manage().window().maximize();
   	 	
   	 
		
		Set <String> WinHandles = driver.getWindowHandles();
		   
		    while (!driver.getTitle().contains("AWA Start Form")) {
		        for (String handle: WinHandles) {
		       
		           	driver.switchTo().window(handle);
		    	  
		        }
		    }

		 WebElement create = driver.findElement(By.cssSelector("button[name=btnStart]"));
		 create.click();	
		
		 driver.manage().window().maximize(); 
		 testelement = TestAWAType.txtbox_AccountNum(driver);
		 test.log(LogStatus.PASS, "Program: "+programRun);
		 TestAWAType.txtbox_AccountNum(driver).sendKeys(accountRun);
		 test.log(LogStatus.PASS, "**Terminate Advisory Workflow **");
		 test.log(LogStatus.PASS, "Account number found "+accountRun);	
		 test.log(LogStatus.PASS, "Wrap code: "+wrapRun);	
			
				
	
	     TestAWAType.form_Type(driver).click();
		 test.log(LogStatus.PASS, "Checkpoint: Frame clicked");
		    
	
		 Select dropSol= new Select (TestAWAType.drop_Solution(driver));
		 dropSol.selectByVisibleText(flowRun);
		 test.log(LogStatus.PASS, flowRun+" selected");
	
		
		 TestAWAType.button_ContinueType(driver).click();
		 test.log(LogStatus.PASS, "Continue button clicked");
		 
		 testTermSuitability(driver);
		 
		 TestTerminateAccount.button_DoNotLiquidate(driver).click();
		 test.log(LogStatus.PASS, "Do Not Liquidate button clicked");

	} else {
		driver.get(envestURL);
		driver.manage().window().maximize();
		test.log(LogStatus.PASS, "**Terminate Advisory Account - Envestnet workflow** "+envestURL);
			
		
		originalWindow = driver.getWindowHandle();
				
		
		
		driver.manage().window().maximize();
		test.log(LogStatus.PASS, "Window maximized");
		testTermSuitability(driver);
		
	}
			
			
	 
		
		TestTerminateAccount.button_Finish(driver).click();
		test.log(LogStatus.PASS, "Finish button clicked");
		
		
		
		 tstCommon.cleanupPDF();
			
			
			TestSubmission.button_BuildDocPacket(driver).click();
			test.log(LogStatus.PASS, "Build Document Packet clicked");
		
			
			Set <String> WinHandles2 = driver.getWindowHandles();
			        for (String handle: WinHandles2) {
			        	String winTitle = driver.getTitle();
			       		System.out.println("before submission windows"+winTitle+""+handle);   
		
		   if (driver.getTitle().contains("Session Summary Page")) {
			       	    	currentWindow = handle;
			       		    System.out.println("currentwindow"+currentWindow);
			       	     	
			    	  	
			       		}
			       		
			    	  	    
			        }
		
			
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			driver.switchTo().window(currentWindow);
		
		
				
	
		TestSubmission.button_SubmitAccount(driver).click();
		test.log(LogStatus.PASS, "Submit Account button clicked");
		
				
		if (isDialogPresent(driver)) {
			alert = driver.switchTo().alert();
			String alertMessage = alert.getText();
			test.log(LogStatus.WARNING,"There is no fee schedule and an alert has been flagged. Skipping approval process. Alert message>> "+alertMessage);
			alert.accept();
			approvalRun=false;
		} else {
			test.log(LogStatus.PASS,"No alert found for missing fee schedule");
			approvalRun=true;
		}

	if (approvalRun.equals(true)) {
		
		if (!wrapRun.equals("CSM")) {
		TestClosePage.button_CloseWindow(driver).click();
		test.log(LogStatus.PASS, "Close Window button clicked");
		}
		
		driver.switchTo().window(originalWindow);
	
		TestFAApproval tstFAApproval = new TestFAApproval();
		tstFAApproval.approveFA(accountRun, regacctRun, originalWindow, flowRun, true, driver, test, report, wrapRun, typeRun, platformReasonList, programRun);
		test.log(LogStatus.PASS, "FA Approval done");
		
		TestTerminateApproval tstTerminateApproval = new TestTerminateApproval ();
		tstTerminateApproval.approveTerminate(accountRun, originalWindow, driver);
		test.log(LogStatus.PASS, "Terminate Advisory Account Approval done");
		
		 for(Integer count:platformReasonList){ 
			  System.out.println("PlatformReasonList>>"+count);
			  
			  
		      Boolean verifyPDFReply = tstCommon.checkPlatformTerm (count, flowRun);
		     
		      	      
		      if (verifyPDFReply == true) {
	             System.out.println("client playback present for platform reason"+count);
	             test.log(LogStatus.PASS, "Client playback is present in build doc packet for platform reason "+count);
		      } else {
		    	  System.out.println("client playback not present"+count);
		          test.log(LogStatus.FAIL, "Client playback is not present in build doc packet for platform reason "+count); 
		      }
		   }
		   
		   tstCommon.cleanupPDF();
		
	}		
		} catch (Exception e) {
			test.log(LogStatus.FAIL, e.toString());
		}
				
	}
	
	 private static boolean isDialogPresent(WebDriver driver) {
		  try {
	         
	        	driver.switchTo().alert();
	            return true;
	        } catch (Exception e) {
	          
	            return false;
	        }
	    }
	 
	 public void testTermSuitability (WebDriver driver) {
		 for (int p=1; p<10; p++) { 
			 
			  if (p==1) {
			  TestSuitability.check_TermPlatformSuit1(driver).click();
			  platformReasonList.add(Integer.valueOf(p));
			  test.log(LogStatus.PASS, "Platform suitability check box 1 is clicked");
			  } else if (p==2) {
			  TestSuitability.check_TermPlatformSuit2(driver).click();
			  platformReasonList.add(Integer.valueOf(p));
			  test.log(LogStatus.PASS, "Platform suitability check box 2 is clicked");
			  } else if (p==3) {
			  TestSuitability.check_TermPlatformSuit3(driver).click();
			  platformReasonList.add(Integer.valueOf(p));
			  test.log(LogStatus.PASS, "Platform suitability check box 3 is clicked");
			  } else if (p==4) {
			  TestSuitability.check_TermPlatformSuit4(driver).click();
			  platformReasonList.add(Integer.valueOf(p));
			  test.log(LogStatus.PASS, "Platform suitability check box 4 is clicked");
			  } else if (p==5) {
			  TestSuitability.check_TermPlatformSuit5(driver).click();
			  platformReasonList.add(Integer.valueOf(p));
			  test.log(LogStatus.PASS, "Platform suitability check box 5 is clicked");
			  } else if (p==6) {
			  TestSuitability.check_TermPlatformSuit6(driver).click();
			  platformReasonList.add(Integer.valueOf(p));
			  test.log(LogStatus.PASS, "Platform suitability check box 6 is clicked");
			  } else if (p==7) {
				  TestSuitability.check_TermPlatformSuit7(driver).click();
				  platformReasonList.add(Integer.valueOf(p));
				  test.log(LogStatus.PASS, "Platform suitability check box 7 is clicked");
			  } else if (p==8) {
				  TestSuitability.check_TermPlatformSuit8(driver).click();
				  platformReasonList.add(Integer.valueOf(p));
				  test.log(LogStatus.PASS, "Platform suitability check box 8 is clicked");
			  } else if (p==9) {
				  TestSuitability.check_TermPlatformSuit9(driver).click();
				  platformReasonList.add(Integer.valueOf(p));
				  test.log(LogStatus.PASS, "Platform suitability check box 9 is clicked");
			  } 
			  
			 } 
			 
			 System.out.println("Traversing List...");  
			    for(Integer count:platformReasonList){  
			        System.out.println(count);  
			    }  	   
		 
			    
			   TestSuitability.button_TermNext(driver).click();
		 
	 }
	 
	 	 
	 
	 
	 
	 
	 
	 
	
}
