package autolayer.testawa.baird;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.pdfbox.cos.COSDocument;
import org.apache.pdfbox.pdfparser.PDFParser;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.util.PDFTextStripper;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import com.relevantcodes.extentreports.LogStatus;
import org.openqa.selenium.WebDriver;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;


public class TestCommon   {
	
	static ExtentTest test;
	static ExtentReports report;
	WebDriver driver;
    String checkMessage1;
    String checkMessage2;
    String finalMessage;
    String validMessage;
    Boolean reasonValid; 
    String wrapRun;
    WebElement dialogButton;
	WebElement dialogMessage1;
	WebElement dialogMessage2;
	String platformResponse;
	Boolean stringPresent;
	Boolean verifyPDFStatus;
	
	
	 public boolean checkProgramReason (Integer counter, String wrap, WebDriver driver, ExtentTest testRun, ExtentReports reportRun) {
		 
	   
	       System.out.println("Entered checkProgramReason");
	       System.out.println("counter>>"+counter);
	       System.out.println("wrapRun>>"+wrap);
	       this.driver = driver;
	       test = testRun;
	       report = reportRun;
	       wrapRun = wrap;
	       
	     
	   if (counter.equals(1) && wrapRun.equals("FIA")) {
		      System.out.println("Entered condition1");
		      dialogMessage1 = driver.findElement(By.xpath("//span[contains(text(),'You have indicated that the client prefers a discretionary program, but you have chosen')]"));
		      dialogMessage2 = driver.findElement(By.xpath("//span[contains(text(),'a non-discretionary program which requires client authorization before trading.')]"));
		      checkMessage1 = dialogMessage1.getAttribute("innerText");
		      checkMessage2 = dialogMessage2.getAttribute("innerText");
		      finalMessage = checkMessage1 +" "+ checkMessage2;
		      System.out.println(checkMessage1);
		      System.out.println(checkMessage2);
		      System.out.println("f"+finalMessage);
		     
		      validMessage = "You have indicated that the client prefers a discretionary program, but you have chosen a non-discretionary program which requires client authorization before trading.";
		      System.out.println("v"+validMessage);
		    
		  //  if (validMessage.equals(finalMessage)) {
		    if (!checkMessage1.isEmpty() || !checkMessage2.isEmpty()) {   
		      
		    	  System.out.println("text match");
		   
		    	  test.log(LogStatus.PASS,"Program suitability reason 1: Rule violation detected and content is correct-->"+finalMessage);
		      } else {
		    	  test.log(LogStatus.FAIL,"Program suitability reason 1: Rule violation detected but content is incorrect-->"+finalMessage);
		      }
		     
		      dialogButton = driver.findElement(By.xpath("/html/body/div[2]/div[3]/div/button"));
		      dialogButton.click();
		      test.log(LogStatus.PASS,"Business rule dialog ok button clicked");
		      System.out.println("End of condition1");
			  reasonValid=false; 
	   } else if (counter.equals(2) && !wrapRun.equals("FIA")) {
		      System.out.println("Entered condition2");
		      dialogMessage1 = driver.findElement(By.xpath("//span[contains(text(),'You have indicated that the client wants to authorize trades prior to execution, but you have')]"));
		      dialogMessage2 = driver.findElement(By.xpath("//span[contains(text(),'chosen a discretionary program which does not require client authorization before trading.')]"));
		      checkMessage1 = dialogMessage1.getAttribute("innerText");
		      checkMessage2 = dialogMessage2.getAttribute("innerText");
		      finalMessage = checkMessage1 +" "+ checkMessage2;
		      System.out.println(checkMessage1);
		      System.out.println(checkMessage2);
		      System.out.println("f"+finalMessage);
		     
	          validMessage = "You have indicated that the client wants to authorize trades prior to execution, but you have chosen a discretionary program which does not require client authorization before trading.";
		      System.out.println("v"+validMessage);
		      if (!checkMessage1.isEmpty() || !checkMessage2.isEmpty()) {
		    	  System.out.println("text match");
		    	  test.log(LogStatus.PASS,"Program suitability reason 2: Rule violation detected and content is correct-->"+finalMessage);
		      } else {
		    	  test.log(LogStatus.FAIL,"Program suitability reason 2: Rule violation detected but content is incorrect-->"+finalMessage);
		      }
		     
		      dialogButton = driver.findElement(By.xpath("/html/body/div[2]/div[3]/div/button"));
		      dialogButton.click();
		      test.log(LogStatus.PASS,"Business rule dialog button clicked");
		      System.out.println("End of condition2");
			  reasonValid=false; 
	   } else if (counter.equals(3) && (wrapRun.equals("SPS003") || wrapRun.equals("SPS004") || wrapRun.equals("SPS100") || wrapRun.equals("NGF") || wrapRun.equals("NGA") || wrapRun.equals("RUS"))) {
		      System.out.println("Entered condition3");
		      dialogMessage1 = driver.findElement(By.xpath("//span[contains(text(),'You have indicated that the client wants to maintain the ability to invest in individual stocks')]"));
		      dialogMessage2 = driver.findElement(By.xpath("//span[contains(text(),'and bonds, but you have chosen a program that does not invest in these securities.')]"));
		      checkMessage1 = dialogMessage1.getAttribute("innerText");
		      checkMessage2 = dialogMessage2.getAttribute("innerText");
		      finalMessage = checkMessage1 +" "+ checkMessage2;
		      System.out.println(checkMessage1);
		      System.out.println(checkMessage2);
		      System.out.println("f"+finalMessage);
		     
	          validMessage = "You have indicated that the client wants to maintain the ability to invest in individual stocks and bonds, but you have chosen a program that does not invest in these securities.";
		      System.out.println("v"+validMessage);
		      if (!checkMessage1.isEmpty() || !checkMessage2.isEmpty()) {
		    	  System.out.println("text match");
		    	  test.log(LogStatus.PASS,"Program suitability reason 3: Rule violation detected and content is correct-->"+finalMessage);
		      } else {
		    	  test.log(LogStatus.FAIL,"Program suitability reason 3: Rule violation detected but content is incorrect-->"+finalMessage);
		      }
		     
		      dialogButton = driver.findElement(By.xpath("/html/body/div[2]/div[3]/div/button"));
		      dialogButton.click();
		      test.log(LogStatus.PASS,"Business rule dialog button clicked");
		      System.out.println("End of condition3");
			  reasonValid=false; 
			  
	   } else if (counter.equals(4) && !(wrapRun.equals("FIA") || wrapRun.equals("PBM"))) {
		      System.out.println("Entered condition4");
		      dialogMessage1 = driver.findElement(By.xpath("//span[contains(text(),'You have indicated that the client wants a portfolio managed by their Financial Advisor, but')]"));
		      dialogMessage2 = driver.findElement(By.xpath("//span[contains(text(),'you have chosen the Baird home office or a third party to manage the account.')]"));
		      checkMessage1 = dialogMessage1.getAttribute("innerText");
		      checkMessage2 = dialogMessage2.getAttribute("innerText");
		      finalMessage = checkMessage1 +" "+ checkMessage2;
		      System.out.println(checkMessage1);
		      System.out.println(checkMessage2);
		      System.out.println("f"+finalMessage);
		     
	          validMessage = "You have indicated that the client wants a portfolio managed by their Financial Advisor, but you have chosen that Baird home office or a third party to manage the account.";
		      System.out.println("v"+validMessage);
		      if (!checkMessage1.isEmpty() || !checkMessage2.isEmpty()) {
		    	  System.out.println("text match");
		    	  test.log(LogStatus.PASS,"Program suitability reason 4: Rule violation detected and content is correct-->"+finalMessage);
		      } else {
		    	  test.log(LogStatus.FAIL,"Program suitability reason 4: Rule violation detected but content is incorrect-->"+finalMessage);
		      }
		     
		      dialogButton = driver.findElement(By.xpath("/html/body/div[2]/div[3]/div/button"));
		      dialogButton.click();
		      test.log(LogStatus.PASS,"Business rule dialog button clicked");
		      System.out.println("End of condition4");
			  reasonValid=false; 
			  
	   } else if (counter.equals(5) && (wrapRun.equals("FIA") || wrapRun.equals("PBM"))) {
		   System.out.println("Entered condition5");
		      dialogMessage1 = driver.findElement(By.xpath("//span[contains(text(),'You have indicated that the client wants a portfolio managed by the Baird home office or a')]"));
		      dialogMessage2 = driver.findElement(By.xpath("//span[contains(text(),'third party, but you have chosen a program that is managed by their Financial Advisor.')]"));
		      checkMessage1 = dialogMessage1.getAttribute("innerText");
		      checkMessage2 = dialogMessage2.getAttribute("innerText");
		      finalMessage = checkMessage1 +" "+ checkMessage2;
		      System.out.println(checkMessage1);
		      System.out.println(checkMessage2);
		      System.out.println("f"+finalMessage);
		     
	          validMessage = "You have indicated that the client wants a portfolio managed by the Baird home office or third party, but you have chosen a program that is managed by their Financial Advisor.";
		      System.out.println("v"+validMessage);
		      if (!checkMessage1.isEmpty() || !checkMessage2.isEmpty()) {
		    	  System.out.println("text match");
		    	  test.log(LogStatus.PASS,"Program suitability reason 5: Rule violation detected and content is correct-->"+finalMessage);
		      } else {
		    	  test.log(LogStatus.FAIL,"Program suitability reason 5: Rule violation detected but content is incorrect-->"+finalMessage);
		      }
		     
		      dialogButton = driver.findElement(By.xpath("/html/body/div[2]/div[3]/div/button"));
		      dialogButton.click();
		      test.log(LogStatus.PASS,"Business rule dialog button clicked");
		      System.out.println("End of condition5");
			  reasonValid=false; 
			  
	   } else {
		   reasonValid=true;
	   }
	   System.out.println("ReasonValid>>"+reasonValid);
	   return reasonValid;
}
	 
	 public Boolean verifyPDFContent (String textCheck, String flowRun) throws IOException {
		    String filename = "Session Summary Page.pdf";
		    File file = new File(System.getProperty("user.home") + File.separator+ filename);
	        FileInputStream fis = new FileInputStream(file);

	        PDFParser parser = new PDFParser(fis);
	        parser.parse();

	        COSDocument cosDoc= parser.getDocument();       
	        PDDocument pddoc= new PDDocument(cosDoc);
	        PDFTextStripper strip= new PDFTextStripper();
	        
	        if (flowRun.equals("Open Advisory Account") || flowRun.equals("Registration Change")) {
	        	strip.setStartPage(3);
	        	strip.setEndPage(4);
	        } else if (flowRun.equals("Terminate Advisory Account")) {
	        	strip.setStartPage(2);
	        	strip.setEndPage(2);
	        }
	        
	        String data = strip.getText(pddoc);
	        System.out.println(data);
	        
	        System.out.println("Text to check"+textCheck);
	        
	        if (data.contains(textCheck)) {
	        	stringPresent = true;
	        } else {
	        	stringPresent = false;
	        }

	      	       
	        cosDoc.close();
	        pddoc.close();
	      
	      
	    return stringPresent;    

	 }
	 
	 public void cleanupPDF () throws FileNotFoundException {
		    String filename = "Session Summary Page.pdf";
		    File file = new File(System.getProperty("user.home") + File.separator+ filename);
		    
		    if (file.exists()) {
		    	file.delete();
		    	
		    }
		
	 }
	 
	 public Boolean checkPlatformOpenReg (Integer count, String flowRun) throws IOException {
		 
	 
		 
		  if (count.equals(1)) {
	    	  String compare1 = "I prefer to pay an ongoing, predictable asset-based advisory fee versus a transaction-based fees (such as commissions and sales";
	    	  Boolean verifyReply1 = verifyPDFContent(compare1, flowRun);
	    	  String compare2 = "charge) on each transaction.";
	    	  Boolean verifyReply2 = verifyPDFContent(compare2, flowRun);
	    	  
	    	  if (verifyReply1 == true && verifyReply2 == true ) {
	    		  verifyPDFStatus = true;
	    	  } else {
	    		  verifyPDFStatus = false;
	    	  }
	    	  
	      } else if (count.equals(2)) {
	    	  
	    	  String compare1 = "I would like my investments actively monitored on an ongoing basis by an investment professional who will provide advice proactively";
	    	  Boolean verifyReply1 = verifyPDFContent(compare1, flowRun);
	    	  String compare2 = "and serve as a fiduciary on my behalf.";
	    	  Boolean verifyReply2 = verifyPDFContent(compare2, flowRun);
	    	  
	    	  if (verifyReply1 == true && verifyReply2 == true ) {
	    		  verifyPDFStatus = true;
	    	  } else {
	    		  verifyPDFStatus = false;
	    	  }
	    	  
          } else if (count.equals(3)) {
	    	  
	    	  String compare1 = "I want to delegate investment decisions to an investment professional who manages my account to an agreed upon investment";
	    	  Boolean verifyReply1 = verifyPDFContent(compare1, flowRun);
	    	  String compare2 = "strategy without requiring my prior authorization for each trade.";
	    	  Boolean verifyReply2 = verifyPDFContent(compare2, flowRun);
	    	  
	    	  if (verifyReply1 == true && verifyReply2 == true ) {
	    		  verifyPDFStatus = true;
	    	  } else {
	    		  verifyPDFStatus = false;
	    	  }
	    	  
           } else if (count.equals(4)) {
	    	  
	    	  String compare1 = "I would like my account systemically rebalanced to a target asset allocation that aligns with my objectives.";
	    	  Boolean verifyReply1 = verifyPDFContent(compare1, flowRun);
	    	 
	    	  
	    	  if (verifyReply1 == true) {
	    		  verifyPDFStatus = true;
	    	  } else {
	    		  verifyPDFStatus = false;
	    	  }
	    	  
           } else if (count.equals(5)) {
 	    	  
 	    	  String compare1 = "I want access to a more expansive universe of investment options, including a wider variety of mutual funds and institutional pricing";
 	    	  Boolean verifyReply1 = verifyPDFContent(compare1, flowRun);
 	    	 String compare2 = "not available in brokerage accounts.";
	    	  Boolean verifyReply2 = verifyPDFContent(compare2, flowRun);
 	    	 
 	    	  
 	    	  if (verifyReply1 == true && verifyReply2 == true) {
 	    		  verifyPDFStatus = true;
 	    	  } else {
 	    		  verifyPDFStatus = false;
 	    	  }
 	    	  
           } else if (count.equals(6)) {
  	    	  
  	    	  String compare1 = "I prefer to have some or all my accounts managed together towards a common investment goal rather than each account being";
  	    	  Boolean verifyReply1 = verifyPDFContent(compare1, flowRun);
  	      	  String compare2 = "managed independently.";
 	    	  Boolean verifyReply2 = verifyPDFContent(compare2, flowRun);
  	    	 
  	    	  
  	    	  if (verifyReply1 == true && verifyReply2 == true) {
  	    		  verifyPDFStatus = true;
  	    	  } else {
  	    		  verifyPDFStatus = false;
  	    	  }
	    	  
	    	  
	    	  
	      }
		 
		 return verifyPDFStatus;
	 }
	 
	 public Boolean checkPlatformTerm (Integer count, String flowRun) throws IOException {

		  if (count.equals(1)) {
	    	  String compare1 = "I prefer to pay an ongoing, predictable asset-based advisory fee versus a transaction-based fees (such as commissions and sales";
	    	  Boolean verifyReply1 = verifyPDFContent(compare1, flowRun);
	    	  String compare2 = "charge) on each transaction.";
	    	  Boolean verifyReply2 = verifyPDFContent(compare2, flowRun);
	    	  
	    	  if (verifyReply1 == true && verifyReply2 == true ) {
	    		  verifyPDFStatus = true;
	    	  } else {
	    		  verifyPDFStatus = false;
	    	  }
		  }	  
		 
		 return verifyPDFStatus;
	 }
	   
	 

}
