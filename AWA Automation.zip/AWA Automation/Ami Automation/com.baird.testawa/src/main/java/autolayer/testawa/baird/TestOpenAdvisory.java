//'****************************************************************************
//' Description  : This module handles non-Envestnet for Open Advisory processes
//' Author       : Mel Llesol
//' Created      : 01/6/2020
//' Last Update  : 04/20/2020
//'****************************************************************************



package autolayer.testawa.baird;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import pagelayer.testawa.baird.*;
import guilayer.testawa.baird.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import org.openqa.selenium.Alert;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;
import org.apache.pdfbox.cos.COSDocument;
//import org.apache.pdfbox.io.MemoryUsageSetting;
import org.apache.pdfbox.io.RandomAccessRead;
//import org.apache.pdfbox.io.ScratchFile;
import org.apache.pdfbox.pdfparser.PDFParser;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.util.PDFTextStripper;


public class TestOpenAdvisory extends TestProcessor {
	
	WebElement testelement;
	WebDriver driver;
	static ExtentTest test;
	static ExtentReports report;
	Alert alert;
	Boolean approvalRun;
	LocalDate date = LocalDate.now();
	String originalWindow;
	String pdfWindow;
	String pdfURL;
	Boolean verifyPDFReply;
	String currentWindow;
	//Integer programReasonSelected;
//	int[] programReasonSelected;
	
	
	
		
	//runs the non-Envestnet process, reads JSON data and executes web elements 
	public void runFlow(String account, String program, String flow, String wrap, String type, String stub, WebDriver driver, ExtentTest testRun, ExtentReports reportRun, Boolean stage) {	
		
		this.driver = driver;
		test = testRun;
		report = reportRun;
		String accountRun = account;
		String regacctRun = null;
		String programRun = program;
		String flowRun = flow;
		String stubRun = stub;
		String envestURL = "http://uatworkflow/lfserver/awa?ENV_ID="+stubRun;
		String wrapRun = wrap;
		String typeRun = type;
		Boolean stageRun = stage;
		String formattedDate = date.format(DateTimeFormatter.ofLocalizedDate(FormatStyle.SHORT));
	    List<Integer>programReasonList=new ArrayList<Integer>();
	    List<Integer>platformReasonList=new ArrayList<Integer>();
		

		
	try {	
		
	  TestCommon tstCommon = new TestCommon();
		
	  if (!(wrapRun.equals("CSM") || wrapRun.equals("UMA")) ) {
		driver.manage().window().maximize(); 
		driver.get("http://uatworkflow");
		test.log(LogStatus.PASS, "http://uatworkflow accessed");
			  
	 
	    driver.findElement(By.linkText("Fee Based")).click();
		test.log(LogStatus.PASS, "Fee Based link clicked");
			  
			  
	    originalWindow = driver.getWindowHandle();
	
	    driver.manage().window().maximize(); 
		driver.findElement(By.linkText("Advisory Workflow Application (AWA)")).click();
   	    driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
   		driver.manage().window().maximize();
	
		
		 Set <String> WinHandles = driver.getWindowHandles();
		   
		    while (!driver.getTitle().contains("AWA Start Form")) {
		        for (String handle: WinHandles) {
		       		           
		    	  	driver.switchTo().window(handle);
		    	  	    
		        }
		    }

		    
	   	    WebElement create = driver.findElement(By.cssSelector("button[name=btnStart]"));
		    create.click();	

		
		testelement = TestAWAType.txtbox_AccountNum(driver);
		TestAWAType.txtbox_AccountNum(driver).sendKeys(accountRun);
		test.log(LogStatus.PASS, "**Open Advisory Workflow **");
		test.log(LogStatus.PASS, "Account number found "+accountRun);	
			
	    TestAWAType.form_Type(driver).click();
	    test.log(LogStatus.PASS, "Checkpoint: Frame clicked");
		    
		Select dropSol= new Select (TestAWAType.drop_Solution(driver));
		dropSol.selectByVisibleText("Open Advisory Account");
		test.log(LogStatus.PASS, "Open Advisory selected");


		TestAWAType.button_ContinueType(driver).click();
		test.log(LogStatus.PASS, "Continue button clicked");
		

		Select dropProg = new Select (TestAdvisoryProgram.drop_Program(driver));
		dropProg.selectByVisibleText(programRun);
		test.log(LogStatus.PASS, programRun+" selected");
		
	    if (wrapRun.equals("PBM")){
	    	
	    		Select dropSolution = new Select (TestAdvisoryProgram.drop_Solution(driver));
	    		dropSolution.selectByIndex(0);
	    		test.log(LogStatus.PASS, "Solution selected");
	  
	  
	    		Select dropModel = new Select (TestAdvisoryProgram.drop_Model(driver));
	    		dropModel.selectByIndex(0);
	    		test.log(LogStatus.PASS, "Model selected");
	    
	    	
			
		} else if (wrapRun.equals("SPS001")){
	    	
	  
	    		Select drop_ImpMethod = new Select (TestAdvisoryProgram.drop_ImpMethod(driver));
	    		drop_ImpMethod.selectByIndex(1);
	    		test.log(LogStatus.PASS, "Implementation Method selected");
	
	    	
	    		Select drop_AllocationPortfolio = new Select (TestAdvisoryProgram.drop_AllocationPortfolio(driver));
	    		drop_AllocationPortfolio.selectByIndex(2);
	    		test.log(LogStatus.PASS, "Allocation Portfolio selected");


	    		Select drop_FixedIncome = new Select (TestAdvisoryProgram.drop_FixedIncome(driver));
	    		drop_FixedIncome.selectByIndex(1);
	    		test.log(LogStatus.PASS, "Fixed Income selected");

	    	

	    		Select drop_AlignModel = new Select (TestAdvisoryProgram.drop_AlignModel(driver));
	    		drop_AlignModel.selectByIndex(1);
	    		test.log(LogStatus.PASS, "Align Model selected");

	    	

	    		Select drop_RebalancingOption = new Select (TestAdvisoryProgram.drop_RebalancingOption(driver));
	    		drop_RebalancingOption.selectByIndex(0);
	    		test.log(LogStatus.PASS, "Rebalancing Option selected");

	    	
	    } else if (wrapRun.equals("SPS004")){

	    		Select dropImpMethod = new Select (TestAdvisoryProgram.drop_ImpMethod(driver));
	    		dropImpMethod.selectByIndex(1);
	    		test.log(LogStatus.PASS, "Implementation Method selected");

	    	
	        }
	    
	    
			TestAdvisoryProgram.radio_Invest(driver).click();
			test.log(LogStatus.PASS, "Investment button selected");
	

			TestAdvisoryProgram.button_Continue(driver).click();
			test.log(LogStatus.PASS, "Continue button selected");
	
		
		
		if (wrapRun.equals("PBM")){

				TestAdvisoryProgram.button_Continue(driver).click();
				test.log(LogStatus.PASS, "Continue button selected");
	
		}
		

		
	  }	else {
		    driver.get(envestURL);
			test.log(LogStatus.PASS, "**Open Advisory - Envestnet workflow ** "+envestURL);
			test.log(LogStatus.PASS, programRun+" selected");
			driver.manage().window().maximize();
			originalWindow = driver.getWindowHandle();
	  }
		
	 for (int p=1; p<7; p++) { 
		 
	  if (p==1) {
	  TestSuitability.check_OpenRegPlatformSuit1(driver).click();
	  platformReasonList.add(Integer.valueOf(p));
	  test.log(LogStatus.PASS, "Platform suitability check box 1 is clicked");
	  } else if (p==2) {
	  TestSuitability.check_OpenRegPlatformSuit2(driver).click();
	  platformReasonList.add(Integer.valueOf(p));
	  test.log(LogStatus.PASS, "Platform suitability check box 2 is clicked");
	  } else if (p==3) {
	  TestSuitability.check_OpenRegPlatformSuit3(driver).click();
	  platformReasonList.add(Integer.valueOf(p));
	  test.log(LogStatus.PASS, "Platform suitability check box 3 is clicked");
	  } else if (p==4) {
	  TestSuitability.check_OpenRegPlatformSuit4(driver).click();
	  platformReasonList.add(Integer.valueOf(p));
	  test.log(LogStatus.PASS, "Platform suitability check box 4 is clicked");
	  } else if (p==5) {
	  TestSuitability.check_OpenRegPlatformSuit5(driver).click();
	  platformReasonList.add(Integer.valueOf(p));
	  test.log(LogStatus.PASS, "Platform suitability check box 5 is clicked");
	  } else if (p==6) {
	  TestSuitability.check_OpenRegPlatformSuit6(driver).click();
	  platformReasonList.add(Integer.valueOf(p));
	  test.log(LogStatus.PASS, "Platform suitability check box 6 is clicked");
	  } 
	 } 
	 
	 System.out.println("Traversing List...");  
	    for(Integer count:platformReasonList){  
	        System.out.println(count);  
	    }  
	  
	    
	    TestSuitability.check_OpenRegProgramAttest(driver).click();
		test.log(LogStatus.PASS, "Program attestation is clicked");
	 
	  
	  for (int i=1; i<6; i++ ) {
		
		  if (i==1) {
			  TestSuitability.check_OpenRegProgramSuit1(driver).click();
			  System.out.println("Program suit 1 clicked");
			  test.log(LogStatus.PASS, "Program suitability reason 1 clicked");
		
			
			  if (tstCommon.checkProgramReason(i, wrapRun, driver, test, report) == true) {
				  
				 
				  programReasonList.add(Integer.valueOf(i));
				  
			  }
			  
		
			  
		  }else if (i==2) {
			  TestSuitability.check_OpenRegProgramSuit2(driver).click();
			  System.out.println("Program suit 2 clicked");
			  test.log(LogStatus.PASS, "Program suitability reason 2 clicked");
			 
			  if (tstCommon.checkProgramReason(i, wrapRun, driver, test, report) == true) {
				  programReasonList.add(Integer.valueOf(i));
			  }
			  
		  
		  } else if (i==3) {
			  TestSuitability.check_OpenRegProgramSuit3(driver).click();
			  System.out.println("Program suit 3 clicked");
			  test.log(LogStatus.PASS, "Program suitability reason 3 clicked");
			
			  if (tstCommon.checkProgramReason(i, wrapRun, driver, test, report) == true) {
				  programReasonList.add(Integer.valueOf(i));
			  }
		  } else if (i==4) {
			  TestSuitability.check_OpenRegProgramSuit4(driver).click();
			  System.out.println("Program suit 4 clicked");
			  test.log(LogStatus.PASS, "Program suitability reason 4 clicked");
			 
			  if (tstCommon.checkProgramReason(i, wrapRun, driver, test, report) == true) {
				  programReasonList.add(Integer.valueOf(i));
			  }
		  } else if (i==5) {
			  TestSuitability.check_OpenRegProgramSuit5(driver).click();
			  System.out.println("Program suit 5 clicked");
			  test.log(LogStatus.PASS, "Program suitability reason 5 clicked");
			 
			  if (tstCommon.checkProgramReason(i, wrapRun, driver, test, report) == true) {
				  programReasonList.add(Integer.valueOf(i));
			  }	
			
	   }
		  
		  System.out.println("Traversing List...");  
		    for(Integer count:programReasonList){  
		        System.out.println(count);  
		    }  
	  }

				
        driver.manage().window().maximize();
		test.log(LogStatus.PASS, "Window maximized");
		
		TestSuitability.button_OpenRegNext(driver).click();
		test.log(LogStatus.PASS, "AWA suitability next button is clicked");
		
	if (wrapRun.equals("CSM") || wrapRun.equals("UMA"))  {
			    TestAddSchedule.button_NextHousehold(driver).click();
				test.log(LogStatus.PASS, "NextHousehold button clicked"); 
			    TestOtherInfo.proxyConfirm(driver).click();
				test.log(LogStatus.PASS, "Proxy Confirm clicked");
		   
    } else {

	
		TestAddSchedule.button_AddNewSchedule(driver).click();
		test.log(LogStatus.PASS, "Add New Schedule button clicked");


		Select dropTypeSched = new Select (TestAddSchedule.drop_TypeSchedule(driver));
		dropTypeSched.selectByVisibleText("Breakpoint");
		test.log(LogStatus.PASS, "Breakpoint selected");


		TestAddSchedule.text_HouseholdTier1(driver).sendKeys("1.00");
		TestAddSchedule.text_HouseholdTier2(driver).sendKeys("1.00");
		TestAddSchedule.text_HouseholdTier3(driver).sendKeys("1.00");
		TestAddSchedule.text_HouseholdTier4(driver).sendKeys("1.00");
		TestAddSchedule.text_HouseholdTier5(driver).sendKeys("1.00");
		TestAddSchedule.text_HouseholdTier6(driver).sendKeys("1.00");
		test.log(LogStatus.PASS, "Household Tier added");


		Select dropApplySched = new Select (TestAddSchedule.drop_ApplySchedule(driver));
		dropApplySched.selectByVisibleText("New Schedule 1");
		test.log(LogStatus.PASS, "New Schedule selected");

	
		TestAddSchedule.button_NextHousehold(driver).click();
		test.log(LogStatus.PASS, "NextHousehold button clicked");
		
		
    }
		
	 if (typeRun.equals("STP") || wrapRun.equals("SPS004"))  { 
		
		
		    TestOtherInfo.CUSIPMutualFunds_RadioNo(driver).click();
			test.log(LogStatus.PASS, "CUSIP Mutual Funds' No radio button clicked");


			TestOtherInfo.CUSIPSecurities_RadioNo(driver).click();
			test.log(LogStatus.PASS, "CUSIP Securities' No radio button clicked");

			
	
		
	} else if (!wrapRun.equals("CSM")) {
		if (!typeRun.equals("STP") || !wrapRun.equals("SPS004") ) {
		
	
		TestOtherInfo.CUSIPMutualFunds_RadioYes(driver).click();
		test.log(LogStatus.PASS, "CUSIP Mutual Funds' Yes radio button clicked");



		TestOtherInfo.CUSIPSecurities_RadioYes(driver).click();
		test.log(LogStatus.PASS, "CUSIP Securities' Yes radio button clicked");


		
		TestOtherInfo.CUSIPSymbol(driver).sendKeys("aaabbbccc11");
		test.log(LogStatus.PASS, "CUSIP Symbol entered");

		
		TestOtherInfo.CUSIPDate(driver).sendKeys(formattedDate);
		test.log(LogStatus.PASS, "CUSIP Date entered");


		TestOtherInfo.CUSIPSecurity(driver).sendKeys("aaaabbbbcc22");
		test.log(LogStatus.PASS, "CUSIP Security Title entered");
		}

	}
	
	 

		TestOtherInfo.otherinfoFinish(driver).click();
		test.log(LogStatus.PASS, "Finish button clicked");

      
		tstCommon.cleanupPDF();
		
			
		TestSubmission.button_BuildDocPacket(driver).click();
		test.log(LogStatus.PASS, "Build Document Packet clicked");
	
		
		Set <String> WinHandles2 = driver.getWindowHandles();
		        for (String handle: WinHandles2) {
		        	String winTitle = driver.getTitle();
		       		System.out.println("before submission windows"+winTitle+""+handle);   
	
	   if (driver.getTitle().contains("Session Summary Page")) {
		       	    	currentWindow = handle;
		       		    System.out.println("currentwindow"+currentWindow);
		       	     	
		    	  	
		       		}
		       		
		    	  	    
		        }
	
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.switchTo().window(currentWindow);
		

		TestSubmission.button_UpdateHousehold(driver).click();
		test.log(LogStatus.PASS, "Update Household button clicked");
		
		TestSubmission.checkbox_AddHousehold(driver).click();
		test.log(LogStatus.PASS, "Add Household Billing account checkbox clicked");


		TestSubmission.button_SaveMaintenance(driver).click();
		test.log(LogStatus.PASS, "Save Maintenance button clicked");
		
			
		
	    TestSubmission.button_SubmitAccount(driver).click();
		test.log(LogStatus.PASS, "Submit button clicked");
		
		 
					
		if (isDialogPresent(driver)) {
			alert = driver.switchTo().alert();
			String alertMessage = alert.getText();
			test.log(LogStatus.WARNING,"There is no fee schedule and an alert has been flagged. Skipping approval process. Alert message>> "+alertMessage);
			
			alert.accept();
			approvalRun=false;
			
			
		} else {
			test.log(LogStatus.PASS,"No alert found for missing fee schedule");
			approvalRun=true;
		}
		
		

	if (approvalRun.equals(true)) {	 

		 if (!(wrapRun.equals("CSM") || wrapRun.equals("UMA")) ) {
		TestClosePage.button_CloseWindow(driver).click();
		test.log(LogStatus.PASS, "Close window button clicked");
		 }
	
		driver.switchTo().window(originalWindow);
		
      
		if (!stageRun.equals(true)) {
		
		TestFAApproval tstFAApproval = new TestFAApproval();
		tstFAApproval.approveFA(accountRun, regacctRun, originalWindow, flowRun, true, driver, test, report, wrapRun, typeRun, programReasonList, programRun);
		test.log(LogStatus.PASS, "FA Approval done");

        
				
		if (!typeRun.equals("STP")) {
	
		TestAdvisoryOpsNewAccount tstAdvisoryOpsNewAccount = new TestAdvisoryOpsNewAccount();
		tstAdvisoryOpsNewAccount.AdvisoryOpsNewAcctApprove(accountRun, driver, typeRun);
		test.log(LogStatus.PASS, "Advisory Ops Approval done");

		
	
		  }
       }
		
	}
	
	if (typeRun.equals("Reject")){
		driver.findElement(By.linkText("Inbox")).click();
		String processAcct = convertAccount (accountRun);
	    WebElement approveItem = driver.findElement(By.xpath("//td[contains(text(), '"+processAcct+"')]"));
	    approveItem.click();
	    
	}
	
	   for(Integer count:platformReasonList){ 
		  System.out.println("PlatformReasonList>>"+count);
		  
		  
	      Boolean verifyPDFReply = tstCommon.checkPlatformOpenReg (count, flowRun);
	     
	      	      
	      if (verifyPDFReply == true) {
             System.out.println("client playback present for platform reason"+count);
             test.log(LogStatus.PASS, "Client playback is present in build doc packet for platform reason "+count);
	      } else {
	    	  System.out.println("client playback not present"+count);
	          test.log(LogStatus.FAIL, "Client playback is not present in build doc packet for platform reason "+count); 
	      }
	   }
	   
	   tstCommon.cleanupPDF();
	   
	  } catch (Exception e) {
		 
		  if (e instanceof NullPointerException || e instanceof ArrayIndexOutOfBoundsException) {
				test.log(LogStatus.FAIL, "Missing element "+e.toString());
			} else {
				test.log(LogStatus.FAIL, e.toString());
			}
		  
	  }
	
	
	}	
	
	 private static boolean isDialogPresent(WebDriver driver) {
	        try {
	           
	        	driver.switchTo().alert();
	            return true;
	        } catch (Exception e) {
	           
	            return false;
	        }
	    }
	 
		 
	
	
	
}
