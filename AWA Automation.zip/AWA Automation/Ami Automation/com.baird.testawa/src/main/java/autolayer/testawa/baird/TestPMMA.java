//'****************************************************************************
//' Description  : This module handles non-Envestnet for PMMA processes
//' Author       : Mel Llesol
//' Created      : 01/6/2020
//' Last Update  : 04/20/2020
//'****************************************************************************


package autolayer.testawa.baird;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import pagelayer.testawa.baird.*;
import guilayer.testawa.baird.*;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import org.openqa.selenium.Alert;
import java.time.format.DateTimeFormatter;
import java.time.format.FormatStyle;


public class TestPMMA extends TestProcessor {
	WebElement testelement;
	WebDriver driver;
	static ExtentTest test;
	static ExtentReports report;
    Alert alert;
    Boolean approvalRun;
    LocalDate date = LocalDate.now();
    String originalWindow;
    
		
	
	//runs the non-Envestnet process, reads JSON data and executes web elements 
	public void runFlow(String account, String program, String flow, String wrap, String type, String stub, WebDriver driver, ExtentTest testRun, ExtentReports reportRun) {	
		

		this.driver = driver;
		test = testRun;
		report = reportRun;
		String accountRun = account;
		String regacctRun = null;
		String programRun = program;
		String flowRun = flow;
		String typeRun = type;
		String stubRun = stub;
		String envestURL = "http://uatworkflow/lfserver/awa?ENV_ID="+stubRun;
		String wrapRun = wrap;
		String formattedDate = date.format(DateTimeFormatter.ofLocalizedDate(FormatStyle.SHORT));
		List<Integer>programReasonList=new ArrayList<Integer>();
		
	try {	 
		
	if (!(wrapRun.equals("CSM") || wrapRun.equals("UMA") || wrapRun.equals("UMC")) ) {
		driver.manage().window().maximize(); 
		driver.get("http://uatworkflow");
		test.log(LogStatus.PASS, "http://uatworkflow accessed");
		
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.findElement(By.linkText("Fee Based")).click();
		test.log(LogStatus.PASS, "Fee Based link clicked");
		  
		originalWindow = driver.getWindowHandle();
		
		driver.manage().window().maximize(); 
		driver.findElement(By.linkText("Advisory Workflow Application (AWA)")).click();
   	    driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
   	 	driver.manage().window().maximize();
			
	    Set <String> WinHandles = driver.getWindowHandles();
		   
		    while (!driver.getTitle().contains("AWA Start Form")) {
		        for (String handle: WinHandles) {
		       
		           	driver.switchTo().window(handle);
		    	  
	    
		        }
		    }

		    driver.manage().window().maximize();
	   	    WebElement create = driver.findElement(By.cssSelector("button[name=btnStart]"));
		    create.click();	

		
		
		test.log(LogStatus.PASS, "**PMMA Workflow selected **");
		driver.manage().window().maximize();
		testelement = TestAWAType.txtbox_AccountNum(driver);
		TestAWAType.txtbox_AccountNum(driver).sendKeys(accountRun);
		test.log(LogStatus.PASS, "Account number found "+accountRun);	
			
	
	    TestAWAType.form_Type(driver).click();
	    test.log(LogStatus.PASS, "Checkpoint: Frame clicked");
		    
		Select dropSol= new Select (TestAWAType.drop_Solution(driver));
		dropSol.selectByVisibleText(flowRun);
		test.log(LogStatus.PASS, flowRun+" selected");
	
		TestAWAType.button_ContinueType(driver).click();
		test.log(LogStatus.PASS, "Continue button clicked");
		
		
		
		if (wrapRun.equals("FIA") || wrapRun.equals("NPM")) {
			Select dropProg = new Select (TestAdvisoryProgram.drop_Program(driver));
			dropProg.selectByVisibleText("Advisory Choice");
		} else if (wrapRun.equals("SPS004")) {
			Select dropProg = new Select (TestAdvisoryProgram.drop_Program(driver));
			dropProg.selectByVisibleText("ALIGN Tactical");
			Select dropImp =  new Select (TestAdvisoryProgram.drop_ImpMethod(driver));
			dropImp.selectByIndex(1);
			test.log(LogStatus.PASS, programRun+" selected");
			
		} else if (wrapRun.equals("SPS100")) {
			Select dropProg = new Select (TestAdvisoryProgram.drop_Program(driver));
			dropProg.selectByVisibleText("ALIGN Custom Sleeves");
			Select dropRebalance = new Select (TestAdvisoryProgram.drop_RebalancingOption(driver));
			dropRebalance.selectByIndex(1);
		}  else if (typeRun.equals("BHH")) {
			Select dropProg = new Select (TestAdvisoryProgram.drop_Program(driver));
			dropProg.selectByVisibleText("Advisory Choice");
		
		}
		
		
		
		TestAdvisoryProgram.radio_Invest(driver).click();
		test.log(LogStatus.PASS, "Investment button selected");
			
		TestAdvisoryProgram.button_Continue(driver).click();
		test.log(LogStatus.PASS, "Continue button selected");
		
		if (wrapRun.equals("NGA")) {
			TestAdvisoryProgram.button_Continue(driver).click();
		}
	
		if (wrapRun.equals("SPS100")) {
			Select dropAssetClass = new Select (TestAlignCustom.drop_AssetClass(driver));
			dropAssetClass.selectByIndex(1);
			Select dropInvestmentSelection = new Select (TestAlignCustom.drop_InvestmentSelection(driver));
			dropInvestmentSelection.selectByIndex(1);
			TestAlignCustom.button_AddClass(driver).click();
			TestAlignCustom.text_AssetAllocation2(driver).sendKeys("98.000");
			TestAlignCustom.button_AlignCustomNext(driver).click();
						
		}
		
		driver.manage().window().maximize();
		test.log(LogStatus.PASS, "Window maximized");
		
		checkSuitability(driver, wrapRun, test, report, programReasonList);
		
		TestSuitability.button_PmmaNext(driver).click();
		test.log(LogStatus.PASS, "Next button clicked");
		
		if (wrapRun.equals("NGA")) {
			TestBairdNext.txtbox_ClientName(driver).sendKeys("Test NGA");
			TestBairdNext.txtbox_BirthDate(driver).sendKeys(formattedDate);
			TestBairdNext.txtbox_ServiceDate(driver).sendKeys(formattedDate);
			TestBairdNext.txtbox_AnnualFee(driver).sendKeys("500");
		    TestBairdNext.checkBox_ProfessionalSalaryGrowth(driver).click();
		    TestBairdNext.checkBox_NetworkOfAumClients(driver).click();
		    TestBairdNext.txtArea_BairdNextConsiderations(driver).sendKeys("business ownership");
		    TestBairdNext.checkbox_ExistingClientHeir(driver).click();
		    TestBairdNext.txtbox_StatementHHAccount(driver).sendKeys("100200100");
		    TestBairdNext.txtArea_OtherMeetClient(driver).sendKeys("test NGA");
				    TestBairdNext.button_Next(driver).click();
	
			
		} else if (!wrapRun.equals("NGA") && !typeRun.equals("ManualFee")) {
		TestAddSchedule.button_AddNewSchedule(driver).click();
		test.log(LogStatus.PASS, "Add New Schedule button clicked");
			
			Select dropTypeSched = new Select (TestAddSchedule.drop_TypeSchedule(driver));
			if (wrapRun.equals("SPS100")) {
			dropTypeSched.selectByVisibleText("Tiered");
			TestAddSchedule.text_HouseholdTier1(driver).sendKeys("1.00");
			TestAddSchedule.text_HouseholdTier2(driver).sendKeys("0.90");
			TestAddSchedule.text_HouseholdTier3(driver).sendKeys("0.80");
			TestAddSchedule.text_HouseholdTier4(driver).sendKeys("0.70");
			TestAddSchedule.text_HouseholdTier5(driver).sendKeys("0.60");
			TestAddSchedule.text_HouseholdTier6(driver).sendKeys("0.50");
			test.log(LogStatus.PASS, "Household Tier added");
			
			
			} else {
				dropTypeSched.selectByVisibleText("Breakpoint");
				test.log(LogStatus.PASS, "Breakpoint selected");
			
				TestAddSchedule.text_HouseholdTier1(driver).sendKeys("1.00");
				TestAddSchedule.text_HouseholdTier2(driver).sendKeys("1.00");
				TestAddSchedule.text_HouseholdTier3(driver).sendKeys("1.00");
				TestAddSchedule.text_HouseholdTier4(driver).sendKeys("1.00");
				TestAddSchedule.text_HouseholdTier5(driver).sendKeys("1.00");
				TestAddSchedule.text_HouseholdTier6(driver).sendKeys("1.00");
				test.log(LogStatus.PASS, "Household Tier added");
		         
			       
			
     	}		//closes NGA logic
			
		Select dropApplySched = new Select (TestAddSchedule.drop_ApplySchedule(driver));
		dropApplySched.selectByVisibleText("New Schedule 1");
		test.log(LogStatus.PASS, "New Schedule selected");
		
//	}		
		TestAddSchedule.button_NextHousehold(driver).click();
		test.log(LogStatus.PASS, "NextHousehold button clicked");
		
		if (wrapRun.equals("FIA")) {
		TestOtherInfo.CUSIPMutualFunds_RadioYes(driver).click();
		test.log(LogStatus.PASS, "CUSIP Mutual Funds' Yes radio button clicked");
			
		TestOtherInfo.CUSIPSecurities_RadioYes(driver).click();
		test.log(LogStatus.PASS, "CUSIP Securities' Yes radio button clicked");
			
		TestOtherInfo.CUSIPSymbol(driver).sendKeys("11112222");
		test.log(LogStatus.PASS, "CUSIP Symbol entered");
			
    	TestOtherInfo.CUSIPDate(driver).sendKeys(formattedDate);
		test.log(LogStatus.PASS, "CUSIP Date entered");
	
		
		TestOtherInfo.CUSIPSecurity(driver).sendKeys("aaaabbbb");
		test.log(LogStatus.PASS, "CUSIP Security Title entered");
		} else if (wrapRun.equals("UMC")) {
			TestOtherInfo.CUSIPMutualFunds_RadioNo(driver).click();
			TestOtherInfo.CUSIPSecurities_RadioNo(driver).click();
			
		} else {
			TestOtherInfo.proxyConfirm(driver).click();
			test.log(LogStatus.PASS, "Proxy Confirm clicked");
			
		        }
		
	} else if (typeRun.equals("ManualFee")) {
		TestAddSchedule.check_ManualFee(driver).click();
		test.log(LogStatus.PASS, "Manual Fee selected");
		Select dropAttachment = new Select (TestAddSchedule.drop_Attachment(driver));
		dropAttachment.selectByVisibleText("Tiered");
		test.log(LogStatus.PASS, "Tiered selected");
		Select dropApplySched = new Select (TestAddSchedule.drop_ApplySchedule(driver));
		dropApplySched.selectByVisibleText("Attachment");
		test.log(LogStatus.PASS, "Attachment selected");
		TestAddSchedule.button_NextHousehold(driver).click();
		test.log(LogStatus.PASS, "NextHousehold button clicked");
		TestOtherInfo.CUSIPSecurities_RadioNo(driver).click();
		test.log(LogStatus.PASS, "Securities No clicked");
		TestOtherInfo.CUSIPMutualFunds_RadioNo(driver).click();
		test.log(LogStatus.PASS, "Mutual Funds No clicked");
	
		
	  }
	
	}
	
	
	if (wrapRun.equals("CSM") || wrapRun.equals("UMA") || wrapRun.equals("UMC"))  {
		driver.get(envestURL);
		test.log(LogStatus.PASS, "**PMMA - Envestnet workflow ** "+envestURL);
		driver.manage().window().maximize();
		test.log(LogStatus.PASS, "Envestnet processed "+envestURL);
		
		originalWindow = driver.getWindowHandle();
		
		checkSuitability(driver, wrapRun, test, report, programReasonList);
		
		
		TestSuitability.button_PmmaNext(driver).click();
		test.log(LogStatus.PASS, "Next button clicked");
		
		
		TestAddSchedule.button_NextHousehold(driver).click();
		test.log(LogStatus.PASS, "NextHousehold button clicked");

		
		TestOtherInfo.proxyConfirm(driver).click();
		test.log(LogStatus.PASS, "Proxy Confirm clicked");
		
	}
	
		TestOtherInfo.otherinfoFinish(driver).click();
		test.log(LogStatus.PASS, "Finish button clicked");

		TestSubmission.button_UpdateHousehold(driver).click();
		test.log(LogStatus.PASS, "Update Billing Household button clicked");
		
		if (!typeRun.equals("BHH")) {
  		TestSubmission.checkbox_AddHousehold(driver).click();
		test.log(LogStatus.PASS, "Add billing household account checkbox clicked");
 	
		} else {
		
			if (TestSubmission.checkbox_AddHousehold(driver).isSelected()); {
		    test.log(LogStatus.PASS, "BHH Test: First billing household account checkbox clicked");
			}
			
			if (TestSubmission.checkbox_AddHousehold2(driver).isSelected()) {
			test.log(LogStatus.PASS, "BHH Test: Second billing household account checkbox clicked");
			}
				
		}
		
		TestSubmission.button_SaveMaintenance(driver).click();
		test.log(LogStatus.PASS, "Save maintenance button clicked");
		
		
		TestSubmission.button_SubmitAccount(driver).click();
		test.log(LogStatus.PASS, "Submit button clicked");
		
		
					
		if (isDialogPresent(driver)) {
			alert = driver.switchTo().alert();
			String alertMessage = alert.getText();
			test.log(LogStatus.WARNING,"There is no fee schedule and an alert has been flagged. Skipping approval process. Alert message>> "+alertMessage);
			alert.accept();
			approvalRun=false;
			
		} else {
			test.log(LogStatus.PASS,"No alert found for missing fee schedule");
			approvalRun=true;
		}
	
	if (approvalRun.equals(true)) {	
		if (!(wrapRun.equals("CSM") || wrapRun.equals("UMA") || wrapRun.equals("UMC")) ) {	
		TestClosePage.button_CloseWindow(driver).click();
		test.log(LogStatus.PASS, "Close window clicked");
		}
		driver.switchTo().window(originalWindow);
		
    	TestFAApproval tstFAApproval = new TestFAApproval();
		tstFAApproval.approveFA(accountRun, regacctRun, originalWindow, flowRun, true, driver, test, report, wrapRun, typeRun, programReasonList, programRun);
		test.log(LogStatus.PASS, "FA Approval done");
		
		TestWorkable tstworkable = new TestWorkable();
		tstworkable.approveFBAA(accountRun, test, report, driver);
		test.log(LogStatus.PASS, "Workable Approval Day 1 done");
		
		if (!typeRun.equals("ModelChange")) {
		TestHoldingQueue tstholdingqueue = new TestHoldingQueue();
		tstholdingqueue.approveHold(accountRun, driver); 
		test.log(LogStatus.PASS, "Holding Queue Approval Day 1 done");
			
		tstworkable.approveFBAA(accountRun, test, report, driver);
		test.log(LogStatus.PASS, "Workable Approval Day 2 done");
	                                     	}
		
	                     }
	
		
	} catch (Exception e) {
		
		
		if (e instanceof NullPointerException) {
			test.log(LogStatus.FAIL, "Missing element "+e.toString());
		} else {
			test.log(LogStatus.FAIL, e.toString());
		}
		
	  }
				
		  }
	
	private static boolean isDialogPresent(WebDriver driver) {
		try {
	          
	        	driver.switchTo().alert();
	            return true;
	        } catch (Exception e) {
	            
	            return false;
	        }
    }
	
	public void checkSuitability(WebDriver driver, String wrap, ExtentTest testRun, ExtentReports reportRun, List<Integer> programReasonRun) {
		String wrapRun = wrap;
		test = testRun;
		report = reportRun;
		List<Integer>programReasonList=new ArrayList<Integer>();
		programReasonList = programReasonRun;
		
		
		TestSuitability.check_PMMAProgramAttest(driver).click();
		test.log(LogStatus.PASS, "Suitability attestation check box clicked");
		
		
		TestCommon tstCommon = new TestCommon();
		
		System.out.println("PMMA Wraprun"+wrapRun);
		  
		  for (int i=1; i<6; i++ ) {
			
			  if (i==1) {
				  TestSuitability.check_PMMAProgramSuit1(driver).click();
				  test.log(LogStatus.PASS, "Program suitability reason 1 clicked");
			
				
				  if (tstCommon.checkProgramReason(i, wrapRun, driver, test, report) == true) {
					  
					 
					  programReasonList.add(Integer.valueOf(i));
					  
				  }
				  
				 
			  }else if (i==2) {
				 
				  TestSuitability.check_PMMAProgramSuit2(driver).click();
				  test.log(LogStatus.PASS, "Program suitability reason 2 clicked");
				  if (tstCommon.checkProgramReason(i, wrapRun, driver, test, report) == true) {
					  programReasonList.add(Integer.valueOf(i));
				  }
				  
			  
			  } else if (i==3) {
				  TestSuitability.check_PMMAProgramSuit3(driver).click();
				  test.log(LogStatus.PASS, "Program suitability reason 3 clicked");
				  if (tstCommon.checkProgramReason(i, wrapRun, driver, test, report) == true) {
					  programReasonList.add(Integer.valueOf(i));
				  }
			  } else if (i==4) {
				  TestSuitability.check_PMMAProgramSuit4(driver).click();
				  test.log(LogStatus.PASS, "Program suitability reason 4 clicked");
				  if (tstCommon.checkProgramReason(i, wrapRun, driver, test, report) == true) {
					  programReasonList.add(Integer.valueOf(i));
				  }
			  } else if (i==5) {
				  
				  TestSuitability.check_PMMAProgramSuit5(driver).click();
				  test.log(LogStatus.PASS, "Program suitability reason 5 clicked");
				  if (tstCommon.checkProgramReason(i, wrapRun, driver, test, report) == true) {
					  programReasonList.add(Integer.valueOf(i));
				  }	
				
		   }
			  
			  System.out.println("Traversing List...");  
			    for(Integer count:programReasonList){  
			        System.out.println(count);  
			    }  
		  }
	
			
		
	}
		
}
