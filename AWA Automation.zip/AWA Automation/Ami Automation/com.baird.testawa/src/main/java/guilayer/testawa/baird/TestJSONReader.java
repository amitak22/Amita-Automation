//'****************************************************************************
//' Description  : Logic to handles reading of JSON input/test parameters
//' Author       : Mel Llesol
//' Created      : 11/5/2019
//' Last Update  : 03/20/2020
//'****************************************************************************

package guilayer.testawa.baird;
import java.io.IOException;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import java.io.InputStream;
import java.io.Reader;
import java.io.InputStreamReader;

public class TestJSONReader extends TestProcessor {

	Integer count;
	String account;
	String wrapflow;
	String programflow;
	String typeflow;
	String stubflow;
	String regacctflow;

	
	//main JSON file reader logic
	public String readData (String testFlow, Integer count)  throws IOException  {
		
    
		try {
			JSONParser jsonParser = new JSONParser();
			InputStream is = this.getClass().getResourceAsStream("/TestData/TestData.json");
			Reader rd = new InputStreamReader (is, "UTF-8");
		    JSONObject jsonObject = (JSONObject) jsonParser.parse(rd);
			String counter = count.toString();
			JSONObject testList = (JSONObject)jsonObject.get(testFlow+counter);
			account = testList.get("account").toString();
			
			
	 	   }
			
			catch (ParseException e) {
            e.printStackTrace();
           
                                     }
		
		
		return account;
		                                                 
    }
	
	
	//reads the wrap element in JSON file
	public String readWrap (String testFlow, Integer count)  throws IOException  {
		
    
		try {
			JSONParser jsonParser =new JSONParser();
			InputStream is = this.getClass().getResourceAsStream("/TestData/TestData.json");
			Reader rd = new InputStreamReader (is, "UTF-8");
		    JSONObject jsonObject = (JSONObject) jsonParser.parse(rd);

			String counter = count.toString();
			JSONObject testList = (JSONObject)jsonObject.get(testFlow+counter);
			wrapflow = testList.get("wrap").toString();
			
			
	 	   }
			
			catch (ParseException e) {
            e.printStackTrace();
           
                                     }
		
		
		return wrapflow;
		                                                 
    }
	
	//reads the program element in JSON file
	public String readProgram (String testFlow, Integer count)  throws IOException  {
		
    
		try {
			
			JSONParser jsonParser =new JSONParser();
			InputStream is = this.getClass().getResourceAsStream("/TestData/TestData.json");
			Reader rd = new InputStreamReader (is, "UTF-8");
		    JSONObject jsonObject = (JSONObject) jsonParser.parse(rd);

			String counter = count.toString();
			JSONObject testList = (JSONObject)jsonObject.get(testFlow+counter);
			programflow = testList.get("program").toString();
			
			
	 	   }
			
			catch (ParseException e) {
            e.printStackTrace();
            
                                     }
		
		return programflow;
		                                                 
    }
	
	//reads the type element in JSON file
	public String readType (String testFlow, Integer count)  throws IOException  {
	
    
		try {
			JSONParser jsonParser =new JSONParser();
			InputStream is = this.getClass().getResourceAsStream("/TestData/TestData.json");
			Reader rd = new InputStreamReader (is, "UTF-8");
		    JSONObject jsonObject = (JSONObject) jsonParser.parse(rd);

			String counter = count.toString();
			JSONObject testList = (JSONObject)jsonObject.get(testFlow+counter);
			typeflow = testList.get("type").toString();
			
			
	 	   }
			
			catch (ParseException e) {
            e.printStackTrace();
            
                                     }
		
		return typeflow;
		                                                 
    }
	
	
	//reads the stub element in JSON file
	public String readStub (String testFlow, Integer count)  throws IOException  {
	
    
		try {
			JSONParser jsonParser =new JSONParser();
			InputStream is = this.getClass().getResourceAsStream("/TestData/TestData.json");
			Reader rd = new InputStreamReader (is, "UTF-8");
		    JSONObject jsonObject = (JSONObject) jsonParser.parse(rd);

			String counter = count.toString();
			JSONObject testList = (JSONObject)jsonObject.get(testFlow+counter);
			stubflow = testList.get("stub").toString();
			
			
	 	   }
			
			catch (ParseException e) {
            e.printStackTrace();
          
                                     }
		
		return stubflow;
		                                                 
    }
	
	//reads the regacct element in JSON file
	public String readRegAcct (String testFlow, Integer count)  throws IOException  {

    
		try {
			JSONParser jsonParser =new JSONParser();
			InputStream is = this.getClass().getResourceAsStream("/TestData/TestData.json");
			Reader rd = new InputStreamReader (is, "UTF-8");
		    JSONObject jsonObject = (JSONObject) jsonParser.parse(rd);

			String counter = count.toString();
			JSONObject testList = (JSONObject)jsonObject.get(testFlow+counter);
			regacctflow = testList.get("regaccount").toString();
			
			
	 	   }
			
			catch (ParseException e) {
            e.printStackTrace();
          
                                     }
		
		return regacctflow;
		                                                 
    }
	
	
		
    

}
