//'****************************************************************************
//' Description : Logic to check items being tested/for display in tablegrid
//' Author      : Mel Llesol
//' Created     : 11/5/2019
//' Last Update : 03/20/2020
//'****************************************************************************

package guilayer.testawa.baird;


public class TestItem extends TestMain {

	
	 Integer run;
	 String flow;
	 String startdatetime;
	 String enddatetime;
	 String status;
	 

	    //constructor method
	    public TestItem() {
	    }

	    //overloading method 
	    public TestItem(Integer run , String flow, String startdatetime, String enddatetime, String status) {
	        this.run  = run ;
	        this.flow = flow;
	        this.startdatetime = startdatetime;
	        this.enddatetime = enddatetime;
	        this.status = status;
	    }

	    //accessor method for run info
	    public Integer getRun () {
	        return run ;
	    }

	    //set method for run info
	    public void setRun (Integer run ) {
	        this.run  = run ;
	    }

	    //accessor method for flow info
	    public String getFlow() {
	        return flow;
	    }

	    //set method for flow info
	    public void setFlow (String flow) {
	        this.flow = flow;
	    }
	 
	    //accessor method for local date and time info
	    public String getStartLocalDateTime() {
	        return startdatetime;
	    }
	    
	    //set method for local date and time info
	    public void setStartLocalDateTime(String startdatetime) {
	        this.startdatetime = startdatetime;
	    }
	 
	    //accessor method for local date and time
	    public String getEndLocalDateTime() {
	        return enddatetime;
	    }
	    
	    //set method for local date and time
	    public void setEndLocalDateTime(String enddatetime) {
	        this.enddatetime = enddatetime;
	    }
	    
	    
	    //accessor method for status info
	    public String getStatus() {
	        return status;
	    }

	    //set method for status info
	    public void setStatus(String status) {
	        this.status = status;
	    }
	    
	
}
