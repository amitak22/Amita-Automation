
//'****************************************************************************
//' Description : Main GUI logic which handles workflow and test cases selection
//' Author      : Mel Llesol
//' Created     : 11/5/2019
//' Last Update : 03/20/2020
//'****************************************************************************

package guilayer.testawa.baird;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;

import java.util.HashMap;
import java.util.Random;
import javafx.scene.control.Button;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import javafx.scene.input.MouseEvent;
import javafx.event.EventHandler;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import java.time.LocalDateTime;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import javafx.concurrent.Task;
import io.github.bonigarcia.wdm.WebDriverManager;





public class TestMain extends Application {

	public String inputAccount;
	public String inputProgram;
	public String inputWorkflow;
	public String inputStatus;
	public String inputDriverPath;
	public Boolean interruptStatus;
	TableView<TestItem> tableview;
    public Integer addCount = 0;
	public Integer runCount = 0;
	public Integer stopCount = 0;
	String StartDateTimeValue = null;
	String EndDateTimeValue = null;
	WebDriver driver;
	static ExtentTest testExtent;
	static ExtentReports reportExtent;
	Task<Void> task;
	//String testURL;


	public static void main(String[] args) {
			
		launch(args);
	}

	public void start(Stage stage)
    {
		
		WebDriverManager.chromedriver().setup();
	
		
		ChromeOptions chromeOptions = new ChromeOptions();
		//setting visible run
        chromeOptions.setHeadless(false);
        
        HashMap<String, Object> chromeOptionsMap = new HashMap<String, Object>();
        chromeOptionsMap.put("plugins.plugins_disabled", new String[] {
                "Chrome PDF Viewer"
        });
        chromeOptionsMap.put("plugins.always_open_pdf_externally", true);
        chromeOptions.setExperimentalOption("prefs", chromeOptionsMap);

        String downloadFilepath = System.getProperty("user.home");
        chromeOptionsMap.put("download.default_directory", downloadFilepath);

       
     
		//creates tablegrid to display test items
		tableview = new TableView<>();
		
		TableColumn<TestItem, Integer> runColumn = new TableColumn<TestItem, Integer>("Run");
		runColumn.setCellValueFactory(new PropertyValueFactory<>("Run"));
		
		TableColumn<TestItem, String> flowColumn = new TableColumn<TestItem, String>("Flow");
        flowColumn.setCellValueFactory(new PropertyValueFactory<>("Flow"));
        
        TableColumn<TestItem, String> startColumn = new TableColumn<TestItem, String>("Start DateTime");
        startColumn.setCellValueFactory(new PropertyValueFactory<>("StartLocalDateTime"));
        
        TableColumn<TestItem, String> endColumn = new TableColumn<TestItem, String>("End DateTime");
        endColumn.setCellValueFactory(new PropertyValueFactory<>("EndLocalDateTime"));
                
        TableColumn<TestItem, String> statusColumn = new TableColumn<TestItem, String>("Status");
        statusColumn.setCellValueFactory(new PropertyValueFactory<>("Status"));


         flowColumn.setMinWidth(200);
         startColumn.setMinWidth(200);
         endColumn.setMinWidth(200);
         
         //add columns to the table
         tableview.getColumns().add(runColumn);
         tableview.getColumns().add(flowColumn);
         tableview.getColumns().add(startColumn);
         tableview.getColumns().add(endColumn);
         tableview.getColumns().add(statusColumn);
         
           
         //Add label and choicebox
         Label testLbl = new Label("Workflow:");
         
         ChoiceBox<String> test = new ChoiceBox<>();
 
        
         // Add the items to the ChoiceBox
         test.getItems().addAll("Reg-Open Advisory Account", "Reg-Registration Change", "Reg-Program/Manager/Model/Allocation Change", "Reg-Fee Schedule Change Only","Reg-Terminate Advisory Account", "Stage-Open Advisory Account");

                  
         // Display controls in a GridPane
         GridPane root = new GridPane();
       
         // Set the spacing between columns and rows
         root.setVgap(20);
         root.setHgap(10);
       

          // Add the Labels and the ChoiceBox to the GridPane
       
          Button addButton = new Button ("Add to Test");
          Button runButton = new Button("Run Test");
          Button stopButton = new Button("Stop Test");
  
     
          //Add to root view
          root.add(testLbl, 0, 1);
          root.add(test, 0, 2);
          root.add(addButton, 0, 3);
          root.add(runButton, 0, 4);
          root.add(tableview, 0, 5);
     
       
         
          // Set the Size of the GridPane
          root.setMinSize(450, 550);
         
        /* 
         * Set the padding of the GridPane
         * Set the border-style of the GridPane
         * Set the border-width of the GridPane
         * Set the border-insets of the GridPane
         * Set the border-radius of the GridPane
         * Set the border-color of the GridPane
        */     
        root.setStyle("-fx-padding: 10;" +
                "-fx-border-style: solid inside;" +
                "-fx-border-width: 7;" +
                "-fx-border-insets: 5;" +
                "-fx-border-radius: 5;" +
                "-fx-border-color: gray;");
       
        
        
        // Create the Scene
        Scene scene = new Scene(root);
        
        stage.setResizable(false);
   
        // Add the scene to the Stage
        stage.setScene(scene);
        // Set the title of the Stage
        stage.setTitle("Test AWA v1.0");
        // Display the Stage
        stage.show();   
        
        //Add workflow logic
        addButton.setOnMouseClicked((new EventHandler<MouseEvent>() { 
        	
        
            public void handle(MouseEvent event) { 
        
            
            	inputWorkflow = test.getValue();
               	inputStatus = "";
            	
            
            	ObservableList<TestItem> itemMembers = getitemMembers(addCount, inputWorkflow, StartDateTimeValue, EndDateTimeValue, inputStatus);
            	tableview.getItems().addAll(addCount, itemMembers);
           
           	  
                          	
            
            	addCount++;
            	                            
                                                                     }
            
        }         )); 
                                                 
        
         //Run workflows queued
         runButton.setOnMouseClicked((new EventHandler<MouseEvent>() { 
        	
        	
          public void handle(MouseEvent event) { 
            	addButton.setDisable(true);
                driver = new ChromeDriver(chromeOptions);
           
            	
            	StartDateTimeValue = LocalDateTime.now().toString();
            	EndDateTimeValue = "";
            	inputStatus="Running";
                inputDriverPath = System.getProperty("user.home");
        
                
                String currentFlowRun = tableview.getColumns().get(1).getCellObservableValue(runCount).getValue().toString();
                TestItem updatedMembers = new TestItem (runCount, currentFlowRun, StartDateTimeValue, EndDateTimeValue, inputStatus);
                tableview.getItems().set(runCount, updatedMembers);
             
              
                Random rnd = new Random();
                int random = rnd.nextInt(1000000);
                String filename = "\\"+"\\"+"ExtentReportResults-"+random+".html";
              
           
        	       reportExtent = new ExtentReports(System.getProperty("user.home")+filename);
                   testExtent = reportExtent.startTest("ExtentReport","AWA Run");
        
                
            
                    task = new Task<Void>() {
                	@Override
                	protected Void call () {
                     while (runCount<tableview.getItems().size() || task !=null) 	{ 	  
                        try {
                           		String currentFlowRun = tableview.getColumns().get(1).getCellObservableValue(runCount).getValue().toString();
                              
                             	 TestProcessor tstAWA = new TestProcessor();
                            	
                            
            
                         	   if (runCount>0) {
                             	  StartDateTimeValue = LocalDateTime.now().toString();
                             	 inputStatus="Running";
                             	EndDateTimeValue="";
                             	TestItem updatedMembers = new TestItem (runCount, currentFlowRun, StartDateTimeValue, EndDateTimeValue, inputStatus);
                                tableview.getItems().set(runCount, updatedMembers);
                                tableview.refresh();  
                                               }
                         	   
                        
                                  tstAWA.runFlow(currentFlowRun, inputDriverPath, driver, reportExtent, testExtent);
                                  EndDateTimeValue = LocalDateTime.now().toString();
                             	   String inputStatus="Completed";
                                  
                                  inputStatus = "Completed";
                
                               
                                  TestItem updatedMembers = new TestItem (runCount, currentFlowRun, StartDateTimeValue, EndDateTimeValue, inputStatus);
                                  tableview.getItems().set(runCount, updatedMembers);
                                  runCount++;
                         	      tableview.refresh();
                      
                         	     
                         	     
                             	 } catch (Exception e) {
                             		inputStatus = "Failed";	
                             		 tableview.getItems().set(runCount, updatedMembers);
                                 	  runCount++;
           
                             		
                             	 }
                       
                  
                          
                    	   closeReport();
                               }
                          	  
                           
               	           
               	              driver.quit();
                          	  return null;
                          
                                     }
                            };
                            
              
                            
                            Thread thread = new Thread(task);
                            thread.setDaemon(true);
                            thread.start();
                            
     
                          	  
                                    
                           }
                         
            
               })); 
         
         
         //stop Button logic to be added
         stopButton.setOnMouseClicked((new EventHandler<MouseEvent>() { 
        	 
        	  public void handle(MouseEvent event) { 
        		  task.cancel();
        		  task = null;
        		  
        		  
        		  if (runCount>0) {
        		  EndDateTimeValue = LocalDateTime.now().toString(); 	  
        		  inputStatus = "Stopped";
        		  String currentFlowRun = tableview.getColumns().get(1).getCellObservableValue(runCount).getValue().toString();
        		  TestItem runMembers = new TestItem (runCount, currentFlowRun, StartDateTimeValue, EndDateTimeValue, inputStatus);
                  tableview.getItems().set(runCount, runMembers);
        		  } else {
        			  while (stopCount<tableview.getItems().size())	{ 	
        				  
        				  EndDateTimeValue = LocalDateTime.now().toString(); 	  
                		  inputStatus = "Stopped";
                		  String currentFlowRun = tableview.getColumns().get(1).getCellObservableValue(stopCount).getValue().toString();
                		  TestItem runMembers = new TestItem (stopCount, currentFlowRun, StartDateTimeValue, EndDateTimeValue, inputStatus);
                          tableview.getItems().set(stopCount, runMembers);
        				  
        			  }
        			  
        		  }
        		  
        	  }
                           
         }));

  }
	
	public ObservableList<TestItem> getitemMembers(Integer run, String workflow, String begindatetimeinput, String enddatetimeinput, String inputRunStatus) {
		Integer runCount = run;
		String inputWork = workflow;
		String StartDateTimeValue = begindatetimeinput;
		String EndDateTimeValue = enddatetimeinput;
		String inputStatus = inputRunStatus;
		ObservableList<TestItem> itemMembers = FXCollections.<TestItem>observableArrayList();
		TestItem member = new TestItem(runCount,inputWork, StartDateTimeValue, EndDateTimeValue, inputStatus);
		itemMembers.add(member);
			
		return itemMembers;
		
	}
	
	public static void closeReport() {
    	reportExtent.endTest(testExtent);
    	reportExtent.flush();
    	 
     }
	
  
}
