//'***************************************************************************************
//' Description : Processor logic - handles workflows selected from GUI interface/program
//' Author      : Mel Llesol
//' Created     : 11/5/2019
//' Last Update : 04/17/2020
//'***************************************************************************************



package guilayer.testawa.baird;

import java.util.Set;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import autolayer.testawa.baird.*;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.Alert;
import java.io.File;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.chrome.ChromeDriver;



public class TestProcessor extends TestMain{
	
	public String accountRun;
	public String regaccountRun;
	public String programRun;
	public String wrapRun;
	public String flowRun;
	public String typeRun;
	public String stubRun;
	public String choiceRun;
	public String driverRunPath;
	public Boolean runSuccess;
	public Boolean responseReset;
	public Boolean responseOptOut;
	public Boolean stageTest;
	static ExtentTest test;
	static ExtentReports report;
	TestJSONReader tstJSONReader;
	WebDriver driver;
	String testURL;
	
	
	
	
	

	//main logic to process the workflows queued in GUI
	public void runFlow(String choice, String driverPath, WebDriver driver, ExtentReports reportRun, ExtentTest testRun) {
	    this.driver = driver; 
		choiceRun = choice;
		driverRunPath = driverPath;
		test = testRun;
		report = reportRun;
		testURL="http://uatworkflow";
		stageTest=false;
		
	
		
	   
		
	    //logic to handle the different workflow
	    switch (choiceRun) {
	    
			
	        //TestPMMA01 handles non-Envestnet, TestPMMA02 handles Envestnet    
	        case "Reg-Program/Manager/Model/Allocation Change" :
      	   
	        	flowRun="Program/Manager/Model/Allocation Change";
	          	TestPMMA tstpmma = new TestPMMA();
	       		tstJSONReader = new TestJSONReader();
        		
			
	       		
	       		driver.get("http://uatworkflow");
    		    driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
    			driver.findElement(By.linkText("Fee Based")).click();
    			driver.manage().window().maximize();
    			String currentPMMAWindow = driver.getWindowHandle();
        		
			
        		
			    try {
				
			    killSubsession (flowRun); 
				driver.close();
				driver.switchTo().window(currentPMMAWindow);
				
			    } catch (Exception e) {
			    	driver.close();
					driver.switchTo().window(currentPMMAWindow);
			    	
			    }
	       		
	       		
	       				
        		
        		
        		try {
        			        		
        			
	        	    Integer count = 1;
	        	    while (tstJSONReader.readData(flowRun, count)!=null) {
	        
	        		
	        	    readJSON(count);
	        	   
	        		resetAccount(accountRun);
	        			        		
    	    		if (responseReset == true) {
    	    			test.log(LogStatus.PASS, "Account Reset successful");
    	    		} else {
    	    			test.log(LogStatus.FAIL, "Account Reset failed");
    	    		}
	        		
    	    		optOutAccount (accountRun);
    	    		
    	    		if (responseOptOut == true) {
    	    			test.log(LogStatus.PASS, "Account Optout to False is successful");
    	    		} else {
    	    			test.log(LogStatus.FAIL, "Account Optout failed");
    	    		}
    	    		
    	    			
	        		
	        		try {
	        		//	if (!(wrapRun.equals("CSM") || wrapRun.equals("UMA") || wrapRun.equals("UMC")) ) {
	        		//	tstpmma01.runFlow(accountRun, programRun, flowRun, wrapRun, typeRun, driver, test, report);
	        		//    count++;
	        		//	}else {
	        				tstpmma.runFlow(accountRun,  programRun, flowRun, wrapRun, typeRun, stubRun, driver, test, report);
	        				count++;
	        				
	        			//}
	        		}
	        		catch (Exception e) {
	        			count++;
	        			continue;
	        		}
	        	
	        	   
	        	    }  
	        	 
        		}	
	        	                                                    
	        	catch (Exception e) {
	        		   		
	        		test.log(LogStatus.PASS, "Test case done"); 	
	    	                      }
	        	  
	    	     
	    	      
	        break;
	        
	        
	        //TestRegChange01 handles both non-Envestnet and Envestnet
	        case "Reg-Registration Change" :
	      	        flowRun = "Registration Change";
		        	
		          	TestRegChange tstregchange = new TestRegChange();
	        		tstJSONReader = new TestJSONReader();
	        		
			        		
	        	
	        		driver.get("http://uatworkflow");
	    		    driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	    			driver.findElement(By.linkText("Fee Based")).click();
	    			driver.manage().window().maximize();
	    			String currentRegChgWindow = driver.getWindowHandle();
	        		
				
	        		
				    try {
					
				    killSubsession (flowRun); 
					driver.close();
					driver.switchTo().window(currentRegChgWindow);
					
				    } catch (Exception e) {
				    	driver.close();
						driver.switchTo().window(currentRegChgWindow);
				    	
				    }
	        		
	        		
	        		try {
	        		
		        	    Integer count = 1;
		        	    while (tstJSONReader.readData(flowRun, count)!=null) {
		        
		        		readJSON(count);
		        		
		        		resetAccount(accountRun);
		        		resetAccount(regaccountRun);
		        		
        	    		if (responseReset == true) {
        	    			test.log(LogStatus.PASS, "Account Reset successful");
        	    		} else {
        	    			test.log(LogStatus.FAIL, "Account Reset failed");
        	    		}
        	    		
        	    		
        	    		optOutAccount (accountRun);
        	    		optOutAccount (regaccountRun);
        	    		
        	    		if (responseOptOut == true) {
        	    			test.log(LogStatus.PASS, "Account Optout to False is successful");
        	    		} else {
        	    			test.log(LogStatus.FAIL, "Account Optout failed");
        	    		}
		        		
		        		 
		        		try {
		        			tstregchange.runFlow(accountRun, regaccountRun, programRun, flowRun, wrapRun, typeRun, driver, test, report);
		        		count++;
		        		}
		        		catch (Exception e) {
		        			count++;
		        			continue;
		        			
		        		}
		        	
		        	   
		        	    }  
		        	 
	        		}	
		        	                                                    
		        	catch (Exception e) {
		        		test.log(LogStatus.PASS, "Test case done"); 	  			
		        		
		    	                      }
		        	  
		    	     
		    	      
		        break;
	        
	        
	      	//TestFeeChange01 handles non-Envestnet, TestFeeChange02 handles Envestnet       
	        case "Reg-Fee Schedule Change Only" :
	        	flowRun = "Fee Schedule Change Only";
	        	
	          	TestFeeChange tstFeeChange = new TestFeeChange();
	          	tstJSONReader = new TestJSONReader();
        		
			
        	
				driver.get("http://uatworkflow");
    		    driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
    			driver.findElement(By.linkText("Fee Based")).click();
    			driver.manage().window().maximize();
    			String currentFeeChgWindow = driver.getWindowHandle();
        		
			
        		
			    try {
				
			    killSubsession (flowRun); 
				driver.close();
				driver.switchTo().window(currentFeeChgWindow);
				
			    } catch (Exception e) {
			    	driver.close();
					driver.switchTo().window(currentFeeChgWindow);
			    	
			    }
        		
				
        		
        		try {
        			
	        	    Integer count = 1;
	        	    while (tstJSONReader.readData(flowRun, count)!=null) {
	        	    	
	        	    	try {
	        	    		readJSON(count);
	        	    		resetAccount(accountRun);
	        	    		if (responseReset == true) {
	        	    			test.log(LogStatus.PASS, "Account Reset successful");
	        	    		} else {
	        	    			test.log(LogStatus.FAIL, "Account Reset failed");
	        	    		}
	        	    		
	        	    		optOutAccount (accountRun);
	        	    		
	        	    		if (responseOptOut == true) {
	        	    			test.log(LogStatus.PASS, "Account Optout to False is successful");
	        	    		} else {
	        	    			test.log(LogStatus.FAIL, "Account Optout failed");
	        	    		}
	        	    		
	        	    	}catch (Exception e) {
	        	    		continue;
	        	    	}
	        
	        		try {
	        			
        		//	if (!(wrapRun.equals("CSM") || wrapRun.equals("UMA")) ) {	
        		 
	        	//	tstFeeChange01.runFlow(accountRun, programRun, flowRun, wrapRun, driver, test, report, typeRun);
	        	//	count++;
        		//	} else {
        			
    	        		tstFeeChange.runFlow(accountRun, programRun, flowRun, wrapRun, typeRun, stubRun, driver, test, report);
    	        		count++;
        		//	}
        				
	        		                                                     
	        		}
	        		catch (Exception e) {
	        			count++;
	        			continue;
	        		}
	        	
	        	   
	        	    }  
	        	 
        		}	
	        	                                                    
	        	catch (Exception e) {
	        		test.log(LogStatus.PASS, "Test case done"); 	
	        		
	    	                      }
                                                    	        	      
	        	 
	        	 
	        	 break;
	        	 
	        //TestTerm01 handles non-Envestnet, TestTerm02 handles non-Envesnet	 
	        case "Reg-Terminate Advisory Account" :
	        	flowRun="Terminate Advisory Account"; 
	        	
	          	TestTerm tstTerm = new TestTerm();
	        	//TestTerm02 tstTerm02 = new TestTerm02();
        		tstJSONReader = new TestJSONReader();
        		
			        		
				driver.get("http://uatworkflow");
    		    driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
    			driver.findElement(By.linkText("Fee Based")).click();
    			driver.manage().window().maximize();
    			String currentTermWindow = driver.getWindowHandle();
        		
			
        		
			    try {
				
			    killSubsession (flowRun); 
				driver.close();
				driver.switchTo().window(currentTermWindow);
				
			    } catch (Exception e) {
			    	driver.close();
					driver.switchTo().window(currentTermWindow);
			    	
			    }
        		
        		
        		try {
        			
	        	    Integer count = 1;
	        	    while (tstJSONReader.readData(flowRun, count)!=null) {
	        	    	
	        	    	
	        	    	
	        	    	try {
	        	    		readJSON(count);
	        	    		resetAccount(accountRun);
	        	    		if (responseReset == true) {
	        	    			test.log(LogStatus.PASS, "Account Reset successful");
	        	    		} else {
	        	    			test.log(LogStatus.FAIL, "Account Reset failed");
	        	    		}
	        	    		
	        	    		optOutAccount (accountRun);
	        	    		
	        	    		if (responseOptOut == true) {
	        	    			test.log(LogStatus.PASS, "Account Optout to False is successful");
	        	    		} else {
	        	    			test.log(LogStatus.FAIL, "Account Optout failed");
	        	    		}
	        	    		
	        	    		
	        	    	}catch (Exception e) {
	        	    		continue;
	        	    	}
	        	    	
	        	    	
	        
	        		try {
	        			
        			//if (!(wrapRun.equals("CSM") || wrapRun.equals("UMA")) ) {	
        		        
        		//		tstTerm01.runFlow(accountRun, programRun, flowRun, wrapRun, driver, test, report, typeRun);
	        	//	count++;
        		//	} else {
        			
        				tstTerm.runFlow(accountRun, programRun, flowRun, wrapRun, typeRun, stubRun, driver, test, report);
    	        		count++;
        		//	}
        				
	        		                                                     
	        		}
	        		catch (Exception e) {
	        			count++;
	        			continue;
	        		}
	        	
	        	   
	        	    }  
	        	 
        		}	
	        	                                                    
	        	catch (Exception e) {
	        		test.log(LogStatus.PASS, "Test case done");  	 	
	        		
	    	                      }
                                                    	        	      
	        	 
	        	 
	        	 break;	 
	        	 
	        	 
	        //TestOpenAdvisory01 handles non-Envestnet, TestOpenAdvisory02 handles Envestnet	 
	        case "Reg-Open Advisory Account" :
	        	 
	        	flowRun = "Open Advisory Account";
	          	TestOpenAdvisory tstopenflow = new TestOpenAdvisory();
	      
	          	
        		tstJSONReader = new TestJSONReader();
        		
        		driver.get("http://uatworkflow");
    		    driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
    			driver.findElement(By.linkText("Fee Based")).click();
    			driver.manage().window().maximize();
    			String currentOpenWindow = driver.getWindowHandle();
        		
			        		
			    try {
				
			    killSubsession (flowRun); 
				driver.close();
				driver.switchTo().window(currentOpenWindow);
				
			    } catch (Exception e) {
			    	driver.close();
					driver.switchTo().window(currentOpenWindow);
			    	
			    }
				
			  
			  
			 
             
        	        		
        		try {
        			
	        	    Integer count = 1;
	        	    while (tstJSONReader.readData(flowRun, count)!=null) {
	        	    	readJSON(count);
	        	   try {	
	        	    	resetAccount(accountRun);
        	    		if (responseReset == true) {
        	    			test.log(LogStatus.PASS, "Account Reset successful");
        	    		} else {
        	    			test.log(LogStatus.FAIL, "Account Reset failed");
        	    		}
	        	     } catch (Exception e) {
	        	  	 test.log(LogStatus.WARNING, "Account reset skipped");
	        	     }
	        	     
	        	     
        	    	try {
        	    		
        	    	
        	    		optOutAccount (accountRun);
        	    		
        	    		if (responseOptOut == true) {
        	    			test.log(LogStatus.PASS, "Account Optout to False is successful");
        	    		} else {
        	    			test.log(LogStatus.FAIL, "Account Optout failed");
        	    		}
        	    		
        	    	} catch (Exception e) {
        	    		test.log(LogStatus.WARNING, "Account opt out skipped");
        	   	}
        	    		
	        	    	
	        		try {
	        			
	        		//	if (!(wrapRun.equals("CSM") || wrapRun.equals("UMA")) ) {
	        			   	
	        			
	        			//   tstopenflow.runFlow(accountRun, programRun, flowRun, wrapRun, typeRun, driver, test, report, stageTest);
	        		       count++;
	        		//	} else { 
	        				 
	        			   tstopenflow.runFlow(accountRun, programRun, flowRun, wrapRun, typeRun, stubRun, driver, test, report, stageTest);
		        	//	   count++;
	        				
	        				
	        		//	  }
	        				
	        		    }
	        		catch (Exception e) {
	        			count++;
	        			continue;
	        		                    }
	        	
	        	   
	        	    }  
	        	 
        		}	
	        	                                                    
	        	catch (Exception e) {
	        		test.log(LogStatus.PASS, "Test case done"); 		   			
	        		
	    	                      }
                                                    	        	      
	        	 
	        	
	        	 break;
	        	 
	        case "Stage-Open Advisory Account" :
	        	 
	        	flowRun = "Stage-Open Advisory Account";
	        	stageTest = true;
	          	TestOpenAdvisory tstopenStageFlow = new TestOpenAdvisory();
	          //	TestOpenAdvisory02 tstopenStageFlow2 = new TestOpenAdvisory02();
	          	
        		tstJSONReader = new TestJSONReader();
        		
        		try {
        			killSubsession (flowRun);
        		} catch (Exception e) {
        			test.log(LogStatus.WARNING, "Kill subsession skipped");
        		}
        		
        	        		
        		try {
        			
	        	    Integer count = 1;
	        	    while (tstJSONReader.readData(flowRun, count)!=null) {
	        	    	readJSON(count);
	        	    	resetAccount(accountRun);
        	    		if (responseReset == true) {
        	    			test.log(LogStatus.PASS, "Account Reset successful");
        	    		} else {
        	    			test.log(LogStatus.FAIL, "Account Reset failed");
        	    		}
        	    		
        	    		optOutAccount (accountRun);
        	    		
        	    		if (responseOptOut == true) {
        	    			test.log(LogStatus.PASS, "Account Optout to False is successful");
        	    		} else {
        	    			test.log(LogStatus.FAIL, "Account Optout failed");
        	    		}
	        	    	
	        		try {
	        			
	        		//	if (!(wrapRun.equals("CSM") || wrapRun.equals("UMA")) ) {
	        			   	
	        			
	        			   tstopenStageFlow.runFlow(accountRun, programRun, flowRun, wrapRun, typeRun, stubRun, driver, test, report, stageTest);
	        		       count++;
	        		//	} else { 
	        				 
	        		//	   tstopenStageFlow2.runFlow(accountRun, programRun, flowRun, wrapRun, typeRun, stubRun, driver, test, report, stageTest);
		        	//	   count++;
	        				
	        				
	        		//	}
	        				
	        		    }
	        		catch (Exception e) {
	        			count++;
	        			continue;
	        		                    }
	        	
	        	   
	        	    }  
	        	 
        		}	
	        	                                                    
	        	catch (Exception e) {
	        		test.log(LogStatus.PASS, "Test case done"); 		   			
	        		
	    	                      }
                                                    	        	      
	        	 
	        	
	        	 break; 	 
	        	 
	        	 
	        	 
	                       }
    
	    
	   
	    
	}
	
  
	   
	   public void readJSON (Integer count) {
		   
	       try {
	          
          
   		       accountRun = tstJSONReader.readData(flowRun, count);
   		       programRun = tstJSONReader.readProgram(flowRun, count);
   		       wrapRun = tstJSONReader.readWrap(flowRun, count);
   		       typeRun = tstJSONReader.readType(flowRun, count);
   		       stubRun = tstJSONReader.readStub(flowRun, count);
   		      
   		
   		    if (flowRun.equals("Registration Change")) {
   			
   	           regaccountRun = tstJSONReader.readRegAcct(flowRun, count);
   			
   	   	    }
   		 
	  }
   		  catch (Exception e) {
   			  test.log(LogStatus.WARNING, "Nothing to read from JSON data");  
   			  
   		  }
		   
	   }
	   
	   
	   //reset account logic
	   public boolean resetAccount (String account) {
		 
		   String accountReset = account;
		   
		   driver.get("http://uatadvisoryprogram.rwbaird.com/TestData/swagger/ui/index#!/BetaTestData/BetaTestData_SetBetaInformationFromWarehouse");
		   driver.manage().window().maximize();
			
					
			WebDriverWait wait = new WebDriverWait (driver, 20);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='BetaTestData_BetaTestData_SetBetaInformationFromWarehouse_content']/form/table/tbody/tr/td[2]/input"))).clear();
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='BetaTestData_BetaTestData_SetBetaInformationFromWarehouse_content']/form/table/tbody/tr/td[2]/input"))).sendKeys(accountReset);
			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='BetaTestData_BetaTestData_SetBetaInformationFromWarehouse_content']/form/div[2]/input"))).click();
			String element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='BetaTestData_BetaTestData_SetBetaInformationFromWarehouse_content']/div[2]/div[3]/pre"))).getAttribute("textContent");
			
			if (element.equals ("200")) {
				responseReset = true;
				
			} else {
				responseReset = false;
				
			}
		   
		   
		   
		   return responseReset;
		
	   }
	   
	   public boolean optOutAccount (String account) {
		   String accountOptOut = account;
		   driver.get("http://uatadvisoryprogram.rwbaird.com/TestData/swagger/ui/index#!/BairdTestData/BairdTestData_SetAccountOptOutFlag");
		   driver.navigate().refresh();
		   driver.manage().window().maximize();
		   
		   WebDriverWait wait = new WebDriverWait (driver, 20);
		   wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='BairdTestData_BairdTestData_SetAccountOptOutFlag_content']/form/table/tbody/tr[1]/td[2]/input"))).clear();
		   wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='BairdTestData_BairdTestData_SetAccountOptOutFlag_content']/form/table/tbody/tr[1]/td[2]/input"))).sendKeys(accountOptOut);
		   Select dropOptOut = new Select (driver.findElement(By.xpath("//*[@id='BairdTestData_BairdTestData_SetAccountOptOutFlag_content']/form/table/tbody/tr[2]/td[2]/select")));
		   dropOptOut.selectByVisibleText("false");
		   wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='BairdTestData_BairdTestData_SetAccountOptOutFlag_content']/form/div[2]/input"))).click();
		   		
		   String element = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='BairdTestData_BairdTestData_SetAccountOptOutFlag_content']/div[2]/div[3]/pre"))).getAttribute("textContent");
			
			if (element.equals ("200")) {
				responseOptOut = true;
				
			} else {
				responseOptOut = false;
				
			}
		   
		   
		   return responseOptOut;
		   
	   }
	   
	   public void killSubsession (String flowRun) {
		   
		   String flowKillSession = flowRun;
		   
		   
		 	driver.findElement(By.linkText("Kill AWA Subprocesses By Account Number")).click();
		 	driver.manage().window().maximize();
		 	findWindow ("Kill AWA Subprocesses By Account Number");
		 	
		 	
		 	
		 	Integer killSessionCount = 1;
		 	
		 
		 	
	      try {
			 
    	    while (tstJSONReader.readData(flowKillSession, killSessionCount) != null ) {
    	    	String accountToKill = tstJSONReader.readData(flowKillSession, killSessionCount);
    	       	driver.findElement(By.xpath("//*[@id='accountNumbers']")).click();
    	    	driver.findElement(By.xpath("//*[@id='accountNumbers']")).sendKeys(accountToKill);
    	    	driver.findElement(By.xpath("//*[@id='accountNumbers']")).sendKeys(Keys.ENTER);
    		    killSessionCount++;
    		
    	    } 
    	    
	      } catch (Exception e) { 
	    	  System.out.println(e.toString());
	    	  
	      }
    	    
    	   WebDriverWait wait = new WebDriverWait (driver, 1);
    	   System.out.println("after wait");
    	   wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("button[id=btnFind]"))).click();
    	   System.out.println("after Find");
    	    
 		   WebElement textProcToKill = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='processesToKill']")));
    	   String textPresent = textProcToKill.getAttribute("value");
    	   System.out.println("after value");
 		  
 		   
 		   if (!textPresent.equals(null)) {
 			   driver.findElement((By.cssSelector("button[id=btnKill]"))).click();
 			  driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
 			   Alert alert = driver.switchTo().alert();
 			   alert.accept();
 			   
 		   }
    	    
    	
	   }
	   
	   
	   public void findWindow (String window) {
			
			 Set <String> WinHandles = driver.getWindowHandles();
			  
			  while (!driver.getTitle().contains(window)) {
			        for (String handle: WinHandles) {
			       
			          
			    	  	driver.switchTo().window(handle);
			    	  	
			    	  	
		  
			        }
			    }

			
		    }
	   
	   
	   public void takeSnapShot (WebDriver driver, String filePath) throws Exception {
		   TakesScreenshot scrShot =((TakesScreenshot)driver);
		   File SrcFile=scrShot.getScreenshotAs(OutputType.FILE);
		   File DestFile=new File(filePath);
		   FileUtils.copyFile(SrcFile, DestFile);

		   
	    	 
	     }
	   
	   
	   public String convertAccount (String account) {
			String accountConvert = account;
			
			char [] charAcct = new char [4];
			
			for (int i=0; i<4; i++) {
				charAcct[i] = accountConvert.charAt(i);
				
			}
			
			String leftaccount = new String (charAcct);
			
			
			
			for (int i=4; i<8; i++) {
				charAcct[i-4] = accountConvert.charAt(i);
				
			}
			
			String rightaccount = new String (charAcct);
			
			String finalAcct = leftaccount+"-"+rightaccount;
			

			return finalAcct;
			
		}
	   
	  


	
}

    